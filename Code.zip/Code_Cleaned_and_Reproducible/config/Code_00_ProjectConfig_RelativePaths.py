# -*- coding: utf-8 -*-
"""
Shared path configuration for the manuscript source-data and code package.

All paths are relative to the repository root. This avoids local machine paths and
allows the code package to be uploaded to a journal repository or run on another
computer after replacing the input data files.
"""
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = PROJECT_ROOT / "source_data"
OUTPUT_DIR = PROJECT_ROOT / "outputs"
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

FIGURE_DATA = {
    "fig1": DATA_DIR / "SourceData_Fig1.xlsx",
    "fig2": DATA_DIR / "SourceData_Fig2.xlsx",
    "fig3": DATA_DIR / "SourceData_Fig3.xlsx",
    "fig4": DATA_DIR / "SourceData_Fig4.xlsx",
    "fig5": DATA_DIR / "SourceData_Fig5.xlsx",
}

CITY_ORDER = ["Beijing", "Shanghai", "Guangzhou", "Shenzhen", "Tianjin", "Chengdu"]
SCENARIOS = [f"S{i}" for i in range(8)]

# Model-training data placeholders. Replace these with the corresponding prepared files.
MODEL_SAMPLE_TABLE = DATA_DIR / "model_training_samples.csv"
SPATIAL_COVARIATE_DIR = DATA_DIR / "covariate_rasters"
FUTURE_CLIMATE_DIR = DATA_DIR / "future_climate"
