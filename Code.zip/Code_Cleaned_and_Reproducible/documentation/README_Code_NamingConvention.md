# Code naming convention

The code files are ordered by the analysis workflow.

1. `Code_01_*` to `Code_07_*`: raw data preparation and covariate processing.
2. `Code_08_*` to `Code_10_*`: model training, grid prediction, TreeSHAP and spatial ablation attribution.
3. `Code_11_*` to `Code_16_*`: NSGA-III optimization, inequality diagnostics, future SSP replay and county-scale statistics.
4. `Code_17_*` to `Code_22_*`: figure plotting scripts.

Paths should be edited in `config/Code_00_ProjectConfig_RelativePaths.py`. Scripts are retained as reference code for reproducibility and auditability.
