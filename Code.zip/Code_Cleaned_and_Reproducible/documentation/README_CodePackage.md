# Manuscript Source Data and Code Package

This package organizes source data and code for the manuscript figures.

## Folder structure

- `source_data/`: standardized Excel workbooks for main figures.
  - `SourceData_Fig1.xlsx`: flood-prediction performance, SHAP summaries and spatial SHAP honeycomb data.
  - `SourceData_Fig2.xlsx`: adaptation-frontier summaries and Pareto data schema.
  - `SourceData_Fig3.xlsx`: objective-surface and benefit-demand-residual diagnostics.
  - `SourceData_Fig4.xlsx`: planning-lever responses and distributional diagnostic summaries.
  - `SourceData_Fig5.xlsx`: future SSP stress-test summaries.
- `src/`: portable scripts with relative paths.
  - `config_project.py`: shared relative path configuration.
  - `plot_source_data_summaries.py`: regenerates summary plots from the Excel source data.
  - `train_main_model_template.py`: path-clean model-training template.
  - `run_all_figures.py`: runs the source-data plotting script.
- `legacy_reference_scripts/`: path-normalized copies of the full local workflow scripts. These retain the detailed production logic and replace local absolute paths by relative placeholders.

## Quick start

```bash
cd src
python run_all_figures.py
```

Outputs are written to `outputs/`.

## Notes for repository upload

The Excel files contain figure-level source data. Very large raster inputs, street-view imagery and NetCDF climate files are not embedded in the Excel files. The corresponding data directories should be provided separately if full raster-level reruns are required.
