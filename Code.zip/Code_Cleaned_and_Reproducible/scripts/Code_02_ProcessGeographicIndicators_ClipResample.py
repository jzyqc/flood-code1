import os
import numpy as np
import geopandas as gpd
import rasterio
from rasterio.mask import mask
from rasterio.enums import Resampling
from rasterio.warp import reproject, Resampling as WarpResampling

# --- 1. 路径与参数设置 ---
raster_folder = r"E:\中国特大城市洪水\保存地理指标计算"
polygon_folder = r"E:\中国特大城市洪水\全部市图层"
output_root = r"E:\中国特大城市洪水\结果计算过程"
target_res = 500  # 目标分辨率 500m

if not os.path.exists(output_root):
    os.makedirs(output_root)

rasters = [f for f in os.listdir(raster_folder) if f.lower().endswith('.tif')]
polygons = [f for f in os.listdir(polygon_folder) if f.lower().endswith('.shp')]

# --- 2. 批量处理循环 ---
for poly_file in polygons:
    city_name = os.path.splitext(poly_file)[0]
    print(f"\n>>> 正在处理城市: {city_name}")

    city_dir = os.path.join(output_root, city_name)
    if not os.path.exists(city_dir):
        os.makedirs(city_dir)

    # 读取面状矢量数据
    original_gdf = gpd.read_file(os.path.join(polygon_folder, poly_file))

    for raster_file in rasters:
        try:
            raster_path = os.path.join(raster_folder, raster_file)
            raster_label = os.path.splitext(raster_file)[0]

            # 根据是否重采样，设置不同的输出文件名后缀
            if "土地利用" in raster_label:
                out_path = os.path.join(city_dir, f"{city_name}_{raster_label}_OriginalRes.tif")
                need_resample = False
                print(f"  正在处理 (仅裁剪): {raster_label}...")
            else:
                out_path = os.path.join(city_dir, f"{city_name}_{raster_label}_500m.tif")
                need_resample = True
                print(f"  正在处理 (裁剪+重采样): {raster_label}...")

            with rasterio.open(raster_path) as src:
                # 关键：对齐坐标系
                gdf = original_gdf.to_crs(src.crs)
                shapes = gdf.geometry.values
                nodata_val = src.nodata if src.nodata is not None else -9999

                # A. 统一进行按掩模裁剪 (Crop)
                out_image, out_transform = mask(src, shapes, crop=True, nodata=nodata_val, all_touched=True)

                if need_resample:
                    # B1. 执行 500m 重采样逻辑
                    new_width = int(max(1, out_image.shape[2] * abs(out_transform[0]) / target_res))
                    new_height = int(max(1, out_image.shape[1] * abs(out_transform[4]) / target_res))

                    new_transform = rasterio.transform.from_origin(
                        out_transform[2], out_transform[5], target_res, target_res
                    )

                    resample_alg = WarpResampling.nearest if "土地利用" in raster_label else WarpResampling.bilinear
                    resampled_data = np.zeros((src.count, new_height, new_width), dtype=out_image.dtype)

                    for i in range(src.count):
                        reproject(
                            source=out_image[i],
                            destination=resampled_data[i],
                            src_transform=out_transform,
                            src_crs=src.crs,
                            dst_transform=new_transform,
                            dst_crs=src.crs,
                            resampling=resample_alg,
                            src_nodata=nodata_val,
                            dst_nodata=nodata_val
                        )

                    final_data = resampled_data
                    final_transform = new_transform
                    final_width = new_width
                    final_height = new_height
                else:
                    # B2. 跳过重采样，直接使用裁剪结果
                    final_data = out_image
                    final_transform = out_transform
                    final_width = out_image.shape[2]
                    final_height = out_image.shape[1]

                # C. 更新元数据并写入
                out_meta = src.meta.copy()
                out_meta.update({
                    "driver": "GTiff",
                    "height": final_height,
                    "width": final_width,
                    "transform": final_transform,
                    "nodata": nodata_val,
                    "dtype": out_image.dtype
                })

                with rasterio.open(out_path, "w", **out_meta) as dest:
                    dest.write(final_data)

            print(f"    - [完成] {os.path.basename(out_path)}")

        except Exception as e:
            print(f"  !! 处理 {raster_file} 时出错: {str(e)}")

print("\n任务完成！土地利用保持原样，其余已对齐至 500m。")