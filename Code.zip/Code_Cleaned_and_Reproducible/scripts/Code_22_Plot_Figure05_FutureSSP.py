# -*- coding: utf-8 -*-
"""Future SSP stress-test figure v54: code-drawn, vector-editable PDF/SVG.
Fixes: aligned vector hexagons, no white mesh overlay, stable statistical axes.
"""
import os, zipfile, shutil
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import colors as mcolors
from matplotlib.colors import LinearSegmentedColormap, Normalize
from matplotlib.gridspec import GridSpecFromSubplotSpec
from matplotlib.patches import RegularPolygon
from scipy.spatial import cKDTree
from scipy.stats import gaussian_kde

BASE = Path('/mnt/data')
HEX_ROOT = BASE / 'future_final_hex_data_outputs_inspect' / 'future_final_hex_data_outputs'
if not HEX_ROOT.exists():
    with zipfile.ZipFile(BASE / 'future_final_hex_data_outputs.zip', 'r') as z:
        z.extractall(BASE / 'future_final_hex_data_outputs_inspect')
    HEX_ROOT = BASE / 'future_final_hex_data_outputs_inspect' / 'future_final_hex_data_outputs'

# Use the complete annual summary for trajectory panels; the robustness file may not contain SSP585.
annual_path = BASE / 'future_S0S7_annual_summary(2).csv'
if not annual_path.exists():
    annual_path = BASE / 'future_S0S7_annual_summary_RUNNING(2).csv'
if not annual_path.exists():
    annual_path = BASE / 'future_S0S7_annual_summary_with_benefit_robustness(2).csv'
annual = pd.read_csv(annual_path)
if 'CGI_mean' in annual.columns and 'F3_CGI_mean' not in annual.columns:
    annual['F3_CGI_mean'] = annual['CGI_mean']

hexdf = pd.read_csv(HEX_ROOT / 'future_hex_derived_s0_s7_metrics.csv')
quintile_df = pd.read_csv(HEX_ROOT / 'future_hex_quintile_targeting.csv')
fair = pd.read_csv(HEX_ROOT / 'future_hex_s0_s7_state_fairness_change_compact.csv')
city_summary = pd.read_csv(HEX_ROOT / 'future_city_summary.csv')
lorenz = pd.read_csv(HEX_ROOT / 'future_hex_lorenz_points.csv')
OUT = BASE / 'future_original_plus_equity_v59'
OUT.mkdir(exist_ok=True)

# ---------------- constants ----------------
CITY_ORDER = ['Beijing', 'Tianjin', 'Shanghai', 'Chengdu', 'Guangzhou', 'Shenzhen']
CITY_ABBR = {'Beijing':'BJ', 'Tianjin':'TJ', 'Shanghai':'SH', 'Chengdu':'CD', 'Guangzhou':'GZ', 'Shenzhen':'SZ'}
SSPS = ['ssp126', 'ssp245', 'ssp585']
SSP_TITLE = {'ssp126':'SSP126', 'ssp245':'SSP245', 'ssp585':'SSP585'}
YEARS4 = [2030,2050,2070,2100]
SCENS = [f'S{i}' for i in range(8)]
SCENS1 = [f'S{i}' for i in range(1,8)]

plt.rcParams['font.family'] = 'DejaVu Serif'
plt.rcParams['pdf.fonttype'] = 42
plt.rcParams['ps.fonttype'] = 42
plt.rcParams['svg.fonttype'] = 'none'
plt.rcParams['axes.unicode_minus'] = False
plt.rcParams['font.size'] = 6.2

# Stronger, less-white color scale for maps
_base = plt.get_cmap('RdYlBu_r')
CMAP_MAP = LinearSegmentedColormap.from_list('RdYlBu_r_solid', _base(np.linspace(0.04, 0.97, 256)))
CMAP_SCEN = LinearSegmentedColormap.from_list('scenario', _base(np.linspace(0.05, 0.95, 256)))
SCEN_COL = {s: CMAP_SCEN(v) for s, v in zip(SCENS, np.linspace(0.07,0.93,8))}
SSP_COL = {'ssp126':'#2D66B3', 'ssp245':'#E08A29', 'ssp585':'#C42B2C'}
QCOL = {'Q1':'#D8E8F6', 'Q2':'#EAF3F9', 'Q3':'#F5EFD2', 'Q4':'#F4D7BE', 'Q5':'#E8B9B3'}
TEXT_C = '#163A5F'
EDGE_C = '#67727E'        # thin, dark-grey hex boundary instead of white mesh
PANEL_FACE = '#FBFCFD'

# city-specific coarsening: keep Shenzhen/GZ finer, keep large cities readable
COARSEN = {'Beijing':3, 'Tianjin':2, 'Shanghai':2, 'Chengdu':2, 'Guangzhou':1, 'Shenzhen':1}

# ---------------- derived tables ----------------
pf = annual.groupby(['Year','SSP','Scenario'], as_index=False)['P_flood_mean'].mean()
s0 = annual[annual['Scenario']=='S0'][['City','SSP','Year','F1_mean']].rename(columns={'F1_mean':'F1_S0'})
f1chg = annual.merge(s0, on=['City','SSP','Year'], how='left')
f1chg['F1_red_pct'] = (f1chg['F1_S0'] - f1chg['F1_mean']) / f1chg['F1_S0'].replace(0,np.nan) * 100
f1chg.loc[f1chg['Scenario']=='S0', 'F1_red_pct'] = 0
obj = annual.groupby(['City','SSP','Scenario'], as_index=False).agg(F2=('F2_mean','mean'), F3=('F3_CGI_mean','mean'))
cityf1 = annual[(annual['SSP']=='ssp585') & (annual['Scenario'].isin(['S0','S7']))].copy()
cityf1_mean = cityf1.groupby(['City','Scenario'], as_index=False)['F1_mean'].mean()

metric_cols = [c for c in ['F1ReductionPct','F2GainPct','F3GainPct','S7_P_flood','S7_F1','S7_F2','S7_F3','BenefitTotal','ResidualDemand','BDR','DemandAlignedBenefit','Mismatch'] if c in hexdf.columns]
parts=[]
for city in CITY_ORDER:
    fac = COARSEN[city]
    d = hexdf[hexdf['City']==city].copy()
    d['qg'] = np.floor_divide(d['q'].astype(int), fac)
    d['rg'] = np.floor_divide(d['r'].astype(int), fac)
    ag = d.groupby(['City','SSP','Year','qg','rg'], as_index=False).agg(**{c:(c,'mean') for c in metric_cols})
    parts.append(ag)
agg = pd.concat(parts, ignore_index=True)

# pointy-top axial q-r grid: exact lattice, no overlapping scatter markers
SQ3=np.sqrt(3.0)
agg['GridX'] = SQ3 * (agg['qg'] + 0.5*agg['rg'])
agg['GridY'] = 1.5 * agg['rg']
agg['PlotX']=np.nan; agg['PlotY']=np.nan
city_limits={}; city_radius={}
for city in CITY_ORDER:
    idx = agg['City']==city
    sub = agg.loc[idx]
    xmin,xmax = sub['GridX'].min(), sub['GridX'].max()
    ymin,ymax = sub['GridY'].min(), sub['GridY'].max()
    cx,cy = (xmin+xmax)/2, (ymin+ymax)/2
    span = max(xmax-xmin, ymax-ymin)
    span = 1.0 if span==0 else span
    agg.loc[idx,'PlotX'] = (agg.loc[idx,'GridX'] - cx)/span + 0.5
    agg.loc[idx,'PlotY'] = (agg.loc[idx,'GridY'] - cy)/span + 0.5
    pts = agg.loc[idx & (agg['SSP']=='ssp585') & (agg['Year']==2100), ['PlotX','PlotY']].drop_duplicates().to_numpy()
    if len(pts) >= 2:
        tree=cKDTree(pts); dists,_ = tree.query(pts,k=2)
        nn=float(np.nanmedian(dists[:,1]))
        # pointy-top: nearest center = sqrt(3)*R. Use slightly smaller R to leave a hairline boundary, not a white mesh.
        rad = (nn / SQ3) * 0.97
    else:
        rad=0.018
    if city in ['Shenzhen','Guangzhou']:
        rad *= 0.94
    city_radius[city]=float(np.clip(rad,0.010,0.027))
    pad = city_radius[city]*1.10
    city_limits[city]=(-pad,1+pad,-pad,1+pad)

# ---------------- style helpers ----------------
def lighten(c, a=0.32):
    c=np.array(mcolors.to_rgb(c)); return tuple(c+(1-c)*a)

def add_vector_bg(ax):
    # Vector rectangle bands instead of raster imshow; editable in PDF/SVG.
    # Preserve the existing x/y limits so the background never distorts statistics.
    x0, x1 = ax.get_xlim()
    y0, y1 = ax.get_ylim()
    if not np.isfinite([x0, x1, y0, y1]).all() or x0 == x1:
        return
    span = x1 - x0
    ax.axvspan(x0, x1, color='#FBFCFD', zorder=-5, lw=0)
    cols=['#DDEBF8','#EAF2F8','#F6EFD8','#F5DCCB','#EBC2BD']
    for i,col in enumerate(cols):
        ax.axvspan(x0 + span*i/5, x0 + span*(i+1)/5, color=col, alpha=0.20, zorder=-4, lw=0)
    ax.set_xlim(x0, x1)
    ax.set_ylim(y0, y1)

def style_axes(ax,tick=5.8,gx='y'):
    ax.spines['top'].set_visible(False); ax.spines['right'].set_visible(False)
    ax.spines['left'].set_linewidth(0.65); ax.spines['bottom'].set_linewidth(0.65)
    ax.tick_params(labelsize=tick,width=0.55,length=2.0,pad=1.25)
    if gx is not None:
        ax.grid(True,axis=gx,lw=0.28,alpha=0.20,zorder=0)

def panel_label(ax,lab):
    ax.text(0.012,0.988,lab,transform=ax.transAxes,ha='left',va='top',fontsize=9.0,fontweight='bold',
            bbox=dict(facecolor='white',edgecolor='none',alpha=0.92,pad=0.08),zorder=100)

def map_cell(ax, df, metric, vmin, vmax, title='', rowlab=None):
    ax.set_facecolor(PANEL_FACE)
    if len(df):
        city=df['City'].iloc[0]
        norm=Normalize(vmin=vmin,vmax=vmax)
        rad=city_radius.get(city,0.016)
        xs=df['PlotX'].to_numpy(); ys=df['PlotY'].to_numpy(); vals=df[metric].to_numpy()
        order=np.lexsort((xs,ys))
        for i in order:
            poly=RegularPolygon((xs[i],ys[i]), numVertices=6, radius=rad, orientation=np.pi/6,
                                facecolor=CMAP_MAP(norm(vals[i])), edgecolor=(0.20,0.25,0.30,0.13), linewidth=0.006,
                                antialiased=False, joinstyle='miter')
            ax.add_patch(poly)
        ax.set_xlim(*city_limits[city][:2]); ax.set_ylim(*city_limits[city][2:])
    ax.set_aspect('equal', adjustable='box')
    ax.set_xticks([]); ax.set_yticks([])
    for sp in ax.spines.values():
        sp.set_visible(True); sp.set_linewidth(0.28); sp.set_edgecolor('#8A9098')
    if title: ax.set_title(title,fontsize=6.2,pad=0.18)
    if rowlab:
        ax.text(-0.045,0.5,rowlab,transform=ax.transAxes,ha='right',va='center',fontsize=6.4,fontweight='bold')

def line_box(ax,ssp,lab=None):
    sub=pf[pf['SSP']==ssp]
    for s in SCENS:
        ds=sub[sub['Scenario']==s].sort_values('Year')
        ax.plot(ds['Year'], ds['P_flood_mean'], color=SCEN_COL[s], lw=1.0 if s not in ['S0','S7'] else 1.45, ls='--' if s=='S0' else '-', zorder=2)
    ax.set_xlim(2015,2100); ax.set_xticks([2030,2050,2070,2100])
    ax.set_title(f'{SSP_TITLE[ssp]} P_flood',fontsize=8.0,loc='left',pad=0.8)
    ax.set_ylabel('Mean',fontsize=6.0,fontweight='bold')
    add_vector_bg(ax); style_axes(ax,tick=4.4,gx='both')
    if lab: panel_label(ax,lab)

def f1rain(ax,ssp,lab=None):
    sub=annual[(annual['SSP']==ssp)&(annual['Year']==2100)]
    s0v=sub[sub['Scenario']=='S0'][['City','F1_mean']].rename(columns={'F1_mean':'base'})
    data=[]
    for s in SCENS1:
        cur=sub[sub['Scenario']==s][['City','F1_mean']].merge(s0v,on='City')
        data.append(((cur['base']-cur['F1_mean'])/cur['base']*100).values)
    for i,vals in enumerate(data,1):
        vals=np.asarray(vals); vals=vals[np.isfinite(vals)]
        if len(vals)>=4 and np.nanstd(vals)>1e-12:
            ys=np.linspace(vals.min(),vals.max(),120); den=gaussian_kde(vals)(ys); den=den/den.max()*0.18
            ax.fill_betweenx(ys,i-den,i+den,color=lighten(SCEN_COL[SCENS1[i-1]],0.36),ec=SCEN_COL[SCENS1[i-1]],lw=0.45,alpha=0.80)
        ax.boxplot(vals,positions=[i],widths=0.12,patch_artist=True,showfliers=False,
                   medianprops=dict(color='black',lw=0.48), boxprops=dict(facecolor='white',edgecolor=SCEN_COL[SCENS1[i-1]],lw=0.48),
                   whiskerprops=dict(color=SCEN_COL[SCENS1[i-1]],lw=0.42), capprops=dict(lw=0))
        ax.scatter(i,np.nanmean(vals),marker='D',s=7.5,facecolors='white',edgecolors='black',lw=0.22,zorder=4)
    ax.set_xticks(np.arange(1,8)); ax.set_xticklabels(SCENS1,fontsize=4.8)
    ax.set_title(f'{SSP_TITLE[ssp]} F1 reduction',fontsize=8.0,loc='left',pad=0.8)
    ax.set_ylabel('F1 red. (%)',fontsize=6.0,fontweight='bold')
    add_vector_bg(ax); style_axes(ax,tick=4.3)
    if lab: panel_label(ax,lab)

def bar_metric(ax,metric,title,ylabel,lab=None):
    df=obj.groupby('Scenario',as_index=False)[metric].mean().set_index('Scenario').reindex(SCENS)
    x=np.arange(len(SCENS))
    for i,s in enumerate(SCENS):
        ax.bar(i,df.loc[s,metric],width=0.50,color=lighten(SCEN_COL[s],0.35),edgecolor=SCEN_COL[s],lw=0.45)
    ax.set_xticks(x); ax.set_xticklabels(SCENS,fontsize=4.8)
    ax.set_title(title,fontsize=8.0,loc='left',pad=0.8); ax.set_ylabel(ylabel,fontsize=6.0,fontweight='bold')
    add_vector_bg(ax); style_axes(ax,tick=4.3,gx='y')
    if lab: panel_label(ax,lab)

def city_f1_panel(ax,lab=None):
    mp=cityf1_mean.pivot(index='City',columns='Scenario',values='F1_mean').reindex(CITY_ORDER)
    x=np.arange(len(CITY_ORDER)); w=0.28
    ax.bar(x-w/2,mp['S0'].values,width=w,color=lighten(SCEN_COL['S0'],0.35),edgecolor=SCEN_COL['S0'],lw=0.45,label='S0')
    ax.bar(x+w/2,mp['S7'].values,width=w,color=lighten(SCEN_COL['S7'],0.35),edgecolor=SCEN_COL['S7'],lw=0.45,label='S7')
    ax.set_xticks(x); ax.set_xticklabels([CITY_ABBR[c] for c in CITY_ORDER],fontsize=4.8)
    ax.set_title('City F1: S0 vs S7',fontsize=8.0,loc='left',pad=0.8); ax.set_ylabel('Mean F1',fontsize=6.0,fontweight='bold')
    ax.legend(frameon=False,fontsize=4.4,loc='upper left',ncol=2,handlelength=1.0,columnspacing=0.6,borderaxespad=0.2)
    add_vector_bg(ax); style_axes(ax,tick=4.3)
    if lab: panel_label(ax,lab)

def fair_traj(ax,metric,title,ylabel,lab=None):
    for ssp in SSPS:
        sub=city_summary[city_summary['SSP']==ssp]
        grp=sub.groupby('Year')[metric].mean().reindex(YEARS4)
        ax.plot(np.arange(len(YEARS4)),grp.values,color=SSP_COL[ssp],lw=1.05,marker='o',ms=2.0,label=SSP_TITLE[ssp])
    ax.set_xticks(np.arange(len(YEARS4))); ax.set_xticklabels(YEARS4,fontsize=4.6)
    ax.set_title(title,fontsize=8.0,loc='left',pad=0.8); ax.set_ylabel(ylabel,fontsize=6.0,fontweight='bold')
    add_vector_bg(ax); style_axes(ax,tick=4.1,gx='both')
    if lab: panel_label(ax,lab)

def quint(ax,metric,title,ylabel,lab=None):
    x=np.arange(1,6)
    for j,q in enumerate(['Q1','Q2','Q3','Q4','Q5'],1):
        ax.axvspan(j-0.5,j+0.5,color=QCOL[q],alpha=0.25,zorder=-4,lw=0)
    for ssp in SSPS:
        sub=quintile_df[(quintile_df['Year']==2100)&(quintile_df['SSP']==ssp)]
        grp=sub.groupby('DemandQuintile')[metric].mean().reindex(['Q1','Q2','Q3','Q4','Q5'])
        ax.plot(x,grp.values,color=SSP_COL[ssp],lw=1.05,marker='o',ms=2.0,label=SSP_TITLE[ssp])
    ax.set_xticks(x); ax.set_xticklabels(['Q1','Q2','Q3','Q4','Q5'],fontsize=4.8)
    ax.set_title(title,fontsize=8.0,loc='left',pad=0.8); ax.set_ylabel(ylabel,fontsize=5.1,fontweight='bold')
    style_axes(ax,tick=4.2); ax.set_facecolor('#FBFCFD')
    if lab: panel_label(ax,lab)

def lorenz_panel(ax,indicator,title,lab=None):
    for ssp in SSPS:
        sub=lorenz[(lorenz['Year']==2100)&(lorenz['SSP']==ssp)&(lorenz['Scenario']=='S0_to_S7')&(lorenz['Indicator']==indicator)]
        if sub.empty: continue
        pooled=sub.groupby('CellShare',as_index=False)['ValueShare'].mean()
        ax.plot(pooled['CellShare'],pooled['ValueShare'],color=SSP_COL[ssp],lw=1.05,label=SSP_TITLE[ssp])
    ax.plot([0,1],[0,1],color='#666',ls='--',lw=0.45)
    ax.set_xlim(0,1); ax.set_ylim(0,1)
    ax.set_title(title,fontsize=8.0,loc='left',pad=0.8); ax.set_xlabel('Cell share',fontsize=5.4); ax.set_ylabel('Value share',fontsize=5.8,fontweight='bold')
    add_vector_bg(ax); style_axes(ax,tick=4.1,gx='both')
    if lab: panel_label(ax,lab)

def signed_log(x):
    x=np.asarray(x,dtype=float); return np.sign(x)*np.log10(1+np.abs(x))

def forest(ax,lab=None):
    mets=[('Gini_RelativeChange_pct','Gini'),('Theil_T_RelativeChange_pct','Theil'),('Atkinson_1_RelativeChange_pct','Atk'),('Hoover_RelativeChange_pct','Hoover'),('Top20_Share_RelativeChange_pct','Top20'),('P90_P10_Ratio_RelativeChange_pct','P90/P10')]
    inds=['F1','F2','F3','P_flood']; markers={'F1':'o','F2':'s','F3':'^','P_flood':'D'}
    ax.axvspan(-2.1,0,color='#C8D9EE',alpha=0.56,zorder=0,lw=0); ax.axvspan(0,2.1,color='#F0D7D1',alpha=0.56,zorder=0,lw=0)
    ax.axvline(0,color='#666',ls='--',lw=0.50)
    for yi,(col,name) in enumerate(mets):
        vals=[]
        for ind in inds:
            for ssp in SSPS:
                row=fair[(fair['Year']==2100)&(fair['SSP']==ssp)&(fair['Indicator']==ind)]
                if row.empty: continue
                v=signed_log(row.iloc[0][col]); vals.append(v)
                ax.scatter(v,yi+(SSPS.index(ssp)-1)*0.045+(inds.index(ind)-1.5)*0.010,s=7.0,color=SSP_COL[ssp],marker=markers[ind],edgecolors='white',linewidths=0.16,zorder=3)
        if vals:
            ax.hlines(yi,np.quantile(vals,0.25),np.quantile(vals,0.75),color='#6A87A7',lw=0.85)
            ax.scatter(np.mean(vals),yi,s=14,marker='D',color='#1B5AA6',edgecolors='white',linewidths=0.22,zorder=4)
    ax.set_yticks(np.arange(len(mets))); ax.set_yticklabels([n for _,n in mets],fontsize=4.8); ax.invert_yaxis(); ax.set_xlim(-2.1,2.1)
    ax.set_title('Inequality shift',fontsize=8.0,loc='left',pad=0.8); ax.set_xlabel('signed log10(1+% change)',fontsize=5.4)
    style_axes(ax,tick=4.1,gx=None)
    if lab: panel_label(ax,lab)

def city_bar(ax,metric,title,ylabel,lab=None):
    sub=city_summary[city_summary['Year']==2100]
    x=np.arange(len(CITY_ORDER)); w=0.22
    for i,ssp in enumerate(SSPS):
        vals=sub[sub['SSP']==ssp].set_index('City').reindex(CITY_ORDER)[metric].values
        ax.bar(x+(i-1)*w,vals,width=w,color=SSP_COL[ssp],alpha=0.82,edgecolor='white',lw=0.20,label=SSP_TITLE[ssp])
    ax.set_xticks(x); ax.set_xticklabels([CITY_ABBR[c] for c in CITY_ORDER],fontsize=4.7)
    ax.set_title(title,fontsize=8.0,loc='left',pad=0.8); ax.set_ylabel(ylabel,fontsize=5.7,fontweight='bold')
    add_vector_bg(ax); style_axes(ax,tick=4.1)
    if lab: panel_label(ax,lab)

# ---------------- figure ----------------
fig=plt.figure(figsize=(14.8,8.8),dpi=360)
outer=fig.add_gridspec(1,2,width_ratios=[2.18,1.42],wspace=0.020,left=0.018,right=0.996,top=0.905,bottom=0.050)
map_gs=GridSpecFromSubplotSpec(2,1,subplot_spec=outer[0,0],height_ratios=[1.16,0.92],hspace=0.040)

Abox=fig.add_subplot(map_gs[0,0]); Abox.axis('off'); panel_label(Abox,'a')
Abox.text(0.045,1.010,'S0-S7 response maps at 2100: F1 reduction, F2 level and F3/CGI level across SSPs',
          transform=Abox.transAxes,fontsize=8.2,fontweight='bold',va='bottom')

# 6 city rows x 9 columns. Each SSP contains F1 reduction, F2 and F3/CGI.
# F3GainPct is nearly zero in the data, so F3/CGI endpoint is shown to avoid blank maps.
subA=GridSpecFromSubplotSpec(7,9,subplot_spec=map_gs[0,0],
                             height_ratios=[0.24,1,1,1,1,1,1],
                             wspace=0.006,hspace=0.010)

metricA=[('F1ReductionPct','F1 red.'),('S7_F2','F2'),('S7_F3','F3/CGI')]
dA=agg[agg['Year']==2100].copy()
rngA={}
for metric,label in metricA:
    vals=dA[metric].replace([np.inf,-np.inf],np.nan).dropna()
    if len(vals)==0:
        rngA[metric]=(0,1)
    else:
        lo=float(np.nanpercentile(vals,2))
        hi=float(np.nanpercentile(vals,98))
        if metric=='F1ReductionPct':
            lo=max(0,lo)
        if hi<=lo:
            hi=lo+1e-6
        rngA[metric]=(lo,hi)

for g,ssp in enumerate(SSPS):
    for m,(metric,label) in enumerate(metricA):
        axh=fig.add_subplot(subA[0,g*3+m]); axh.axis('off')
        if m==1:
            txthead=f'{SSP_TITLE[ssp]}\n{label}'
            fs=5.7
            fw='bold'
        else:
            txthead=label
            fs=5.2
            fw='bold'
        axh.text(0.5,0.52,txthead,ha='center',va='center',fontsize=fs,fontweight=fw)

Aaxes=[]
for r,city in enumerate(CITY_ORDER):
    for g,ssp in enumerate(SSPS):
        for m,(metric,label) in enumerate(metricA):
            ax=fig.add_subplot(subA[r+1,g*3+m])
            dcell=dA[(dA['City']==city)&(dA['SSP']==ssp)]
            vminA,vmaxA=rngA[metric]
            map_cell(ax,dcell,metric,vminA,vmaxA,
                     title='',rowlab=CITY_ABBR[city] if (g==0 and m==0) else None)
            Aaxes.append(ax)

# compact metric-specific colorbars for a
for i,(metric,label) in enumerate(metricA):
    cax=fig.add_axes([0.052 + i*0.115, 0.902, 0.085, 0.006])
    sm=plt.cm.ScalarMappable(norm=plt.Normalize(*rngA[metric]),cmap=CMAP_MAP); sm.set_array([])
    cb=fig.colorbar(sm,cax=cax,orientation='horizontal')
    cb.ax.tick_params(labelsize=4.3,length=1.0,pad=0.6)
    cb.outline.set_linewidth(0.25)
    cb.set_label(label,fontsize=4.5,labelpad=0.0)

Bbox=fig.add_subplot(map_gs[1,0]); Bbox.axis('off'); panel_label(Bbox,'b')
Bbox.text(0.045,1.010,'S7 endpoint surfaces under SSP585 at 2100: state, benefit and residual-gap indicators',
          transform=Bbox.transAxes,fontsize=8.2,fontweight='bold',va='bottom')

# 6 city rows x 9 endpoint indicators; aligned with panel a.
subB=GridSpecFromSubplotSpec(7,9,subplot_spec=map_gs[1,0],
                             height_ratios=[0.24,1,1,1,1,1,1],
                             wspace=0.006,hspace=0.010)

rowsB=[
    ('S7_P_flood','P_flood'),
    ('S7_F1','F1'),
    ('S7_F2','F2'),
    ('S7_F3','F3/CGI'),
    ('BenefitTotal','Benefit'),
    ('ResidualDemand','Residual'),
    ('BDR','ACR/BDR'),
    ('DemandAlignedBenefit','Aligned ben.'),
    ('Mismatch','Mismatch')
]

dB=agg[(agg['Year']==2100)&(agg['SSP']=='ssp585')].copy()
rngB={}
for metric,label in rowsB:
    vals=dB[metric].replace([np.inf,-np.inf],np.nan).dropna()
    if len(vals)==0:
        rngB[metric]=(0,1)
    else:
        lo=float(np.nanpercentile(vals,2))
        hi=float(np.nanpercentile(vals,98))
        if metric not in ['Mismatch']:
            lo=max(0,lo)
        if hi<=lo:
            hi=lo+1e-6
        rngB[metric]=(lo,hi)

for c,(metric,label) in enumerate(rowsB):
    axh=fig.add_subplot(subB[0,c]); axh.axis('off')
    axh.text(0.5,0.52,label,ha='center',va='center',fontsize=5.25,fontweight='bold')

Baxes=[]
for r,city in enumerate(CITY_ORDER):
    for c,(metric,label) in enumerate(rowsB):
        ax=fig.add_subplot(subB[r+1,c])
        dd=dB[dB['City']==city]
        vminB,vmaxB=rngB[metric]
        map_cell(ax,dd,metric,vminB,vmaxB,
                 title='',rowlab=CITY_ABBR[city] if c==0 else None)
        Baxes.append(ax)

# three compact representative colorbars for b; all maps are metric-wise scaled
for i,(metric,label) in enumerate([rowsB[0],rowsB[4],rowsB[8]]):
    cax=fig.add_axes([0.052 + i*0.115, 0.030, 0.085, 0.006])
    sm=plt.cm.ScalarMappable(norm=plt.Normalize(*rngB[metric]),cmap=CMAP_MAP); sm.set_array([])
    cb=fig.colorbar(sm,cax=cax,orientation='horizontal')
    cb.ax.tick_params(labelsize=4.3,length=1.0,pad=0.6)
    cb.outline.set_linewidth(0.25)
    cb.set_label(label,fontsize=4.5,labelpad=0.0)

stats=GridSpecFromSubplotSpec(6,4,subplot_spec=outer[0,1],hspace=0.34,wspace=0.20)
ax=fig.add_subplot(stats[0,0]); line_box(ax,'ssp126','c')
ax=fig.add_subplot(stats[0,1]); line_box(ax,'ssp245','d')
ax=fig.add_subplot(stats[0,2]); line_box(ax,'ssp585','e')
ax=fig.add_subplot(stats[0,3]); city_f1_panel(ax,'f')
ax=fig.add_subplot(stats[1,0]); f1rain(ax,'ssp126','g')
ax=fig.add_subplot(stats[1,1]); f1rain(ax,'ssp245','h')
ax=fig.add_subplot(stats[1,2]); f1rain(ax,'ssp585','i')
ax=fig.add_subplot(stats[1,3]); forest(ax,'j')
ax=fig.add_subplot(stats[2,0]); bar_metric(ax,'F2','F2 across S0-S7','Mean F2','k')
ax=fig.add_subplot(stats[2,1]); bar_metric(ax,'F3','F3/CGI across S0-S7','Mean F3','l')
ax=fig.add_subplot(stats[2,2]); fair_traj(ax,'Q5TargetingEfficiency','Q5 targeting','Q5 (%)','m')
metric_r='HUDR' if 'HUDR' in city_summary.columns else 'Q5ResidualShare'
ax=fig.add_subplot(stats[2,3]); fair_traj(ax,metric_r,'Unmet burden','HUDR' if metric_r=='HUDR' else 'Residual (%)','n')
ax=fig.add_subplot(stats[3,0]); quint(ax,'BenefitShare','Benefit by quintile','Share (%)','o')
ax=fig.add_subplot(stats[3,1]); quint(ax,'MeanBDR','Coverage by quintile','BDR','p')
ax=fig.add_subplot(stats[3,2]); quint(ax,'ResidualShare','Residual by quintile','Share (%)','q')
ax=fig.add_subplot(stats[3,3]); city_bar(ax,'Mean_F1ReductionPct','City F1 reduction','F1 red. (%)','r')
ax=fig.add_subplot(stats[4,0]); fair_traj(ax,'Mean_BenefitTotal','Benefit total','Mean','s')
ax=fig.add_subplot(stats[4,1]); fair_traj(ax,'Mean_BDR','Adaptive coverage','Mean BDR','t')
ax=fig.add_subplot(stats[4,2]); fair_traj(ax,'Mean_ResidualDemand','Residual demand','Mean','u')
ax=fig.add_subplot(stats[4,3]); city_bar(ax,'Mean_P_floodReductionPct','City P_flood red.','P_flood red. (%)','v')
ax=fig.add_subplot(stats[5,0]); lorenz_panel(ax,'BenefitTotal','Lorenz: benefit total','w'); ax.legend(frameon=False,fontsize=4.1,loc='upper left')
ax=fig.add_subplot(stats[5,1]); lorenz_panel(ax,'ResidualDemand','Lorenz: residual demand','x')
ax=fig.add_subplot(stats[5,2]); city_bar(ax,'Q5ResidualShare','City Q5 residual','Q5 residual (%)','y')
ax=fig.add_subplot(stats[5,3]); city_bar(ax,'Q5TargetingEfficiency','City Q5 targeting','Q5 targeting (%)','z')

fig.suptitle('Future SSP stress-test with expanded multi-objective honeycomb maps and equity diagnostics',fontsize=11.8,fontweight='bold',y=0.975,color=TEXT_C)
fig.text(0.51,0.956,'Panel a displays SSP-specific F1 reduction, F2 and F3/CGI responses; panel b expands endpoint indicators for benefit and residual-gap interpretation.',ha='center',va='center',fontsize=5.6,color=TEXT_C)
leg=fig.add_axes([0.03,0.943,0.33,0.015]); leg.axis('off')
for i,s in enumerate(SCENS):
    xx=i*0.118
    leg.plot([xx,xx+0.04],[0.5,0.5],color=SCEN_COL[s],lw=1.15)
    leg.text(xx+0.045,0.5,s,va='center',ha='left',fontsize=4.8)
leg.set_xlim(0,1); leg.set_ylim(0,1)

OUT.mkdir(exist_ok=True)
png=OUT/'fig_future_v59.png'; pdf=OUT/'fig_future_v59.pdf'; svg=OUT/'fig_future_v59.svg'
fig.savefig(png,dpi=360,bbox_inches='tight',pad_inches=0.003)
fig.savefig(pdf,dpi=360,bbox_inches='tight',pad_inches=0.003)
fig.savefig(svg,dpi=360,bbox_inches='tight',pad_inches=0.003)
plt.close(fig)

# top-level copies and package
for p in [png,pdf,svg]:
    shutil.copy2(p, BASE/p.name)
code_path=BASE/'fig_future_v59_code.py'
# if run from same path this is already there; otherwise copy is harmless
if Path(__file__).resolve()!=code_path.resolve():
    shutil.copy2(__file__,code_path)
zip_path=BASE/'fig_future_v59_package.zip'
with zipfile.ZipFile(zip_path,'w',compression=zipfile.ZIP_DEFLATED) as z:
    for p in [BASE/'fig_future_v59.png',BASE/'fig_future_v59.pdf',BASE/'fig_future_v59.svg',code_path]:
        z.write(p,arcname=p.name)
print(BASE/'fig_future_v59.png')
print(BASE/'fig_future_v59.pdf')
print(BASE/'fig_future_v59.svg')
print(code_path)
print(zip_path)
