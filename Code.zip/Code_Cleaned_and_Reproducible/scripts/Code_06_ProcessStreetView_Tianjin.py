# -*- coding: utf-8 -*-
"""
天津市（images25.csv + images50.csv 合并）街景指标计算
+ 100m 栅格化（raw）+ IDW 填充（mask 内尽量无缺失）

输入:
  E:\中国特大城市洪水\街景数据\images25.csv
  E:\中国特大城市洪水\街景数据\images50.csv

输出:
  E:\中国特大城市洪水\SV_Tianjin_outputs_IDW\
    streetview_raw_tianjin.csv
    streetview_final_tianjin.csv
    天津\points.gpkg
    天津\01_raw_rasters\*.tif (+count.tif)
    天津\02_idw_rasters\*.tif

依赖:
  numpy pandas tqdm rasterio pyproj scipy geopandas shapely fiona
"""

import os
import re
import math
from pathlib import Path

import numpy as np
import pandas as pd
from tqdm import tqdm

import rasterio
from rasterio.transform import from_origin
from rasterio.features import rasterize

from pyproj import Transformer
from scipy.spatial import cKDTree


# ===================== 0) 配置 =====================
IN_CSVS = [
    r"E:\中国特大城市洪水\街景数据\images25.csv",
    r"E:\中国特大城市洪水\街景数据\images50.csv",
]

OUT_ROOT = r"E:\中国特大城市洪水\SV_Tianjin_outputs_IDW"
TMP_RAW_CSV = os.path.join(OUT_ROOT, "streetview_raw_tianjin.csv")
FINAL_CSV   = os.path.join(OUT_ROOT, "streetview_final_tianjin.csv")

CITY_NAME = "天津"

# ⚠️ 改成你的天津市边界 shp
CITY_SHP = r"E:\中国特大城市洪水\天津市区域t.shp"

# 最终栅格化变量
RASTER_VARS = [
    "GVI", "SVF", "BVI", "Micro_ISA", "Micro_PSA",
    "SCE", "SEI", "TAE", "CFI", "FOE",
    "RPP", "MSRI", "ECO"
]

CHUNKSIZE = 200_000

# 100m 米制栅格
PIXEL_SIZE_M = 100.0
PAD_M = 0.0

# IDW 参数
IDW_K = 12
IDW_POWER = 2.0
IDW_CHUNK = 200_000


# ===================== 0.1) 自动判断分隔符（逗号 / tab） =====================
def detect_sep(csv_path: str) -> str:
    # 用第一行判断更稳
    with open(csv_path, "r", encoding="utf-8-sig", errors="ignore") as f:
        line = f.readline()
    return "\t" if line.count("\t") > line.count(",") else ","


# ===================== 1) 列名匹配（尾空格安全） =====================
def _norm(s: str) -> str:
    if s is None:
        return ""
    s = str(s).strip().lower().replace("，", ",")
    s = re.sub(r"\s+", " ", s)
    return s

def build_colmap(columns):
    return {_norm(c): c for c in columns}

def resolve_cols(colmap, candidates):
    found, missing = [], []
    keys = list(colmap.keys())
    for cand in candidates:
        nc = _norm(cand)
        if nc in colmap:
            found.append(colmap[nc]); continue
        first = nc.split(",")[0].strip()
        if first in colmap:
            found.append(colmap[first]); continue
        hits = [k for k in keys if (k == nc) or (nc in k and len(nc) >= 5)]
        if len(hits) == 1:
            found.append(colmap[hits[0]])
        else:
            missing.append(cand)
    return found, missing

def sum_cols(df, cols):
    if not cols:
        return pd.Series(0.0, index=df.index)
    cols2 = [c for c in cols if c in df.columns]
    if not cols2:
        return pd.Series(0.0, index=df.index)
    return df[cols2].sum(axis=1)

def safe_div(a, b, eps=1e-6):
    return a / (b + eps)


# ===================== 2) 从 image 字符串解析 lon/lat（避免把 90/0 当坐标） =====================
def extract_lon_lat_from_image(s: str):
    """
    你的文件名长这样：
      119935_117.1389_39.0900_90_0.png
    最稳：split('_')[1] 和 [2]
    """
    s = str(s)
    base = os.path.basename(s)
    base = os.path.splitext(base)[0]
    parts = base.split("_")
    if len(parts) >= 3:
        try:
            lon = float(parts[1])
            lat = float(parts[2])
            if 70 <= lon <= 140 and 0 <= lat <= 60:
                return lon, lat
        except Exception:
            pass

    # 兜底：正则找所有数字
    nums = re.findall(r"-?\d+(?:\.\d+)?", base)
    vals = [float(x) for x in nums] if len(nums) else []
    if len(vals) < 2:
        return (np.nan, np.nan)

    # 优先找天津附近
    for i in range(len(vals) - 1):
        a, b = vals[i], vals[i + 1]
        if 110 <= a <= 125 and 30 <= b <= 45:
            return (a, b)
        if 110 <= b <= 125 and 30 <= a <= 45:
            return (b, a)

    # 再退一步：排除明显角度
    bad_angles = {0.0, 90.0, 180.0, 270.0}
    for i in range(len(vals) - 1):
        a, b = vals[i], vals[i + 1]
        if (a in bad_angles and b in bad_angles):
            continue
        if 70 <= a <= 140 and 0 <= b <= 60 and b >= 10:
            return (a, b)
        if 70 <= b <= 140 and 0 <= a <= 60 and a >= 10:
            return (b, a)

    return (np.nan, np.nan)


# ===================== 3) 在线统计（Welford） =====================
class RunningStats:
    def __init__(self):
        self.n = 0
        self.mean = 0.0
        self.M2 = 0.0

    def update(self, x: np.ndarray):
        x = x.astype(np.float64, copy=False)
        for v in x:
            self.n += 1
            delta = v - self.mean
            self.mean += delta / self.n
            delta2 = v - self.mean
            self.M2 += delta * delta2

    def std(self):
        if self.n <= 0:
            return 0.0
        var = self.M2 / self.n
        return math.sqrt(var) if var > 0 else 0.0

def z_from_stats(series: pd.Series, mean: float, std: float, eps=1e-12):
    if std < eps:
        return (series - mean) * 0.0
    return (series - mean) / std


# ===================== 4) ADE150 类集合（按你原脚本口径） =====================
SKY = ["sky"]
VEG_ALL = ["tree", "palm, palm tree", "plant", "grass", "flower"]
WATER_ALL = ["water", "river", "sea", "lake", "pool", "fountain", "falls"]

IMPERV = ["road, route", "sidewalk, pavement", "path", "stairs", "stairway, staircase"]
PERV = ["earth, ground", "land, ground, soil", "sand", "field", "grass"]

V_HARD = ["building", "skyscraper", "house", "tower", "wall", "column, pillar", "bridge, span"]
BARRIER = ["wall", "fence"]

VEH_ALL = ["car", "bus", "truck", "van", "bicycle", "minibike, motorbike"]
STREET_ASSET = ["traffic light", "street lamp", "pole", "signboard, sign", "booth",
                "awning, sunshade, sunblind", "canopy"]

SIGNAGE = ["signboard, sign", "poster, posting, placard, notice, bill, card", "trade name", "bulletin board"]
OPENINGS = ["door", "window", "screen door, screen"]


# ===================== 5) 每个CSV：读取表头 -> usecols =====================
def prepare_usecols_for_file(csv_path: str):
    sep = detect_sep(csv_path)
    header = pd.read_csv(csv_path, nrows=0, encoding="utf-8-sig", sep=sep)  # ✅ 不用 engine="python"
    cols = list(header.columns)
    id_col = cols[0]
    colmap = build_colmap(cols)

    sets = {
        "Sky": SKY,
        "Veg": VEG_ALL,
        "Water": WATER_ALL,
        "Imperv": IMPERV,
        "Perv": PERV,
        "V_hard": V_HARD,
        "Barrier": BARRIER,
        "Veh_all": VEH_ALL,
        "StreetAsset": STREET_ASSET,
        "Signage": SIGNAGE,
        "Openings": OPENINGS,
    }

    resolved = {}
    for name, cand in sets.items():
        real_cols, _ = resolve_cols(colmap, cand)
        resolved[name] = real_cols

    needed = {id_col}
    for v in resolved.values():
        needed.update(v)

    needed_cols = [c for c in needed if c in set(cols)]
    return sep, id_col, resolved, needed_cols


# ===================== 6) Pass1：合并两表计算 raw + 统计 z =====================
def pass1_raw_and_stats(csv_paths):
    z_targets = ["Micro_ISA","Micro_PSA","GVI","SVF","BVI","SCE","SEI","TAE","CFI","FOE"]
    stats = {k: RunningStats() for k in z_targets}

    first_write = True
    total_kept = 0
    scale_div = 1.0
    pbar = tqdm(desc="Pass1 raw（天津=两表合并）", unit="rows")

    for csv_path in csv_paths:
        sep, id_col, resolved, needed_cols = prepare_usecols_for_file(csv_path)

        reader = pd.read_csv(
            csv_path, usecols=needed_cols,
            chunksize=CHUNKSIZE,
            encoding="utf-8-sig",
            low_memory=False,     # ✅ C 引擎支持
            sep=sep               # ✅ 不用 engine="python"
        )

        for chunk in reader:
            pbar.update(len(chunk))

            lonlat = chunk[id_col].map(extract_lon_lat_from_image)
            lon = lonlat.map(lambda t: t[0]).astype(float)
            lat = lonlat.map(lambda t: t[1]).astype(float)

            num_cols = [c for c in chunk.columns if c != id_col]
            if num_cols:
                chunk[num_cols] = chunk[num_cols].apply(pd.to_numeric, errors="coerce").fillna(0.0)

            if first_write and num_cols:
                maxv = chunk[num_cols].max().max()
                if maxv > 1.5:
                    scale_div = 100.0
            if scale_div != 1.0 and num_cols:
                chunk[num_cols] = chunk[num_cols] / scale_div

            Sky = sum_cols(chunk, resolved["Sky"])
            Veg = sum_cols(chunk, resolved["Veg"])
            Water = sum_cols(chunk, resolved["Water"])
            Imperv = sum_cols(chunk, resolved["Imperv"])
            Perv = sum_cols(chunk, resolved["Perv"])
            Vhard = sum_cols(chunk, resolved["V_hard"])
            Barrier = sum_cols(chunk, resolved["Barrier"])
            Veh = sum_cols(chunk, resolved["Veh_all"])
            StreetAsset = sum_cols(chunk, resolved["StreetAsset"])
            Signage = sum_cols(chunk, resolved["Signage"])
            Openings = sum_cols(chunk, resolved["Openings"])

            eps = 1e-6
            out = pd.DataFrame({
                "image": chunk[id_col].astype(str).values,
                "city": CITY_NAME,
                "lon": lon.values,
                "lat": lat.values,

                "GVI": Veg,
                "SVF": Sky,
                "BVI": Water,
                "Micro_ISA": Imperv,
                "Micro_PSA": Perv,

                "SCE": safe_div(Vhard, Vhard + Sky, eps),
                "SEI": safe_div(Barrier, Barrier + Sky, eps),

                "TAE": Veh + StreetAsset,
                "CFI": Signage,
                "FOE": Openings,
            })

            for k in z_targets:
                stats[k].update(out[k].to_numpy())

            out.to_csv(
                TMP_RAW_CSV, index=False,
                mode="w" if first_write else "a",
                header=first_write, encoding="utf-8-sig"
            )
            first_write = False
            total_kept += len(out)

    pbar.close()
    means = {k: stats[k].mean for k in stats}
    stds  = {k: stats[k].std() for k in stats}
    return total_kept, means, stds


# ===================== 7) Pass2：复合指数（RPP/MSRI/ECO） =====================
def pass2_final(means, stds):
    first_write = True
    total_rows = 0
    reader = pd.read_csv(TMP_RAW_CSV, chunksize=CHUNKSIZE, encoding="utf-8-sig", low_memory=False)
    pbar = tqdm(desc="Pass2 复合指数（天津）", unit="rows")

    for chunk in reader:
        pbar.update(len(chunk))
        total_rows += len(chunk)

        for c in chunk.columns:
            if c not in ["image","city"]:
                chunk[c] = pd.to_numeric(chunk[c], errors="coerce")

        z = {}
        for k in means.keys():
            z[k] = z_from_stats(chunk[k], means[k], stds[k])

        chunk["RPP"]  = z["Micro_ISA"] + z["SCE"] + z["SEI"] - z["Micro_PSA"] - z["GVI"]
        chunk["MSRI"] = z["Micro_PSA"] + z["GVI"] + z["SVF"] - z["Micro_ISA"] - z["SEI"]
        chunk["ECO"]  = z["GVI"] + z["Micro_PSA"] + z["SVF"] + z["BVI"]

        chunk.to_csv(
            FINAL_CSV, index=False,
            mode="w" if first_write else "a",
            header=first_write, encoding="utf-8-sig"
        )
        first_write = False

    pbar.close()
    return total_rows


# ===================== 8) 读城市边界（转3857） =====================
def read_city_geom_3857(shp_path):
    import geopandas as gpd
    gdf = gpd.read_file(shp_path)
    if gdf.crs is None:
        gdf = gdf.set_crs("EPSG:4326")
    gdf = gdf.to_crs("EPSG:3857")
    return gdf.unary_union


# ===================== 9) 写点图层（GeoPackage） =====================
def write_points_gpkg(city_name, df_city, out_gpkg):
    import fiona
    from shapely.geometry import Point, mapping

    out_gpkg = str(out_gpkg)
    if os.path.exists(out_gpkg):
        os.remove(out_gpkg)

    props = {"image": "str:254", "city": "str:32"}
    for col in RASTER_VARS:
        if col in df_city.columns:
            props[col] = "float"

    schema = {"geometry": "Point", "properties": props}

    with fiona.open(
        out_gpkg, mode="w", driver="GPKG",
        crs="EPSG:4326", layer="points", schema=schema
    ) as dst:
        for _, r in tqdm(df_city.iterrows(), total=len(df_city), desc=f"写点图层 {city_name}", unit="pt"):
            if not (np.isfinite(r["lon"]) and np.isfinite(r["lat"])):
                continue
            geom = mapping(Point(float(r["lon"]), float(r["lat"])))
            prop = {"image": str(r["image"]), "city": str(r["city"])}
            for col in RASTER_VARS:
                if col in df_city.columns:
                    v = r[col]
                    prop[col] = None if pd.isna(v) else float(v)
            dst.write({"geometry": geom, "properties": prop})


# ===================== 10) IDW 填充（mask内尽量无缺失） =====================
def idw_fill_mask(raw_arr, mask, transform, k=12, power=2.0, chunk_size=200_000):
    inside = (mask == 1)

    vr, vc = np.where(inside & np.isfinite(raw_arr))
    if len(vr) == 0:
        return raw_arr

    x0 = transform.c
    y0 = transform.f
    px = transform.a
    py = transform.e  # negative
    xs = x0 + (vc + 0.5) * px
    ys = y0 + (vr + 0.5) * py
    pts = np.column_stack([xs, ys]).astype(np.float64)
    vals = raw_arr[vr, vc].astype(np.float64)

    tree = cKDTree(pts)

    tr, tc = np.where(inside & (~np.isfinite(raw_arr)))
    if len(tr) == 0:
        return raw_arr

    filled = raw_arr.copy().astype(np.float32)

    for start in tqdm(range(0, len(tr), chunk_size), desc="IDW 填充", unit="cells"):
        rr = tr[start:start + chunk_size]
        cc = tc[start:start + chunk_size]

        tx = x0 + (cc + 0.5) * px
        ty = y0 + (rr + 0.5) * py
        tpts = np.column_stack([tx, ty]).astype(np.float64)

        try:
            d, idx = tree.query(tpts, k=min(k, len(vals)), workers=-1)
        except TypeError:
            d, idx = tree.query(tpts, k=min(k, len(vals)))

        if d.ndim == 1:
            d = d[:, None]
            idx = idx[:, None]

        zero = (d == 0)
        if zero.any():
            outv = np.empty(d.shape[0], dtype=np.float64)
            hit = zero.any(axis=1)
            outv[hit] = vals[idx[hit, zero[hit].argmax(axis=1)]]
            miss = ~hit
            dm = d[miss]
            im = idx[miss]
            w = 1.0 / (dm ** power + 1e-12)
            outv[miss] = (w * vals[im]).sum(axis=1) / w.sum(axis=1)
        else:
            w = 1.0 / (d ** power + 1e-12)
            outv = (w * vals[idx]).sum(axis=1) / w.sum(axis=1)

        filled[rr, cc] = outv.astype(np.float32)

    return filled


# ===================== 11) 天津：raw栅格 + count栅格 + idw栅格 =====================
def make_city_outputs(city, df_city, shp_path, out_city_dir):
    out_city_dir = Path(out_city_dir)
    raw_dir = out_city_dir / "01_raw_rasters"
    idw_dir = out_city_dir / "02_idw_rasters"
    raw_dir.mkdir(parents=True, exist_ok=True)
    idw_dir.mkdir(parents=True, exist_ok=True)

    points_gpkg = out_city_dir / "points.gpkg"
    write_points_gpkg(city, df_city, points_gpkg)

    geom_3857 = read_city_geom_3857(shp_path)
    minx, miny, maxx, maxy = geom_3857.bounds
    minx -= PAD_M; miny -= PAD_M; maxx += PAD_M; maxy += PAD_M

    def align_floor(v, s): return math.floor(v / s) * s
    def align_ceil(v, s):  return math.ceil(v / s) * s
    minx = align_floor(minx, PIXEL_SIZE_M)
    miny = align_floor(miny, PIXEL_SIZE_M)
    maxx = align_ceil(maxx, PIXEL_SIZE_M)
    maxy = align_ceil(maxy, PIXEL_SIZE_M)

    width  = int(round((maxx - minx) / PIXEL_SIZE_M))
    height = int(round((maxy - miny) / PIXEL_SIZE_M))
    transform = from_origin(minx, maxy, PIXEL_SIZE_M, PIXEL_SIZE_M)

    mask = rasterize(
        [(geom_3857, 1)],
        out_shape=(height, width),
        transform=transform,
        fill=0,
        dtype=np.uint8
    )

    to3857 = Transformer.from_crs("EPSG:4326", "EPSG:3857", always_xy=True)
    xs, ys = to3857.transform(
        df_city["lon"].to_numpy(dtype=np.float64),
        df_city["lat"].to_numpy(dtype=np.float64)
    )

    col = np.floor((xs - minx) / PIXEL_SIZE_M).astype(np.int32)
    row = np.floor((maxy - ys) / PIXEL_SIZE_M).astype(np.int32)
    valid = (row >= 0) & (row < height) & (col >= 0) & (col < width)

    if valid.sum() == 0:
        print(f"[警告] {city}：点全部落在栅格外，检查边界/坐标解析")
        return

    row = row[valid]
    col = col[valid]
    idx = (row.astype(np.int64) * width + col.astype(np.int64))

    profile = {
        "driver": "GTiff",
        "height": height,
        "width": width,
        "count": 1,
        "dtype": "float32",
        "crs": "EPSG:3857",
        "transform": transform,
        "nodata": -9999.0,
        "compress": "DEFLATE",
        "tiled": True,
        "blockxsize": 256,
        "blockysize": 256,
    }

    cnt_flat = np.bincount(idx, minlength=height * width).astype(np.float32)
    cnt_arr = cnt_flat.reshape((height, width))
    cnt_arr[mask == 0] = np.nan
    with rasterio.open(raw_dir / "count.tif", "w", **profile) as dst:
        dst.write(np.where(np.isfinite(cnt_arr), cnt_arr, -9999.0).astype(np.float32), 1)

    for var in RASTER_VARS:
        if var not in df_city.columns:
            continue

        vals = pd.to_numeric(df_city[var], errors="coerce").to_numpy(dtype=np.float64)[valid]
        ok = np.isfinite(vals)
        if ok.sum() == 0:
            print(f"[跳过] {city}-{var}: 全空")
            continue

        idx_ok = idx[ok]
        vals_ok = vals[ok]

        sum_flat = np.bincount(idx_ok, weights=vals_ok, minlength=height * width).astype(np.float64)
        cnt_flat2 = np.bincount(idx_ok, minlength=height * width).astype(np.float64)

        raw_flat = np.full(height * width, np.nan, dtype=np.float64)
        has = cnt_flat2 > 0
        raw_flat[has] = sum_flat[has] / cnt_flat2[has]
        raw_arr = raw_flat.reshape((height, width)).astype(np.float32)
        raw_arr[mask == 0] = np.nan

        raw_path = raw_dir / f"{var}.tif"
        with rasterio.open(raw_path, "w", **profile) as dst:
            dst.write(np.where(np.isfinite(raw_arr), raw_arr, -9999.0).astype(np.float32), 1)

        idw_arr = idw_fill_mask(
            raw_arr, mask, transform,
            k=IDW_K, power=IDW_POWER, chunk_size=IDW_CHUNK
        )
        idw_arr[mask == 0] = np.nan

        idw_path = idw_dir / f"{var}.tif"
        with rasterio.open(idw_path, "w", **profile) as dst:
            dst.write(np.where(np.isfinite(idw_arr), idw_arr, -9999.0).astype(np.float32), 1)

        f = np.isfinite(raw_arr)
        g = np.isfinite(idw_arr)
        print(f"[{city}-{var}] raw_valid={int(f.sum())}  idw_valid={int(g.sum())}")

    print(f"✅ {city} 输出完成：{out_city_dir}")


# ===================== 12) 主流程 =====================
def main():
    Path(OUT_ROOT).mkdir(parents=True, exist_ok=True)

    kept, means, stds = pass1_raw_and_stats(IN_CSVS)
    print(f"Pass1完成：天津记录数（两表合计）={kept}  raw={TMP_RAW_CSV}")

    total = pass2_final(means, stds)
    print(f"Pass2完成：final行数={total}  final={FINAL_CSV}")

    df = pd.read_csv(FINAL_CSV, encoding="utf-8-sig", low_memory=False)
    df["city"] = CITY_NAME
    df["lon"] = pd.to_numeric(df["lon"], errors="coerce")
    df["lat"] = pd.to_numeric(df["lat"], errors="coerce")
    df = df.dropna(subset=["lon", "lat"])

    out_city_dir = Path(OUT_ROOT) / CITY_NAME
    print(f"\n=== {CITY_NAME} 点数: {len(df)} ===")
    make_city_outputs(
        city=CITY_NAME,
        df_city=df,
        shp_path=CITY_SHP,
        out_city_dir=out_city_dir
    )

    print("\n全部完成 ✅ 输出目录：", OUT_ROOT)


if __name__ == "__main__":
    main()
