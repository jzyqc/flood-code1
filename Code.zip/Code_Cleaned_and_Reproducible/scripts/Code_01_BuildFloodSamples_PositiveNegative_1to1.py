# -*- coding: utf-8 -*-
"""
六城市洪水正负样本构建（1:1）
规则：
1. 读取每个城市洪水正样本点 shp
2. 读取每个城市 ECO.tif，判断街景有效区/无效区
3. 统计正样本落在“有效区/无效区”的数量比例
4. 按相同比例生成负样本（总数 = 正样本数，1:1）
5. 负样本需满足：
   - 在城市边界内
   - 与所有正样本保持最小缓冲距离
   - 与已生成负样本保持最小间距
   - 分层落在有效区/无效区
6. 输出每个城市最终点 shp，字段 label：正样本=1，负样本=0

依赖：
pip install geopandas rasterio shapely pyproj numpy pandas fiona rtree
"""

import os
import math
import random
from pathlib import Path

import numpy as np
import pandas as pd
import geopandas as gpd
import rasterio
from rasterio.features import geometry_mask
from shapely.geometry import Point
from shapely.ops import unary_union
from shapely.prepared import prep


# ========================= 配置区 =========================

# 六个城市边界 shp 所在目录
CITY_BOUNDARY_DIR = r"E:\中国特大城市洪水\全部市图层"

# 输出目录
OUT_DIR = r"E:\中国特大城市洪水\全部最终洪水点图层_含正负样本"

# 缓冲与抽样参数（单位：米；最终统一到 EPSG:3857 下处理）
MIN_DIST_TO_POS_M = 120.0      # 负样本到任意正样本的最小距离
MIN_DIST_BETWEEN_NEG_M = 120.0 # 负样本之间最小距离
MAX_RANDOM_ATTEMPTS = 300000   # 每层最多尝试次数
RANDOM_SEED = 20250218

# 城市配置
# 北京 ECO 路径你没单独给，我按常规目录名先写成“北京市数据\ECO.tif”
# 如果你的北京路径不同，请只改 eco 这一行即可
CITY_CONFIG = {
    "北京": {
        "point": r"E:\中国特大城市洪水\北京洪水.shp",
        "eco":   r"E:\中国特大城市洪水\北京市数据\ECO.tif",
        "boundary_keywords": ["北京", "北京市"],
    },
    "成都": {
        "point": r"E:\中国特大城市洪水\成都市.shp",
        "eco":   r"E:\中国特大城市洪水\成都市数据\ECO.tif",
        "boundary_keywords": ["成都", "成都市"],
    },
    "广州": {
        "point": r"E:\中国特大城市洪水\广州洪水.shp",
        "eco":   r"E:\中国特大城市洪水\广州市数据\ECO.tif",
        "boundary_keywords": ["广州", "广州市"],
    },
    "上海": {
        "point": r"E:\中国特大城市洪水\上海洪水.shp",
        "eco":   r"E:\中国特大城市洪水\上海市数据\ECO.tif",
        "boundary_keywords": ["上海", "上海市"],
    },
    "深圳": {
        "point": r"E:\中国特大城市洪水\深圳洪水.shp",
        "eco":   r"E:\中国特大城市洪水\深圳市数据\ECO.tif",
        "boundary_keywords": ["深圳", "深圳市"],
    },
    "天津": {
        "point": r"E:\中国特大城市洪水\天津洪水.shp",
        "eco":   r"E:\中国特大城市洪水\天津市数据\ECO.tif",
        "boundary_keywords": ["天津", "天津市"],
    },
}


# ========================= 通用函数 =========================

def ensure_dir(path):
    Path(path).mkdir(parents=True, exist_ok=True)

def find_boundary_shp(city_name, keywords, shp_dir):
    shp_dir = Path(shp_dir)
    all_shps = list(shp_dir.rglob("*.shp"))
    candidates = []

    for p in all_shps:
        stem = p.stem
        if any(k in stem for k in keywords):
            score = 0
            for k in keywords:
                if k in stem:
                    score += 2
            if "边界" in stem:
                score += 1
            if "行政" in stem:
                score += 1
            if "区域" in stem:
                score += 1
            score -= len(stem) * 0.01
            candidates.append((score, str(p)))

    if not candidates:
        raise FileNotFoundError(f"找不到 {city_name} 对应的城市边界 shp，请检查目录：{shp_dir}")

    candidates.sort(reverse=True)
    return candidates[0][1]

def to_3857(gdf):
    if gdf.crs is None:
        gdf = gdf.set_crs("EPSG:4326", allow_override=True)
    return gdf.to_crs("EPSG:3857")

def read_boundary_3857(boundary_shp):
    gdf = gpd.read_file(boundary_shp)
    if gdf.empty:
        raise RuntimeError(f"城市边界为空：{boundary_shp}")
    gdf = to_3857(gdf)
    geom = gdf.geometry.unary_union
    if geom.is_empty:
        raise RuntimeError(f"城市边界几何为空：{boundary_shp}")
    return geom

def read_points_3857(point_shp):
    gdf = gpd.read_file(point_shp)
    if gdf.empty:
        raise RuntimeError(f"正样本点为空：{point_shp}")

    if gdf.crs is None:
        gdf = gdf.set_crs("EPSG:4326", allow_override=True)
    gdf = gdf.to_crs("EPSG:3857")

    # 仅保留点
    gdf = gdf[gdf.geometry.notnull()].copy()
    gdf = gdf[gdf.geometry.type.isin(["Point", "MultiPoint"])].copy()
    if gdf.empty:
        raise RuntimeError(f"正样本点图层中没有有效点：{point_shp}")

    # MultiPoint 拆开
    gdf = gdf.explode(index_parts=False).reset_index(drop=True)
    return gdf

def sample_raster_validity_at_points(points_gdf_3857, eco_tif):
    """
    在正样本点位置读取 ECO.tif：
    有有限值 -> 1（街景有效）
    nodata / nan -> 0（街景无效）
    """
    with rasterio.open(eco_tif) as src:
        # 栅格转到点坐标 CRS
        if src.crs is None:
            raise RuntimeError(f"ECO.tif 缺少 CRS：{eco_tif}")

        pts = points_gdf_3857.to_crs(src.crs)
        coords = [(geom.x, geom.y) for geom in pts.geometry]
        vals = list(src.sample(coords))

        out = []
        nodata = src.nodata
        for v in vals:
            vv = v[0]
            if nodata is not None and vv == nodata:
                out.append(0)
            elif np.isfinite(vv):
                out.append(1)
            else:
                out.append(0)
        return np.array(out, dtype=np.uint8)

def raster_masks_from_boundary(eco_tif, boundary_geom_3857):
    """
    生成：
    1) 城市边界内像元 mask
    2) 街景有效像元 mask（ECO 有值）
    3) 街景无效像元 mask（ECO 无值）
    全部在 ECO 栅格网格上
    """
    with rasterio.open(eco_tif) as src:
        if src.crs is None:
            raise RuntimeError(f"ECO.tif 缺少 CRS：{eco_tif}")

        boundary_in_raster_crs = gpd.GeoSeries([boundary_geom_3857], crs="EPSG:3857").to_crs(src.crs).iloc[0]

        data = src.read(1)
        nodata = src.nodata

        city_mask = ~geometry_mask(
            [boundary_in_raster_crs],
            transform=src.transform,
            invert=False,
            out_shape=(src.height, src.width)
        )

        if nodata is not None:
            valid_data = np.isfinite(data) & (data != nodata)
        else:
            valid_data = np.isfinite(data)

        valid_mask = city_mask & valid_data
        invalid_mask = city_mask & (~valid_data)

        return {
            "transform": src.transform,
            "crs": src.crs,
            "width": src.width,
            "height": src.height,
            "city_mask": city_mask,
            "valid_mask": valid_mask,
            "invalid_mask": invalid_mask,
        }

def mask_to_candidate_points(mask, transform):
    """
    把 True 像元转成像元中心点坐标（栅格 CRS 下）
    """
    rows, cols = np.where(mask)
    if len(rows) == 0:
        return np.empty((0, 2), dtype=np.float64)

    xs, ys = rasterio.transform.xy(transform, rows, cols, offset="center")
    pts = np.column_stack([np.array(xs, dtype=np.float64), np.array(ys, dtype=np.float64)])
    return pts

def thinning_points(points_xy, min_dist):
    """
    简单网格法去重/稀疏化，避免候选点过密
    """
    if len(points_xy) == 0:
        return points_xy

    grid = {}
    kept = []
    cell = min_dist

    for x, y in points_xy:
        gx = int(math.floor(x / cell))
        gy = int(math.floor(y / cell))

        ok = True
        for ix in range(gx - 1, gx + 2):
            for iy in range(gy - 1, gy + 2):
                if (ix, iy) in grid:
                    for px, py in grid[(ix, iy)]:
                        if (x - px) ** 2 + (y - py) ** 2 < min_dist ** 2:
                            ok = False
                            break
                    if not ok:
                        break
            if not ok:
                break

        if ok:
            kept.append((x, y))
            grid.setdefault((gx, gy), []).append((x, y))

    return np.array(kept, dtype=np.float64)

def build_spatial_index_points(points_xy, cell_size):
    grid = {}
    for x, y in points_xy:
        gx = int(math.floor(x / cell_size))
        gy = int(math.floor(y / cell_size))
        grid.setdefault((gx, gy), []).append((x, y))
    return grid

def is_far_enough(x, y, grid, min_dist, cell_size):
    gx = int(math.floor(x / cell_size))
    gy = int(math.floor(y / cell_size))
    d2 = min_dist ** 2
    for ix in range(gx - 1, gx + 2):
        for iy in range(gy - 1, gy + 2):
            if (ix, iy) in grid:
                for px, py in grid[(ix, iy)]:
                    if (x - px) ** 2 + (y - py) ** 2 < d2:
                        return False
    return True

def add_point_to_grid(x, y, grid, cell_size):
    gx = int(math.floor(x / cell_size))
    gy = int(math.floor(y / cell_size))
    grid.setdefault((gx, gy), []).append((x, y))

def generate_negative_points_from_candidates(
    candidate_xy,
    n_target,
    pos_xy,
    neg_existing_xy=None,
    min_dist_to_pos=120.0,
    min_dist_between_neg=120.0,
    random_seed=42
):
    """
    从候选点集合中抽样负样本，满足：
    - 与正样本最小距离
    - 与已有负样本/新负样本最小距离
    """
    rng = np.random.default_rng(random_seed)

    if neg_existing_xy is None:
        neg_existing_xy = np.empty((0, 2), dtype=np.float64)

    if len(candidate_xy) == 0:
        return np.empty((0, 2), dtype=np.float64)

    cand = candidate_xy.copy()
    rng.shuffle(cand)

    cell_size = max(min_dist_to_pos, min_dist_between_neg)
    pos_grid = build_spatial_index_points(pos_xy, cell_size)
    neg_grid = build_spatial_index_points(neg_existing_xy, cell_size)

    chosen = []

    for x, y in cand:
        if not is_far_enough(x, y, pos_grid, min_dist_to_pos, cell_size):
            continue
        if not is_far_enough(x, y, neg_grid, min_dist_between_neg, cell_size):
            continue

        chosen.append((x, y))
        add_point_to_grid(x, y, neg_grid, cell_size)

        if len(chosen) >= n_target:
            break

    return np.array(chosen, dtype=np.float64)

def make_gdf_from_xy(points_xy, crs, city_name, label):
    geoms = [Point(x, y) for x, y in points_xy]
    gdf = gpd.GeoDataFrame(
        {
            "city": [city_name] * len(geoms),
            "label": [label] * len(geoms),
        },
        geometry=geoms,
        crs=crs
    )
    return gdf

def safe_int_split(total, ratio_a):
    a = int(round(total * ratio_a))
    a = max(0, min(total, a))
    b = total - a
    return a, b


# ========================= 主逻辑 =========================

def process_one_city(city_name, cfg):
    print(f"\n{'='*25} 开始处理：{city_name} {'='*25}")

    point_shp = cfg["point"]
    eco_tif = cfg["eco"]
    boundary_shp = find_boundary_shp(city_name, cfg["boundary_keywords"], CITY_BOUNDARY_DIR)

    if not os.path.exists(point_shp):
        raise FileNotFoundError(f"{city_name} 正样本点不存在：{point_shp}")
    if not os.path.exists(eco_tif):
        raise FileNotFoundError(f"{city_name} ECO.tif 不存在：{eco_tif}")
    if not os.path.exists(boundary_shp):
        raise FileNotFoundError(f"{city_name} 城市边界不存在：{boundary_shp}")

    print(f"[1] 正样本点：{point_shp}")
    print(f"[2] ECO栅格：{eco_tif}")
    print(f"[3] 城市边界：{boundary_shp}")

    # 读取数据
    boundary_geom_3857 = read_boundary_3857(boundary_shp)
    pos_gdf_3857 = read_points_3857(point_shp)

    # 只保留边界内正样本
    prepared_boundary = prep(boundary_geom_3857)
    pos_gdf_3857 = pos_gdf_3857[pos_gdf_3857.geometry.apply(lambda g: prepared_boundary.contains(g) or prepared_boundary.intersects(g))].copy()
    pos_gdf_3857 = pos_gdf_3857.reset_index(drop=True)

    if pos_gdf_3857.empty:
        raise RuntimeError(f"{city_name}：城市边界内没有正样本点")

    # 去重：同坐标重复点只保留一个
    pos_gdf_3857["x"] = pos_gdf_3857.geometry.x.round(3)
    pos_gdf_3857["y"] = pos_gdf_3857.geometry.y.round(3)
    pos_gdf_3857 = pos_gdf_3857.drop_duplicates(subset=["x", "y"]).copy().reset_index(drop=True)
    pos_xy = pos_gdf_3857[["x", "y"]].to_numpy(dtype=np.float64)
    n_pos = len(pos_gdf_3857)

    print(f"[4] 边界内正样本数：{n_pos}")

    # 统计正样本街景有效/无效
    pos_validity = sample_raster_validity_at_points(pos_gdf_3857, eco_tif)
    n_pos_valid = int((pos_validity == 1).sum())
    n_pos_invalid = int((pos_validity == 0).sum())

    ratio_valid = n_pos_valid / n_pos if n_pos > 0 else 1.0
    ratio_invalid = n_pos_invalid / n_pos if n_pos > 0 else 0.0

    print(f"[5] 正样本中街景有效：{n_pos_valid}")
    print(f"[6] 正样本中街景无效：{n_pos_invalid}")
    print(f"[7] 有效/无效比例：{ratio_valid:.4f} / {ratio_invalid:.4f}")

    # 目标负样本数量（1:1）
    n_neg_total = n_pos
    n_neg_valid, n_neg_invalid = safe_int_split(n_neg_total, ratio_valid)

    print(f"[8] 目标负样本总数：{n_neg_total}")
    print(f"[9] 其中有效区负样本：{n_neg_valid}")
    print(f"[10] 其中无效区负样本：{n_neg_invalid}")

    # ECO栅格生成候选区
    masks = raster_masks_from_boundary(eco_tif, boundary_geom_3857)

    valid_candidates = mask_to_candidate_points(masks["valid_mask"], masks["transform"])
    invalid_candidates = mask_to_candidate_points(masks["invalid_mask"], masks["transform"])

    # 候选点统一转到 3857
    if str(masks["crs"]).upper() != "EPSG:3857":
        valid_gs = gpd.GeoSeries([Point(x, y) for x, y in valid_candidates], crs=masks["crs"]).to_crs("EPSG:3857")
        invalid_gs = gpd.GeoSeries([Point(x, y) for x, y in invalid_candidates], crs=masks["crs"]).to_crs("EPSG:3857")
        valid_candidates = np.column_stack([valid_gs.x.values, valid_gs.y.values]) if len(valid_gs) else np.empty((0, 2))
        invalid_candidates = np.column_stack([invalid_gs.x.values, invalid_gs.y.values]) if len(invalid_gs) else np.empty((0, 2))

    # 用最小间距做一次稀疏化，减少候选点过密
    valid_candidates = thinning_points(valid_candidates, MIN_DIST_BETWEEN_NEG_M)
    invalid_candidates = thinning_points(invalid_candidates, MIN_DIST_BETWEEN_NEG_M)

    print(f"[11] 有效区候选点数：{len(valid_candidates)}")
    print(f"[12] 无效区候选点数：{len(invalid_candidates)}")

    # 先在有效区抽
    neg_valid_xy = generate_negative_points_from_candidates(
        candidate_xy=valid_candidates,
        n_target=n_neg_valid,
        pos_xy=pos_xy,
        neg_existing_xy=np.empty((0, 2), dtype=np.float64),
        min_dist_to_pos=MIN_DIST_TO_POS_M,
        min_dist_between_neg=MIN_DIST_BETWEEN_NEG_M,
        random_seed=RANDOM_SEED + 11
    )

    # 再在无效区抽
    neg_invalid_xy = generate_negative_points_from_candidates(
        candidate_xy=invalid_candidates,
        n_target=n_neg_invalid,
        pos_xy=pos_xy,
        neg_existing_xy=neg_valid_xy,
        min_dist_to_pos=MIN_DIST_TO_POS_M,
        min_dist_between_neg=MIN_DIST_BETWEEN_NEG_M,
        random_seed=RANDOM_SEED + 29
    )

    # 如果某一层抽不够，允许从另一层补齐，但仍保持全域建模
    neg_xy = np.vstack([neg_valid_xy, neg_invalid_xy]) if len(neg_valid_xy) or len(neg_invalid_xy) else np.empty((0, 2))
    lack = n_neg_total - len(neg_xy)

    if lack > 0:
        print(f"[警告] {city_name} 分层抽样后还差 {lack} 个负样本，开始从全域候选区补齐。")

        all_candidates = np.vstack([valid_candidates, invalid_candidates]) if len(valid_candidates) or len(invalid_candidates) else np.empty((0, 2))

        neg_extra_xy = generate_negative_points_from_candidates(
            candidate_xy=all_candidates,
            n_target=lack,
            pos_xy=pos_xy,
            neg_existing_xy=neg_xy,
            min_dist_to_pos=MIN_DIST_TO_POS_M,
            min_dist_between_neg=MIN_DIST_BETWEEN_NEG_M,
            random_seed=RANDOM_SEED + 77
        )

        if len(neg_extra_xy) > 0:
            neg_xy = np.vstack([neg_xy, neg_extra_xy])

    if len(neg_xy) < n_neg_total:
        print(f"[警告] {city_name} 最终仅生成 {len(neg_xy)} 个负样本，少于目标 {n_neg_total}。建议调小缓冲距离。")

    # 负样本裁到最终数量
    neg_xy = neg_xy[:n_neg_total]

    print(f"[13] 最终负样本数：{len(neg_xy)}")

    # 构建输出
    pos_out = make_gdf_from_xy(pos_xy, "EPSG:3857", city_name, 1)
    neg_out = make_gdf_from_xy(neg_xy, "EPSG:3857", city_name, 0)

    final_gdf = pd.concat([pos_out, neg_out], ignore_index=True)
    final_gdf = gpd.GeoDataFrame(final_gdf, geometry="geometry", crs="EPSG:3857").to_crs("EPSG:4326")

    # 增加 id 字段
    final_gdf.insert(0, "pid", range(1, len(final_gdf) + 1))

    # 输出 shp
    ensure_dir(OUT_DIR)
    out_shp = os.path.join(OUT_DIR, f"{city_name}_洪水正负样本.shp")

    # 删除旧文件（shp 一套文件）
    for ext in [".shp", ".shx", ".dbf", ".prj", ".cpg"]:
        p = out_shp.replace(".shp", ext)
        if os.path.exists(p):
            os.remove(p)

    final_gdf.to_file(out_shp, driver="ESRI Shapefile", encoding="utf-8")

    print(f"[14] 输出完成：{out_shp}")
    print(f"{city_name} 处理结束。")


def main():
    random.seed(RANDOM_SEED)
    np.random.seed(RANDOM_SEED)
    ensure_dir(OUT_DIR)

    print("开始批量生成六城市洪水正负样本...")
    print(f"输出目录：{OUT_DIR}")
    print(f"负样本比例：1:1")
    print(f"负样本到正样本最小距离：{MIN_DIST_TO_POS_M} m")
    print(f"负样本之间最小距离：{MIN_DIST_BETWEEN_NEG_M} m")

    failed = []

    for city_name, cfg in CITY_CONFIG.items():
        try:
            process_one_city(city_name, cfg)
        except Exception as e:
            print(f"\n[失败] {city_name}：{e}")
            failed.append((city_name, str(e)))

    print("\n" + "=" * 60)
    print("全部处理完成。")
    if failed:
        print("以下城市失败：")
        for c, msg in failed:
            print(f"- {c}: {msg}")
    else:
        print("全部城市成功。")


if __name__ == "__main__":
    main()