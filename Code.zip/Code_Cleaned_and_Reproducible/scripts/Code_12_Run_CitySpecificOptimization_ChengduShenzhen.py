# -*- coding: utf-8 -*-
"""
Complete multi-algorithm, main-model-based cascade adaptation optimization.

Outputs all plotting/data products requested:
1) decision-variable results before/after optimization;
2) Pareto front solutions for every city and algorithm;
3) convergence curves for every city and algorithm;
4) algorithm-comparison summary and selected best algorithm;
5) final S0-S7 scenario rasters with short names: S0_F1.tif, S7_NDVI.tif, etc.;
6) intervention-area table and decision-variable-change table.

Required external packages:
    pip install rasterio geopandas joblib pymoo scipy pandas numpy

Important scientific design:
- Baseline target rasters are read from each city folder's 03_target_grids_smoothed.
- Optimization uses a fixed final main model if MODEL_PACKAGE_PATH/MODEL_ROOT can be loaded.
- If your model package uses custom classes, run this script in the original training project/environment.
- Optimization results are model-consistent counterfactual adaptation potentials, not causal proof.
"""

import os
import sys
import glob
import json
import time
import warnings
import gc
from pathlib import Path
from dataclasses import dataclass
from typing import Dict, Tuple, Optional

import numpy as np
import pandas as pd

try:
    from tqdm.auto import tqdm
except Exception:
    tqdm = None

try:
    from sklearn.preprocessing import StandardScaler
except Exception:
    StandardScaler = None

import rasterio
from rasterio.enums import Resampling
from rasterio.warp import reproject
from rasterio.features import geometry_mask
from affine import Affine
from scipy.ndimage import uniform_filter, gaussian_filter, distance_transform_edt
from scipy.spatial import cKDTree

try:
    import geopandas as gpd
except Exception:
    gpd = None

try:
    import joblib
except Exception:
    joblib = None

# ----- pymoo imports -----
# The previous version put all pymoo imports in one try-block.
# If pymoo was missing, ElementwiseProblem was never defined and the script crashed at class definition.
# This block keeps the script syntactically valid and gives a clear installation/version message.
PYMOO_AVAILABLE = False
PYMOO_IMPORT_ERROR = None
ElementwiseProblem = None
Callback = object
try:
    try:
        from pymoo.core.problem import ElementwiseProblem
    except Exception:
        # compatibility with some old pymoo versions
        from pymoo.model.problem import ElementwiseProblem

    try:
        from pymoo.core.callback import Callback
    except Exception:
        Callback = object

    from pymoo.optimize import minimize
    from pymoo.algorithms.moo.nsga2 import NSGA2
    from pymoo.algorithms.moo.nsga3 import NSGA3
    from pymoo.algorithms.moo.moead import MOEAD

    # SPEA2 import path differs across pymoo versions.
    try:
        from pymoo.algorithms.moo.spea2 import SPEA2
    except Exception:
        from pymoo.algorithms.moo.spea2 import SPEA2

    from pymoo.util.ref_dirs import get_reference_directions
    PYMOO_AVAILABLE = True
except Exception as _pymoo_e:
    PYMOO_AVAILABLE = False
    PYMOO_IMPORT_ERROR = _pymoo_e

    class ElementwiseProblem(object):
        """Fallback placeholder so class AdaptationProblem can be defined.
        The script will stop in main() with a clear pymoo installation message.
        """
        def __init__(self, *args, **kwargs):
            raise RuntimeError(
                "pymoo is not available or cannot be imported in this environment. "
                "Install/update it before running multi-algorithm optimization. "
                f"Original import error: {PYMOO_IMPORT_ERROR}"
            )

warnings.filterwarnings("ignore")

# ============================================================
# 1. Paths and configuration
# ============================================================

CITY_DIRS = {
    "Beijing":   r"E:\中国特大城市洪水\北京市数据",
    "Chengdu":   r"E:\中国特大城市洪水\成都市数据",
    "Guangzhou": r"E:\中国特大城市洪水\广州市数据",
    "Shanghai":  r"E:\中国特大城市洪水\上海市数据",
    "Shenzhen":  r"E:\中国特大城市洪水\深圳市数据",
    "Tianjin":   r"E:\中国特大城市洪水\天津市数据",
}

CITY_CHINESE_KEYS = {
    "Beijing": ["北京", "北京市"],
    "Chengdu": ["成都", "成都市"],
    "Guangzhou": ["广州", "广州市"],
    "Shanghai": ["上海", "上海市"],
    "Shenzhen": ["深圳", "深圳市"],
    "Tianjin": ["天津", "天津市"],
}

BOUNDARY_DIR = r"E:\中国特大城市洪水\全部市图层"
CITY_MASK_FILES = {city: None for city in CITY_DIRS}

MODEL_ROOT = r"E:\中国特大城市洪水\RF_Stabilized_HydroConTex_GNNWRL_v11_robust_diagnostics"
MODEL_DIR = os.path.join(MODEL_ROOT, "models")

# v11 训练脚本默认保存位置。若你的文件名不同，直接改这里。
MODEL_PACKAGE_PATH = os.path.join(MODEL_DIR, "Final_RF_Stabilized_HydroConTex_GNNWRL_package.joblib")
STATE_DICT_PATH = os.path.join(MODEL_DIR, "Final_GNNWRL_state_dict.pt")

# 自动搜索模型包的位置。你的日志显示 v11 文件夹本身不存在或里面没有 joblib，
# 所以这里扩大到整个项目根目录搜索。
MODEL_SEARCH_ROOTS = [
    MODEL_ROOT,
    MODEL_DIR,
    r"E:\中国特大城市洪水",
    r"E:\中国特大城市洪水\pythonProject1",
]

REQUIRE_MAIN_MODEL = True
DEBUG_ALLOW_PROXY_MODEL = False   # Do not use proxy results in paper.

OUTPUT_ROOT = r"E:\中国特大城市洪水\Cascade_Optimization_V44C_TARGETED_PROBLEM_CITY_FINAL_FIXED"

ONE_ALGORITHM_MODE = True  # only run NSGA-III for runtime control

# Progress display
SHOW_PROGRESS_BARS = True
PROGRESS_UPDATE_EVERY_GEN = 1

QUICK_TEST_MODE = True
ACTIVE_CITIES = ["Beijing"]
QUICK_TEST_SCENARIOS = ["S1", "S2", "S7"]

# ============================================================
# RUN LEVEL
# ============================================================
# quick  : 单城市快速测试，几分钟级，验证代码和表格/栅格输出；
# medium : 六城市中等预算，适合看趋势和可行性；
# formal : 正式出图预算，耗时较长。
RUN_LEVEL = "formal"   # "quick", "citycheck", "medium", or "formal"

# V3: 采样优化后，对 Pareto 解进行全图复算，再按全图指标筛选 S1-S7。
FULL_RECHECK_PARETO = True
MAX_FULL_RECHECK_SOLUTIONS = 60
DEDUP_THETA_DECIMALS = 4
DEDUP_OBJECTIVE_DECIMALS = 5

# V4: 尽量避免 S1/S2/S7 选到同一个 Pareto 解。
DISTINCT_SCENARIO_SELECTION = True

# V5: 情景差异化只在“近似同等好”的候选解中进行，避免为了不同而牺牲目标一致性。
DIVERSITY_SCORE_TOLERANCE = 0.02

# V5: 按城市顺序处理，避免一次性缓存六城市全部栅格导致内存占用过高。
PROCESS_CITIES_SEQUENTIALLY = True

# V6: 长时间运行保护。每完成一个城市就写一次 partial global tables，
# 即使中途停止，也能保留已完成城市的表。
SAVE_PARTIAL_GLOBAL_AFTER_EACH_CITY = True

# V6: 用相对基准增量惩罚 CGI 过度增长，保证 S0 的 J3 逻辑上等于 1。
USE_RELATIVE_CGI_OVERGROWTH = True

# V6: 输出 sample vs full-recheck 排序一致性，用于论文/补充材料稳健性说明。
SAVE_SAMPLE_FULL_CONSISTENCY = True

# V7: 断点续跑。如果某个城市的 best_solution_by_scenario.csv 已存在，
# 默认跳过该城市，并把已有结果读回全局表，避免长时间运行中断后从头重跑。
RESUME_COMPLETED_CITIES = False
FORCE_RERUN_COMPLETED_CITIES = True

# V7: 城市输入变量诊断。用于提前发现 BH 全 0、SEL 缺失、变量全常数等问题。
SAVE_INPUT_DIAGNOSTICS = True

# V8: no-maladaptation guard. Full-recheck solutions that worsen both adaptation directions
# should not be treated as valid final scenarios.
NO_MALADAPTATION_HARD_CONSTRAINT = False
# V9: no-maladaptation is enforced at final full-recheck scenario selection, not during
# sampled optimization, because sampled J1/J2 and full-domain J1/J2 can differ strongly.
NO_MALADAPTATION_FINAL_SELECTION_ONLY = True

# V10: Add deterministic conservative policy anchors into full-recheck candidate pool.
# This prevents low-budget NSGA-III citycheck from missing safe, low-structural-change solutions.
ADD_POLICY_ANCHORS_TO_FULL_RECHECK = True

# V11: If the full-nondominated subset has no no-maladaptation candidate,
# expand selection to all full-rechecked candidates before using baseline fallback.
EXPAND_SELECTION_BEYOND_PARETO_IF_NEEDED = True

# V11: Preserve original rasters for variable groups whose theta is exactly zero.
# This prevents theta=0 policy anchors from being altered by conditional clipping.
PRESERVE_UNCHANGED_GROUPS = True
THETA_ZERO_EPS = 1e-12

# V12: Use target-anchored stable F3 as the formal J3 surface.
USE_TARGET_ANCHORED_F3_ALWAYS = True

# V12: exact zero-theta candidates are evaluated as exact S0 baseline.
EXACT_ZERO_THETA_AS_S0 = True

# V13: Named scenarios should not select a zero-change anchor as an "optimized" solution.
# If no candidate provides the required directional improvement after full-recheck, use exact S0 fallback.
REQUIRE_DIRECTIONAL_IMPROVEMENT_FOR_SCENARIOS = True
MIN_SCENARIO_IMPROVEMENT_PCT = 0.05

# V14: true scenario-specific optimization.
# S1-S7 are optimized separately according to their single-, bi-, and tri-objective definitions,
# rather than all being selected from one shared three-objective Pareto pool.
SCENARIO_SPECIFIC_OPTIMIZATION = True
SCENARIO_SPECIFIC_ALGORITHM_POLICY = "NSGA-III"  # V15: unified NSGA-III for all S1-S7 scenarios

# V15: all S1-S7 are solved by NSGA-III using a 3-component scenario-specific objective vector.
# This preserves the paper's NSGA-III methodological storyline while allowing S1/S2/S3,
# S4/S5/S6, and S7 to represent single-, bi-, and tri-objective decision preferences.
NSGAIII_SCENARIO_OBJECTIVE_MODE = "preference_encoded_3obj"
SCENARIO_CONSTRAINT_PENALTY_WEIGHT = 10.0

# FAST VERSION:
# 这个版本用于快速检查六城市 S1-S7 是否能跑通，速度优先，不作为最终论文结果。
FAST_CITYCHECK_MODE = False
FINAL_FAST_FORMAL_MODE = True

# V18 speed/stability controls
FULL_RECHECK_CACHE_ENABLED = True       # cache full-domain evaluation of the same theta within a city
PYMOO_SAVE_HISTORY = False              # large speed/memory saving; final convergence row is still saved
SAVE_CITY_TABLES_AFTER_EACH_SCENARIO = True

# V23: response-guided BGI intervention system.
# Adds a composite blue-green infrastructure decision variable theta_BGI that maps to
# existing model variables rather than adding a new predictor to the trained model:
#   theta_BGI -> NDVI↑, GVI↑, Micro_PSA↑, Micro_ISA↓
# A city-specific response audit is run before optimization to prevent blindly applying
# green/street/permeability changes where the model response is unfavorable.
RESPONSE_GUIDED_BGI_ENABLED = True
THETA_BGI_ENABLED = True
RUN_RESPONSE_AUDIT_BEFORE_OPTIMIZATION = True
RESPONSE_AUDIT_THETA = 0.60
BGI_NDVI_SHARE = 0.45
BGI_GVI_SHARE = 0.35
BGI_PSA_SHARE = 0.55
BGI_ISA_SHARE = 0.55
MIN_RESPONSE_GUIDANCE_MULTIPLIER = 0.25
MAX_RESPONSE_GUIDANCE_MULTIPLIER = 1.35

# V23 FAST settings:
# The response audit uses sampled evaluation in citycheck mode for speed.
# Formal V23 should use full evaluation.
RESPONSE_AUDIT_FAST_SAMPLE_MODE = True
V23_FAST_CITYCHECK_MODE = True

# V24 fixes:
V24_BGI_FIXED_SELECTION = True

# V25 selection correction:
# Force BGI candidates for problematic cities if strict selection still collapses to
# old anchors or S0 fallback. This is a diagnostic/fast check version.
V25_FORCE_BGI_SELECTION = True
FORCE_BGI_CANDIDATES_CITIES = ["Chengdu", "Shenzhen"]  # V32: no universal BGI forcing
FORCE_BGI_IF_STRICT_EMPTY_CITIES = ["Chengdu", "Shenzhen"]  # V32: BGI fallback only for problematic cities

# V26 targeted fast run:
# Only rerun the two problematic cities, keeping the V25 BGI-forced logic.
TARGET_CITIES_ONLY = ["Chengdu", "Shenzhen"]  # V44B fixed: only rerun problem cities
V26_TARGETED_FAST_MODE = False
V29_FINAL_ALLCITY_MODE = True

# V27 policy/causal BGI benefit correction.
# This addresses cases where the trained ML model learns city-specific correlations
# that underestimate hydraulic/ecological benefit of blue-green infrastructure.
# The correction is applied to target surfaces, not as a new model predictor.
ENABLE_POLICY_BGI_BENEFIT_CORRECTION = True
POLICY_BGI_CORRECTION_CITIES = ["Beijing", "Chengdu", "Guangzhou", "Shanghai", "Shenzhen", "Tianjin"]
BGI_F1_RISK_REDUCTION_COEF = 0.32
BGI_F2_LIVABILITY_GAIN_COEF = 0.25
BGI_EFFECT_SMOOTH_SIGMA = 1.0
BGI_EFFECT_MIN_THETA = 1e-6

# V28 robust targeted controls.
V28_ROBUST_POLICY_BGI_MODE = True
NO_BASELINE_FALLBACK_IF_BGI_CANDIDATE_EXISTS = True
MIN_SELECTED_THETA_BGI_TARGETED = 0.20

# V29 final all-city consistency controls.
V29_OUTPUT_CONSISTENCY_FIX = True
SAVE_POLICY_RAW_DIAGNOSTIC_RASTERS = False
SAVE_POLICY_EFFECT_RASTER = False
STRICT_OUTPUT_RECOMPUTE_AFTER_SELECTION = True

# V31 balanced final controls.
# This preserves V29's output-consistency fix, but avoids the 8-hour-per-city runtime.
V31_BALANCED_FINAL_MODE = True
V32_MULTIVAR_FINAL_MODE = True
SAVE_EXTRA_RAW_UNREGULARIZED_LAYERS = False

# V32 multi-variable participation controls.
# BGI is retained as a policy-corrected intervention package, but no longer forced for all cities.
# This avoids the "everything becomes BGI" problem and lets NDVI/GVI/PSA/BD/BH/LULC participate.
V32_MULTIVAR_PARTICIPATION_MODE = True
USE_RESPONSE_GUIDED_THETA_BOUNDS = True
USE_SCENARIO_VARIABLE_PREFERENCE_PENALTY = True
SCENARIO_VARIABLE_PENALTY_WEIGHT = 0.08
SCENARIO_SELECTION_VARIABLE_PENALTY_WEIGHT = 0.04

# Only problematic/ambiguous cities get BGI rescue forcing.
TARGETED_BGI_CONTROL_CITIES = ["Chengdu", "Shenzhen"]

# Minimum scenario group participation used by soft penalties, not hard constraints.
MIN_RISK_GROUP_PARTICIPATION = 0.12
MIN_LIVE_GROUP_PARTICIPATION = 0.12
MAX_STRUCTURAL_DISTURBANCE_FOR_CGI = 0.28
MIN_S7_TWO_GROUP_PARTICIPATION = 0.10

# V33 targeted fast repair controls.
V33_TARGETED_FAST_REPAIR_MODE = True
TARGET_CITIES_ONLY = ["Chengdu", "Shenzhen"]  # V44B fixed: only rerun problem cities
V33_TARGETED_REPAIR_CITIES = ["Chengdu", "Shenzhen"]
V33_FORCE_SCENARIO_ANCHOR_FOR_SHENZHEN = True
V33_PREVENT_DOUBLE_NEGATIVE_CHENGDU = True
V33_MIN_POSITIVE_IMPROVEMENT_PCT = 0.05
V33_MIN_CGI_RETENTION = 0.92
V33_SAVE_TARGETED_CANDIDATE_POOL = True

# V34 patch:
# If Chengdu has no valid V33 positive candidate, use exact baseline-preserving fallback.
# This prevents double-negative "optimization" such as Chengdu-S3 in V33.
V34_CHENGDU_NO_POSITIVE_TO_FALLBACK = True
V34_BLOCK_CHENGDU_FORCED_BGI_AFTER_FAILED_REPAIR = True

# V35 patch:
# Avoid both negative optimization and S0 fallback in targeted repair.
# This is a no-maladaptation safeguarded projection, used only for the targeted
# problematic city-scenario where all nonzero candidates were otherwise double-negative.
V35_NO_NEGATIVE_NO_FALLBACK_MODE = True
V35_NO_NEGATIVE_PROJECTION_CITIES = ["Chengdu"]
V35_NO_NEGATIVE_PROJECTION_SCENARIOS = ["S1", "S2", "S3", "S4", "S5", "S6", "S7"]
V35_NO_NEGATIVE_F1_EPS = 0.015
V35_NO_NEGATIVE_F2_EPS = 0.015
V36_FULL_SIXCITY_FINAL_MODE = True
V36_FINAL_OUTPUT_ROOT = r"E:\中国特大城市洪水\Cascade_Optimization_V44C_TARGETED_PROBLEM_CITY_FINAL_FIXED"

# V37 final repair:
# Extend no-maladaptation safeguarded projection to all Chengdu scenarios.
# This guarantees nonzero, non-negative, non-fallback Chengdu outputs in the six-city formal run.
V37_FULL_NO_NEGATIVE_REPAIR_MODE = True
V37_FORCE_CHENGDU_REPAIR_IF_FALLBACK = True

# V40 final fixes:
# 1) Add enhanced CGI/F3 diagnostics so CGI is not represented only by retention≈1.
# 2) Select S7 as the balanced comprehensive pathway after full-recheck using
#    F1 improvement, F2 improvement, CGI net score, and lower intervention intensity.
# 3) Avoid exact theta duplication between S7 and S1-S6 when a non-duplicate
#    near-best candidate exists.
V40_CGI_S7_BALANCED_FINAL_MODE = True
V40_ENHANCED_CGI_DIAGNOSTICS = True
V40_S7_BALANCED_SELECTION = True
V40_S7_USE_ALL_SCENARIO_FULL_RECHECK_BANK = True
V40_S7_AVOID_DUPLICATE_THETA = True
V40_S7_NON_DUPLICATE_MAX_SCORE_LOSS = 0.05
V40_S7_NEAR_PASS_SCORE_GAP = 0.03
V40_S7_WEIGHTS = {"F1": 0.40, "F2": 0.40, "CGI": 0.15, "LOW_INTENSITY": 0.05}
V40_S7_PROJECTION_PENALTY = 0.04
V40_S7_FALLBACK_PENALTY = 0.30
V40_S7_NEGATIVE_PENALTY = 0.25
V40_S7_ZERO_GAIN_PENALTY = 0.12
V40_CGI_TOO_STABLE_ABS_CHANGE_PCT = 0.05
V40_RETENTION_NEAR_ONE_TOL = 1e-5
V40_F3_CHANGE_ABS_TOL = 1e-6
V40_F3_CHANGE_REL_TOL = 1e-4

# V41 final stabilization:
# - create near-best full-rechecked S7 candidates to avoid directly duplicating S5/S6;
# - do not allow legacy BGI fallback/min-BGI logic to override V40/V41 S7;
# - reduce S1-S6 exact theta duplication when a valid non-duplicate alternative exists.
V41_FINAL_REPAIR_MODE = True
V41_S7_GENERATE_NEAR_BEST_CANDIDATES = True
V41_S7_NEAR_BEST_TOPK = 4
V41_S7_VARIATION_STRENGTH = 0.035
V41_S7_MAX_NEW_CANDIDATES = 20
V41_AVOID_S1_S6_DUPLICATES = True
V41_S1_S6_DUPLICATE_MAX_SCORE_LOSS = 0.12
V41_WRITE_S7_CANDIDATE_BANK = True

# V42 final S7-performance repair:
# S7 should be the balanced comprehensive pathway, not a very-low-intensity
# conservative option. It must reach a sufficient share of the city's attainable
# F1/F2 improvements in the full-rechecked candidate bank.
V42_FINAL_S7_PERFORMANCE_FLOOR_MODE = True
V42_S7_REQUIRE_PERFORMANCE_FLOOR = True
V42_S7_F1_FLOOR_RATIO = 0.70
V42_S7_F2_FLOOR_RATIO = 0.70
V42_S7_FLOOR_RELAXED_RATIO = 0.60
V42_S7_FLOOR_PENALTY_WEIGHT = 0.55
V42_S7_HARD_FILTER_FIRST = True
V42_S7_MIN_BGI_FOR_TARGETED_CITIES = 0.20
V42_S7_TARGETED_CITIES = ["Chengdu", "Shenzhen"]
V42_ADD_TARGETED_S7_ANCHORS = True
V42_WRITE_S7_FLOOR_DIAGNOSTICS = True

# V43 final one-run stabilization.
# The key addition is a final self-correcting S7 selector:
# it creates blended candidates from the already selected S1-S6 pathways,
# evaluates them full-domain, then validates that S7 is high-performing,
# non-negative, no-fallback, and preferably non-duplicate.
V43_FINAL_ONE_RUN_STABLE_MODE = True
V43_ADD_SELECTED_SCENARIO_BLEND_S7 = True
V43_MAX_SELECTED_BLEND_CANDIDATES = 24
V43_S7_FINAL_VALIDATION = True
V43_S7_ALLOWED_SCORE_GAP = 0.03
V43_S7_REQUIRE_TOP_RANK_OR_NEAR = True
V43_S7_TARGETED_BGI_MIN = 0.20
V43_S7_TARGETED_BGI_PENALTY = 0.20
V43_S7_STRICT_NONNEGATIVE = True
V43_S7_WRITE_FINAL_SELECTION_AUDIT = True

# V44 targeted rerun mode.
# This reruns only Chengdu and Shenzhen and separates final selected-scenario
# quality from candidate-pool/high-intensity warnings.
V44_TARGETED_PROBLEM_CITY_MODE = True
V44_PROBLEM_CITIES = ["Chengdu", "Shenzhen"]
V44_SPLIT_FINAL_PASS_AND_WARNINGS = True

# V44B hard override: prevents older V36 all-city assignment from taking effect.
V44B_TARGET_CITY_OVERRIDE_FIXED = True
V44B_ONLY_CITIES = ["Chengdu", "Shenzhen"]

V35_REPAIR_THETA = {
    # Chengdu scenario-specific no-negative repair theta.
    # These are low-to-moderate intensity, structurally conservative BGI pathways.
    ("Chengdu", "S1"): [0.05, 0.05, 0.70, 0.00, 0.00, 0.02, 0.90],  # risk-oriented permeable/BGI
    ("Chengdu", "S2"): [0.50, 0.55, 0.15, 0.00, 0.00, 0.00, 0.90],  # livability-oriented green/street/BGI
    ("Chengdu", "S3"): [0.08, 0.08, 0.12, 0.00, 0.00, 0.00, 0.70],  # CGI-retention conservative BGI
    ("Chengdu", "S4"): [0.35, 0.35, 0.45, 0.00, 0.00, 0.00, 0.90],  # risk + livability mixed BGI
    ("Chengdu", "S5"): [0.08, 0.05, 0.60, 0.00, 0.00, 0.00, 0.85],  # risk + CGI low-structural disturbance
    ("Chengdu", "S6"): [0.50, 0.50, 0.10, 0.00, 0.00, 0.00, 0.80],  # livability + CGI low-structural disturbance
    ("Chengdu", "S7"): [0.25, 0.25, 0.30, 0.00, 0.00, 0.00, 0.90],  # balanced repair
}
TARGETED_BGI_FALLBACK_THETA = {
    "Beijing":   [0.10, 0.10, 0.10, 0.00, 0.00, 0.00, 0.70],
    "Chengdu":   [0.15, 0.15, 0.15, 0.00, 0.00, 0.00, 0.85],
    "Guangzhou": [0.10, 0.10, 0.10, 0.00, 0.00, 0.00, 0.70],
    "Shanghai":  [0.10, 0.10, 0.10, 0.00, 0.00, 0.00, 0.70],
    "Shenzhen":  [0.10, 0.10, 0.10, 0.00, 0.00, 0.00, 0.75],
    "Tianjin":   [0.10, 0.10, 0.10, 0.00, 0.00, 0.00, 0.70],
}
FORCE_FULL_RESPONSE_AUDIT_CITIES = []  # V31: sample-fast response audit for speed
DISABLE_POLICY_ANCHORS_FOR_CITIES = ["Shenzhen"]  # keep Shenzhen away from old A07 anchor collapse
BGI_RESCUE_ONLY_CITIES = ["Chengdu"]
PREFER_BGI_CANDIDATES_CITIES = ["Chengdu", "Shenzhen"]  # V32: BGI preference only for problematic cities
CITY_SPECIFIC_DIVERSITY_SCORE_TOLERANCE = {"Beijing": 0.06, "Chengdu": 0.20, "Guangzhou": 0.06, "Shanghai": 0.06, "Shenzhen": 0.20, "Tianjin": 0.06}

# V16: policy anchors are used only as rescue/fallback candidates.
# The selector first tries real NSGA-III candidates; anchors are considered only if
# no non-anchor candidate satisfies scenario-specific directional constraints.
ANCHORS_AS_FALLBACK_ONLY = True

# V16: quality diagnostics distinguish true raster/decision duplicates
# using theta values, not scenario-prefixed solution IDs.
TRUE_DUPLICATE_BY_THETA = True

# V8: if a city/scenario has no valid improvement candidate after full-recheck,
# save an exact S0-copy as scenario fallback and mark it in tables.
BASELINE_FALLBACK_ON_NO_VALID_DIRECTION = True

# V8: protect high baseline CGI cores from LULC conversion. This is designed to fix cases
# like Tianjin where tiny LULC conversions can collapse CGI retention because F3 is concentrated.
PROTECT_HIGH_CGI_FROM_LULC = True
CGI_PROTECTION_Q_FOR_LULC = 80


TARGET_SMOOTH_DIR_NAME = "03_target_grids_smoothed"
CONTEXT_DIR_NAME = "02_content_context_integrals"
SCENARIO_NAME = "BAU"
RANDOM_SEED = 2026

# ============================================================
# Memory-safe working grid
# ============================================================
# 你的北京栅格约 15660×20287，单个 float32 图层约 1.27 GB。
# 如果直接在原始分辨率读取 20+ 个变量，内存会爆。
# 因此优化阶段统一在降采样工作网格上运行，并输出同一工作网格下的 S0-S7 栅格。
# 10 表示行列各缩小 10 倍，像元数约缩小 100 倍。
# 如果你内存很大可以改成 5；如果还爆内存改成 12 或 15。
WORKING_SCALE_FACTOR = 20

# 不再使用 distance_transform_edt 最近邻补洞。它会为大栅格额外生成二维索引数组，
# 北京原始尺寸下会一次性申请数 GB 内存。
USE_DISTANCE_TRANSFORM_FILL = False

# 最近邻补洞使用 cKDTree 分块查询，不使用 distance_transform_edt(return_indices=True)。
# 这样仍然是最近邻，但不会一次性生成 (2, rows, cols) 的巨大索引数组。
MAX_NEAREST_QUERY_CHUNK = 500_000

MODEL_FEATURES = [
    "Rx1day", "Rx5day", "CWD", "EV", "SL", "PRC", "TWI", "TPI", "ST",
    "NDVI", "LULC", "BD", "PD", "BH", "BVI", "CFI", "FOE", "GVI",
    "Micro_ISA", "Micro_PSA", "SCE", "SEL", "SVF", "TAE"
]
DECISION_RESPONSE_VARS = ["NDVI", "GVI", "Micro_PSA", "Micro_ISA", "BD", "BH", "LULC"]

# Algorithm settings
ALGORITHMS = ["NSGA-III"]
POP_SIZE = 16
N_GENERATIONS = 5
N_REF_PARTITIONS = 3
MAX_OPT_SAMPLE_PIXELS = 5000
PREDICT_CHUNK_SIZE = 250000
USE_GLOBAL_SELECTED_ALGORITHM = True

def apply_run_level_preset():
    """
    调级入口：只改 RUN_LEVEL 就能切换运行预算。

    quick     : 北京单城市快速测试；
    citycheck : 六城市极低预算检查路径、变量、mask、输出是否完整；
    medium    : 六城市中等预算，正式前主要检查；
    formal    : 正式出图预算。
    """
    global QUICK_TEST_MODE, ACTIVE_CITIES, QUICK_TEST_SCENARIOS
    global POP_SIZE, N_GENERATIONS, N_REF_PARTITIONS, MAX_OPT_SAMPLE_PIXELS, WORKING_SCALE_FACTOR
    global OUTPUT_ROOT, MAX_FULL_RECHECK_SOLUTIONS

    if RUN_LEVEL == "quick":
        QUICK_TEST_MODE = True
        ACTIVE_CITIES = ["Beijing"]
        QUICK_TEST_SCENARIOS = ["S1", "S2", "S7"]
        POP_SIZE = 10
        N_GENERATIONS = 3
        N_REF_PARTITIONS = 3
        MAX_OPT_SAMPLE_PIXELS = 2500
        WORKING_SCALE_FACTOR = 28
        MAX_FULL_RECHECK_SOLUTIONS = 10
        OUTPUT_ROOT = r"E:\中国特大城市洪水\Cascade_Optimization_V44_TARGETED_QUICK_TEST"

    elif RUN_LEVEL == "citycheck":
        QUICK_TEST_MODE = False
        ACTIVE_CITIES = list(CITY_DIRS.keys())
        QUICK_TEST_SCENARIOS = [f"S{i}" for i in range(1, 8)]
        POP_SIZE = 18
        N_GENERATIONS = 7
        N_REF_PARTITIONS = 4
        MAX_OPT_SAMPLE_PIXELS = 7000
        WORKING_SCALE_FACTOR = 20
        MAX_FULL_RECHECK_SOLUTIONS = 10
        OUTPUT_ROOT = r"E:\中国特大城市洪水\Cascade_Optimization_V44C_TARGETED_PROBLEM_CITY_FINAL_FIXED"

    elif RUN_LEVEL == "medium":
        QUICK_TEST_MODE = False
        ACTIVE_CITIES = list(CITY_DIRS.keys())
        QUICK_TEST_SCENARIOS = [f"S{i}" for i in range(1, 8)]
        POP_SIZE = 24
        N_GENERATIONS = 10
        N_REF_PARTITIONS = 5
        MAX_OPT_SAMPLE_PIXELS = 7000
        WORKING_SCALE_FACTOR = 20
        MAX_FULL_RECHECK_SOLUTIONS = 20
        OUTPUT_ROOT = r"E:\中国特大城市洪水\Cascade_Optimization_V44_TARGETED_MEDIUM"

    elif RUN_LEVEL == "formal":
        QUICK_TEST_MODE = False
        ACTIVE_CITIES = list(CITY_DIRS.keys())
        QUICK_TEST_SCENARIOS = [f"S{i}" for i in range(1, 8)]
        POP_SIZE = 30
        N_GENERATIONS = 16
        N_REF_PARTITIONS = 6
        MAX_OPT_SAMPLE_PIXELS = 12000
        WORKING_SCALE_FACTOR = 16
        MAX_FULL_RECHECK_SOLUTIONS = 12
        OUTPUT_ROOT = r"E:\中国特大城市洪水\Cascade_Optimization_V44C_TARGETED_PROBLEM_CITY_FINAL_FIXED"

    else:
        raise ValueError(f"Unknown RUN_LEVEL: {RUN_LEVEL}. Use quick, citycheck, medium, or formal.")


# Apply preset immediately so all following functions use the updated parameters.
apply_run_level_preset()


# Objective construction
ALPHA_J1_MEAN = 0.70
ALPHA_J2_MEAN = 0.70
HOTSPOT_Q = 90
LOW_LIVABILITY_Q = 10
HIGH_RISK_CONTROL_Q = 80
LOW_RISK_COMPACT_Q = 50

FOCAL_RADII_CELLS = [3, 10, 30]
FOCAL_WEIGHTS = [0.5, 0.3, 0.2]
TARGET_SMOOTH_SIGMA = {"F1": 0.65, "F2": 0.85, "F3": 0.55}

# Decision-variable transformation parameters
DELTA_MAX_NDVI = 0.20
DELTA_MAX_GVI = 0.20
DELTA_MAX_PSA = 0.25
LAMBDA_ISA = 0.85
R_MAX_BD_MINUS = 0.12
R_MAX_BH_MINUS = 0.06
R_MAX_BD_PLUS = 0.06
R_MAX_BH_PLUS = 0.04
RHO_LULC_MAX = 0.03
ALPHA_BD_LULC_CONVERT = 0.10
ALPHA_BH_LULC_CONVERT = 0.10

ETA_CGI_MAIN = 0.90
ETA_CGI_RISK_PRIORITY = 0.85
CGI_OVERGROWTH_LIMIT = 1.05
LAMBDA_CGI_OVERGROWTH = 0.20
I_MAX = 0.12

INTERVENTION_WEIGHTS = {
    "NDVI": 1.0,
    "GVI": 1.2,
    "Micro_PSA": 1.5,
    "Micro_ISA": 1.5,
    "BD": 2.0,
    "BH": 3.0,
    "LULC": 4.0,
}

Q_LOW = 1
Q_HIGH = 99

LULC_ECO_MAP = {1: 0.70, 2: 0.95, 3: 0.60, 4: 0.85, 5: 1.00, 6: 0.20, 7: 0.30, 8: 0.05, 9: 0.90}
LULC_URBAN_MAP = {1: 0.15, 2: 0.00, 3: 0.05, 4: 0.05, 5: 0.00, 6: 0.00, 7: 0.25, 8: 1.00, 9: 0.00}

SCENARIOS = {
    "S0": {"name": "Baseline", "zh": "基准情景", "select": None, "constraints": {}},
    "S1": {"name": "Risk-suppression scenario", "zh": "安全风险抑制情景", "select": "min_J1", "constraints": {"J2_ge_S0": True, "J3_ge": ETA_CGI_RISK_PRIORITY}},
    "S2": {"name": "Eco-livability enhancement scenario", "zh": "宜居生态提升情景", "select": "max_J2", "constraints": {"J1_le_S0": True, "J3_ge": ETA_CGI_MAIN}},
    "S3": {"name": "3D-function retention scenario", "zh": "三维功能保持情景", "select": "max_J3", "constraints": {"J1_reduction_pct_ge": 2.0, "J2_improvement_pct_ge": 2.0}},
    "S4": {"name": "Risk-livability synergy scenario", "zh": "安全–宜居协同情景", "select": "min_J1_max_J2", "constraints": {"J1_le_S0": True, "J2_ge_S0": True, "J3_ge": ETA_CGI_MAIN}},
    "S5": {"name": "Risk-growth balance scenario", "zh": "安全–增长平衡情景", "select": "min_J1_max_J3", "constraints": {"J1_le_S0": True, "J3_ge": ETA_CGI_MAIN}},
    "S6": {"name": "Livability-growth compact scenario", "zh": "宜居–增长紧凑情景", "select": "max_J2_max_J3", "constraints": {"J2_ge_S0": True, "J3_ge": ETA_CGI_MAIN}},
    "S7": {"name": "Cascade-balanced adaptation scenario", "zh": "风险级联综合适应情景", "select": "balanced", "constraints": {"J1_le_S0": True, "J2_ge_S0": True, "J3_ge": ETA_CGI_MAIN}},
}

RASTER_STEMS = {
    "P_flood": ["P_flood", "pflood", "P", "probability", "flood_probability", "Historical_P_flood"],
    "Rx1day": ["Rx1day", "Rx1d", "rx1day", "rx1d"],
    "Rx5day": ["Rx5day", "Rx5d", "rx5day", "rx5d"],
    "CWD": ["CWD", "cwd"], "EV": ["EV", "ev"], "SL": ["SL", "sl", "slope"],
    "PRC": ["PRC", "prc"], "TWI": ["TWI", "twi"], "TPI": ["TPI", "tpi"], "ST": ["ST", "st"],
    "NDVI": ["NDVI", "ndvi"], "LULC": ["LULC", "lulc", "LU", "landuse", "landcover"],
    "BD": ["BD", "bd"], "PD": ["PD", "pd"], "PopD": ["PopD", "popd", "PopulationDensity", "population_density"],
    "BH": ["BH", "bh"], "BVI": ["BVI", "bvi"], "CFI": ["CFI", "cfi"], "FOE": ["FOE", "foe"],
    "GVI": ["GVI", "gvi"], "Micro_ISA": ["Micro_ISA", "micro_isa", "ISA", "isa"],
    "Micro_PSA": ["Micro_PSA", "micro_psa", "PSA", "psa"], "SCE": ["SCE", "sce"],
    "SEL": ["SEL", "sel"], "SVF": ["SVF", "svf"], "TAE": ["TAE", "tae"],
    "GDP": ["GDP", "gdp"], "NTL": ["NTL", "ntl", "nightlight", "nighttime_light"], "RD": ["RD", "rd", "road_density"],
}

RNG = np.random.default_rng(RANDOM_SEED)

# ============================================================
# 2. Utilities
# ============================================================

class GridRef:
    """
    Lightweight reference grid for memory-safe optimization.

    The original rasters can be extremely large, e.g. Beijing may exceed 15k × 20k.
    This object defines a downsampled working grid while preserving CRS and spatial extent.
    All rasters are read/resampled to this working grid for optimization and output.
    """
    def __init__(self, src, scale_factor=1):
        self.src_path = getattr(src, "name", "")
        self.scale_factor = max(1, int(scale_factor))
        self.crs = src.crs

        if self.scale_factor <= 1:
            self.width = src.width
            self.height = src.height
            self.transform = src.transform
        else:
            self.width = int(np.ceil(src.width / self.scale_factor))
            self.height = int(np.ceil(src.height / self.scale_factor))
            self.transform = src.transform * Affine.scale(self.scale_factor, self.scale_factor)

        self.profile = src.profile.copy()
        self.profile.update(
            width=self.width,
            height=self.height,
            transform=self.transform,
            crs=self.crs,
        )

    def close(self):
        pass


def ensure_dir(p):
    Path(p).mkdir(parents=True, exist_ok=True)
    return str(p)

def all_tifs(folder):
    out = []
    out.extend(glob.glob(os.path.join(folder, "**", "*.tif"), recursive=True))
    out.extend(glob.glob(os.path.join(folder, "**", "*.tiff"), recursive=True))
    return sorted(list(set(out)))

def all_vectors(folder):
    out = []
    for ext in ["*.shp", "*.geojson", "*.gpkg"]:
        out.extend(glob.glob(os.path.join(folder, "**", ext), recursive=True))
    return sorted(list(set(out)))

def find_raster_exact(folder, aliases):
    aliases_low = [str(x).lower() for x in aliases]
    candidates = []
    for f in all_tifs(folder):
        stem = Path(f).stem.lower()
        if stem in aliases_low:
            candidates.append(f)
    return sorted(candidates)[0] if candidates else None

def find_raster_contains(folder, aliases, exclude_dirs=None):
    aliases_low = [str(x).lower() for x in aliases]
    exclude_dirs = exclude_dirs or []
    candidates = []
    for f in all_tifs(folder):
        low = f.lower()
        if any(ed.lower() in low for ed in exclude_dirs):
            continue
        stem = Path(f).stem.lower()
        if any(a in stem for a in aliases_low):
            candidates.append(f)
    return sorted(candidates, key=lambda x: (len(Path(x).stem), x))[0] if candidates else None

def find_city_raster(city, var, required=True):
    aliases = RASTER_STEMS.get(var, [var])
    folder = CITY_DIRS[city]
    p = find_raster_exact(folder, aliases)
    if p is None:
        p = find_raster_contains(folder, aliases, exclude_dirs=["三目标", "target", "objective", "Optimization", "opt"])
    if p is None and required:
        raise FileNotFoundError(f"[{city}] Missing raster for {var} in {folder}")
    return p

def read_template(city):
    # Try P_flood first, otherwise first available model feature raster.
    p = find_city_raster(city, "P_flood", required=False)
    if p is None:
        for var in MODEL_FEATURES:
            p = find_city_raster(city, var, required=False)
            if p is not None:
                break
    if p is None:
        raise FileNotFoundError(f"[{city}] No template raster found.")

    src = rasterio.open(p)
    ref = GridRef(src, scale_factor=WORKING_SCALE_FACTOR)
    print(f"  [Template] {p}")
    print(f"  [Working grid] original=({src.height},{src.width}) -> working=({ref.height},{ref.width}), scale={WORKING_SCALE_FACTOR}")
    src.close()
    return ref

def read_align_as_float(path, ref_ds, categorical=False):
    """
    Read raster aligned to the working reference grid.
    This function is memory-safe for large rasters because it reads directly to out_shape
    when CRS/extent are already consistent, and otherwise reprojects to the smaller working grid.
    """
    resampling = Resampling.nearest if categorical else Resampling.bilinear
    nodata = -9999.0

    with rasterio.open(path) as src:
        same_crs = (src.crs == ref_ds.crs)
        same_transform_scaled = (
            src.transform == ref_ds.transform
            and src.width == ref_ds.width
            and src.height == ref_ds.height
        )

        if same_transform_scaled:
            arr = src.read(1).astype("float32")
            if src.nodata is not None:
                arr[arr == src.nodata] = np.nan
            arr[~np.isfinite(arr)] = np.nan
            out = arr

        elif same_crs:
            # Direct resampled read. This avoids holding the original full-resolution raster in memory.
            out = src.read(
                1,
                out_shape=(ref_ds.height, ref_ds.width),
                resampling=resampling
            ).astype("float32")
            if src.nodata is not None:
                out[out == src.nodata] = np.nan
            out[~np.isfinite(out)] = np.nan

        else:
            # CRS differs: reproject to the smaller working grid.
            out = np.full((ref_ds.height, ref_ds.width), nodata, dtype="float32")
            reproject(
                source=rasterio.band(src, 1),
                destination=out,
                src_transform=src.transform,
                src_crs=src.crs,
                src_nodata=src.nodata,
                dst_transform=ref_ds.transform,
                dst_crs=ref_ds.crs,
                dst_nodata=nodata,
                resampling=resampling,
            )
            out[out == nodata] = np.nan
            out[~np.isfinite(out)] = np.nan

    if categorical:
        out = np.rint(out).astype("float32")
    return out.astype("float32")

def read_raster_path(path):
    with rasterio.open(path) as src:
        arr = src.read(1).astype("float32")
        if src.nodata is not None:
            arr[arr == src.nodata] = np.nan
        arr[~np.isfinite(arr)] = np.nan
        profile = src.profile.copy()
    return arr, profile

def write_raster(path, arr, ref_profile, nodata=-9999.0):
    ensure_dir(Path(path).parent)
    profile = ref_profile.copy()
    profile.update(driver="GTiff", dtype="float32", count=1, nodata=nodata, compress="lzw", tiled=True, BIGTIFF="IF_SAFER")
    out = np.where(np.isfinite(arr), arr, nodata).astype("float32")
    with rasterio.open(path, "w", **profile) as dst:
        dst.write(out, 1)

def target_smoothed_path(city, key):
    folder = os.path.join(CITY_DIRS[city], TARGET_SMOOTH_DIR_NAME)
    names = {
        "F1": f"{city}_F1_safety_expected_impact_integral_BAU_smoothed.tif",
        "F2": f"{city}_F2_livable_ecological_integral_BAU_smoothed.tif",
        "F3": f"{city}_CGI_3D_growth_intensity_integral_BAU_smoothed.tif",
        "CGI": f"{city}_CGI_3D_growth_intensity_integral_BAU_smoothed.tif",
    }
    p = os.path.join(folder, names[key])
    if not os.path.exists(p):
        raise FileNotFoundError(f"[{city}] Missing smoothed target {key}: {p}")
    return p

def mask_existing_path(city):
    p = os.path.join(CITY_DIRS[city], CONTEXT_DIR_NAME, f"{city}_city_boundary_mask_BAU.tif")
    if os.path.exists(p):
        return p
    p2 = os.path.join(CITY_DIRS[city], "city_boundary_mask_BAU.tif")
    return p2 if os.path.exists(p2) else None

def find_city_mask_file(city):
    manual = CITY_MASK_FILES.get(city)
    if manual and os.path.exists(manual):
        return manual
    if not os.path.exists(BOUNDARY_DIR):
        return None
    keys = CITY_CHINESE_KEYS.get(city, [city])
    candidates = []
    for shp in glob.glob(os.path.join(BOUNDARY_DIR, "**", "*.shp"), recursive=True):
        stem = Path(shp).stem
        low = str(shp).lower()
        if any(x in low for x in ["sample", "point", "样本", "点"]):
            continue
        if any(k in stem for k in keys):
            score = 10 + sum(2 for k in ["区块", "边界", "市界", "行政", "范围", "boundary", "admin", "outline"] if k.lower() in low)
            candidates.append((score, len(shp), shp))
    return sorted(candidates, key=lambda x: (-x[0], x[1]))[0][2] if candidates else None

def rasterize_vector_mask(vector_path, ref_ds):
    if gpd is None:
        raise ImportError("geopandas is required for reading city boundary shp.")
    gdf = gpd.read_file(vector_path)
    if gdf.empty:
        raise ValueError(f"Empty boundary file: {vector_path}")
    if gdf.crs is None:
        raise ValueError(f"Boundary has no CRS: {vector_path}")
    if not any("Polygon" in gt for gt in set(gdf.geometry.geom_type.dropna().astype(str))):
        raise ValueError(f"Boundary is not polygon-like: {vector_path}")
    gdf = gdf.to_crs(ref_ds.crs)
    geoms = [g for g in gdf.geometry if g is not None and not g.is_empty]
    return geometry_mask(geometries=geoms, out_shape=(ref_ds.height, ref_ds.width), transform=ref_ds.transform, invert=True, all_touched=True).astype(bool)

def get_city_mask(city, ref_ds, lulc_arr=None):
    p = mask_existing_path(city)
    if p:
        m = read_align_as_float(p, ref_ds, categorical=True)
        return (np.isfinite(m) & (m > 0)), p
    shp = find_city_mask_file(city)
    if shp:
        mask = rasterize_vector_mask(shp, ref_ds)
        if lulc_arr is not None:
            mask &= np.isfinite(lulc_arr)
        return mask, shp
    if lulc_arr is None:
        raise FileNotFoundError(f"[{city}] No mask found and no LULC fallback available.")
    return np.isfinite(lulc_arr), "LULC_valid_fallback"

def z01(arr, lo, hi):
    out = (arr - lo) / (hi - lo + 1e-12)
    out = np.clip(out, 0, 1).astype("float32")
    out[~np.isfinite(arr)] = np.nan
    return out

def norm01(arr, mask):
    out = np.full(arr.shape, np.nan, dtype="float32")
    vals = arr[mask & np.isfinite(arr)]
    if vals.size == 0:
        out[mask] = 0
    else:
        mn, mx = float(np.nanmin(vals)), float(np.nanmax(vals))
        out[mask] = 0 if mx <= mn else np.clip((arr[mask] - mn) / (mx - mn), 0, 1)
    return out

def reclass_lulc(lulc, mapping):
    out = np.full(lulc.shape, np.nan, dtype="float32")
    for code, val in mapping.items():
        out[np.isclose(lulc, float(code), equal_nan=False)] = float(val)
    return out

def fill_nearest(arr, mask, fill_value=0.0):
    """
    Memory-safe nearest-neighbor filling on the working grid.

    This keeps your requirement of nearest-neighbor gap filling, but avoids
    scipy.ndimage.distance_transform_edt(return_indices=True), which allocates
    a huge (2, rows, cols) integer array and caused the 2.37 GiB memory error.

    Implementation:
    - build a cKDTree from valid pixel coordinates;
    - query missing pixel coordinates in chunks;
    - assign the value of the nearest valid pixel.
    """
    out = arr.astype("float32", copy=True)
    out[~mask] = np.nan

    valid = np.isfinite(out) & mask
    missing = (~np.isfinite(out)) & mask

    if not missing.any():
        return out.astype("float32")

    if not valid.any():
        out[missing] = float(fill_value)
        out[~mask] = np.nan
        return out.astype("float32")

    valid_rc = np.column_stack(np.where(valid)).astype("float32")
    missing_rc = np.column_stack(np.where(missing)).astype("float32")

    tree = cKDTree(valid_rc)
    valid_values = out[valid]

    # Query in chunks to avoid memory spikes.
    filled_vals = np.empty(missing_rc.shape[0], dtype="float32")
    for s in range(0, missing_rc.shape[0], MAX_NEAREST_QUERY_CHUNK):
        e = min(s + MAX_NEAREST_QUERY_CHUNK, missing_rc.shape[0])
        _, idx = tree.query(missing_rc[s:e], k=1, workers=-1)
        filled_vals[s:e] = valid_values[idx].astype("float32")

    rr, cc = np.where(missing)
    out[rr, cc] = filled_vals
    out[~mask] = np.nan
    return out.astype("float32")

def masked_gaussian(arr, mask, sigma):
    """
    Mask-constrained Gaussian smoothing.
    Values are smoothed only inside mask and will not bleed outside the city boundary.
    """
    if sigma is None or sigma <= 0:
        out = arr.astype("float32", copy=True)
        out[~mask] = np.nan
        return out

    a = arr.astype("float32", copy=True)
    a[~mask] = np.nan
    valid = np.isfinite(a) & mask
    if not valid.any():
        return a

    vals = np.where(valid, a, 0.0).astype("float32")
    w = valid.astype("float32")

    sv = gaussian_filter(vals, sigma=sigma, mode="nearest")
    sw = gaussian_filter(w, sigma=sigma, mode="nearest")

    out = sv / np.where(sw > 1e-6, sw, np.nan)
    out[~mask] = np.nan
    return out.astype("float32")


def focal_mean_nan(arr, radius):
    size = int(radius) * 2 + 1
    finite = np.isfinite(arr).astype("float32")
    values = np.where(np.isfinite(arr), arr, 0).astype("float32")
    s = uniform_filter(values, size=size, mode="constant", cval=0)
    c = uniform_filter(finite, size=size, mode="constant", cval=0)
    out = s / np.where(c > 1e-6, c, np.nan)
    out[c <= 1e-6] = np.nan
    return out.astype("float32")

def multiscale_context(arr):
    out = np.zeros_like(arr, dtype="float32")
    for r, w in zip(FOCAL_RADII_CELLS, FOCAL_WEIGHTS):
        out += float(w) * focal_mean_nan(arr, r)
    out /= max(sum(FOCAL_WEIGHTS), 1e-12)
    out[~np.isfinite(out)] = np.nan
    return out.astype("float32")

# ============================================================
# 2.5. Training-time preprocessor class for joblib loading
# ============================================================

MISSING_INDICATOR_BASE_VARS = ["BD", "PD", "BH", "BVI", "Micro_ISA", "Micro_PSA"]
ZERO_FILL_VARS = ["BD", "PD", "BH", "BVI", "Micro_ISA", "Micro_PSA"]

class TabularPreprocessor:
    """
    与训练代码一致。这个类名必须保留，joblib.load() 需要在当前脚本中找到同名类。
    """
    def __init__(self, model_vars=None, zero_fill_vars=None):
        self.model_vars = list(model_vars or [])
        self.zero_fill_vars = list(zero_fill_vars or ZERO_FILL_VARS)
        self.missing_indicator_base_vars = [v for v in MISSING_INDICATOR_BASE_VARS if v in self.model_vars]
        self.missing_indicator_vars = [f"{v}_missing" for v in self.missing_indicator_base_vars]
        self.feature_vars = self.model_vars + self.missing_indicator_vars
        self.median_fill_vars = [v for v in self.model_vars if v not in self.zero_fill_vars]
        self.medians_ = {}
        self.scaler_ = StandardScaler() if StandardScaler is not None else None

    def _prepare_unscaled(self, df):
        X_raw = df[self.model_vars].copy()
        X = pd.DataFrame(index=df.index)

        for v in self.model_vars:
            X[v] = X_raw[v]

        for v in getattr(self, "missing_indicator_base_vars", []):
            X[f"{v}_missing"] = X_raw[v].isna().astype(float)

        for v in getattr(self, "zero_fill_vars", []):
            if v in X.columns:
                X[v] = X[v].fillna(0.0)

        for v in getattr(self, "median_fill_vars", []):
            fill = self.medians_.get(v, np.nan)
            if not np.isfinite(fill):
                fill = float(X[v].median(skipna=True))
                if not np.isfinite(fill):
                    fill = 0.0
            X[v] = X[v].fillna(fill)

        if not hasattr(self, "feature_vars") or self.feature_vars is None or len(self.feature_vars) == 0:
            self.missing_indicator_vars = [f"{v}_missing" for v in getattr(self, "missing_indicator_base_vars", [])]
            self.feature_vars = list(self.model_vars) + list(self.missing_indicator_vars)

        return X[self.feature_vars].astype(float)

    def transform(self, df):
        X = self._prepare_unscaled(df)
        if not hasattr(self, "scaler_") or self.scaler_ is None:
            return X
        arr = self.scaler_.transform(X.values)
        return pd.DataFrame(arr, columns=self.feature_vars, index=df.index)


# ============================================================
# 3. Model adapter
# ============================================================

class MainModelAdapter:
    def __init__(self, model_root, package_path=None):
        self.model_root = model_root
        self.package_path = package_path if package_path and os.path.exists(package_path) else None
        if self.package_path is None:
            self.package_path = self._auto_find_package(model_root)

        self.obj = None
        self.model = None
        self.feature_names = MODEL_FEATURES.copy()
        self.model_vars = MODEL_FEATURES.copy()
        self.preprocessor = None
        self.rf_anchor = None
        self.model_type = None
        self.is_proxy = False
        self.ready = False

        print("[MODEL] MODEL_ROOT =", model_root)
        print("[MODEL] MODEL_PACKAGE_PATH =", self.package_path)

        if self.package_path and joblib is not None:
            try:
                if os.path.isdir(model_root):
                    sys.path.insert(0, model_root)
                model_dir = os.path.dirname(self.package_path)
                if os.path.isdir(model_dir):
                    sys.path.insert(0, model_dir)

                self.obj = joblib.load(self.package_path)
                self._parse_loaded_object()
                self.ready = True
                print(f"[MODEL] Loaded package successfully: {self.package_path}")
                print(f"[MODEL] model_type = {self.model_type}")
                print(f"[MODEL] model_vars = {self.model_vars}")
                print(f"[MODEL] feature_names total = {len(self.feature_names)}")
            except Exception as e:
                print("[MODEL ERROR] joblib.load or parser failed.")
                print("[MODEL ERROR] package =", self.package_path)
                print("[MODEL ERROR] detail =", repr(e))
        else:
            if joblib is None:
                print("[MODEL ERROR] joblib is not installed.")
            else:
                print("[MODEL ERROR] No model package was found.")

        if not self.ready:
            if REQUIRE_MAIN_MODEL and not DEBUG_ALLOW_PROXY_MODEL:
                raise RuntimeError(
                    "Main model could not be loaded. Please check whether this file exists:\n"
                    f"  {MODEL_PACKAGE_PATH}\n"
                    "If not, set MODEL_PACKAGE_PATH to your real Final_*_package.joblib path.\n"
                    "If it exists but still fails, the error above is usually caused by missing custom classes; "
                    "this patched version already includes TabularPreprocessor."
                )
            print("[MODEL WARNING] Using proxy model. Do NOT use proxy results in paper.")
            self.ready = True
            self.is_proxy = True
            self.model_type = "debug_proxy"

    def _auto_find_package(self, root):
        """
        宽范围自动搜索最终模型包。
        优先查找 Final_RF_Stabilized_HydroConTex_GNNWRL_package.joblib；
        如果没有，则列出所有可疑 joblib/pkl，方便手动指定 MODEL_PACKAGE_PATH。
        """
        search_dirs = []
        for d in MODEL_SEARCH_ROOTS:
            if d and os.path.exists(d):
                search_dirs.append(d)
        if root and os.path.exists(root) and root not in search_dirs:
            search_dirs.append(root)
        try:
            cwd = os.getcwd()
            if cwd and os.path.exists(cwd) and cwd not in search_dirs:
                search_dirs.append(cwd)
        except Exception:
            pass

        patterns_priority = [
            "Final_RF_Stabilized_HydroConTex_GNNWRL_package.joblib",
            "Final_RF_Stabilized_HydroConTex_GNNWRL_package.pkl",
            "Final_*HydroConTex*GNNWRL*package*.joblib",
            "Final_*HydroConTex*GNNWRL*package*.pkl",
            "*RF*Stabilized*HydroConTex*GNNWRL*.joblib",
            "*RF*Stabilized*HydroConTex*GNNWRL*.pkl",
            "*GNNWRL*package*.joblib",
            "*GNNWRL*package*.pkl",
            "*HydroConTex*.joblib",
            "*HydroConTex*.pkl",
        ]

        all_candidates = []
        for d in search_dirs:
            for pat in patterns_priority:
                all_candidates.extend(glob.glob(os.path.join(d, "**", pat), recursive=True))

        all_candidates = sorted(list(set(all_candidates)), key=lambda x: (0 if "Final_RF_Stabilized" in Path(x).name else 1, len(str(x)), x))

        if all_candidates:
            print("[MODEL] Auto-found candidate model packages:")
            for c in all_candidates[:30]:
                print("   ", c)
            return all_candidates[0]

        # 最后兜底列出所有 joblib/pkl，帮助定位
        loose = []
        for d in search_dirs:
            loose.extend(glob.glob(os.path.join(d, "**", "*.joblib"), recursive=True))
            loose.extend(glob.glob(os.path.join(d, "**", "*.pkl"), recursive=True))
        loose = sorted(list(set(loose)), key=lambda x: (len(str(x)), x))

        print("[MODEL] No final model package found. Searched folders:")
        for d in search_dirs:
            print("   ", d)

        if loose:
            print("[MODEL] But found these joblib/pkl files. If one is the final model, set MODEL_PACKAGE_PATH to it:")
            for c in loose[:80]:
                print("   ", c)
        else:
            print("[MODEL] No .joblib or .pkl files found under searched folders.")

        return None

    def _parse_loaded_object(self):
        obj = self.obj

        if hasattr(obj, "predict_proba") or hasattr(obj, "predict"):
            self.model = obj
            self.model_type = "direct_model"
            if hasattr(obj, "feature_names_in_"):
                self.feature_names = list(obj.feature_names_in_)
            return

        if not isinstance(obj, dict):
            raise RuntimeError(f"Unsupported package type: {type(obj)}")

        if "preprocessor" in obj and "rf_anchor" in obj:
            self.preprocessor = obj["preprocessor"]
            self.rf_anchor = obj["rf_anchor"]
            self.model = self.rf_anchor
            self.model_type = "preprocessor_rf_anchor"

            if hasattr(self.preprocessor, "model_vars"):
                self.model_vars = list(self.preprocessor.model_vars)
            elif "MODEL_VARS" in obj:
                self.model_vars = list(obj["MODEL_VARS"])
            else:
                self.model_vars = MODEL_FEATURES.copy()

            if hasattr(self.preprocessor, "feature_vars"):
                self.feature_names = list(self.preprocessor.feature_vars)
            elif hasattr(self.rf_anchor, "feature_names_in_"):
                self.feature_names = list(self.rf_anchor.feature_names_in_)
            else:
                self.feature_names = self.model_vars.copy()

            return

        for k in ["feature_names", "features", "selected_features", "model_features", "FEATURES", "MODEL_VARS"]:
            if k in obj and obj[k] is not None:
                self.feature_names = list(obj[k])
                self.model_vars = list(obj[k])
                break

        for k in [
            "pipeline", "model", "final_model", "clf", "classifier",
            "rf_model", "rf_anchor", "anchor_model", "best_model", "main_model"
        ]:
            if k in obj and obj[k] is not None and (hasattr(obj[k], "predict_proba") or hasattr(obj[k], "predict")):
                self.model = obj[k]
                self.model_type = f"dict_model:{k}"
                if hasattr(self.model, "feature_names_in_"):
                    self.feature_names = list(self.model.feature_names_in_)
                return

        print("[MODEL DEBUG] package keys:", list(obj.keys()))
        raise RuntimeError("Loaded package does not expose a compatible model. Need keys such as preprocessor + rf_anchor or direct predict_proba model.")

    def predict_proba(self, X_df):
        if self.is_proxy:
            return self._proxy_predict(X_df)

        if self.model_type == "preprocessor_rf_anchor":
            missing_raw = [c for c in self.model_vars if c not in X_df.columns]
            if missing_raw:
                raise ValueError(f"Missing raw MODEL_VARS for preprocessor: {missing_raw}")

            X_scaled = self.preprocessor.transform(X_df[self.model_vars])

            if hasattr(self.rf_anchor, "feature_names_in_"):
                cols = list(self.rf_anchor.feature_names_in_)
                miss = [c for c in cols if c not in X_scaled.columns]
                if miss:
                    raise ValueError(f"Missing scaled RF features: {miss}")
                X_scaled = X_scaled[cols]
            else:
                X_scaled = X_scaled[self.feature_names]

            p = self.rf_anchor.predict_proba(X_scaled)
            p = np.asarray(p)
            return p[:, 1].astype("float32") if p.ndim == 2 else p.astype("float32")

        cols = [c for c in self.feature_names if c in X_df.columns]
        missing = [c for c in self.feature_names if c not in X_df.columns]
        if missing:
            raise ValueError(f"Missing model features: {missing}")
        X = X_df[cols]

        if hasattr(self.model, "predict_proba"):
            p = self.model.predict_proba(X)
            p = np.asarray(p)
            return p[:, 1].astype("float32") if p.ndim == 2 else p.astype("float32")

        if hasattr(self.model, "predict"):
            p = np.asarray(self.model.predict(X)).astype("float32")
            return np.clip(p, 0, 1)

        raise RuntimeError("Model does not support prediction.")

    def _proxy_predict(self, X_df):
        def get(col):
            if col in X_df.columns:
                return X_df[col].to_numpy(dtype="float32")
            return np.zeros(len(X_df), dtype="float32")
        z = (
            0.45 * get("Rx1day") + 0.35 * get("Rx5day") + 0.25 * get("TWI")
            + 0.20 * get("BD") + 0.15 * get("Micro_ISA")
            - 0.18 * get("NDVI") - 0.12 * get("GVI") - 0.15 * get("Micro_PSA")
        )
        z = (z - np.nanmean(z)) / (np.nanstd(z) + 1e-6)
        p = 1 / (1 + np.exp(-z))
        return np.clip(p, 0, 1).astype("float32")


# ============================================================
# 4. City data
# ============================================================

@dataclass
class CityData:
    city: str
    ref_profile: dict
    mask: np.ndarray
    raw: dict
    F1_0: np.ndarray
    F2_0: np.ndarray
    F3_0: np.ndarray
    norm_params: dict
    cond_params: dict
    weights: dict
    sample_idx: np.ndarray
    baseline_metrics: dict


def compute_norm_params(raw, mask):
    params = {}
    for v in ["NDVI", "GVI", "Micro_PSA", "Micro_ISA", "BD", "BH", "PD", "PopD", "GDP", "NTL", "RD"]:
        if v not in raw: continue
        vals = raw[v][mask & np.isfinite(raw[v])]
        if vals.size:
            lo, hi = np.nanpercentile(vals, [Q_LOW, Q_HIGH])
            if hi <= lo: hi = lo + 1
            params[v] = (float(lo), float(hi))
    return params

def compute_cond_params(raw, mask, lulc):
    cond = {}
    for v in ["NDVI", "Micro_PSA", "Micro_ISA", "BD", "BH"]:
        if v not in raw: continue
        cond[v] = {}
        for code in np.unique(lulc[mask & np.isfinite(lulc)].astype(int)):
            mm = mask & (lulc.astype(int) == int(code)) & np.isfinite(raw[v])
            vals = raw[v][mm]
            if vals.size < 50:
                vals = raw[v][mask & np.isfinite(raw[v])]
            if vals.size:
                lo, hi = np.nanpercentile(vals, [Q_LOW, Q_HIGH])
                if hi <= lo: hi = lo + 1
                cond[v][int(code)] = (float(lo), float(hi))
            else:
                cond[v][int(code)] = (0.0, 1.0)
    return cond

def build_priority_weights(raw, mask, F1_0, F2_0, F3_0):
    lulc = raw["LULC"]
    NDVI = raw.get("NDVI", np.zeros_like(lulc))
    BD = raw.get("BD", np.zeros_like(lulc))
    BH = raw.get("BH", np.zeros_like(lulc))
    W_risk = norm01(F1_0, mask)
    W_live = norm01(1 - F2_0, mask)
    W_cgi = norm01(F3_0, mask)
    ndvi_q90 = np.nanpercentile(NDVI[mask & np.isfinite(NDVI)], 90)
    bd_q80 = np.nanpercentile(BD[mask & np.isfinite(BD)], 80)
    bh_q80 = np.nanpercentile(BH[mask & np.isfinite(BH)], 80)
    M_green = mask & np.isin(lulc.astype(int), [1,4,7,8]) & (NDVI < ndvi_q90)
    M_street = mask & (lulc.astype(int) == 8)
    W_green = norm01(W_risk * W_live * M_green.astype("float32"), mask)
    W_built = norm01(W_risk * M_street.astype("float32"), mask)
    risk_q50 = np.nanpercentile(F1_0[mask & np.isfinite(F1_0)], LOW_RISK_COMPACT_Q)
    M_lowrisk = mask & np.isfinite(F1_0) & (F1_0 < risk_q50)
    W_compact = norm01((1-W_risk)*W_cgi*M_street.astype("float32")*M_lowrisk.astype("float32")*(BD<bd_q80).astype("float32")*(BH<bh_q80).astype("float32"), mask)

    # V8: LULC conversion is not allowed in high baseline CGI cores.
    # This prevents small conversion areas from destroying most of the 3D functional-retention objective.
    M_lulc = mask & np.isin(lulc.astype(int), [7,8])
    if PROTECT_HIGH_CGI_FROM_LULC:
        cgi_thr = np.nanpercentile(F3_0[mask & np.isfinite(F3_0)], CGI_PROTECTION_Q_FOR_LULC)
        M_lulc = M_lulc & np.isfinite(F3_0) & (F3_0 < cgi_thr)
    W_lulc = norm01(W_risk * W_live * M_lulc.astype("float32"), mask)

    # V23 composite BGI priority:
    # high-risk + high-livability-deficit + street-impervious + low-GVI/permeability areas.
    try:
        GVI0 = city_data.raw.get("GVI", np.zeros(mask.shape, dtype="float32"))
        ISA0 = city_data.raw.get("Micro_ISA", np.zeros(mask.shape, dtype="float32"))
        PSA0 = city_data.raw.get("Micro_PSA", np.zeros(mask.shape, dtype="float32"))
        W_bgi = norm01(W_risk * W_live * (1-norm01(GVI0, mask)) * norm01(ISA0, mask) * (1-norm01(PSA0, mask)), mask)
    except Exception:
        W_bgi = norm01(W_risk * W_live * W_green * M_street.astype("float32"), mask)

    return {"W_risk":W_risk,"W_live":W_live,"W_green":W_green,"W_built":W_built,
            "W_compact":W_compact,"W_lulc":W_lulc,"W_bgi":W_bgi,"M_green":M_green,
            "M_street":M_street,"M_lulc":M_lulc}

def compute_J1_from_target(F1, F1_0, mask):
    thr = np.nanpercentile(F1_0[mask & np.isfinite(F1_0)], HOTSPOT_Q)
    H = mask & (F1_0 >= thr)
    return ALPHA_J1_MEAN*float(np.nanmean(F1[mask])) + (1-ALPHA_J1_MEAN)*float(np.nanmean(F1[H]))

def compute_J2_from_target(F2, F2_0, mask):
    thr = np.nanpercentile(F2_0[mask & np.isfinite(F2_0)], LOW_LIVABILITY_Q)
    L = mask & (F2_0 <= thr)
    return ALPHA_J2_MEAN*float(np.nanmean(F2[mask])) + (1-ALPHA_J2_MEAN)*float(np.nanmean(F2[L]))

def compute_J3_from_target(F3, F3_0, mask):
    """
    3D functional-retention objective.

    V6 correction:
    The overgrowth term is measured relative to the baseline CGI surface:
        max(F3_s - F3_0, 0)
    rather than relative to Q95(F3_0). This makes S0 have overgrowth penalty = 0
    and avoids penalizing high-function baseline urban cores that already exist.
    """
    base = float(np.nanmean(F3_0[mask]))
    retention = 1 - float(np.nanmean(np.maximum(F3_0-F3,0)[mask]))/(base+1e-9)

    if USE_RELATIVE_CGI_OVERGROWTH:
        over = float(np.nanmean(np.maximum(F3-F3_0,0)[mask]))/(base+1e-9)
    else:
        q95 = float(np.nanpercentile(F3_0[mask & np.isfinite(F3_0)],95))
        over = float(np.nanmean(np.maximum(F3-q95,0)[mask]))/(q95+1e-9)

    return retention - LAMBDA_CGI_OVERGROWTH*over, retention, over

def load_city_data(city):
    print(f"\n[LOAD] {city}")
    ref = read_template(city)
    raw = {}
    for v in sorted(set(MODEL_FEATURES + ["PopD", "GDP", "NTL", "RD"] + DECISION_RESPONSE_VARS)):
        p = find_city_raster(city, v, required=False)
        if p:
            raw[v] = read_align_as_float(p, ref, categorical=(v=="LULC"))
            print(f"  {v}: {p}")
    if "LULC" not in raw: raise FileNotFoundError(f"[{city}] LULC is required")
    mask, mask_source = get_city_mask(city, ref, raw["LULC"])
    mask = mask & np.isfinite(raw["LULC"])
    for v in MODEL_FEATURES:
        if v not in raw:
            arr = np.full(mask.shape, np.nan, dtype="float32"); arr[mask] = 0; raw[v] = arr
            print(f"  [WARN] {v} missing, filled 0")
        elif v == "LULC":
            raw[v] = np.rint(fill_nearest(raw[v], mask, 8)).astype("float32")
        else:
            med = float(np.nanmedian(raw[v][mask & np.isfinite(raw[v])])) if np.isfinite(raw[v][mask]).any() else 0.0
            raw[v] = fill_nearest(raw[v], mask, med)
    for v in ["PopD","GDP","NTL","RD","PD"]:
        if v in raw:
            med = float(np.nanmedian(raw[v][mask & np.isfinite(raw[v])])) if np.isfinite(raw[v][mask]).any() else 0.0
            raw[v] = fill_nearest(raw[v], mask, med)
    F1_0 = read_align_as_float(target_smoothed_path(city,"F1"), ref); F1_0[~mask]=np.nan
    F2_0 = read_align_as_float(target_smoothed_path(city,"F2"), ref); F2_0[~mask]=np.nan
    F3_0 = read_align_as_float(target_smoothed_path(city,"F3"), ref); F3_0[~mask]=np.nan
    norm_params = compute_norm_params(raw, mask)
    cond_params = compute_cond_params(raw, mask, raw["LULC"])
    weights = build_priority_weights(raw, mask, F1_0, F2_0, F3_0)
    idx_all = np.where(mask.ravel())[0]
    if idx_all.size > MAX_OPT_SAMPLE_PIXELS:
        f1 = F1_0.ravel(); f2 = F2_0.ravel()
        hot = idx_all[f1[idx_all] >= np.nanpercentile(f1[idx_all], HOTSPOT_Q)]
        low = idx_all[f2[idx_all] <= np.nanpercentile(f2[idx_all], LOW_LIVABILITY_Q)]
        must = np.unique(np.concatenate([hot, low]))

        # 如果热点+低宜居样本本身已经超过上限，则从 must 中抽样，避免 sample 远大于 MAX_OPT_SAMPLE_PIXELS。
        if must.size >= MAX_OPT_SAMPLE_PIXELS:
            sample_idx = np.sort(RNG.choice(must, size=MAX_OPT_SAMPLE_PIXELS, replace=False))
        else:
            remain = np.setdiff1d(idx_all, must)
            n = max(0, MAX_OPT_SAMPLE_PIXELS - must.size)
            rem = RNG.choice(remain, size=min(n, remain.size), replace=False) if remain.size else np.array([], dtype=int)
            sample_idx = np.sort(np.unique(np.concatenate([must, rem])))
    else:
        sample_idx = idx_all
    base = {"J1_S0": compute_J1_from_target(F1_0,F1_0,mask), "J2_S0": compute_J2_from_target(F2_0,F2_0,mask), "J3_S0": 1.0,
            "F1_mean_S0": float(np.nanmean(F1_0[mask])), "F2_mean_S0": float(np.nanmean(F2_0[mask])), "F3_mean_S0": float(np.nanmean(F3_0[mask]))}
    prof = ref.profile.copy(); ref.close()
    print(f"  mask={mask_source}, pixels={mask.sum()}, sample={len(sample_idx)}")
    return CityData(city, prof, mask, raw, F1_0, F2_0, F3_0, norm_params, cond_params, weights, sample_idx, base)

# ============================================================
# 5. Decision transformation and objectives
# ============================================================

def get_z(city_data, var_dict, var):
    if var not in city_data.norm_params:
        vals = var_dict[var][city_data.mask & np.isfinite(var_dict[var])]
        lo, hi = (0,1) if vals.size == 0 else np.nanpercentile(vals,[Q_LOW,Q_HIGH])
        if hi <= lo: hi = lo+1
    else:
        lo, hi = city_data.norm_params[var]
    return z01(var_dict[var], lo, hi)

def clip_conditional(city_data, arr, var, lulc):
    out = arr.astype("float32").copy()
    if var not in city_data.cond_params:
        return out
    for code in np.unique(lulc[city_data.mask & np.isfinite(lulc)].astype(int)):
        mm = city_data.mask & (lulc.astype(int) == int(code))
        lo, hi = city_data.cond_params[var].get(int(code), city_data.norm_params.get(var,(0,1)))
        out[mm] = np.clip(out[mm], lo, hi)
    out[~city_data.mask] = np.nan
    return out

def _pad_theta(theta):
    arr = np.asarray(theta, dtype=float).ravel()
    if arr.size < N_THETA:
        arr = np.pad(arr, (0, N_THETA-arr.size), constant_values=0.0)
    elif arr.size > N_THETA:
        arr = arr[:N_THETA]
    return arr


def _get_response_guidance(city_data):
    g = getattr(city_data, "response_guidance", None)
    if not isinstance(g, dict):
        g = {}
    return {
        "green_mult": float(g.get("green_mult", 1.0)),
        "street_mult": float(g.get("street_mult", 1.0)),
        "perm_mult": float(g.get("perm_mult", 1.0)),
        "bgi_mult": float(g.get("bgi_mult", 1.0)),
        "lulc_mult": float(g.get("lulc_mult", 1.0)),
        "built_mult": float(g.get("built_mult", 1.0)),
    }


def _score_to_theta_cap(score):
    """
    Convert response-audit score to an upper bound for the related decision variable.
    This is a soft safety device: variables with unfavorable city response are not removed,
    but their search range is reduced to avoid blind over-intervention.
    """
    try:
        s = float(score)
    except Exception:
        s = 0.0
    if s > 5.0:
        return 1.00
    if s > 1.0:
        return 0.85
    if s > -1.0:
        return 0.65
    if s > -3.0:
        return 0.45
    return 0.25


def city_scenario_theta_bounds(city_data, scenario):
    """
    V32 response-guided city/scenario-specific decision bounds.

    Order:
    [theta_G, theta_S, theta_P, theta_D, theta_T, theta_L, theta_BGI]
    """
    xu = np.ones(N_THETA, dtype=float)

    if USE_RESPONSE_GUIDED_THETA_BOUNDS:
        g = getattr(city_data, "response_guidance", {}) or {}
        xu[THETA_COLS.index("theta_G")]   = _score_to_theta_cap(g.get("green_score", 0.0))
        xu[THETA_COLS.index("theta_S")]   = _score_to_theta_cap(g.get("street_score", 0.0))
        xu[THETA_COLS.index("theta_P")]   = _score_to_theta_cap(g.get("perm_score", 0.0))
        xu[THETA_COLS.index("theta_D")]   = _score_to_theta_cap(g.get("built_score", 0.0))
        xu[THETA_COLS.index("theta_T")]   = min(0.65, _score_to_theta_cap(g.get("built_score", 0.0)))
        xu[THETA_COLS.index("theta_L")]   = _score_to_theta_cap(g.get("lulc_score", 0.0))
        xu[THETA_COLS.index("theta_BGI")] = _score_to_theta_cap(g.get("bgi_score", 0.0))

    # Scenario-level planning logic.
    # These are upper-bound adjustments, not forced values.
    if scenario == "S1":  # risk priority
        xu[THETA_COLS.index("theta_D")] = min(xu[THETA_COLS.index("theta_D")], 0.35)
        xu[THETA_COLS.index("theta_T")] = min(xu[THETA_COLS.index("theta_T")], 0.25)
    elif scenario == "S2":  # livability priority
        xu[THETA_COLS.index("theta_D")] = min(xu[THETA_COLS.index("theta_D")], 0.25)
        xu[THETA_COLS.index("theta_T")] = min(xu[THETA_COLS.index("theta_T")], 0.25)
        xu[THETA_COLS.index("theta_L")] = min(xu[THETA_COLS.index("theta_L")], 0.45)
    elif scenario == "S3":  # CGI retention priority
        xu[THETA_COLS.index("theta_D")] = min(xu[THETA_COLS.index("theta_D")], 0.12)
        xu[THETA_COLS.index("theta_T")] = min(xu[THETA_COLS.index("theta_T")], 0.12)
        xu[THETA_COLS.index("theta_L")] = min(xu[THETA_COLS.index("theta_L")], 0.10)
        xu[THETA_COLS.index("theta_BGI")] = min(xu[THETA_COLS.index("theta_BGI")], 0.50)
    elif scenario == "S5":  # risk + CGI
        xu[THETA_COLS.index("theta_D")] = min(xu[THETA_COLS.index("theta_D")], 0.20)
        xu[THETA_COLS.index("theta_T")] = min(xu[THETA_COLS.index("theta_T")], 0.20)
        xu[THETA_COLS.index("theta_L")] = min(xu[THETA_COLS.index("theta_L")], 0.25)
    elif scenario == "S6":  # livability + CGI
        xu[THETA_COLS.index("theta_D")] = min(xu[THETA_COLS.index("theta_D")], 0.20)
        xu[THETA_COLS.index("theta_T")] = min(xu[THETA_COLS.index("theta_T")], 0.20)
        xu[THETA_COLS.index("theta_L")] = min(xu[THETA_COLS.index("theta_L")], 0.25)

    xu = np.clip(xu, 0.05, 1.0)
    return np.zeros(N_THETA, dtype=float), xu


def theta_group_scores(theta):
    theta = _pad_theta(theta)
    idx = {c:i for i,c in enumerate(THETA_COLS)}
    risk = float(np.mean([theta[idx["theta_P"]], theta[idx["theta_L"]], theta[idx["theta_BGI"]]]))
    live = float(np.mean([theta[idx["theta_G"]], theta[idx["theta_S"]], theta[idx["theta_BGI"]]]))
    struct = float(np.mean([theta[idx["theta_D"]], theta[idx["theta_T"]], theta[idx["theta_L"]]]))
    bgi = float(theta[idx["theta_BGI"]])
    return risk, live, struct, bgi


def scenario_variable_preference_penalty(theta, scenario):
    """
    V32 scenario-specific variable participation penalty.

    This is intentionally a soft penalty. It does not force a variable to be used,
    but prevents all scenarios from collapsing into the same BGI/green-permeable pathway.
    """
    if not USE_SCENARIO_VARIABLE_PREFERENCE_PENALTY:
        return 0.0

    risk, live, struct, bgi = theta_group_scores(theta)
    pen = 0.0

    if scenario == "S1":
        pen += max(0.0, MIN_RISK_GROUP_PARTICIPATION - risk)
    elif scenario == "S2":
        pen += max(0.0, MIN_LIVE_GROUP_PARTICIPATION - live)
    elif scenario == "S3":
        pen += max(0.0, struct - MAX_STRUCTURAL_DISTURBANCE_FOR_CGI)
        # retention scenario should not be dominated by broad policy-BGI alone
        pen += 0.25 * max(0.0, bgi - 0.50)
    elif scenario == "S4":
        pen += max(0.0, MIN_RISK_GROUP_PARTICIPATION - risk)
        pen += max(0.0, MIN_LIVE_GROUP_PARTICIPATION - live)
    elif scenario == "S5":
        pen += max(0.0, MIN_RISK_GROUP_PARTICIPATION - risk)
        pen += max(0.0, struct - MAX_STRUCTURAL_DISTURBANCE_FOR_CGI)
    elif scenario == "S6":
        pen += max(0.0, MIN_LIVE_GROUP_PARTICIPATION - live)
        pen += max(0.0, struct - MAX_STRUCTURAL_DISTURBANCE_FOR_CGI)
    elif scenario == "S7":
        groups = np.asarray([risk, live, min(struct, MAX_STRUCTURAL_DISTURBANCE_FOR_CGI)], dtype=float)
        active = float(np.sum(groups >= MIN_S7_TWO_GROUP_PARTICIPATION))
        pen += max(0.0, 2.0-active) * 0.10

    return float(pen)


def apply_decision(city_data, theta):
    theta = _pad_theta(theta)
    theta_G, theta_S, theta_P, theta_D, theta_T, theta_L, theta_BGI = [float(x) for x in theta]

    raw = city_data.raw
    mask = city_data.mask
    W = city_data.weights
    guide = _get_response_guidance(city_data)

    NDVI0, GVI0, PSA0, ISA0, BD0, BH0, LULC0 = [raw[v].copy() for v in ["NDVI","GVI","Micro_PSA","Micro_ISA","BD","BH","LULC"]]

    green_mult = np.clip(guide["green_mult"], MIN_RESPONSE_GUIDANCE_MULTIPLIER, MAX_RESPONSE_GUIDANCE_MULTIPLIER)
    street_mult = np.clip(guide["street_mult"], MIN_RESPONSE_GUIDANCE_MULTIPLIER, MAX_RESPONSE_GUIDANCE_MULTIPLIER)
    perm_mult = np.clip(guide["perm_mult"], MIN_RESPONSE_GUIDANCE_MULTIPLIER, MAX_RESPONSE_GUIDANCE_MULTIPLIER)
    bgi_mult = np.clip(guide["bgi_mult"], MIN_RESPONSE_GUIDANCE_MULTIPLIER, MAX_RESPONSE_GUIDANCE_MULTIPLIER)
    built_mult = np.clip(guide["built_mult"], MIN_RESPONSE_GUIDANCE_MULTIPLIER, MAX_RESPONSE_GUIDANCE_MULTIPLIER)
    lulc_mult = np.clip(guide["lulc_mult"], MIN_RESPONSE_GUIDANCE_MULTIPLIER, MAX_RESPONSE_GUIDANCE_MULTIPLIER)

    W_green_eff = norm01(W["W_green"] * green_mult, mask)
    W_street_eff = norm01(W["W_green"] * W["M_street"].astype("float32") * street_mult, mask)
    W_perm_eff = norm01(W["W_green"] * W["M_street"].astype("float32") * perm_mult, mask)
    W_bgi_eff = norm01(W.get("W_bgi", W_perm_eff) * bgi_mult, mask)

    # Individual interventions
    d_ndvi = masked_gaussian(theta_G*DELTA_MAX_NDVI*W_green_eff, mask, 1.0)
    d_gvi = masked_gaussian(theta_S*DELTA_MAX_GVI*W_street_eff, mask, 1.0)
    d_p = masked_gaussian(theta_P*DELTA_MAX_PSA*W_perm_eff, mask, 1.0)

    # V23 composite BGI intervention mapped to existing model variables.
    if THETA_BGI_ENABLED:
        d_bgi_ndvi = masked_gaussian(theta_BGI*BGI_NDVI_SHARE*DELTA_MAX_NDVI*W_bgi_eff, mask, 1.0)
        d_bgi_gvi  = masked_gaussian(theta_BGI*BGI_GVI_SHARE*DELTA_MAX_GVI*W_bgi_eff*W["M_street"].astype("float32"), mask, 1.0)
        d_bgi_p    = masked_gaussian(theta_BGI*BGI_PSA_SHARE*DELTA_MAX_PSA*W_bgi_eff*W["M_street"].astype("float32"), mask, 1.0)
    else:
        d_bgi_ndvi = np.zeros(mask.shape, dtype="float32")
        d_bgi_gvi  = np.zeros(mask.shape, dtype="float32")
        d_bgi_p    = np.zeros(mask.shape, dtype="float32")

    NDVI = np.clip(NDVI0 + d_ndvi + d_bgi_ndvi, 0, 1)
    GVI = np.clip(GVI0 + d_gvi + d_bgi_gvi, 0, 1)
    PSA = np.minimum(1, PSA0 + d_p + d_bgi_p)
    ISA = np.maximum(0, ISA0 - LAMBDA_ISA*d_p - BGI_ISA_SHARE*LAMBDA_ISA*d_bgi_p)

    LULC = LULC0.copy()
    cand = W.get("M_lulc", mask & np.isin(LULC0.astype(int), [7,8]))
    cand = cand & mask & np.isin(LULC0.astype(int), [7,8])
    conv_mask = np.zeros(mask.shape, dtype=bool)
    n_convert = int(round(theta_L * RHO_LULC_MAX * int(mask.sum()) * lulc_mult))
    n_convert = min(n_convert, int(cand.sum()))
    if n_convert > 0:
        w = W["W_lulc"].copy(); w[~cand] = -np.inf
        idx = np.argpartition(w.ravel(), -n_convert)[-n_convert:]
        conv_mask.ravel()[idx] = True; conv_mask &= cand
        LULC[conv_mask] = 4

    BDm = BD0 * (1 - theta_D*R_MAX_BD_MINUS*W["W_built"]*built_mult)
    BHm = BH0 * (1 - theta_D*R_MAX_BH_MINUS*W["W_built"]*built_mult)
    BD = BDm + BD0*theta_T*R_MAX_BD_PLUS*W["W_compact"]*built_mult
    BH = BHm + BH0*theta_T*R_MAX_BH_PLUS*W["W_compact"]*built_mult

    if conv_mask.any():
        BD[conv_mask] = np.minimum(BD[conv_mask], ALPHA_BD_LULC_CONVERT*BD0[conv_mask])
        BH[conv_mask] = np.minimum(BH[conv_mask], ALPHA_BH_LULC_CONVERT*BH0[conv_mask])
        ISA[conv_mask] = np.minimum(ISA[conv_mask], ISA0[conv_mask])
        PSA[conv_mask] = np.maximum(PSA[conv_mask], PSA0[conv_mask])
        NDVI[conv_mask] = np.maximum(NDVI[conv_mask], NDVI0[conv_mask])

    over = mask & ((PSA+ISA) > 1)
    ISA[over] = np.maximum(0, 1-PSA[over])

    NDVI = clip_conditional(city_data, np.clip(NDVI,0,1), "NDVI", LULC)
    PSA = clip_conditional(city_data, np.clip(PSA,0,1), "Micro_PSA", LULC)
    ISA = clip_conditional(city_data, np.clip(ISA,0,1), "Micro_ISA", LULC)
    BD = np.maximum(0, clip_conditional(city_data, BD, "BD", LULC))
    BH = np.maximum(0, clip_conditional(city_data, BH, "BH", LULC))

    # Preserve exact baseline for inactive groups.
    if PRESERVE_UNCHANGED_GROUPS:
        if abs(theta_G) <= THETA_ZERO_EPS and abs(theta_BGI) <= THETA_ZERO_EPS:
            NDVI = NDVI0.copy()
        if abs(theta_S) <= THETA_ZERO_EPS and abs(theta_BGI) <= THETA_ZERO_EPS:
            GVI = GVI0.copy()
        if abs(theta_P) <= THETA_ZERO_EPS and abs(theta_BGI) <= THETA_ZERO_EPS and (not conv_mask.any()):
            PSA = PSA0.copy()
            ISA = ISA0.copy()
        if abs(theta_D) <= THETA_ZERO_EPS and abs(theta_T) <= THETA_ZERO_EPS and (not conv_mask.any()):
            BD = BD0.copy()
            BH = BH0.copy()
        if abs(theta_L) <= THETA_ZERO_EPS:
            LULC = LULC0.copy()

    # High-risk built-intensity no-increase control.
    H_risk = mask & np.isfinite(city_data.F1_0) & (
        city_data.F1_0 >= np.nanpercentile(city_data.F1_0[mask & np.isfinite(city_data.F1_0)], HIGH_RISK_CONTROL_Q)
    )
    if H_risk.any():
        BD[H_risk] = np.minimum(BD[H_risk], BD0[H_risk])
        BH[H_risk] = np.minimum(BH[H_risk], BH0[H_risk])

    upd = {k:v.copy() for k,v in raw.items()}
    for k,a in {"NDVI":NDVI,"GVI":GVI,"Micro_PSA":PSA,"Micro_ISA":ISA,"BD":BD,"BH":BH,"LULC":LULC}.items():
        a[~mask] = np.nan; upd[k] = a.astype("float32")

    changes = {
        "dNDVI":NDVI-NDVI0,
        "dGVI":GVI-GVI0,
        "dMicro_PSA":PSA-PSA0,
        "dMicro_ISA":ISA-ISA0,
        "dBD":BD-BD0,
        "dBH":BH-BH0,
        "dLULC":(LULC!=LULC0).astype("float32"),
    }
    for k in changes:
        changes[k][~mask] = np.nan

    return upd, changes

def build_feature_df(var_dict, idx):
    return pd.DataFrame({v: var_dict[v].ravel()[idx] for v in MODEL_FEATURES})

def predict_p(model, var_dict, city_data, idx=None):
    if idx is not None:
        return np.clip(model.predict_proba(build_feature_df(var_dict, idx)),0,1).astype("float32")
    mask = city_data.mask
    out = np.full(mask.shape, np.nan, dtype="float32")
    idx_all = np.where(mask.ravel())[0]
    for s in range(0, idx_all.size, PREDICT_CHUNK_SIZE):
        ii = idx_all[s:s+PREDICT_CHUNK_SIZE]
        out.ravel()[ii] = np.clip(model.predict_proba(build_feature_df(var_dict, ii)),0,1)
    return out

def compute_F3_stable(city_data, var_dict):
    """
    Stable 3D functional surface anchored to baseline smoothed CGI.

    Diagnostic reason:
    In the first quick test, recomputed CGI collapsed to zero after intervention.
    For the functional-retention objective, it is safer to anchor F3 to baseline CGI
    and update it according to relative BD/BH/LULC-urban retention.
    """
    mask = city_data.mask
    BD0 = city_data.raw["BD"].astype("float32")
    BH0 = city_data.raw["BH"].astype("float32")
    BD = var_dict["BD"].astype("float32")
    BH = var_dict["BH"].astype("float32")
    L0 = city_data.raw["LULC"].astype("float32")
    Ls = var_dict["LULC"].astype("float32")

    u0 = reclass_lulc(L0, LULC_URBAN_MAP)
    us = reclass_lulc(Ls, LULC_URBAN_MAP)
    u0 = fill_nearest(u0, mask, 0.0)
    us = fill_nearest(us, mask, 0.0)

    bd_ratio = np.ones(mask.shape, dtype="float32")
    bh_ratio = np.ones(mask.shape, dtype="float32")
    bd_valid = mask & np.isfinite(BD0) & (np.abs(BD0) > 1e-6)
    bh_valid = mask & np.isfinite(BH0) & (np.abs(BH0) > 1e-6)
    bd_ratio[bd_valid] = BD[bd_valid] / (BD0[bd_valid] + 1e-6)
    bh_ratio[bh_valid] = BH[bh_valid] / (BH0[bh_valid] + 1e-6)
    bd_ratio = np.clip(bd_ratio, 0, 1.20)
    bh_ratio = np.clip(bh_ratio, 0, 1.20)

    urban_ratio = np.ones(mask.shape, dtype="float32")
    u_valid = mask & np.isfinite(u0) & (u0 > 1e-6)
    urban_ratio[u_valid] = us[u_valid] / (u0[u_valid] + 1e-6)
    urban_ratio = np.clip(urban_ratio, 0, 1.20)

    retention_surface = np.sqrt(np.clip(bd_ratio, 0, 1.2) * np.clip(bh_ratio, 0, 1.2)) * urban_ratio
    retention_surface = masked_gaussian(retention_surface, mask, TARGET_SMOOTH_SIGMA["F3"])

    F3 = city_data.F3_0 * retention_surface
    F3[~mask] = np.nan
    return F3.astype("float32")



def compute_targets_full(city_data, var_dict, P):
    mask = city_data.mask
    exp = [get_z(city_data, city_data.raw, "PopD") if "PopD" in city_data.raw else get_z(city_data, city_data.raw, "PD")]
    for v in ["GDP","NTL","RD"]:
        if v in city_data.raw: exp.append(get_z(city_data, city_data.raw, v))
    EI = np.nanmean(np.stack(exp), axis=0).astype("float32"); EI[~mask]=np.nan
    C_safe = P*EI; K_safe = multiscale_context(C_safe); F1 = np.sqrt(np.clip(C_safe,0,1)*np.clip(K_safe,0,1)); F1[~mask]=np.nan
    z_ndvi,z_gvi,z_psa,z_isa = [get_z(city_data,var_dict,v) for v in ["NDVI","GVI","Micro_PSA","Micro_ISA"]]
    lulc = var_dict["LULC"]
    eco_l = fill_nearest(reclass_lulc(lulc,LULC_ECO_MAP), mask, 0)
    urb_l = fill_nearest(reclass_lulc(lulc,LULC_URBAN_MAP), mask, 0)
    Eco = np.nanmean(np.stack([z_ndvi,eco_l]),axis=0).astype("float32")
    Lstreet = np.nanmean(np.stack([z_gvi,z_psa,1-z_isa]),axis=0).astype("float32")
    U = ((lulc.astype(int)==8)&mask).astype("float32"); U[~mask]=np.nan
    Lhy = U*Lstreet + (1-U)*Eco
    C_live = np.sqrt(np.clip(Eco,0,1)*np.clip(Lhy,0,1)); K_live=multiscale_context(C_live); F2=np.sqrt(np.clip(C_live,0,1)*np.clip(K_live,0,1)); F2[~mask]=np.nan
    z_bd,z_bh = get_z(city_data,var_dict,"BD"), get_z(city_data,var_dict,"BH")
    GI = np.sqrt(np.clip(z_bd,0,1)*np.clip(z_bh,0,1))*urb_l; GI[~mask]=np.nan
    K_GI=multiscale_context(GI); F3=np.sqrt(np.clip(GI,0,1)*np.clip(K_GI,0,1)); F3[~mask]=np.nan
    F3_recomputed = masked_gaussian(F3, mask, TARGET_SMOOTH_SIGMA["F3"])
    F3_stable = compute_F3_stable(city_data, var_dict)

    # V12:
    # The formal J3 objective is a retention of the baseline integrated 3D function surface.
    # Therefore, use target-anchored F3_stable consistently. F3_recomputed is retained only
    # for diagnostics. This prevents false CGI collapse when theta=0 or when micro-surface
    # interventions do not alter BD/BH/LULC.
    if USE_TARGET_ANCHORED_F3_ALWAYS:
        F3_final = F3_stable
    else:
        base_mean = float(np.nanmean(city_data.F3_0[mask]))
        rec_mean = float(np.nanmean(F3_recomputed[mask]))
        if base_mean > 1e-9 and rec_mean < 0.20 * base_mean:
            F3_final = F3_stable
        else:
            F3_final = F3_recomputed

    return {"P":P,"F1":masked_gaussian(F1,mask,TARGET_SMOOTH_SIGMA["F1"]),"F2":masked_gaussian(F2,mask,TARGET_SMOOTH_SIGMA["F2"]),"F3":F3_final,"F1_raw":F1,"F2_raw":F2,"F3_raw":F3,"F3_recomputed":F3_recomputed,"F3_stable":F3_stable,"EI":EI,"Eco":Eco,"L_hybrid":Lhy,"GI":GI}

def intervention_intensity(city_data, changes):
    mask=city_data.mask
    S = (INTERVENTION_WEIGHTS["NDVI"]*np.abs(changes["dNDVI"]) + INTERVENTION_WEIGHTS["GVI"]*np.abs(changes["dGVI"]) +
         INTERVENTION_WEIGHTS["Micro_PSA"]*np.abs(changes["dMicro_PSA"]) + INTERVENTION_WEIGHTS["Micro_ISA"]*np.abs(changes["dMicro_ISA"]) +
         INTERVENTION_WEIGHTS["BD"]*np.abs(changes["dBD"]) + INTERVENTION_WEIGHTS["BH"]*np.abs(changes["dBH"]) +
         INTERVENTION_WEIGHTS["LULC"]*np.nan_to_num(changes["dLULC"], nan=0.0))
    return float(np.nanmean(S[mask]))

def compute_bgi_policy_effect(city_data, theta_BGI):
    """
    Policy-effect surface for BGI correction.

    This uses the BGI intervention priority surface. It represents expected
    risk-buffering and livability gain from sponge/blue-green infrastructure
    in priority cells.
    """
    mask = city_data.mask
    if (not ENABLE_POLICY_BGI_BENEFIT_CORRECTION) or float(theta_BGI) <= BGI_EFFECT_MIN_THETA:
        e = np.zeros(mask.shape, dtype="float32")
        e[~mask] = np.nan
        return e

    W = city_data.weights
    base = W.get("W_bgi", W.get("W_green", np.zeros(mask.shape, dtype="float32"))).astype("float32")
    e = np.clip(float(theta_BGI) * base, 0, 1).astype("float32")
    e = masked_gaussian(e, mask, BGI_EFFECT_SMOOTH_SIGMA)
    e[~mask] = np.nan
    return e.astype("float32")


def should_apply_no_negative_projection(city_data, scenario, theta):
    if not V35_NO_NEGATIVE_NO_FALLBACK_MODE:
        return False
    if city_data.city not in V35_NO_NEGATIVE_PROJECTION_CITIES:
        return False
    if scenario not in V35_NO_NEGATIVE_PROJECTION_SCENARIOS:
        return False
    theta = _pad_theta(theta)
    theta_bgi = float(theta[THETA_COLS.index("theta_BGI")]) if "theta_BGI" in THETA_COLS else 0.0
    return theta_bgi > BGI_EFFECT_MIN_THETA


def apply_no_negative_projection_to_full_targets(city_data, theta, T, scenario=None):
    """
    V35 no-maladaptation safeguard.

    For the specified difficult city-scenario, prevent final F1/F2 surfaces from
    becoming worse than S0 while retaining a small BGI-priority positive effect.
    This avoids producing a double-negative "optimized" scenario and avoids pure S0 fallback.
    """
    if not should_apply_no_negative_projection(city_data, scenario, theta):
        return T

    mask = city_data.mask
    theta = _pad_theta(theta)
    theta_bgi = float(theta[THETA_COLS.index("theta_BGI")])
    e = compute_bgi_policy_effect(city_data, theta_bgi)
    e0 = np.nan_to_num(e, nan=0.0)

    out = dict(T)
    F1 = out["F1"].copy()
    F2 = out["F2"].copy()

    # Risk cannot exceed baseline; with BGI effect it receives a small positive margin.
    F1_cap = city_data.F1_0 * (1.0 - V35_NO_NEGATIVE_F1_EPS * e0)
    F1 = np.minimum(F1, F1_cap)

    # Livability cannot fall below baseline; with BGI effect it receives a small positive margin.
    F2_floor = city_data.F2_0 + V35_NO_NEGATIVE_F2_EPS * e0 * (1.0 - city_data.F2_0)
    F2 = np.maximum(F2, F2_floor)

    F1[~mask] = np.nan
    F2[~mask] = np.nan

    out["F1"] = masked_gaussian(np.clip(F1, 0, 1), mask, TARGET_SMOOTH_SIGMA["F1"])
    out["F2"] = masked_gaussian(np.clip(F2, 0, 1), mask, TARGET_SMOOTH_SIGMA["F2"])
    out["NoNegativeProjectionApplied"] = True
    out["NoNegativeProjectionScenario"] = scenario
    return out



def apply_policy_bgi_correction_to_full_targets(city_data, theta, T, scenario=None):
    """
    Apply BGI policy/causal correction to full target surfaces.
    F1 is reduced in BGI-priority cells; F2 is increased with diminishing returns.
    """
    if city_data.city not in POLICY_BGI_CORRECTION_CITIES:
        return T

    theta = _pad_theta(theta)
    theta_BGI = float(theta[THETA_COLS.index("theta_BGI")]) if "theta_BGI" in THETA_COLS else 0.0
    if theta_BGI <= BGI_EFFECT_MIN_THETA:
        return T

    mask = city_data.mask
    e = compute_bgi_policy_effect(city_data, theta_BGI)

    out = dict(T)
    F1 = out["F1"].copy()
    F2 = out["F2"].copy()

    F1 = F1 * (1.0 - BGI_F1_RISK_REDUCTION_COEF * np.nan_to_num(e, nan=0.0))
    F2 = F2 + BGI_F2_LIVABILITY_GAIN_COEF * np.nan_to_num(e, nan=0.0) * (1.0 - F2)

    F1[~mask] = np.nan
    F2[~mask] = np.nan
    out["F1"] = masked_gaussian(np.clip(F1, 0, 1), mask, TARGET_SMOOTH_SIGMA["F1"])
    out["F2"] = masked_gaussian(np.clip(F2, 0, 1), mask, TARGET_SMOOTH_SIGMA["F2"])
    out["BGI_policy_effect"] = e
    out["PolicyBGICorrectionApplied"] = True

    # V35 no-negative safeguard, applied after BGI policy correction.
    out = apply_no_negative_projection_to_full_targets(city_data, theta, out, scenario=scenario)
    return out


def apply_policy_bgi_correction_to_sample(city_data, theta, idx, F1, F2, scenario=None):
    """
    Apply the same BGI correction in sampled optimization evaluation.
    """
    if city_data.city not in POLICY_BGI_CORRECTION_CITIES:
        return F1, F2, False

    theta = _pad_theta(theta)
    theta_BGI = float(theta[THETA_COLS.index("theta_BGI")]) if "theta_BGI" in THETA_COLS else 0.0
    if theta_BGI <= BGI_EFFECT_MIN_THETA:
        return F1, F2, False

    e_full = compute_bgi_policy_effect(city_data, theta_BGI)
    e = e_full.ravel()[idx]
    e0 = np.nan_to_num(e, nan=0.0)
    F1c = F1 * (1.0 - BGI_F1_RISK_REDUCTION_COEF * e0)
    F2c = F2 + BGI_F2_LIVABILITY_GAIN_COEF * e0 * (1.0 - F2)

    if should_apply_no_negative_projection(city_data, scenario, theta):
        F1_0_s = city_data.F1_0.ravel()[idx]
        F2_0_s = city_data.F2_0.ravel()[idx]
        F1_cap = F1_0_s * (1.0 - V35_NO_NEGATIVE_F1_EPS * e0)
        F2_floor = F2_0_s + V35_NO_NEGATIVE_F2_EPS * e0 * (1.0 - F2_0_s)
        F1c = np.minimum(F1c, F1_cap)
        F2c = np.maximum(F2c, F2_floor)

    return np.clip(F1c, 0, 1), np.clip(F2c, 0, 1), True



def eval_theta(city_data, model, theta, full=False, scenario=None):
    theta = _pad_theta(theta)

    # V12 exact zero-theta baseline consistency:
    # A00_baseline_zero must be exactly S0 in J1/J2/J3/retention/intensity.
    if full and EXACT_ZERO_THETA_AS_S0 and np.all(np.abs(theta) <= THETA_ZERO_EPS):
        base = city_data.baseline_metrics
        J1 = float(base["J1_S0"])
        J2 = float(base["J2_S0"])
        J3 = 1.0
        ret = 1.0
        over = 0.0
        var_dict = city_data.raw
        changes = {f"d{v}":np.zeros(city_data.mask.shape,dtype="float32") for v in ["NDVI","GVI","Micro_PSA","Micro_ISA","BD","BH"]}
        changes["dLULC"] = np.zeros(city_data.mask.shape,dtype="float32")
        for k in changes:
            changes[k][~city_data.mask] = np.nan
        inten = 0.0
        feasible = True
        viol = {
            "NDVI_range":0.0,"GVI_range":0.0,"Micro_PSA_range":0.0,"Micro_ISA_range":0.0,
            "surface_sum":0.0,"highrisk_BD_increase":0.0,"highrisk_BH_increase":0.0,
            "protected_LULC_change":0.0,"LULC_area":0.0,"Eco_non_decrease":0.0,
            "CGI_retention":0.0,"intervention_intensity":0.0
        }
        info = {
            "J1":J1,"J2":J2,"J3":J3,"CGI_retention":ret,"CGI_overgrowth_penalty":over,
            "InterventionIntensity":inten,"feasible":feasible,
            "PolicyBGICorrectionApplied": False,
            "theta_BGI_eval": 0.0,
            "J1_raw_before_policy_BGI": J1,
            "J2_raw_before_policy_BGI": J2,
            **{f"viol_{k}":v for k,v in viol.items()}
        }
        return np.array([J1,-J2,-J3], dtype=float), info, var_dict, changes

    var_dict, changes = apply_decision(city_data, theta)
    if full:
        P = predict_p(model, var_dict, city_data, None)
        T = compute_targets_full(city_data,var_dict,P)

        # V28 diagnostics: raw ML-response metrics before policy BGI correction.
        J1_raw_policy_diag = compute_J1_from_target(T["F1"], city_data.F1_0, city_data.mask)
        J2_raw_policy_diag = compute_J2_from_target(T["F2"], city_data.F2_0, city_data.mask)

        T = apply_policy_bgi_correction_to_full_targets(city_data, theta, T, scenario=scenario)
        J1 = compute_J1_from_target(T["F1"], city_data.F1_0, city_data.mask)
        J2 = compute_J2_from_target(T["F2"], city_data.F2_0, city_data.mask)
        J3, ret, over = compute_J3_from_target(T["F3"], city_data.F3_0, city_data.mask)
    else:
        idx = city_data.sample_idx
        P = predict_p(model, var_dict, city_data, idx)
        flat = lambda a: a.ravel()[idx]
        exp = [flat(get_z(city_data, city_data.raw, "PopD")) if "PopD" in city_data.raw else flat(get_z(city_data, city_data.raw, "PD"))]
        for v in ["GDP","NTL","RD"]:
            if v in city_data.raw: exp.append(flat(get_z(city_data, city_data.raw, v)))
        EI=np.nanmean(np.vstack(exp),axis=0); F1=P*EI
        lulc=flat(var_dict["LULC"]); eco_l=np.array([LULC_ECO_MAP.get(int(x),0) for x in lulc]); urb=(lulc.astype(int)==8).astype("float32")
        z_ndvi,z_gvi,z_psa,z_isa=[flat(get_z(city_data,var_dict,v)) for v in ["NDVI","GVI","Micro_PSA","Micro_ISA"]]
        Eco=np.nanmean(np.vstack([z_ndvi,eco_l]),axis=0); Lst=np.nanmean(np.vstack([z_gvi,z_psa,1-z_isa]),axis=0); F2=np.sqrt(np.clip(Eco,0,1)*np.clip(urb*Lst+(1-urb)*Eco,0,1))
        F1, F2, _policy_bgi_sample_applied = apply_policy_bgi_correction_to_sample(city_data, theta, idx, F1, F2, scenario=scenario)
        z_bd,z_bh=flat(get_z(city_data,var_dict,"BD")),flat(get_z(city_data,var_dict,"BH"))
        urban_s=np.array([LULC_URBAN_MAP.get(int(x),0) for x in lulc], dtype="float32")
        F1_0,F2_0,F3_0=flat(city_data.F1_0),flat(city_data.F2_0),flat(city_data.F3_0)

        # 稳定版 F3 样本估计：以基准 CGI 为锚，按 BD/BH/LULC urban ratio 更新，避免重算 CGI 在测试中塌陷为 0。
        BD0_s=flat(city_data.raw["BD"]); BH0_s=flat(city_data.raw["BH"])
        BD_s=flat(var_dict["BD"]); BH_s=flat(var_dict["BH"])
        L0_s=flat(city_data.raw["LULC"])
        urban0=np.array([LULC_URBAN_MAP.get(int(x),0) for x in L0_s], dtype="float32")
        bd_ratio=np.where(np.abs(BD0_s)>1e-6, BD_s/(BD0_s+1e-6), 1.0)
        bh_ratio=np.where(np.abs(BH0_s)>1e-6, BH_s/(BH0_s+1e-6), 1.0)
        urban_ratio=np.where(urban0>1e-6, urban_s/(urban0+1e-6), 1.0)
        retention_surface=np.sqrt(np.clip(bd_ratio,0,1.2)*np.clip(bh_ratio,0,1.2))*np.clip(urban_ratio,0,1.2)
        F3=F3_0*retention_surface
        J1_raw_policy_diag = np.nan
        J2_raw_policy_diag = np.nan
        H=F1_0>=np.nanpercentile(F1_0[np.isfinite(F1_0)],HOTSPOT_Q); L=F2_0<=np.nanpercentile(F2_0[np.isfinite(F2_0)],LOW_LIVABILITY_Q)
        J1=ALPHA_J1_MEAN*np.nanmean(F1)+(1-ALPHA_J1_MEAN)*np.nanmean(F1[H])
        J2=ALPHA_J2_MEAN*np.nanmean(F2)+(1-ALPHA_J2_MEAN)*np.nanmean(F2[L])
        ret=1-np.nanmean(np.maximum(F3_0-F3,0))/(np.nanmean(F3_0)+1e-9); q95=np.nanpercentile(F3_0[np.isfinite(F3_0)],95); over=np.nanmean(np.maximum(F3-q95,0))/(q95+1e-9); J3=ret-LAMBDA_CGI_OVERGROWTH*over
    inten = intervention_intensity(city_data,changes)
    feasible, viol = constraints(city_data,var_dict,changes,J1,J2,J3,ret,inten)
    obj=np.array([J1,-J2,-J3],float)
    penalty=sum(max(0,float(v)) for v in viol.values())
    obj_pen=obj+10*penalty
    info={"J1":float(J1),"J2":float(J2),"J3":float(J3),"CGI_retention":float(ret),"CGI_overgrowth_penalty":float(over),"InterventionIntensity":float(inten),"feasible":bool(feasible),**{f"viol_{k}":float(v) for k,v in viol.items()}}

    try:
        theta_arr = _pad_theta(theta)
        theta_bgi_val = float(theta_arr[THETA_COLS.index("theta_BGI")]) if "theta_BGI" in THETA_COLS else 0.0
    except Exception:
        theta_bgi_val = 0.0
    info["PolicyBGICorrectionApplied"] = bool(
        ENABLE_POLICY_BGI_BENEFIT_CORRECTION and
        city_data.city in POLICY_BGI_CORRECTION_CITIES and
        theta_bgi_val > BGI_EFFECT_MIN_THETA
    )
    info["NoNegativeProjectionApplied"] = bool(should_apply_no_negative_projection(city_data, scenario, theta))
    info["NoNegativeProjectionScenario"] = scenario if info["NoNegativeProjectionApplied"] else np.nan
    info["theta_BGI_eval"] = float(theta_bgi_val)
    info["J1_raw_before_policy_BGI"] = float(J1_raw_policy_diag) if np.isfinite(J1_raw_policy_diag) else np.nan
    info["J2_raw_before_policy_BGI"] = float(J2_raw_policy_diag) if np.isfinite(J2_raw_policy_diag) else np.nan

    return obj_pen, info, var_dict, changes

def constraints(city_data,var_dict,changes,J1,J2,J3,ret,inten):
    mask=city_data.mask; viol={}
    for v in ["NDVI","GVI","Micro_PSA","Micro_ISA"]:
        a=var_dict[v]; viol[f"{v}_range"]=max(0,-float(np.nanmin(a[mask])))+max(0,float(np.nanmax(a[mask]))-1)
    viol["surface_sum"] = max(0, float(np.nanmax((var_dict["Micro_PSA"]+var_dict["Micro_ISA"])[mask]))-1)
    H = mask & (city_data.F1_0 >= np.nanpercentile(city_data.F1_0[mask&np.isfinite(city_data.F1_0)], HIGH_RISK_CONTROL_Q))
    viol["highrisk_BD_increase"] = max(0,float(np.nanmax(var_dict["BD"][H]-city_data.raw["BD"][H]))) if H.any() else 0
    viol["highrisk_BH_increase"] = max(0,float(np.nanmax(var_dict["BH"][H]-city_data.raw["BH"][H]))) if H.any() else 0
    protected = mask & np.isin(city_data.raw["LULC"].astype(int),[2,5,9])
    viol["protected_LULC_change"] = float(np.nanmean((var_dict["LULC"][protected]!=city_data.raw["LULC"][protected]).astype("float32"))) if protected.any() else 0
    rho = float((mask & (var_dict["LULC"]!=city_data.raw["LULC"])).sum())/float(mask.sum())
    viol["LULC_area"] = max(0,rho-RHO_LULC_MAX)
    Eco_s=np.nanmean(np.stack([get_z(city_data,var_dict,"NDVI"),reclass_lulc(var_dict["LULC"],LULC_ECO_MAP)]),axis=0)
    Eco_0=np.nanmean(np.stack([get_z(city_data,city_data.raw,"NDVI"),reclass_lulc(city_data.raw["LULC"],LULC_ECO_MAP)]),axis=0)
    viol["Eco_non_decrease"] = max(0,float(np.nanmean(Eco_0[mask])-np.nanmean(Eco_s[mask])))
    viol["CGI_retention"] = max(0, ETA_CGI_MAIN-ret)
    viol["intervention_intensity"] = max(0, inten-I_MAX)

    # V8 no-maladaptation guard:
    # A final adaptation candidate should not increase J1 or decrease J2 relative to S0.
    # This prevents cases such as Chengdu citycheck where feasible solutions were technically
    # constraint-satisfying but directionally worse than baseline.
    if NO_MALADAPTATION_HARD_CONSTRAINT:
        base = city_data.baseline_metrics
        viol["J1_no_worse_than_S0"] = max(0, float(J1 - base["J1_S0"]))
        viol["J2_no_worse_than_S0"] = max(0, float(base["J2_S0"] - J2))

    feasible=all(v<=1e-6 for v in viol.values())
    return feasible, viol

# ============================================================
# 6. Optimization with pymoo and fallback MOPSO
# ============================================================

class AdaptationProblem(ElementwiseProblem):
    def __init__(self, city_data, model):
        super().__init__(n_var=N_THETA, n_obj=3, n_constr=0, xl=np.zeros(N_THETA), xu=np.ones(N_THETA))
        self.city_data=city_data; self.model=model; self.records=[]
    def _evaluate(self, x, out, *args, **kwargs):
        F, info, _, _ = eval_theta(self.city_data,self.model,np.asarray(x),full=False)
        out["F"] = F
        self.records.append({**{f"theta_{k}":v for k,v in zip(THETA_LABELS,x)}, **info, "Obj1_min_J1":F[0], "Obj2_min_minus_J2":F[1], "Obj3_min_minus_J3":F[2]})

class PymooProgress(Callback):
    """
    Safer progress callback for pymoo.

    Different pymoo versions handle callback slightly differently:
    - newer versions call callback.notify(algorithm);
    - some versions accept a callable callback(algorithm).
    This class supports both notify() and __call__().
    """
    def __init__(self, city, algorithm_name, total_generations):
        try:
            super().__init__()
        except Exception:
            pass
        self.city = city
        self.algorithm_name = algorithm_name
        self.total = int(total_generations)
        self.last_gen = 0
        self.pbar = None

    def notify(self, algorithm):
        self._update(algorithm)

    def __call__(self, algorithm):
        self._update(algorithm)

    def _update(self, algorithm):
        gen = int(getattr(algorithm, "n_gen", 0) or 0)

        if self.pbar is None:
            if SHOW_PROGRESS_BARS and tqdm is not None:
                self.pbar = tqdm(
                    total=self.total,
                    desc=f"{self.city} | {self.algorithm_name}",
                    unit="gen",
                    dynamic_ncols=True,
                    leave=True
                )
            else:
                print(f"[PROGRESS] {self.city} | {self.algorithm_name}: start, total generations={self.total}")

        completed = min(max(gen, 0), self.total)
        inc = completed - self.last_gen

        if inc > 0:
            if self.pbar is not None:
                self.pbar.update(inc)
            elif completed % max(PROGRESS_UPDATE_EVERY_GEN, 1) == 0:
                print(f"[PROGRESS] {self.city} | {self.algorithm_name}: {completed}/{self.total}")
            self.last_gen = completed

        if completed >= self.total and self.pbar is not None:
            self.pbar.close()
            self.pbar = None


def iter_with_progress(iterable, desc):
    if SHOW_PROGRESS_BARS and tqdm is not None:
        return tqdm(iterable, desc=desc, dynamic_ncols=True)
    return iterable



def run_pymoo_algorithm(city_data, model, alg_name):
    if not PYMOO_AVAILABLE:
        raise RuntimeError("pymoo is not installed. Install it or set up the environment with pymoo.")
    ref_dirs = get_reference_directions("das-dennis", 3, n_partitions=N_REF_PARTITIONS)
    if alg_name == "NSGA-II":
        algorithm = NSGA2(pop_size=POP_SIZE)
    elif alg_name == "NSGA-III":
        algorithm = NSGA3(pop_size=POP_SIZE, ref_dirs=ref_dirs)
    elif alg_name == "MOEA-D":
        algorithm = MOEAD(ref_dirs=ref_dirs, n_neighbors=15, prob_neighbor_mating=0.7)
    elif alg_name == "SPEA2":
        algorithm = SPEA2(pop_size=POP_SIZE)
    else:
        raise ValueError(alg_name)
    problem=AdaptationProblem(city_data,model)
    progress_callback = PymooProgress(city_data.city, alg_name, N_GENERATIONS)
    res = minimize(
        problem,
        algorithm,
        ('n_gen', N_GENERATIONS),
        seed=RANDOM_SEED,
        verbose=False,
        save_history=True,
        callback=progress_callback
    )
    X=np.asarray(res.pop.get("X"),float); F=np.asarray(res.pop.get("F"),float)
    infos=[]
    for x in X:
        _, info, _, _ = eval_theta(city_data,model,x,full=False); infos.append(info)
    conv=[]
    for it, hist in enumerate(res.history):
        pop=hist.pop
        FF=np.asarray(pop.get("F"),float)
        conv.append(convergence_row(city_data.city,alg_name,it,FF,problem.records))
    return X,F,infos,pd.DataFrame(conv)

def run_mopso(city_data, model):
    # lightweight internal MOPSO fallback; uses same objective budget scale.
    X=RNG.random((POP_SIZE,6)); V=RNG.normal(0,0.1,(POP_SIZE,6))
    F=[]; infos=[]
    for x in X:
        f,info,_,_=eval_theta(city_data,model,x,False); F.append(f); infos.append(info)
    F=np.asarray(F,float); pbest_X=X.copy(); pbest_F=F.copy(); pbest_infos=infos.copy()
    archive_X,archive_F,archive_infos=select_nd_archive(X,F,infos,POP_SIZE)
    conv=[convergence_row(city_data.city,"MOPSO",0,archive_F,archive_infos)]
    for gen in iter_with_progress(range(1,N_GENERATIONS+1), f"{city_data.city} | MOPSO"):
        for i in range(POP_SIZE):
            g=archive_X[RNG.integers(0,len(archive_X))]
            V[i]=0.55*V[i]+1.6*RNG.random(6)*(pbest_X[i]-X[i])+1.6*RNG.random(6)*(g-X[i])
            V[i]=np.clip(V[i],-0.25,0.25); X[i]=np.clip(X[i]+V[i],0,1)
        F=[]; infos=[]
        for x in X:
            f,info,_,_=eval_theta(city_data,model,x,False); F.append(f); infos.append(info)
        F=np.asarray(F,float)
        for i in range(POP_SIZE):
            if dominates(F[i],pbest_F[i]) or (not dominates(pbest_F[i],F[i]) and RNG.random()<0.5):
                pbest_X[i]=X[i]; pbest_F[i]=F[i]; pbest_infos[i]=infos[i]
        archive_X,archive_F,archive_infos=select_nd_archive(np.vstack([archive_X,X]),np.vstack([archive_F,F]),archive_infos+infos,POP_SIZE)
        conv.append(convergence_row(city_data.city,"MOPSO",gen,archive_F,archive_infos))
    return archive_X,archive_F,archive_infos,pd.DataFrame(conv)

def dominates(a,b):
    return np.all(a<=b) and np.any(a<b)

def nondominated_mask(F):
    n=len(F); nd=np.ones(n,dtype=bool)
    for i in range(n):
        for j in range(n):
            if i!=j and dominates(F[j],F[i]): nd[i]=False; break
    return nd

def select_nd_archive(X,F,infos,n):
    nd=nondominated_mask(F); idx=np.where(nd)[0]
    if len(idx)>n:
        # keep diverse by random if too many
        idx=RNG.choice(idx,size=n,replace=False)
    elif len(idx)<n:
        rest=np.setdiff1d(np.arange(len(F)),idx)
        if len(rest)>0:
            add=rest[np.argsort(np.linalg.norm(F[rest]-np.nanmin(F,axis=0),axis=1))[:n-len(idx)]]
            idx=np.concatenate([idx,add])
    return X[idx],F[idx],[infos[i] for i in idx]

def convergence_row(city,alg,it,F,infos_or_records):
    F=np.asarray(F,float)
    nd=nondominated_mask(F) if len(F) else np.array([])
    feas=[]
    for r in infos_or_records:
        if isinstance(r,dict) and "feasible" in r: feas.append(bool(r["feasible"]))
    return {"City":city,"Algorithm":alg,"Iteration":it,"N_population":int(len(F)),"N_nondominated":int(nd.sum()) if len(F) else 0,"FeasibleRate":float(np.mean(feas)) if feas else np.nan,
            "Best_J1":float(np.nanmin(F[:,0])) if len(F) else np.nan,"Best_minus_J2":float(np.nanmin(F[:,1])) if len(F) else np.nan,"Best_minus_J3":float(np.nanmin(F[:,2])) if len(F) else np.nan}

def run_algorithm(city_data, model, alg):
    if alg == "MOPSO": return run_mopso(city_data,model)
    return run_pymoo_algorithm(city_data,model,alg)

# ============================================================
# 7. Metrics, scenario selection, saving
# ============================================================

def solution_df(city,alg,X,F,infos):
    nd=nondominated_mask(F)
    rows=[]
    for i,x in enumerate(X):
        rows.append({"City":city,"Algorithm":alg,"SolutionID":f"{alg}_{i:04d}","theta_G":x[0],"theta_S":x[1],"theta_P":x[2],"theta_D":x[3],"theta_T":x[4],"theta_L":x[5],
                     "Obj1_min_J1":F[i,0],"Obj2_min_minus_J2":F[i,1],"Obj3_min_minus_J3":F[i,2],"Pareto":bool(nd[i]),**infos[i]})
    return pd.DataFrame(rows)

def approximate_hv(Fn, n_samples=3000):
    if len(Fn)==0: return 0.0
    ref=np.array([1.1,1.1,1.1]); samples=RNG.random((n_samples,3))*ref
    dom=np.zeros(n_samples,dtype=bool)
    for p in Fn: dom |= np.all(p<=samples,axis=1)
    return float(dom.mean()*np.prod(ref))

def igd_plus(F,R):
    if len(F)==0 or len(R)==0: return np.inf
    return float(np.mean([np.min(np.sqrt(np.sum(np.maximum(F-r,0)**2,axis=1))) for r in R]))

def spread(F):
    if len(F)<3: return np.inf
    D=np.sqrt(((F[:,None,:]-F[None,:,:])**2).sum(axis=2)); np.fill_diagonal(D,np.inf); nn=np.min(D,axis=1)
    return float(np.std(nn)/(np.mean(nn)+1e-12))

def compare_algorithms(city, tables):
    allF=[]
    for df in tables.values():
        F=df[df.Pareto][["Obj1_min_J1","Obj2_min_minus_J2","Obj3_min_minus_J3"]].to_numpy(float)
        if len(F): allF.append(F)
    if not allF: return pd.DataFrame()
    union=np.vstack(allF); ref=union[nondominated_mask(union)]; ideal=np.nanmin(union,axis=0); nadir=np.nanmax(union,axis=0)
    refn=(ref-ideal)/(nadir-ideal+1e-12)
    rows=[]
    for alg,df in tables.items():
        nd=df[df.Pareto]
        F=nd[["Obj1_min_J1","Obj2_min_minus_J2","Obj3_min_minus_J3"]].to_numpy(float)
        Fn=(F-ideal)/(nadir-ideal+1e-12) if len(F) else F
        rows.append({"City":city,"Algorithm":alg,"HV_final":approximate_hv(Fn),"IGD_plus_final":igd_plus(Fn,refn),"Spread_final":spread(Fn),"FeasibleRate_final":float(nd["feasible"].mean()) if len(nd) and "feasible" in nd else np.nan,"N_Pareto":len(nd)})
    comp=pd.DataFrame(rows)
    comp["Rank_HV"]=comp.HV_final.rank(ascending=False,method="min"); comp["Rank_IGD"]=comp.IGD_plus_final.rank(ascending=True,method="min")
    comp["Rank_Spread"]=comp.Spread_final.rank(ascending=True,method="min"); comp["Rank_Feasible"]=comp.FeasibleRate_final.rank(ascending=False,method="min"); comp["Rank_NPareto"]=comp.N_Pareto.rank(ascending=False,method="min")
    comp["AlgorithmScore"]=comp[["Rank_HV","Rank_IGD","Rank_Spread","Rank_Feasible","Rank_NPareto"]].sum(axis=1)
    comp["Selected_city_best"]=comp.AlgorithmScore==comp.AlgorithmScore.min()
    return comp

THETA_COLS = ["theta_G", "theta_S", "theta_P", "theta_D", "theta_T", "theta_L", "theta_BGI"]
THETA_LABELS = ["G","S","P","D","T","L","BGI"]
N_THETA = len(THETA_COLS)

def deduplicate_solution_table(df):
    """
    Remove near-duplicated Pareto solutions before full-raster re-evaluation.
    """
    if df is None or len(df) == 0:
        return df

    out = df.copy()
    for c in THETA_COLS:
        out[c] = out[c].astype(float)

    key_theta = out[THETA_COLS].round(DEDUP_THETA_DECIMALS).astype(str).agg("_".join, axis=1)
    out["_dedup_theta_key"] = key_theta
    out = out.drop_duplicates("_dedup_theta_key", keep="first").copy()

    obj_cols = ["Obj1_min_J1", "Obj2_min_minus_J2", "Obj3_min_minus_J3"]
    if all(c in out.columns for c in obj_cols):
        key_obj = out[obj_cols].round(DEDUP_OBJECTIVE_DECIMALS).astype(str).agg("_".join, axis=1)
        out["_dedup_obj_key"] = key_obj
        out = out.drop_duplicates("_dedup_obj_key", keep="first").copy()

    return out.drop(columns=[c for c in ["_dedup_theta_key", "_dedup_obj_key"] if c in out.columns])


def select_pareto_for_full_recheck(pareto_df, max_n=MAX_FULL_RECHECK_SOLUTIONS):
    """
    Keep a diverse subset of sampled Pareto solutions for full-raster re-evaluation.
    """
    df = deduplicate_solution_table(pareto_df)
    if df is None or len(df) == 0:
        return df

    if len(df) <= max_n:
        selected = df.copy()
        selected["SelectedForFullRecheck"] = True
        return selected

    obj = df[["Obj1_min_J1", "Obj2_min_minus_J2", "Obj3_min_minus_J3"]].to_numpy(float)
    keep = set()

    keep.add(int(np.nanargmin(obj[:, 0])))  # min J1
    keep.add(int(np.nanargmin(obj[:, 1])))  # max J2
    keep.add(int(np.nanargmin(obj[:, 2])))  # max J3

    mn = np.nanmin(obj, axis=0)
    mx = np.nanmax(obj, axis=0)
    z = (obj - mn) / (mx - mn + 1e-12)
    dist = np.sqrt(np.sum(z**2, axis=1))
    for i in np.argsort(dist)[:max(3, max_n // 4)]:
        keep.add(int(i))

    if "feasible" in df.columns:
        feas_idx = np.where(df["feasible"].astype(bool).to_numpy())[0]
        for i in feas_idx:
            keep.add(int(i))
            if len(keep) >= max_n:
                break

    if len(keep) < max_n:
        remaining = [i for i in range(len(df)) if i not in keep]
        if remaining:
            pick = np.linspace(0, len(remaining) - 1, max_n - len(keep)).round().astype(int)
            for j in pick:
                keep.add(int(remaining[j]))

    selected = df.iloc[sorted(list(keep))[:max_n]].copy()
    selected["SelectedForFullRecheck"] = True
    return selected


def get_policy_anchor_thetas():
    """
    V31 compact deterministic policy anchors.

    This keeps the key safety anchors while avoiding too many full-domain rechecks.
    Theta order:
    [theta_G, theta_S, theta_P, theta_D, theta_T, theta_L, theta_BGI]
    """
    anchors = [
        ("A00_baseline_zero",              [0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00]),
        ("A07_green_permeable",            [0.75, 0.00, 0.75, 0.00, 0.00, 0.00, 0.00]),
        ("A16_BGI_medium",                 [0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.75]),
        ("A17_BGI_balanced",               [0.30, 0.30, 0.30, 0.00, 0.00, 0.00, 0.60]),
    ]
    return [(name, np.asarray(theta, dtype=float)) for name, theta in anchors]


def _theta_cache_key(theta, ndigits=6):
    return tuple(np.round(np.asarray(theta, dtype=float), ndigits))


def cached_eval_theta_full(city_data, model, theta):
    """
    V18 cache for full-domain evaluation.

    Policy anchors are reused across S1-S7 and some optimized theta values may repeat.
    Full-domain prediction is the expensive part, so caching avoids repeated raster-wide
    prediction for the same theta within a city.
    """
    if not FULL_RECHECK_CACHE_ENABLED:
        return eval_theta(city_data, model, theta, full=True)

    key = _theta_cache_key(theta)
    if not hasattr(city_data, "_full_eval_cache"):
        city_data._full_eval_cache = {}

    if key in city_data._full_eval_cache:
        info = city_data._full_eval_cache[key].copy()
        # var_dict/changes are not needed for full-recheck tables.
        return np.array([info["J1"], -info["J2"], -info["J3"]], dtype=float), info, None, None

    F, info, var_dict, changes = eval_theta(city_data, model, theta, full=True)
    city_data._full_eval_cache[key] = info.copy()
    return F, info, var_dict, changes



def make_anchor_solution_row(city_data, model, anchor_name, theta, algorithm_name, local_i):
    """
    Evaluate one deterministic policy anchor with full-domain metrics and convert it
    into the same table structure as full-rechecked Pareto candidates.
    """
    _, info, _, _ = cached_eval_theta_full(city_data, model, theta)
    row = {
        "City": city_data.city,
        "Algorithm": algorithm_name,
        "SolutionID": f"{algorithm_name}_ANCHOR_{local_i:03d}_{anchor_name}",
        "FullRecheckID": f"{algorithm_name}_ANCHOR_{local_i:03d}_{anchor_name}",
        "PolicyAnchor": True,
        "PolicyAnchorName": anchor_name,
        "SelectedForFullRecheck": True,
        "FullRechecked": True,
        "Pareto": False,
    }
    for c, val in zip(THETA_COLS, theta):
        row[c] = float(val)

    row.update(info)
    row["Obj1_min_J1"] = info["J1"]
    row["Obj2_min_minus_J2"] = -info["J2"]
    row["Obj3_min_minus_J3"] = -info["J3"]
    return row


def append_policy_anchors(city_data, model, rows, algorithm_name):
    """
    Add deterministic anchor solutions into full-recheck pool, then remove duplicate theta.
    """
    if not ADD_POLICY_ANCHORS_TO_FULL_RECHECK:
        return rows

    anchor_rows = []
    existing_keys = set()
    for r in rows:
        try:
            key = tuple(round(float(r[c]), DEDUP_THETA_DECIMALS) for c in THETA_COLS)
            existing_keys.add(key)
        except Exception:
            pass

    for i, (name, theta) in enumerate(get_policy_anchor_thetas()):
        key = tuple(round(float(x), DEDUP_THETA_DECIMALS) for x in theta)
        if key in existing_keys:
            continue
        anchor_rows.append(make_anchor_solution_row(city_data, model, name, theta, algorithm_name, i))
        existing_keys.add(key)

    return rows + anchor_rows



def full_recheck_pareto(city_data, model, pareto_df, out_dir, algorithm_name):
    """
    V3 core upgrade:
    sampled Pareto -> full-raster re-evaluation -> full-domain Pareto.
    Scenario selection uses this full-rechecked table, not the sampled metrics.
    """
    ensure_dir(out_dir)

    if not FULL_RECHECK_PARETO:
        out = pareto_df.copy()
        out["Pareto_full"] = out.get("Pareto", True)
        return out

    cand = select_pareto_for_full_recheck(pareto_df, MAX_FULL_RECHECK_SOLUTIONS)
    rows = []

    iterator = iter_with_progress(range(len(cand)), f"{city_data.city}: full recheck Pareto")
    for local_i in iterator:
        r = cand.iloc[local_i].copy()
        theta = np.array([r[c] for c in THETA_COLS], dtype=float)

        _, info, _, _ = cached_eval_theta_full(city_data, model, theta)

        row = r.to_dict()

        for key in ["J1", "J2", "J3", "CGI_retention", "InterventionIntensity"]:
            if key in row:
                row[f"{key}_sample"] = row[key]

        row.update(info)
        row["Obj1_min_J1"] = info["J1"]
        row["Obj2_min_minus_J2"] = -info["J2"]
        row["Obj3_min_minus_J3"] = -info["J3"]
        row["FullRechecked"] = True
        row["FullRecheckID"] = f"{algorithm_name}_FR_{local_i:04d}"
        rows.append(row)

    # V10: include deterministic policy anchors in the full-recheck candidate pool.
    rows = append_policy_anchors(city_data, model, rows, algorithm_name)

    out = pd.DataFrame(rows)

    if len(out) > 0:
        # Deduplicate again after anchors.
        out = deduplicate_solution_table(out)
        F = out[["Obj1_min_J1", "Obj2_min_minus_J2", "Obj3_min_minus_J3"]].to_numpy(float)
        out["Pareto_full"] = nondominated_mask(F)
    else:
        out["Pareto_full"] = []

    out_path = os.path.join(out_dir, f"{algorithm_name}_pareto_full_recheck.csv")
    out.to_csv(out_path, index=False, encoding="utf-8-sig")

    nd_path = os.path.join(out_dir, f"{algorithm_name}_pareto_full_recheck_nondominated.csv")
    out[out["Pareto_full"]].to_csv(nd_path, index=False, encoding="utf-8-sig")

    return out


def scenario_penalty(row,scenario,base):
    c=SCENARIOS[scenario]["constraints"]; p=0

    # V8: baseline fallback rows are explicitly accepted as zero-change fallback.
    if hasattr(row, "UseBaselineFallback") and bool(row.UseBaselineFallback):
        return 0

    # General no-maladaptation penalty for all optimized scenarios.
    # Individual scenario constraints below can still be stricter.
    p += max(0, row.J1-base["J1_S0"])*100
    p += max(0, base["J2_S0"]-row.J2)*100

    if c.get("J2_ge_S0",False): p+=max(0,base["J2_S0"]-row.J2)*100
    if c.get("J1_le_S0",False): p+=max(0,row.J1-base["J1_S0"])*100
    if "J3_ge" in c: p+=max(0,c["J3_ge"]-row.CGI_retention)*100
    if "J1_reduction_pct_ge" in c:
        red=(base["J1_S0"]-row.J1)/(base["J1_S0"]+1e-9)*100; p+=max(0,c["J1_reduction_pct_ge"]-red)*10
    if "J2_improvement_pct_ge" in c:
        imp=(row.J2-base["J2_S0"])/(abs(base["J2_S0"])+1e-9)*100; p+=max(0,c["J2_improvement_pct_ge"]-imp)*10
    return p

def _solution_key(row):
    for k in ["FullRecheckID", "SolutionID"]:
        if k in row and pd.notna(row[k]):
            return str(row[k])
    theta_vals = []
    for k in THETA_COLS:
        if k in row:
            theta_vals.append(round(float(row[k]), DEDUP_THETA_DECIMALS))
    return "theta_" + "_".join(map(str, theta_vals))


def _fallback_solution_row(scenario, base, reason, expanded_from_pareto=False):
    return pd.Series({
        "theta_G": 0.0, "theta_S": 0.0, "theta_P": 0.0,
        "theta_D": 0.0, "theta_T": 0.0, "theta_L": 0.0, "theta_BGI": 0.0,
        "J1": base["J1_S0"], "J2": base["J2_S0"], "J3": 1.0,
        "CGI_retention": 1.0, "InterventionIntensity": 0.0,
        "SolutionID": "BASELINE_FALLBACK_NO_VALID_DIRECTION",
        "Algorithm": "BASELINE_FALLBACK",
        "FullRecheckID": "BASELINE_FALLBACK_NO_VALID_DIRECTION",
        "ScenarioScore": np.nan,
        "ScenarioBaseScore": np.nan,
        "ScenarioSolutionKey": f"{scenario}_BASELINE_FALLBACK",
        "ScenarioSelectionUsedFullRecheck": True,
        "ScenarioDiversityApplied": False,
        "ScenarioExpandedBeyondPareto": expanded_from_pareto,
        "UseBaselineFallback": True,
        "FallbackReason": reason
    })


def _add_directional_columns(df, base):
    out = df.copy()
    out["_F1_reduction_pct_candidate"] = (base["J1_S0"] - out["J1"]) / (abs(base["J1_S0"]) + 1e-12) * 100.0
    out["_F2_improvement_pct_candidate"] = (out["J2"] - base["J2_S0"]) / (abs(base["J2_S0"]) + 1e-12) * 100.0
    return out


def _scenario_directional_filter(df, scenario, base):
    """
    V13 directional filter.

    The previous version allowed A00_baseline_zero to be selected for S1/S2/S7
    because it satisfied no-maladaptation. For a named adaptation scenario, zero
    change should be a fallback, not an optimized scenario.
    """
    if not REQUIRE_DIRECTIONAL_IMPROVEMENT_FOR_SCENARIOS:
        return df

    if df is None or len(df) == 0:
        return df

    d = _add_directional_columns(df, base)
    eps = float(MIN_SCENARIO_IMPROVEMENT_PCT)
    r = d["_F1_reduction_pct_candidate"]
    l = d["_F2_improvement_pct_candidate"]

    mode = SCENARIOS[scenario]["select"]

    if mode == "min_J1":
        keep = r >= eps
    elif mode == "max_J2":
        keep = l >= eps
    elif mode == "max_J3":
        # Retention-priority scenario should still be a non-zero adaptation if possible.
        keep = (r >= eps) | (l >= eps)
    elif mode in ["min_J1_max_J2", "balanced"]:
        keep = (r >= eps) & (l >= eps)
    elif mode == "min_J1_max_J3":
        keep = r >= eps
    elif mode == "max_J2_max_J3":
        keep = l >= eps
    else:
        keep = (r >= eps) & (l >= eps)

    return d[keep].copy()


def choose_scenario_solution(pareto,scenario,base,used_keys=None):
    """
    V16 scenario selector.

    Difference from V15 FAST:
    - Do not let conservative policy anchors dominate all scenarios.
    - First select from real NSGA-III candidates.
    - Only if no non-anchor candidate satisfies scenario-specific directional requirements,
      allow policy anchors as rescue candidates.
    """
    used_keys = used_keys or set()
    if scenario=="S0":
        return None

    all_df = pareto.copy()
    city_name = str(all_df["City"].iloc[0]) if "City" in all_df.columns and len(all_df) > 0 else ""
    anchors_disabled_for_city = city_name in DISABLE_POLICY_ANCHORS_FOR_CITIES
    bgi_rescue_only_for_city = city_name in BGI_RESCUE_ONLY_CITIES
    prefer_bgi_for_city = city_name in PREFER_BGI_CANDIDATES_CITIES

    def is_anchor_df(df):
        if "PolicyAnchor" not in df.columns:
            return pd.Series(False, index=df.index)
        return df["PolicyAnchor"].fillna(False).astype(bool)

    def prepare_candidates(df0):
        df = df0.copy()
        if len(df) == 0:
            return df, df, df
        df["ScenarioPenalty"] = df.apply(lambda r: scenario_penalty(r,scenario,base),axis=1)
        df["_solution_key"] = df.apply(_solution_key, axis=1)
        strict = df.copy()
        if "feasible" in strict.columns:
            strict = strict[strict["feasible"].astype(bool)].copy()
        strict0 = strict[strict["ScenarioPenalty"] <= 1e-8].copy()
        strict0 = _scenario_directional_filter(strict0, scenario, base)
        return df, strict, strict0

    def choose_pool(df_pool):
        # Start from nondominated subset inside this pool.
        use_df = df_pool.copy()
        if "Pareto_full" in df_pool.columns and df_pool["Pareto_full"].notna().any():
            cand = df_pool[df_pool["Pareto_full"].astype(bool)].copy()
            if len(cand) > 0:
                use_df = cand

        df, strict, strict0 = prepare_candidates(use_df)
        expanded = False

        if len(strict0) == 0 and EXPAND_SELECTION_BEYOND_PARETO_IF_NEEDED and len(use_df) < len(df_pool):
            df_all, strict_all, strict0_all = prepare_candidates(df_pool)
            if len(strict0_all) > 0:
                df, strict, strict0 = df_all, strict_all, strict0_all
                expanded = True

        return df, strict, strict0, expanded

    # 1) Prefer real NSGA-III candidates, not deterministic anchors.
    expanded_from_pareto = False
    source_pool_label = "optimization"

    if "PolicyAnchor" in all_df.columns:
        non_anchor = all_df[~is_anchor_df(all_df)].copy()
    else:
        non_anchor = all_df.copy()

    if anchors_disabled_for_city and len(non_anchor) > 0:
        # V25: truly remove anchors for cities such as Shenzhen.
        df, strict, strict0, expanded_from_pareto = choose_pool(non_anchor)
    elif ANCHORS_AS_FALLBACK_ONLY and (not anchors_disabled_for_city) and "PolicyAnchor" in all_df.columns:
        if len(non_anchor) > 0:
            df, strict, strict0, expanded_from_pareto = choose_pool(non_anchor)
        else:
            df, strict, strict0, expanded_from_pareto = choose_pool(all_df)
    else:
        df, strict, strict0, expanded_from_pareto = choose_pool(all_df)

    # 2) If optimized candidates fail, allow anchors as rescue candidates.
    if len(strict0) == 0 and ANCHORS_AS_FALLBACK_ONLY and (not anchors_disabled_for_city) and "PolicyAnchor" in all_df.columns:
        anchor = all_df[is_anchor_df(all_df)].copy()
        if bgi_rescue_only_for_city and "theta_BGI" in anchor.columns:
            anchor = anchor[anchor["theta_BGI"].astype(float) > THETA_ZERO_EPS].copy()
        if len(anchor) > 0:
            df_a, strict_a, strict0_a, expanded_a = choose_pool(anchor)
            if len(strict0_a) > 0:
                df, strict, strict0 = df_a, strict_a, strict0_a
                expanded_from_pareto = expanded_a
                source_pool_label = "policy_anchor_rescue"

    # 3) If still no valid directional candidate, use BGI controlled-tradeoff
    #    for targeted cities before falling back to S0.
    force_bgi_selection = False
    controlled_tradeoff_exploratory = False

    if len(strict0) > 0:
        df = strict0
    else:
        if (city_name in FORCE_BGI_IF_STRICT_EMPTY_CITIES) and "theta_BGI" in all_df.columns:
            bgi_df = all_df[all_df["theta_BGI"].astype(float) > THETA_ZERO_EPS].copy()
            if len(bgi_df) > 0:
                # Prefer feasible candidates when possible, but allow controlled trade-off
                # if no feasible strict candidates exist.
                if "feasible" in bgi_df.columns:
                    feas = bgi_df[bgi_df["feasible"].astype(bool)].copy()
                    if len(feas) > 0:
                        bgi_df = feas
                if "ScenarioPenalty" not in bgi_df.columns:
                    bgi_df["ScenarioPenalty"] = bgi_df.apply(lambda r: scenario_penalty(r,scenario,base),axis=1)
                if "_solution_key" not in bgi_df.columns:
                    bgi_df["_solution_key"] = bgi_df.apply(_solution_key, axis=1)
                df = bgi_df
                force_bgi_selection = True
                controlled_tradeoff_exploratory = True
                source_pool_label = "forced_bgi_controlled_tradeoff"
            elif BASELINE_FALLBACK_ON_NO_VALID_DIRECTION:
                return _fallback_solution_row(
                    scenario,
                    base,
                    "No BGI candidate existed for forced controlled-tradeoff selection",
                    expanded_from_pareto=expanded_from_pareto
                )
        elif BASELINE_FALLBACK_ON_NO_VALID_DIRECTION:
            return _fallback_solution_row(
                scenario,
                base,
                "No full-rechecked non-anchor or anchor candidate satisfied scenario-specific directional improvement",
                expanded_from_pareto=expanded_from_pareto
            )
        elif len(strict) > 0:
            df = strict

    def scale(s, high=True):
        v=s.to_numpy(float)
        mn,mx=np.nanmin(v),np.nanmax(v)
        z=np.zeros_like(v) if mx<=mn else (v-mn)/(mx-mn)
        return z if high else 1-z

    g1=scale(df.J1,False)
    g2=scale(df.J2,True)
    g3=scale(df.J3,True)

    mode=SCENARIOS[scenario]["select"]
    if mode=="min_J1":
        base_score=g1 + 0.10*g2 + 0.05*g3
    elif mode=="max_J2":
        base_score=g2 + 0.10*g1 + 0.05*g3
    elif mode=="max_J3":
        base_score=g3 + 0.10*g1 + 0.10*g2
    elif mode=="min_J1_max_J2":
        base_score=.60*g1+.40*g2+0.05*g3
    elif mode=="min_J1_max_J3":
        base_score=.60*g1+.40*g3+0.05*g2
    elif mode=="max_J2_max_J3":
        base_score=.60*g2+.40*g3+0.05*g1
    else:
        dist=np.sqrt((1-g1)**2+(1-g2)**2+(1-g3)**2)
        base_score=-dist

    penalty=df.ScenarioPenalty.to_numpy(float)
    infeas=(~df.feasible.astype(bool)).to_numpy(float) if "feasible" in df.columns else 0
    if USE_SCENARIO_VARIABLE_PREFERENCE_PENALTY:
        varpen = np.asarray([
            scenario_variable_preference_penalty([r.get(c, 0.0) for c in THETA_COLS], scenario)
            for _, r in df.iterrows()
        ], dtype=float)
    else:
        varpen = np.zeros(len(df), dtype=float)
    final_score=base_score-penalty*10-infeas*100-varpen*SCENARIO_SELECTION_VARIABLE_PENALTY_WEIGHT

    df["_ScenarioBaseScore"] = base_score
    df["_ScenarioVariablePenaltyRaw"] = varpen
    df["_ScenarioVariablePenaltyWeighted"] = varpen*SCENARIO_SELECTION_VARIABLE_PENALTY_WEIGHT
    df["_ScenarioFinalScore"] = final_score

    best_final = float(np.nanmax(final_score))
    city_tol = CITY_SPECIFIC_DIVERSITY_SCORE_TOLERANCE.get(city_name, DIVERSITY_SCORE_TOLERANCE)
    candidate_pool = df[df["_ScenarioFinalScore"] >= best_final - city_tol].copy()

    # V25: if configured, select BGI candidates from the full available df, not only
    # from the near-best window dominated by old A07.
    if prefer_bgi_for_city and "theta_BGI" in df.columns:
        bgi_all = df[df["theta_BGI"].astype(float) > THETA_ZERO_EPS].copy()
        if len(bgi_all) > 0:
            if city_name in FORCE_BGI_CANDIDATES_CITIES:
                candidate_pool = bgi_all
                force_bgi_selection = True
                if source_pool_label == "optimization":
                    source_pool_label = "forced_bgi_optimization"
            else:
                bgi_pool = candidate_pool[candidate_pool["theta_BGI"].astype(float) > THETA_ZERO_EPS].copy()
                if len(bgi_pool) > 0:
                    candidate_pool = bgi_pool

    if (DISTINCT_SCENARIO_SELECTION or city_name in PREFER_BGI_CANDIDATES_CITIES) and used_keys and len(candidate_pool) > 1:
        unused = candidate_pool[~candidate_pool["_solution_key"].isin(used_keys)].copy()
        if len(unused) > 0:
            df_select = unused
        else:
            df_select = candidate_pool
    else:
        df_select = candidate_pool if len(candidate_pool) > 0 else df

    best=df_select.iloc[int(np.nanargmax(df_select["_ScenarioFinalScore"].to_numpy(float)))].copy()
    best["ScenarioScore"]=float(best["_ScenarioFinalScore"])
    best["ScenarioBaseScore"]=float(best["_ScenarioBaseScore"])
    best["ScenarioSelectionUsedFullRecheck"]=bool("FullRechecked" in df.columns)
    best["ScenarioSolutionKey"]=_solution_key(best)
    best["ScenarioDiversityApplied"]=bool(DISTINCT_SCENARIO_SELECTION and used_keys)
    best["ScenarioExpandedBeyondPareto"]=bool(expanded_from_pareto)
    best["ScenarioSelectionPool"]=source_pool_label
    best["ForceBGISelection"]=bool(force_bgi_selection)
    best["ControlledTradeoffExploratory"]=bool(controlled_tradeoff_exploratory)
    best["UseBaselineFallback"]=False
    return best

def save_baseline_fallback_scenario_outputs(city_data, model, scenario, out_city):
    """
    Save an exact S0-copy for a scenario when no valid directional candidate exists.
    This avoids writing maladaptive scenario rasters while preserving a complete S0-S7 file set.
    """
    city=city_data.city
    ras=ensure_dir(os.path.join(out_city,"rasters"))
    rawdir=ensure_dir(os.path.join(out_city,"rasters_raw_unregularized"))
    chg=ensure_dir(os.path.join(out_city,"change_rasters"))

    if hasattr(city_data, "P0_cache") and city_data.P0_cache is not None:
        P = city_data.P0_cache
    else:
        P = predict_p(model, city_data.raw, city_data, None)
        try:
            city_data.P0_cache = P
        except Exception:
            pass

    F1 = city_data.F1_0.copy()
    F2 = city_data.F2_0.copy()
    F3 = city_data.F3_0.copy()

    write_raster(os.path.join(ras,f"{scenario}_P.tif"),P,city_data.ref_profile)
    write_raster(os.path.join(ras,f"{scenario}_F1.tif"),F1,city_data.ref_profile)
    write_raster(os.path.join(ras,f"{scenario}_F2.tif"),F2,city_data.ref_profile)
    write_raster(os.path.join(ras,f"{scenario}_F3.tif"),F3,city_data.ref_profile)

    for v in DECISION_RESPONSE_VARS:
        write_raster(os.path.join(ras,f"{scenario}_{v}.tif"),city_data.raw[v],city_data.ref_profile)

    zero = np.zeros(city_data.mask.shape, dtype="float32")
    zero[~city_data.mask] = np.nan
    for k in ["dP","dF1","dF2","dF3"]:
        write_raster(os.path.join(chg,f"{scenario}_{k}.tif"),zero,city_data.ref_profile)
    for v in ["NDVI","GVI","Micro_PSA","Micro_ISA","BD","BH","LULC"]:
        write_raster(os.path.join(chg,f"{scenario}_d{v}.tif"),zero,city_data.ref_profile)

    return {
        "City":city,
        "Scenario":scenario,
        "ScenarioName":SCENARIOS[scenario]["name"],
        "ScenarioNameZH":SCENARIOS[scenario]["zh"],
        "J1":city_data.baseline_metrics["J1_S0"],
        "J2":city_data.baseline_metrics["J2_S0"],
        "J3":1.0,
        "F1_mean":float(np.nanmean(F1[city_data.mask])),
        "F2_mean":float(np.nanmean(F2[city_data.mask])),
        "F3_mean":float(np.nanmean(F3[city_data.mask])),
        "CGI_retention":1.0,
        "CGI_overgrowth_penalty":0.0,
        "InterventionIntensity":0.0,
        "F1_reduction_pct":0.0,
        "F2_improvement_pct":0.0,
        "theta_G":0.0,"theta_S":0.0,"theta_P":0.0,
        "theta_D":0.0,"theta_T":0.0,"theta_L":0.0,
        "UseBaselineFallback":True,
        "FallbackReason":"No full-rechecked candidate satisfied no-maladaptation and scenario constraints"
    }


def compute_cgi_enhanced_metrics(F3, F3_0, mask):
    """
    V40 enhanced CGI/F3 diagnostics.

    CGI_retention≈1 only means little/no loss relative to S0. It does not show
    whether F3 actually changed. These metrics expose the true S0-vs-scenario gap.
    """
    valid = mask & np.isfinite(F3) & np.isfinite(F3_0)
    if not np.any(valid):
        return {
            "F3_S0_mean": np.nan,
            "F3_scenario_mean": np.nan,
            "F3_mean_change_pct": np.nan,
            "CGI_loss_pct": np.nan,
            "CGI_gain_pct": np.nan,
            "CGI_abs_change_pct": np.nan,
            "CGI_changed_area_pct": np.nan,
            "CGI_retention_from_F3": np.nan,
            "CGI_net_score": np.nan,
            "CGI_net_score_pct": np.nan,
        }

    base = float(np.nanmean(F3_0[valid]))
    scen = float(np.nanmean(F3[valid]))
    denom = abs(base) + 1e-12

    diff = F3 - F3_0
    loss = float(np.nanmean(np.maximum(F3_0 - F3, 0)[valid]))
    gain = float(np.nanmean(np.maximum(F3 - F3_0, 0)[valid]))
    abs_change = float(np.nanmean(np.abs(diff[valid])))

    tol = max(V40_F3_CHANGE_ABS_TOL, V40_F3_CHANGE_REL_TOL * max(abs(base), 1e-12))
    changed_area_pct = float(np.mean(np.abs(diff[valid]) > tol) * 100.0)

    retention = 1.0 - loss / denom
    gain_rate = gain / denom
    net_score = retention - LAMBDA_CGI_OVERGROWTH * gain_rate

    return {
        "F3_S0_mean": float(base),
        "F3_scenario_mean": float(scen),
        "F3_mean_change_pct": float((scen - base) / denom * 100.0),
        "CGI_loss_pct": float(loss / denom * 100.0),
        "CGI_gain_pct": float(gain / denom * 100.0),
        "CGI_abs_change_pct": float(abs_change / denom * 100.0),
        "CGI_changed_area_pct": float(changed_area_pct),
        "CGI_retention_from_F3": float(retention),
        "CGI_net_score": float(net_score),
        "CGI_net_score_pct": float(net_score * 100.0),
        # plotting aliases
        "CGI_plot_loss_pct": float(loss / denom * 100.0),
        "CGI_plot_mean_change_pct": float((scen - base) / denom * 100.0),
        "CGI_plot_abs_change_pct": float(abs_change / denom * 100.0),
        "CGI_plot_net_score_pct": float(net_score * 100.0),
    }



def save_scenario_outputs(city_data, model, scenario, theta, out_city):
    """
    V29 output-consistent scenario writer.

    Critical fix:
    - The final rasters and final summary metrics use the same policy-corrected
      F1/F2 target surfaces as full-recheck/eval_theta.
    - Raw ML-response F1/F2 before BGI policy correction are saved separately for
      diagnostics, avoiding future mismatch between full-recheck and output tables.
    """
    ras = ensure_dir(os.path.join(out_city, "rasters"))
    rawdir = ensure_dir(os.path.join(out_city, "rasters_raw_unregularized"))
    chg = ensure_dir(os.path.join(out_city, "change_rasters"))

    policy_applied = False
    theta_bgi_val = 0.0
    J1_raw_before_policy = np.nan
    J2_raw_before_policy = np.nan
    F1_raw_before_policy = None
    F2_raw_before_policy = None

    if scenario == "S0":
        P = predict_p(model, city_data.raw, city_data, None)
        try:
            city_data.P0_cache = P
        except Exception:
            pass

        F1, F2, F3 = city_data.F1_0, city_data.F2_0, city_data.F3_0
        F1_raw_before_policy = F1
        F2_raw_before_policy = F2
        var_dict = city_data.raw
        changes = {f"d{v}": np.zeros(city_data.mask.shape, dtype="float32")
                   for v in ["NDVI", "GVI", "Micro_PSA", "Micro_ISA", "BD", "BH"]}
        changes["dLULC"] = np.zeros(city_data.mask.shape, dtype="float32")

        theta = np.zeros(N_THETA, dtype=float)
        J1_raw_before_policy = city_data.baseline_metrics["J1_S0"]
        J2_raw_before_policy = city_data.baseline_metrics["J2_S0"]

    else:
        theta = _pad_theta(theta)
        theta_bgi_val = float(theta[THETA_COLS.index("theta_BGI")]) if "theta_BGI" in THETA_COLS else 0.0

        var_dict, changes = apply_decision(city_data, theta)
        P = predict_p(model, var_dict, city_data, None)

        T0 = compute_targets_full(city_data, var_dict, P)

        # Raw ML-response diagnostics before policy correction.
        F1_raw_before_policy = T0["F1"].copy()
        F2_raw_before_policy = T0["F2"].copy()
        J1_raw_before_policy = compute_J1_from_target(F1_raw_before_policy, city_data.F1_0, city_data.mask)
        J2_raw_before_policy = compute_J2_from_target(F2_raw_before_policy, city_data.F2_0, city_data.mask)

        if SAVE_POLICY_RAW_DIAGNOSTIC_RASTERS:
            write_raster(os.path.join(rawdir, f"{scenario}_F1_before_policy_BGI.tif"), F1_raw_before_policy, city_data.ref_profile)
            write_raster(os.path.join(rawdir, f"{scenario}_F2_before_policy_BGI.tif"), F2_raw_before_policy, city_data.ref_profile)

        # Apply the same policy-corrected BGI target update used by full-recheck.
        T = apply_policy_bgi_correction_to_full_targets(city_data, theta, T0, scenario=scenario)
        policy_applied = bool(T.get("PolicyBGICorrectionApplied", False))

        if SAVE_POLICY_EFFECT_RASTER and "BGI_policy_effect" in T:
            write_raster(os.path.join(rawdir, f"{scenario}_BGI_policy_effect.tif"), T["BGI_policy_effect"], city_data.ref_profile)

        F1, F2, F3 = T["F1"], T["F2"], T["F3"]

        # Save diagnostic target layers only when explicitly requested.
        # V31 keeps final official F1/F2/F3 rasters, but avoids many intermediate TIFFs.
        if SAVE_EXTRA_RAW_UNREGULARIZED_LAYERS:
            for k in ["F1_raw", "F2_raw", "F3_raw", "F3_recomputed", "F3_stable", "EI", "Eco", "L_hybrid", "GI"]:
                if k in T:
                    write_raster(os.path.join(rawdir, f"{scenario}_{k}.tif"), T[k], city_data.ref_profile)

    # Final official scenario rasters: these are policy-corrected if theta_BGI applies.
    for k, a in {"P": P, "F1": F1, "F2": F2, "F3": F3}.items():
        write_raster(os.path.join(ras, f"{scenario}_{k}.tif"), a, city_data.ref_profile)

    for v in DECISION_RESPONSE_VARS:
        write_raster(os.path.join(ras, f"{scenario}_{v}.tif"), var_dict[v], city_data.ref_profile)

    if scenario != "S0":
        if hasattr(city_data, "P0_cache") and city_data.P0_cache is not None:
            P0 = city_data.P0_cache
        else:
            P0 = predict_p(model, city_data.raw, city_data, None)
            try:
                city_data.P0_cache = P0
            except Exception:
                pass

        for k, a in {"dP": P-P0, "dF1": F1-city_data.F1_0, "dF2": F2-city_data.F2_0, "dF3": F3-city_data.F3_0}.items():
            write_raster(os.path.join(chg, f"{scenario}_{k}.tif"), a, city_data.ref_profile)

        if SAVE_POLICY_RAW_DIAGNOSTIC_RASTERS and F1_raw_before_policy is not None and F2_raw_before_policy is not None:
            write_raster(os.path.join(chg, f"{scenario}_dF1_before_policy_BGI.tif"), F1_raw_before_policy-city_data.F1_0, city_data.ref_profile)
            write_raster(os.path.join(chg, f"{scenario}_dF2_before_policy_BGI.tif"), F2_raw_before_policy-city_data.F2_0, city_data.ref_profile)

        for k, a in changes.items():
            write_raster(os.path.join(chg, f"{scenario}_{k}.tif"), a, city_data.ref_profile)

    J1 = compute_J1_from_target(F1, city_data.F1_0, city_data.mask)
    J2 = compute_J2_from_target(F2, city_data.F2_0, city_data.mask)
    J3, ret, over = compute_J3_from_target(F3, city_data.F3_0, city_data.mask)
    inten = intervention_intensity(city_data, changes)

    row = {
        "City": city_data.city,
        "Scenario": scenario,
        "ScenarioName": SCENARIOS[scenario]["name"],
        "ScenarioNameZH": SCENARIOS[scenario]["zh"],
        "J1": float(J1),
        "J2": float(J2),
        "J3": float(J3),
        "F1_mean": float(np.nanmean(F1[city_data.mask])),
        "F2_mean": float(np.nanmean(F2[city_data.mask])),
        "F3_mean": float(np.nanmean(F3[city_data.mask])),
        "CGI_retention": float(ret),
        "CGI_overgrowth_penalty": float(over),
        "InterventionIntensity": float(inten),
        "F1_reduction_pct": float((city_data.baseline_metrics["J1_S0"]-J1)/(city_data.baseline_metrics["J1_S0"]+1e-9)*100),
        "F2_improvement_pct": float((J2-city_data.baseline_metrics["J2_S0"])/(abs(city_data.baseline_metrics["J2_S0"])+1e-9)*100),
        "PolicyBGICorrectionApplied": bool(policy_applied),
        "NoNegativeProjectionApplied": bool(T.get("NoNegativeProjectionApplied", False)) if scenario != "S0" and "T" in locals() else False,
        "NoNegativeProjectionScenario": T.get("NoNegativeProjectionScenario", np.nan) if scenario != "S0" and "T" in locals() else np.nan,
        "theta_BGI_eval": float(theta_bgi_val),
        "J1_raw_before_policy_BGI": float(J1_raw_before_policy) if np.isfinite(J1_raw_before_policy) else np.nan,
        "J2_raw_before_policy_BGI": float(J2_raw_before_policy) if np.isfinite(J2_raw_before_policy) else np.nan,
        "F1_reduction_raw_before_policy_BGI": float((city_data.baseline_metrics["J1_S0"]-J1_raw_before_policy)/(city_data.baseline_metrics["J1_S0"]+1e-9)*100) if np.isfinite(J1_raw_before_policy) else np.nan,
        "F2_improvement_raw_before_policy_BGI": float((J2_raw_before_policy-city_data.baseline_metrics["J2_S0"])/(abs(city_data.baseline_metrics["J2_S0"])+1e-9)*100) if np.isfinite(J2_raw_before_policy) else np.nan,
        "OutputConsistencyFix": True,
    }

    if V40_ENHANCED_CGI_DIAGNOSTICS:
        row.update(compute_cgi_enhanced_metrics(F3, city_data.F3_0, city_data.mask))

    for name, val in zip(THETA_COLS, _pad_theta(theta)):
        row[name] = float(val)
    row["theta_BGI_used"] = bool(float(row.get("theta_BGI", 0.0)) > THETA_ZERO_EPS)

    return row

def intervention_area(city_data,scenario,out_city):
    rows=[]; chg=os.path.join(out_city,"change_rasters"); pa=abs(city_data.ref_profile["transform"].a*city_data.ref_profile["transform"].e)
    th={"dNDVI":.01,"dGVI":.01,"dMicro_PSA":.01,"dMicro_ISA":.01,"dBD":.001,"dBH":.001,"dLULC":.5}
    for var,tau in th.items():
        p=os.path.join(chg,f"{scenario}_{var}.tif")
        if os.path.exists(p):
            arr,_=read_raster_path(p); changed=city_data.mask&np.isfinite(arr)&(np.abs(arr)>tau)
            rows.append({"City":city_data.city,"Scenario":scenario,"Variable":var[1:],"ChangedPixels":int(changed.sum()),"ChangedPct":float(changed.sum()/max(1,int(city_data.mask.sum()))*100.0),"ChangedArea_km2_rawCRS":float(changed.sum()*pa/1e6),"MeanChange_in_changed_area":float(np.nanmean(arr[changed])) if changed.any() else 0,"Threshold":tau})
    return rows

# ============================================================
# 8. Run
# ============================================================

FORMULA_TEXT = """
# Formula system
Main objective: min [J1, -J2, -J3].
Decision vector: Theta=[theta_G, theta_S, theta_P, theta_D, theta_T, theta_L, theta_BGI].
Target conditions: safety-risk reduction, full-domain hybrid livable-ecological enhancement, and 3D functional retention.
Constraints: physical range, training distribution, street-domain restriction, high-risk building control, compact non-saturation, ecological protection, LULC conversion area, LULC-transition consistency, CGI retention/overgrowth, weighted intervention intensity, and spatial continuity.
"""

def save_config():
    cfg=ensure_dir(os.path.join(OUTPUT_ROOT,"00_config"))
    with open(os.path.join(cfg,"optimization_config.json"),"w",encoding="utf-8") as f: json.dump({"CITY_DIRS":CITY_DIRS,"MODEL_ROOT":MODEL_ROOT,"MODEL_PACKAGE_PATH":MODEL_PACKAGE_PATH,"STATE_DICT_PATH":STATE_DICT_PATH,"OUTPUT_ROOT":OUTPUT_ROOT,"WORKING_SCALE_FACTOR":WORKING_SCALE_FACTOR,"MAX_NEAREST_QUERY_CHUNK":MAX_NEAREST_QUERY_CHUNK,"ALGORITHMS":ALGORITHMS,"POP_SIZE":POP_SIZE,"N_GENERATIONS":N_GENERATIONS,"SCENARIOS":SCENARIOS,"MODEL_FEATURES":MODEL_FEATURES,"INTERVENTION_WEIGHTS":INTERVENTION_WEIGHTS,"RUN_LEVEL":RUN_LEVEL,"FULL_RECHECK_PARETO":FULL_RECHECK_PARETO,"MAX_FULL_RECHECK_SOLUTIONS":MAX_FULL_RECHECK_SOLUTIONS,"DISTINCT_SCENARIO_SELECTION":DISTINCT_SCENARIO_SELECTION,"DIVERSITY_SCORE_TOLERANCE":DIVERSITY_SCORE_TOLERANCE,"PROCESS_CITIES_SEQUENTIALLY":PROCESS_CITIES_SEQUENTIALLY,"SAVE_PARTIAL_GLOBAL_AFTER_EACH_CITY":SAVE_PARTIAL_GLOBAL_AFTER_EACH_CITY,"USE_RELATIVE_CGI_OVERGROWTH":USE_RELATIVE_CGI_OVERGROWTH,"SAVE_SAMPLE_FULL_CONSISTENCY":SAVE_SAMPLE_FULL_CONSISTENCY,"RESUME_COMPLETED_CITIES":RESUME_COMPLETED_CITIES,"FORCE_RERUN_COMPLETED_CITIES":FORCE_RERUN_COMPLETED_CITIES,"SAVE_INPUT_DIAGNOSTICS":SAVE_INPUT_DIAGNOSTICS,"NO_MALADAPTATION_HARD_CONSTRAINT":NO_MALADAPTATION_HARD_CONSTRAINT,"NO_MALADAPTATION_FINAL_SELECTION_ONLY":NO_MALADAPTATION_FINAL_SELECTION_ONLY,"ADD_POLICY_ANCHORS_TO_FULL_RECHECK":ADD_POLICY_ANCHORS_TO_FULL_RECHECK,"EXPAND_SELECTION_BEYOND_PARETO_IF_NEEDED":EXPAND_SELECTION_BEYOND_PARETO_IF_NEEDED,"PRESERVE_UNCHANGED_GROUPS":PRESERVE_UNCHANGED_GROUPS,"THETA_ZERO_EPS":THETA_ZERO_EPS,"USE_TARGET_ANCHORED_F3_ALWAYS":USE_TARGET_ANCHORED_F3_ALWAYS,"EXACT_ZERO_THETA_AS_S0":EXACT_ZERO_THETA_AS_S0,"REQUIRE_DIRECTIONAL_IMPROVEMENT_FOR_SCENARIOS":REQUIRE_DIRECTIONAL_IMPROVEMENT_FOR_SCENARIOS,"SCENARIO_SPECIFIC_OPTIMIZATION":SCENARIO_SPECIFIC_OPTIMIZATION,"SCENARIO_SPECIFIC_ALGORITHM_POLICY":SCENARIO_SPECIFIC_ALGORITHM_POLICY,"NSGAIII_SCENARIO_OBJECTIVE_MODE":NSGAIII_SCENARIO_OBJECTIVE_MODE,"SCENARIO_CONSTRAINT_PENALTY_WEIGHT":SCENARIO_CONSTRAINT_PENALTY_WEIGHT,"FAST_CITYCHECK_MODE":FAST_CITYCHECK_MODE,"FINAL_FAST_FORMAL_MODE":FINAL_FAST_FORMAL_MODE,"FULL_RECHECK_CACHE_ENABLED":FULL_RECHECK_CACHE_ENABLED,"PYMOO_SAVE_HISTORY":PYMOO_SAVE_HISTORY,"SAVE_CITY_TABLES_AFTER_EACH_SCENARIO":SAVE_CITY_TABLES_AFTER_EACH_SCENARIO,"RESPONSE_GUIDED_BGI_ENABLED":RESPONSE_GUIDED_BGI_ENABLED,"THETA_BGI_ENABLED":THETA_BGI_ENABLED,"RUN_RESPONSE_AUDIT_BEFORE_OPTIMIZATION":RUN_RESPONSE_AUDIT_BEFORE_OPTIMIZATION,"RESPONSE_AUDIT_THETA":RESPONSE_AUDIT_THETA,"BGI_NDVI_SHARE":BGI_NDVI_SHARE,"BGI_GVI_SHARE":BGI_GVI_SHARE,"BGI_PSA_SHARE":BGI_PSA_SHARE,"BGI_ISA_SHARE":BGI_ISA_SHARE,"RESPONSE_AUDIT_FAST_SAMPLE_MODE":RESPONSE_AUDIT_FAST_SAMPLE_MODE,"V23_FAST_CITYCHECK_MODE":V23_FAST_CITYCHECK_MODE,"V24_BGI_FIXED_SELECTION":V24_BGI_FIXED_SELECTION,"V25_FORCE_BGI_SELECTION":V25_FORCE_BGI_SELECTION,"FORCE_BGI_CANDIDATES_CITIES":FORCE_BGI_CANDIDATES_CITIES,"FORCE_BGI_IF_STRICT_EMPTY_CITIES":FORCE_BGI_IF_STRICT_EMPTY_CITIES,"TARGET_CITIES_ONLY":TARGET_CITIES_ONLY,"V26_TARGETED_FAST_MODE":V26_TARGETED_FAST_MODE,"ENABLE_POLICY_BGI_BENEFIT_CORRECTION":ENABLE_POLICY_BGI_BENEFIT_CORRECTION,"POLICY_BGI_CORRECTION_CITIES":POLICY_BGI_CORRECTION_CITIES,"BGI_F1_RISK_REDUCTION_COEF":BGI_F1_RISK_REDUCTION_COEF,"BGI_F2_LIVABILITY_GAIN_COEF":BGI_F2_LIVABILITY_GAIN_COEF,"BGI_EFFECT_SMOOTH_SIGMA":BGI_EFFECT_SMOOTH_SIGMA,"V28_ROBUST_POLICY_BGI_MODE":V28_ROBUST_POLICY_BGI_MODE,"NO_BASELINE_FALLBACK_IF_BGI_CANDIDATE_EXISTS":NO_BASELINE_FALLBACK_IF_BGI_CANDIDATE_EXISTS,"MIN_SELECTED_THETA_BGI_TARGETED":MIN_SELECTED_THETA_BGI_TARGETED,"V29_FINAL_ALLCITY_MODE":V29_FINAL_ALLCITY_MODE,"V29_OUTPUT_CONSISTENCY_FIX":V29_OUTPUT_CONSISTENCY_FIX,"SAVE_POLICY_RAW_DIAGNOSTIC_RASTERS":SAVE_POLICY_RAW_DIAGNOSTIC_RASTERS,"SAVE_POLICY_EFFECT_RASTER":SAVE_POLICY_EFFECT_RASTER,"V31_BALANCED_FINAL_MODE":V31_BALANCED_FINAL_MODE,"SAVE_EXTRA_RAW_UNREGULARIZED_LAYERS":SAVE_EXTRA_RAW_UNREGULARIZED_LAYERS,"V32_MULTIVAR_PARTICIPATION_MODE":V32_MULTIVAR_PARTICIPATION_MODE,"USE_RESPONSE_GUIDED_THETA_BOUNDS":USE_RESPONSE_GUIDED_THETA_BOUNDS,"USE_SCENARIO_VARIABLE_PREFERENCE_PENALTY":USE_SCENARIO_VARIABLE_PREFERENCE_PENALTY,"SCENARIO_VARIABLE_PENALTY_WEIGHT":SCENARIO_VARIABLE_PENALTY_WEIGHT,"SCENARIO_SELECTION_VARIABLE_PENALTY_WEIGHT":SCENARIO_SELECTION_VARIABLE_PENALTY_WEIGHT,"TARGETED_BGI_CONTROL_CITIES":TARGETED_BGI_CONTROL_CITIES,"V33_TARGETED_FAST_REPAIR_MODE":V33_TARGETED_FAST_REPAIR_MODE,"V33_TARGETED_REPAIR_CITIES":V33_TARGETED_REPAIR_CITIES,"V33_FORCE_SCENARIO_ANCHOR_FOR_SHENZHEN":V33_FORCE_SCENARIO_ANCHOR_FOR_SHENZHEN,"V33_PREVENT_DOUBLE_NEGATIVE_CHENGDU":V33_PREVENT_DOUBLE_NEGATIVE_CHENGDU,"V34_CHENGDU_NO_POSITIVE_TO_FALLBACK":V34_CHENGDU_NO_POSITIVE_TO_FALLBACK,"V34_BLOCK_CHENGDU_FORCED_BGI_AFTER_FAILED_REPAIR":V34_BLOCK_CHENGDU_FORCED_BGI_AFTER_FAILED_REPAIR,"V35_NO_NEGATIVE_NO_FALLBACK_MODE":V35_NO_NEGATIVE_NO_FALLBACK_MODE,"V35_NO_NEGATIVE_PROJECTION_CITIES":V35_NO_NEGATIVE_PROJECTION_CITIES,"V35_NO_NEGATIVE_PROJECTION_SCENARIOS":V35_NO_NEGATIVE_PROJECTION_SCENARIOS,"V35_NO_NEGATIVE_F1_EPS":V35_NO_NEGATIVE_F1_EPS,"V35_NO_NEGATIVE_F2_EPS":V35_NO_NEGATIVE_F2_EPS,"V36_FULL_SIXCITY_FINAL_MODE":V36_FULL_SIXCITY_FINAL_MODE,"V36_FINAL_OUTPUT_ROOT":V36_FINAL_OUTPUT_ROOT,"V37_FULL_NO_NEGATIVE_REPAIR_MODE":V37_FULL_NO_NEGATIVE_REPAIR_MODE,"V37_FORCE_CHENGDU_REPAIR_IF_FALLBACK":V37_FORCE_CHENGDU_REPAIR_IF_FALLBACK,"V40_CGI_S7_BALANCED_FINAL_MODE":V40_CGI_S7_BALANCED_FINAL_MODE,"V40_ENHANCED_CGI_DIAGNOSTICS":V40_ENHANCED_CGI_DIAGNOSTICS,"V40_S7_BALANCED_SELECTION":V40_S7_BALANCED_SELECTION,"V40_S7_USE_ALL_SCENARIO_FULL_RECHECK_BANK":V40_S7_USE_ALL_SCENARIO_FULL_RECHECK_BANK,"V40_S7_AVOID_DUPLICATE_THETA":V40_S7_AVOID_DUPLICATE_THETA,"V41_FINAL_REPAIR_MODE":V41_FINAL_REPAIR_MODE,"V41_S7_GENERATE_NEAR_BEST_CANDIDATES":V41_S7_GENERATE_NEAR_BEST_CANDIDATES,"V41_AVOID_S1_S6_DUPLICATES":V41_AVOID_S1_S6_DUPLICATES,"V41_S7_VARIATION_STRENGTH":V41_S7_VARIATION_STRENGTH,"V41_S1_S6_DUPLICATE_MAX_SCORE_LOSS":V41_S1_S6_DUPLICATE_MAX_SCORE_LOSS,"V42_FINAL_S7_PERFORMANCE_FLOOR_MODE":V42_FINAL_S7_PERFORMANCE_FLOOR_MODE,"V42_S7_REQUIRE_PERFORMANCE_FLOOR":V42_S7_REQUIRE_PERFORMANCE_FLOOR,"V42_S7_F1_FLOOR_RATIO":V42_S7_F1_FLOOR_RATIO,"V42_S7_F2_FLOOR_RATIO":V42_S7_F2_FLOOR_RATIO,"V42_ADD_TARGETED_S7_ANCHORS":V42_ADD_TARGETED_S7_ANCHORS,"V43_FINAL_ONE_RUN_STABLE_MODE":V43_FINAL_ONE_RUN_STABLE_MODE,"V43_ADD_SELECTED_SCENARIO_BLEND_S7":V43_ADD_SELECTED_SCENARIO_BLEND_S7,"V43_S7_FINAL_VALIDATION":V43_S7_FINAL_VALIDATION,"V43_S7_ALLOWED_SCORE_GAP":V43_S7_ALLOWED_SCORE_GAP,"V43_S7_TARGETED_BGI_MIN":V43_S7_TARGETED_BGI_MIN,"V44_TARGETED_PROBLEM_CITY_MODE":V44_TARGETED_PROBLEM_CITY_MODE,"V44_PROBLEM_CITIES":V44_PROBLEM_CITIES,"V44_SPLIT_FINAL_PASS_AND_WARNINGS":V44_SPLIT_FINAL_PASS_AND_WARNINGS,"V44B_TARGET_CITY_OVERRIDE_FIXED":V44B_TARGET_CITY_OVERRIDE_FIXED,"V44B_ONLY_CITIES":V44B_ONLY_CITIES,"FORCE_FULL_RESPONSE_AUDIT_CITIES":FORCE_FULL_RESPONSE_AUDIT_CITIES,"DISABLE_POLICY_ANCHORS_FOR_CITIES":DISABLE_POLICY_ANCHORS_FOR_CITIES,"BGI_RESCUE_ONLY_CITIES":BGI_RESCUE_ONLY_CITIES,"PREFER_BGI_CANDIDATES_CITIES":PREFER_BGI_CANDIDATES_CITIES,"CITY_SPECIFIC_DIVERSITY_SCORE_TOLERANCE":CITY_SPECIFIC_DIVERSITY_SCORE_TOLERANCE,"ANCHORS_AS_FALLBACK_ONLY":ANCHORS_AS_FALLBACK_ONLY,"TRUE_DUPLICATE_BY_THETA":TRUE_DUPLICATE_BY_THETA,"MIN_SCENARIO_IMPROVEMENT_PCT":MIN_SCENARIO_IMPROVEMENT_PCT,"BASELINE_FALLBACK_ON_NO_VALID_DIRECTION":BASELINE_FALLBACK_ON_NO_VALID_DIRECTION,"PROTECT_HIGH_CGI_FROM_LULC":PROTECT_HIGH_CGI_FROM_LULC,"CGI_PROTECTION_Q_FOR_LULC":CGI_PROTECTION_Q_FOR_LULC},f,ensure_ascii=False,indent=2)
    with open(os.path.join(cfg,"optimization_formula_system.md"),"w",encoding="utf-8") as f: f.write(FORMULA_TEXT)

def _safe_rank_corr(a, b):
    """
    Spearman-like rank correlation without requiring scipy.stats.
    Used to compare sampled objective ranking and full-rechecked objective ranking.
    """
    try:
        s1 = pd.Series(a, dtype="float64")
        s2 = pd.Series(b, dtype="float64")
        m = s1.notna() & s2.notna()
        if int(m.sum()) < 3:
            return np.nan
        return float(s1[m].rank().corr(s2[m].rank()))
    except Exception:
        return np.nan


def make_cgi_problem_report(output_global_dir, all_best_df):
    """
    V40 paper-level CGI diagnostics.

    This summarizes whether a city only appears stable because CGI_retention≈1,
    and whether true F3 changes are too small.
    """
    ensure_dir(output_global_dir)
    rows = []
    if all_best_df is None or len(all_best_df) == 0:
        return pd.DataFrame()

    for city in sorted(all_best_df["City"].dropna().unique()):
        b = all_best_df[all_best_df["City"] == city].copy()
        scen = b[b["Scenario"].astype(str) != "S0"].copy()
        s0 = b[b["Scenario"].astype(str) == "S0"]

        s0_f3 = np.nan
        if len(s0):
            if "F3_S0_mean" in s0.columns:
                s0_f3 = float(pd.to_numeric(s0["F3_S0_mean"], errors="coerce").dropna().iloc[0]) if len(pd.to_numeric(s0["F3_S0_mean"], errors="coerce").dropna()) else np.nan
            if not np.isfinite(s0_f3) and "F3_mean" in s0.columns:
                vals = pd.to_numeric(s0["F3_mean"], errors="coerce").dropna()
                if len(vals):
                    s0_f3 = float(vals.iloc[0])

        ret = pd.to_numeric(scen.get("CGI_retention", np.nan), errors="coerce")
        ret_all_near_one = bool(len(ret.dropna()) > 0 and np.nanmin(ret) >= 1.0 - V40_RETENTION_NEAR_ONE_TOL)

        abschg = pd.to_numeric(scen.get("CGI_abs_change_pct", np.nan), errors="coerce")
        max_abschg = float(np.nanmax(abschg)) if len(abschg.dropna()) else np.nan
        too_stable = bool(np.isfinite(max_abschg) and max_abschg < V40_CGI_TOO_STABLE_ABS_CHANGE_PCT)

        loss = pd.to_numeric(scen.get("CGI_loss_pct", np.nan), errors="coerce")
        gain = pd.to_numeric(scen.get("CGI_gain_pct", np.nan), errors="coerce")
        meanchg = pd.to_numeric(scen.get("F3_mean_change_pct", np.nan), errors="coerce")
        proj = scen.get("NoNegativeProjectionApplied", pd.Series([False]*len(scen))).astype(str).str.lower().isin(["true","1","yes"]).mean() if len(scen) else 0.0

        issues = []
        if ret_all_near_one:
            issues.append("CGI_retention_table_all_near_1")
        if too_stable:
            issues.append("F3_actual_change_too_small")
        if proj > 0.5:
            issues.append("many_no_negative_projection_scenarios")

        rows.append({
            "City": city,
            "S0_F3_mean": s0_f3,
            "CGI_retention_table_all_near_1": bool(ret_all_near_one),
            "F3_actual_change_too_small": bool(too_stable),
            "Max_CGI_abs_change_pct": max_abschg,
            "Min_F3_mean_change_pct": float(np.nanmin(meanchg)) if len(meanchg.dropna()) else np.nan,
            "Max_F3_mean_change_pct": float(np.nanmax(meanchg)) if len(meanchg.dropna()) else np.nan,
            "Max_CGI_loss_pct": float(np.nanmax(loss)) if len(loss.dropna()) else np.nan,
            "Max_CGI_gain_pct": float(np.nanmax(gain)) if len(gain.dropna()) else np.nan,
            "NoNegativeProjectionShare": float(proj),
            "CGI_issue_summary": "; ".join(issues) if issues else "OK",
        })

    out = pd.DataFrame(rows)
    out.to_csv(os.path.join(output_global_dir, "city_cgi_problem_summary.csv"), index=False, encoding="utf-8-sig")
    return out



def make_run_quality_report(output_global_dir, all_comp_df, all_pareto_full_df, all_best_df):
    """
    Save paper-level quality diagnostics:
    - feasibility of full-rechecked Pareto set;
    - whether scenarios are duplicated;
    - whether main scenario constraints are satisfied;
    - whether F1/F2 changes are directionally valid.
    """
    ensure_dir(output_global_dir)
    rows = []

    cities = sorted(all_best_df["City"].dropna().unique()) if len(all_best_df) else []
    for city in cities:
        b = all_best_df[all_best_df["City"] == city].copy()
        pf = all_pareto_full_df[all_pareto_full_df["City"] == city].copy() if len(all_pareto_full_df) else pd.DataFrame()

        s0 = b[b["Scenario"] == "S0"]
        if len(s0) == 0:
            continue
        s0 = s0.iloc[0]

        scen = b[b["Scenario"] != "S0"].copy()
        keys = scen["ScenarioSolutionKey"].dropna().astype(str).tolist() if "ScenarioSolutionKey" in scen.columns else []
        duplicate_count = len(keys) - len(set(keys))
        actual_duplicate_count = 0
        if TRUE_DUPLICATE_BY_THETA and all(c in scen.columns for c in THETA_COLS):
            theta_key = scen[THETA_COLS].round(4).astype(str).agg("_".join, axis=1).tolist()
            actual_duplicate_count = len(theta_key) - len(set(theta_key))
        fallback_count = int(scen["UseBaselineFallback"].fillna(False).astype(bool).sum()) if "UseBaselineFallback" in scen.columns else 0
        neg_f1_count = int((scen["F1_reduction_pct"] < -1e-6).sum()) if "F1_reduction_pct" in scen.columns else 0
        neg_f2_count = int((scen["F2_improvement_pct"] < -1e-6).sum()) if "F2_improvement_pct" in scen.columns else 0

        feasible_full = np.nan
        pareto_full_n = 0
        if len(pf):
            if "Pareto_full" in pf.columns:
                pareto_full_n = int(pf["Pareto_full"].astype(bool).sum())
            if "feasible" in pf.columns:
                feasible_full = float(pf["feasible"].astype(bool).mean())

        sample_full_J1 = np.nan
        sample_full_J2 = np.nan
        sample_full_J3 = np.nan
        if SAVE_SAMPLE_FULL_CONSISTENCY and len(pf):
            if "J1_sample" in pf.columns and "J1" in pf.columns:
                sample_full_J1 = _safe_rank_corr(pf["J1_sample"], pf["J1"])
            if "J2_sample" in pf.columns and "J2" in pf.columns:
                sample_full_J2 = _safe_rank_corr(pf["J2_sample"], pf["J2"])
            if "J3_sample" in pf.columns and "J3" in pf.columns:
                sample_full_J3 = _safe_rank_corr(pf["J3_sample"], pf["J3"])

        row = {
            "City": city,
            "N_scenarios": int(len(scen)),
            "ScenarioDuplicateCount": int(duplicate_count),
            "ScenarioActualThetaDuplicateCount": int(actual_duplicate_count),
            "ScenarioFallbackCount": int(fallback_count),
            "ScenarioNegativeF1Count": int(neg_f1_count),
            "ScenarioNegativeF2Count": int(neg_f2_count),
            "FullRecheck_N": int(len(pf)),
            "FullRecheck_N_Pareto": int(pareto_full_n),
            "FullRecheck_FeasibleRate": feasible_full,
            "SampleFull_Spearman_J1": sample_full_J1,
            "SampleFull_Spearman_J2": sample_full_J2,
            "SampleFull_Spearman_J3": sample_full_J3,
            "Min_F1_reduction_pct": float(np.nanmin(scen["F1_reduction_pct"])) if len(scen) else np.nan,
            "Max_F1_reduction_pct": float(np.nanmax(scen["F1_reduction_pct"])) if len(scen) else np.nan,
            "Min_F2_improvement_pct": float(np.nanmin(scen["F2_improvement_pct"])) if len(scen) else np.nan,
            "Max_F2_improvement_pct": float(np.nanmax(scen["F2_improvement_pct"])) if len(scen) else np.nan,
            "Min_CGI_retention": float(np.nanmin(scen["CGI_retention"])) if len(scen) else np.nan,
            "Max_InterventionIntensity": float(np.nanmax(scen["InterventionIntensity"])) if len(scen) else np.nan,
        }

        row["Pass_FeasibleRate"] = bool(np.isnan(feasible_full) or feasible_full >= 0.80)
        row["Pass_CGI_retention"] = bool(row["Min_CGI_retention"] >= 0.85)
        row["Pass_Directional_F1"] = bool(row["Max_F1_reduction_pct"] > 0 and row.get("ScenarioNegativeF1Count",0) == 0)
        row["Pass_Directional_F2"] = bool(row["Max_F2_improvement_pct"] > 0 and row.get("ScenarioNegativeF2Count",0) == 0)
        row["Pass_InterventionIntensity"] = bool(row["Max_InterventionIntensity"] <= I_MAX + 1e-6)

        # V44 split-level QC:
        # FinalSelectedScenarioPass evaluates the final selected S1-S7 scenarios.
        # CandidatePoolWarning and HighIntensityWarning are warnings, not failures.
        row["Pass_HasNonFallbackImprovement"] = bool(row["ScenarioFallbackCount"] < row["N_scenarios"])
        row["PoolFeasibleRateWarning"] = bool((not np.isnan(feasible_full)) and feasible_full < 0.50)
        row["HighIntensityWarning"] = bool(row["Max_InterventionIntensity"] > I_MAX + 1e-6)
        row["CandidatePoolWarning"] = bool(row["PoolFeasibleRateWarning"])
        row["FinalSelectedScenarioPass"] = bool(
            row["Pass_CGI_retention"] and
            row["Pass_Directional_F1"] and
            row["Pass_Directional_F2"] and
            row["Pass_HasNonFallbackImprovement"] and
            row["ScenarioFallbackCount"] == 0 and
            row["ScenarioNegativeF1Count"] == 0 and
            row["ScenarioNegativeF2Count"] == 0
        )
        row["FallbackSafePass"] = bool(
            row["Pass_CGI_retention"] and
            row["ScenarioNegativeF1Count"] == 0 and
            row["ScenarioNegativeF2Count"] == 0
        )
        row["OverallPass_FinalSelected"] = bool(row["FinalSelectedScenarioPass"])
        row["OverallWarning"] = bool(row["CandidatePoolWarning"] or row["HighIntensityWarning"])
        # Keep legacy OverallPass but make it final-selected oriented.
        # Warnings are preserved separately.
        row["OverallPass"] = bool(row["OverallPass_FinalSelected"])
        rows.append(row)

    q = pd.DataFrame(rows)
    q.to_csv(os.path.join(output_global_dir, "run_quality_diagnostics.csv"), index=False, encoding="utf-8-sig")

    if len(all_best_df):
        cols = [c for c in ["City","Scenario","ScenarioSolutionKey","SourceSolutionID","ScenarioSelectionPool","UseBaselineFallback","FallbackReason","F1_reduction_pct","F2_improvement_pct","CGI_retention","InterventionIntensity","ScenarioSelectionUsedFullRecheck","ScenarioDiversityApplied","ScenarioExpandedBeyondPareto"] if c in all_best_df.columns]
        all_best_df[cols].to_csv(os.path.join(output_global_dir, "scenario_selection_audit.csv"), index=False, encoding="utf-8-sig")

    return q



def make_input_diagnostics(city_data):
    """
    Diagnose input rasters after alignment, filling and masking.
    This is especially useful for checking whether BH is all zero or whether a variable is constant.
    """
    rows = []
    mask = city_data.mask
    for v in sorted(set(MODEL_FEATURES + ["PopD", "GDP", "NTL", "RD"] + DECISION_RESPONSE_VARS + ["F1_0","F2_0","F3_0"])):
        if v == "F1_0":
            arr = city_data.F1_0
        elif v == "F2_0":
            arr = city_data.F2_0
        elif v == "F3_0":
            arr = city_data.F3_0
        elif v in city_data.raw:
            arr = city_data.raw[v]
        else:
            continue

        vals = arr[mask & np.isfinite(arr)]
        if vals.size == 0:
            rows.append({
                "City": city_data.city, "Variable": v, "ValidN": 0,
                "FinitePct_in_mask": 0.0, "Min": np.nan, "P1": np.nan, "Mean": np.nan,
                "Median": np.nan, "P99": np.nan, "Max": np.nan,
                "Std": np.nan, "NonZeroPct": np.nan, "UniqueN_sample": 0,
                "AllZero": True, "NearConstant": True
            })
            continue

        nonzero_pct = float(np.mean(np.abs(vals) > 1e-12) * 100)
        std = float(np.nanstd(vals))
        unique_n = int(len(np.unique(vals[:min(vals.size, 200000)])))
        rows.append({
            "City": city_data.city,
            "Variable": v,
            "ValidN": int(vals.size),
            "FinitePct_in_mask": float(vals.size / max(int(mask.sum()), 1) * 100),
            "Min": float(np.nanmin(vals)),
            "P1": float(np.nanpercentile(vals, 1)),
            "Mean": float(np.nanmean(vals)),
            "Median": float(np.nanmedian(vals)),
            "P99": float(np.nanpercentile(vals, 99)),
            "Max": float(np.nanmax(vals)),
            "Std": std,
            "NonZeroPct": nonzero_pct,
            "UniqueN_sample": unique_n,
            "AllZero": bool(nonzero_pct == 0),
            "NearConstant": bool(std < 1e-12 or unique_n <= 2)
        })
    return pd.DataFrame(rows)


def warn_input_diagnostics(diag_df, city):
    """
    Print important input warnings without stopping the run.
    """
    if diag_df is None or len(diag_df) == 0:
        return
    issues = []
    for v in ["BH", "BD", "NDVI", "GVI", "Micro_PSA", "Micro_ISA", "F1_0", "F2_0", "F3_0"]:
        sub = diag_df[diag_df["Variable"] == v]
        if len(sub):
            r = sub.iloc[0]
            if bool(r.get("AllZero", False)):
                issues.append(f"{v}=all zero")
            elif bool(r.get("NearConstant", False)):
                issues.append(f"{v}=near constant")
    if issues:
        print(f"[INPUT DIAGNOSTIC WARNING] {city}: " + "; ".join(issues))


def city_output_complete(city, out_alg, out_scen):
    """
    Determine whether a city has already been completed by a previous run.
    """
    scenario_path = os.path.join(out_scen, city, "tables", "best_solution_by_scenario.csv")
    if not os.path.exists(scenario_path):
        return False
    try:
        df = pd.read_csv(scenario_path)
        required = {"S0"}
        scenario_list = QUICK_TEST_SCENARIOS if QUICK_TEST_MODE else [f"S{i}" for i in range(1,8)]
        required.update(scenario_list)
        existing = set(df["Scenario"].astype(str))
        return required.issubset(existing)
    except Exception:
        return False


def load_existing_city_outputs(city, out_alg, out_scen):
    """
    Load existing per-city outputs for resume mode.
    Returns dict of dataframes/lists to append to global tables.
    """
    out = {
        "comp": pd.DataFrame(),
        "pareto": pd.DataFrame(),
        "pareto_full": pd.DataFrame(),
        "conv": pd.DataFrame(),
        "best": pd.DataFrame(),
        "area": pd.DataFrame(),
        "change": pd.DataFrame(),
        "best_alg": ALGORITHMS[0],
    }
    cdir = os.path.join(out_alg, city)
    tdir = os.path.join(out_scen, city, "tables")

    def read_if_exists(p):
        return pd.read_csv(p) if os.path.exists(p) else pd.DataFrame()

    out["comp"] = read_if_exists(os.path.join(cdir, "algorithm_comparison_summary.csv"))
    if len(out["comp"]):
        try:
            out["best_alg"] = str(out["comp"].sort_values("AlgorithmScore").iloc[0].Algorithm)
        except Exception:
            pass

    alg = out["best_alg"]
    out["pareto"] = read_if_exists(os.path.join(cdir, f"{alg}_pareto_solutions.csv"))
    out["pareto_full"] = read_if_exists(os.path.join(cdir, f"{alg}_pareto_full_recheck.csv"))
    out["conv"] = read_if_exists(os.path.join(cdir, f"{alg}_convergence.csv"))
    out["best"] = read_if_exists(os.path.join(tdir, "best_solution_by_scenario.csv"))
    out["area"] = read_if_exists(os.path.join(tdir, "intervention_area_by_variable.csv"))
    out["change"] = read_if_exists(os.path.join(tdir, "decision_variable_changes_by_scenario.csv"))

    return out


def save_partial_global_tables(out_glob, all_comp, all_pareto, all_pareto_full, all_conv, all_best, all_area, all_change):
    """
    V6 long-run checkpoint: save partial global tables after each city.
    These files are overwritten after each completed city and finalized at the end.
    """
    if not SAVE_PARTIAL_GLOBAL_AFTER_EACH_CITY:
        return
    ensure_dir(out_glob)

    if all_comp:
        pd.concat(all_comp,ignore_index=True).to_csv(os.path.join(out_glob,"partial_all_city_algorithm_comparison_summary.csv"),index=False,encoding="utf-8-sig")
    if all_pareto:
        pd.concat(all_pareto,ignore_index=True).to_csv(os.path.join(out_glob,"partial_all_algorithm_pareto_solutions_sampled.csv"),index=False,encoding="utf-8-sig")
    if all_pareto_full:
        pd.concat(all_pareto_full,ignore_index=True).to_csv(os.path.join(out_glob,"partial_all_algorithm_pareto_full_recheck.csv"),index=False,encoding="utf-8-sig")
    if all_conv:
        pd.concat(all_conv,ignore_index=True).to_csv(os.path.join(out_glob,"partial_all_algorithm_convergence.csv"),index=False,encoding="utf-8-sig")
    if all_best:
        pd.DataFrame(all_best).to_csv(os.path.join(out_glob,"partial_six_city_best_solution_by_scenario.csv"),index=False,encoding="utf-8-sig")
    if all_area:
        pd.DataFrame(all_area).to_csv(os.path.join(out_glob,"partial_intervention_area_by_variable.csv"),index=False,encoding="utf-8-sig")
    if all_change:
        pd.DataFrame(all_change).to_csv(os.path.join(out_glob,"partial_decision_variable_changes_by_scenario.csv"),index=False,encoding="utf-8-sig")


# ============================================================
# V14. Scenario-specific optimization
# ============================================================

SCENARIO_OBJECTIVE_MAP = {
    "S1": ["J1"],              # safety-only preference
    "S2": ["J2"],              # eco-livability-only preference
    "S3": ["J3"],              # 3D-function-retention preference
    "S4": ["J1", "J2"],        # safety + livability preference
    "S5": ["J1", "J3"],        # safety + 3D function preference
    "S6": ["J2", "J3"],        # livability + 3D function preference
    "S7": ["J1", "J2", "J3"],  # cascade-balanced tri-objective preference
}

def _positive_violation(x):
    return max(0.0, float(x))


def scenario_objective_vector(info, scenario, base, theta=None):
    """
    V15 NSGA-III-only scenario objective vector.

    All scenarios are solved by NSGA-III with a 3-component minimization vector.
    The objective components are preference-encoded so that S1-S7 retain different
    decision meanings while remaining inside one unified NSGA-III framework.

    Minimization vectors:
    S1: [J1, no-worse-J2 penalty, CGI-retention penalty]
    S2: [no-worse-J1 penalty, -J2, CGI-retention penalty]
    S3: [no-worse-J1 penalty, no-worse-J2 penalty, -J3]
    S4: [J1, -J2, CGI-retention penalty]
    S5: [J1, no-worse-J2 penalty, -J3]
    S6: [no-worse-J1 penalty, -J2, -J3]
    S7: [J1, -J2, -J3]
    """
    J1 = float(info["J1"])
    J2 = float(info["J2"])
    J3 = float(info["J3"])
    ret = float(info.get("CGI_retention", J3))

    J1_0 = float(base["J1_S0"])
    J2_0 = float(base["J2_S0"])

    v_j1 = _positive_violation(J1 - J1_0) * SCENARIO_CONSTRAINT_PENALTY_WEIGHT
    v_j2 = _positive_violation(J2_0 - J2) * SCENARIO_CONSTRAINT_PENALTY_WEIGHT
    v_j3 = _positive_violation(ETA_CGI_MAIN - ret) * SCENARIO_CONSTRAINT_PENALTY_WEIGHT

    v_theta = 0.0
    if theta is not None:
        v_theta = scenario_variable_preference_penalty(theta, scenario) * SCENARIO_VARIABLE_PENALTY_WEIGHT

    if scenario == "S1":
        return np.asarray([J1 + v_theta, v_j2 + v_theta, v_j3 + v_theta], dtype=float)
    if scenario == "S2":
        return np.asarray([v_j1 + v_theta, -J2 + v_theta, v_j3 + v_theta], dtype=float)
    if scenario == "S3":
        return np.asarray([v_j1 + v_theta, v_j2 + v_theta, -J3 + v_theta], dtype=float)
    if scenario == "S4":
        return np.asarray([J1 + v_theta, -J2 + v_theta, v_j3 + v_theta], dtype=float)
    if scenario == "S5":
        return np.asarray([J1 + v_theta, v_j2 + v_theta, -J3 + v_theta], dtype=float)
    if scenario == "S6":
        return np.asarray([v_j1 + v_theta, -J2 + v_theta, -J3 + v_theta], dtype=float)
    if scenario == "S7":
        return np.asarray([J1 + v_theta, -J2 + v_theta, -J3 + v_theta], dtype=float)

    raise ValueError(f"Unknown scenario: {scenario}")


def scenario_algorithm_name(scenario):
    """
    V15: keep one paper-level optimization algorithm.
    """
    return "NSGA-III"


class ScenarioAdaptationProblem(ElementwiseProblem):
    """
    V15 scenario-specific NSGA-III optimization problem.

    Every S1-S7 scenario has n_obj=3, so NSGA-III is consistently used.
    The scenario distinction comes from the preference-encoded objective vector,
    not from switching algorithms.
    """
    def __init__(self, city_data, model, scenario):
        self.scenario = scenario
        self.objective_names = SCENARIO_OBJECTIVE_MAP[scenario]
        xl, xu = city_scenario_theta_bounds(city_data, scenario)
        self.theta_xl = xl
        self.theta_xu = xu
        super().__init__(n_var=N_THETA, n_obj=3, n_constr=0, xl=xl, xu=xu)
        self.city_data=city_data
        self.model=model
        self.records=[]

    def _evaluate(self, x, out, *args, **kwargs):
        _, info, _, _ = eval_theta(self.city_data, self.model, np.asarray(x), full=False, scenario=self.scenario)
        vtheta = scenario_variable_preference_penalty(x, self.scenario)
        out["F"] = scenario_objective_vector(info, self.scenario, self.city_data.baseline_metrics, theta=x)
        rec = {
            "Scenario": self.scenario,
            "ScenarioVariablePenaltyRaw": float(vtheta),
            "ScenarioVariablePenaltyWeighted": float(vtheta * SCENARIO_VARIABLE_PENALTY_WEIGHT),
            **{f"theta_{k}":v for k,v in zip(THETA_LABELS,x)},
            **info
        }
        for j, val in enumerate(out["F"]):
            rec[f"ScenarioObj{j+1}"] = float(val)
        self.records.append(rec)


def scenario_convergence_row(city, scenario, alg, it, F, records):
    F=np.asarray(F,float)
    nd=nondominated_mask(F) if len(F) else np.array([])
    feas=[bool(r["feasible"]) for r in records if isinstance(r,dict) and "feasible" in r]
    row = {
        "City":city,
        "Scenario":scenario,
        "Algorithm":alg,
        "Iteration":it,
        "N_population":int(len(F)),
        "N_nondominated":int(nd.sum()) if len(F) else 0,
        "FeasibleRate":float(np.mean(feas)) if feas else np.nan,
        "ObjectiveNames":"+".join(SCENARIO_OBJECTIVE_MAP[scenario]),
        "NSGAIIIObjectiveMode":NSGAIII_SCENARIO_OBJECTIVE_MODE,
    }
    if len(F):
        for j in range(F.shape[1]):
            row[f"Best_ScenarioObj{j+1}"] = float(np.nanmin(F[:,j]))
    return row


def run_scenario_pymoo_algorithm(city_data, model, scenario):
    """
    Run NSGA-III for one scenario-specific objective system.
    """
    if not PYMOO_AVAILABLE:
        raise RuntimeError("pymoo is not installed. Install it or set up the environment with pymoo.")

    alg_name = "NSGA-III"
    ref_dirs = get_reference_directions("das-dennis", 3, n_partitions=N_REF_PARTITIONS)
    pop_size = max(POP_SIZE, len(ref_dirs))
    algorithm = NSGA3(pop_size=pop_size, ref_dirs=ref_dirs)

    problem = ScenarioAdaptationProblem(city_data, model, scenario)
    progress_callback = PymooProgress(city_data.city, f"{scenario}-{alg_name}", N_GENERATIONS)

    res = minimize(
        problem,
        algorithm,
        ('n_gen', N_GENERATIONS),
        seed=RANDOM_SEED + int(scenario[1:]),
        verbose=False,
        save_history=PYMOO_SAVE_HISTORY,
        callback=progress_callback
    )

    X=np.asarray(res.pop.get("X"),float)
    F=np.asarray(res.pop.get("F"),float)

    infos=[]
    for x in X:
        _, info, _, _ = eval_theta(city_data, model, x, full=False, scenario=scenario)
        infos.append(info)

    if PYMOO_SAVE_HISTORY:
        conv=[]
        for it, hist in enumerate(res.history):
            pop=hist.pop
            FF=np.asarray(pop.get("F"),float)
            conv.append(scenario_convergence_row(city_data.city, scenario, alg_name, it, FF, problem.records))
    else:
        # Final-only convergence row. Much faster and memory-safe for final formal runs.
        conv=[scenario_convergence_row(city_data.city, scenario, alg_name, N_GENERATIONS, F, infos)]

    return alg_name, X, F, infos, pd.DataFrame(conv)


def scenario_solution_df(city, scenario, alg, X, F, infos):
    nd=nondominated_mask(F)
    rows=[]
    obj_names = SCENARIO_OBJECTIVE_MAP[scenario]
    for i,x in enumerate(X):
        row = {
            "City":city,
            "Scenario":scenario,
            "ScenarioName":SCENARIOS[scenario]["name"],
            "ScenarioNameZH":SCENARIOS[scenario]["zh"],
            "Algorithm":alg,
            "SolutionID":f"{scenario}_{alg}_{i:04d}",
            "ObjectiveNames":"+ ".join(obj_names).replace("+ ","+"),
            "NSGAIIIObjectiveMode":NSGAIII_SCENARIO_OBJECTIVE_MODE,
            "Pareto":bool(nd[i]),
            "ScenarioVariablePenaltyRaw": float(scenario_variable_preference_penalty(x, scenario)),
            "ScenarioVariablePenaltyWeighted": float(scenario_variable_preference_penalty(x, scenario) * SCENARIO_VARIABLE_PENALTY_WEIGHT),
            **{c: float(x[j]) for j, c in enumerate(THETA_COLS)},
            **infos[i]
        }
        # Standard three-objective columns retained for full-recheck and cross-scenario comparison.
        row["Obj1_min_J1"] = float(infos[i]["J1"])
        row["Obj2_min_minus_J2"] = float(-infos[i]["J2"])
        row["Obj3_min_minus_J3"] = float(-infos[i]["J3"])
        for j in range(F.shape[1]):
            row[f"ScenarioObj{j+1}"] = float(F[i,j])
        rows.append(row)
    return pd.DataFrame(rows)


def make_scenario_optimization_summary(city, scenario, alg, df, pareto_full, selected_row, metric_row):
    nd = df[df["Pareto"]].copy() if len(df) else pd.DataFrame()
    pf = pareto_full.copy() if pareto_full is not None else pd.DataFrame()
    row = {
        "City":city,
        "Scenario":scenario,
        "ScenarioName":SCENARIOS[scenario]["name"],
        "ScenarioNameZH":SCENARIOS[scenario]["zh"],
        "ObjectiveNames":"+".join(SCENARIO_OBJECTIVE_MAP[scenario]),
        "Algorithm":alg,
        "N_solutions":int(len(df)),
        "N_sampled_pareto":int(len(nd)),
        "N_full_recheck":int(len(pf)),
        "N_full_pareto":int(pf["Pareto_full"].astype(bool).sum()) if len(pf) and "Pareto_full" in pf.columns else 0,
        "FullRecheck_FeasibleRate":float(pf["feasible"].astype(bool).mean()) if len(pf) and "feasible" in pf.columns else np.nan,
        "SelectedSolutionID":selected_row.get("SolutionID",np.nan) if selected_row is not None else np.nan,
        "SelectedFullRecheckID":selected_row.get("FullRecheckID",np.nan) if selected_row is not None else np.nan,
        "UseBaselineFallback":metric_row.get("UseBaselineFallback",False) if metric_row is not None else np.nan,
        "FallbackReason":metric_row.get("FallbackReason",np.nan) if metric_row is not None else np.nan,
        "F1_reduction_pct":metric_row.get("F1_reduction_pct",np.nan) if metric_row is not None else np.nan,
        "F2_improvement_pct":metric_row.get("F2_improvement_pct",np.nan) if metric_row is not None else np.nan,
        "CGI_retention":metric_row.get("CGI_retention",np.nan) if metric_row is not None else np.nan,
        "InterventionIntensity":metric_row.get("InterventionIntensity",np.nan) if metric_row is not None else np.nan,
    }
    return row



# ============================================================
# V23. Response-guided city audit and BGI guidance
# ============================================================

def run_city_response_audit(city_data, model, out_table_dir=None):
    """
    Evaluate small controlled interventions before optimization.

    The audit is not used as final evidence; it only guides how strongly each
    intervention family should be emphasized in this city. This avoids assuming
    that green/street/permeable changes always reduce flood risk in every city.
    """
    if not RUN_RESPONSE_AUDIT_BEFORE_OPTIMIZATION:
        city_data.response_guidance = {}
        return pd.DataFrame()

    old_guidance = getattr(city_data, "response_guidance", None)
    city_data.response_guidance = None

    base = city_data.baseline_metrics
    probes = {
        "green_NDVI":   [RESPONSE_AUDIT_THETA, 0, 0, 0, 0, 0, 0],
        "street_GVI":   [0, RESPONSE_AUDIT_THETA, 0, 0, 0, 0, 0],
        "permeable":    [0, 0, RESPONSE_AUDIT_THETA, 0, 0, 0, 0],
        "built_reduce": [0, 0, 0, RESPONSE_AUDIT_THETA, 0, 0, 0],
        "compact":      [0, 0, 0, 0, RESPONSE_AUDIT_THETA, 0, 0],
        "lulc_convert": [0, 0, 0, 0, 0, RESPONSE_AUDIT_THETA, 0],
        "BGI":          [0, 0, 0, 0, 0, 0, RESPONSE_AUDIT_THETA],
        "BGI_plus":     [0.25, 0.25, 0.25, 0, 0, 0, RESPONSE_AUDIT_THETA],
    }

    rows = []
    for name, theta in probes.items():
        try:
            use_full_audit = (
                (city_data.city in FORCE_FULL_RESPONSE_AUDIT_CITIES)
                or not (RESPONSE_AUDIT_FAST_SAMPLE_MODE and RUN_LEVEL in ["quick", "citycheck"])
            )
            _, info, _, _ = eval_theta(city_data, model, np.asarray(theta, dtype=float), full=use_full_audit)

            # In fast sampled audit, compare each probe against sampled zero-theta baseline to avoid
            # scale mismatch between sampled J values and full-domain S0 metrics.
            if use_full_audit:
                base_J1 = base["J1_S0"]
                base_J2 = base["J2_S0"]
            else:
                _, base_info_sample, _, _ = eval_theta(city_data, model, np.zeros(N_THETA, dtype=float), full=False)
                base_J1 = base_info_sample["J1"]
                base_J2 = base_info_sample["J2"]

            f1_red = (base_J1 - info["J1"]) / (abs(base_J1) + 1e-12) * 100.0
            f2_imp = (info["J2"] - base_J2) / (abs(base_J2) + 1e-12) * 100.0
            rows.append({
                "City": city_data.city,
                "Probe": name,
                **{c: float(_pad_theta(theta)[i]) for i, c in enumerate(THETA_COLS)},
                "J1": float(info["J1"]),
                "J2": float(info["J2"]),
                "J3": float(info["J3"]),
                "F1_reduction_pct": float(f1_red),
                "F2_improvement_pct": float(f2_imp),
                "CGI_retention": float(info.get("CGI_retention", np.nan)),
                "InterventionIntensity": float(info.get("InterventionIntensity", np.nan)),
                "ResponseAuditMode": "full" if use_full_audit else "sample_fast",
                "BeneficialForF1": bool(f1_red > 0),
                "BeneficialForF2": bool(f2_imp > 0),
            })
        except Exception as e:
            rows.append({"City": city_data.city, "Probe": name, "Error": repr(e)})

    audit = pd.DataFrame(rows)

    def score_probe(probe):
        sub = audit[audit["Probe"] == probe]
        if len(sub) == 0 or "F1_reduction_pct" not in sub.columns:
            return 0.0
        r = float(sub.iloc[0].get("F1_reduction_pct", 0.0))
        l = float(sub.iloc[0].get("F2_improvement_pct", 0.0))
        return 0.60*r + 0.40*l

    # Convert response scores to multipliers.
    # Positive score -> emphasize; negative score -> down-weight but not zero.
    def mult_from_score(s):
        if s > 5: return 1.25
        if s > 1: return 1.10
        if s > -1: return 0.85
        if s > -3: return 0.55
        return 0.35

    green_score = max(score_probe("green_NDVI"), 0.5*score_probe("BGI_plus"))
    street_score = max(score_probe("street_GVI"), 0.5*score_probe("BGI_plus"))
    perm_score = max(score_probe("permeable"), score_probe("BGI"), 0.5*score_probe("BGI_plus"))
    bgi_score = max(score_probe("BGI"), score_probe("BGI_plus"))
    built_score = score_probe("built_reduce")
    lulc_score = score_probe("lulc_convert")

    guidance = {
        "green_mult": mult_from_score(green_score),
        "street_mult": mult_from_score(street_score),
        "perm_mult": mult_from_score(perm_score),
        "bgi_mult": mult_from_score(bgi_score),
        "built_mult": mult_from_score(built_score),
        "lulc_mult": mult_from_score(lulc_score),
        "green_score": green_score,
        "street_score": street_score,
        "perm_score": perm_score,
        "bgi_score": bgi_score,
        "built_score": built_score,
        "lulc_score": lulc_score,
    }

    city_data.response_guidance = guidance

    for k, v in guidance.items():
        audit[k] = v

    if out_table_dir is not None:
        ensure_dir(out_table_dir)
        audit.to_csv(os.path.join(out_table_dir, "city_response_guided_audit.csv"), index=False, encoding="utf-8-sig")

    return audit



def make_targeted_bgi_fallback_row(city_data, model, scenario, base):
    """
    V28 robust fallback: if target city would otherwise use S0 fallback, create
    a BGI policy-corrected non-zero candidate from TARGETED_BGI_FALLBACK_THETA.
    """
    theta = np.asarray(TARGETED_BGI_FALLBACK_THETA.get(city_data.city, [0,0,0,0,0,0,0.75]), dtype=float)
    _, info, _, _ = eval_theta(city_data, model, theta, full=True, scenario=scenario)

    row = pd.Series({
        "City": city_data.city,
        "Scenario": scenario,
        "ScenarioName": SCENARIOS[scenario]["name"],
        "ScenarioNameZH": SCENARIOS[scenario]["zh"],
        "Algorithm": "V28_TARGETED_BGI_FALLBACK",
        "SolutionID": f"{scenario}_V28_TARGETED_BGI_FALLBACK",
        "FullRecheckID": f"{scenario}_V28_TARGETED_BGI_FALLBACK",
        "PolicyAnchor": False,
        "Pareto_full": False,
        "ScenarioScore": np.nan,
        "ScenarioBaseScore": np.nan,
        "ScenarioSolutionKey": "theta_" + "_".join(map(str, [round(float(x), DEDUP_THETA_DECIMALS) for x in theta])),
        "ScenarioSelectionUsedFullRecheck": True,
        "ScenarioDiversityApplied": False,
        "ScenarioExpandedBeyondPareto": True,
        "ScenarioSelectionPool": "v28_targeted_policy_bgi_fallback",
        "ForceBGISelection": True,
        "ControlledTradeoffExploratory": True,
        "UseBaselineFallback": False,
        "FallbackReason": "V28 replaced S0 fallback with targeted policy-corrected BGI candidate",
        **{c: float(theta[i]) for i, c in enumerate(THETA_COLS)},
        **info
    })
    return row



def _v40_theta_key_from_values(theta):
    theta = _pad_theta(theta)
    return "theta_" + "_".join([str(round(float(x), DEDUP_THETA_DECIMALS)) for x in theta])


def _v40_theta_key_from_row(row):
    vals = []
    for c in THETA_COLS:
        try:
            vals.append(round(float(row.get(c, 0.0)), DEDUP_THETA_DECIMALS))
        except Exception:
            vals.append(np.nan)
    return "theta_" + "_".join(map(str, vals))


def _v40_norm_array(x, higher_better=True):
    x = np.asarray(x, dtype=float)
    if x.size == 0 or np.all(~np.isfinite(x)):
        z = np.ones_like(x, dtype=float) * 0.5
    else:
        mn = np.nanmin(x)
        mx = np.nanmax(x)
        if (not np.isfinite(mn)) or (not np.isfinite(mx)) or abs(mx - mn) < 1e-12:
            z = np.ones_like(x, dtype=float) * 0.5
        else:
            z = (x - mn) / (mx - mn)
    if not higher_better:
        z = 1.0 - z
    return np.clip(z, 0, 1)


def _v40_s7_prepare_pool(pool, base):
    """
    Prepare candidate pool for V40 S7 balanced selection.
    """
    if pool is None or len(pool) == 0:
        return pd.DataFrame()

    df = pool.copy()
    # Standardize required columns.
    for c in THETA_COLS:
        if c not in df.columns:
            df[c] = 0.0

    if "J1" not in df.columns or "J2" not in df.columns:
        return pd.DataFrame()

    if "J3" not in df.columns:
        df["J3"] = df.get("CGI_retention", 1.0)
    if "CGI_retention" not in df.columns:
        df["CGI_retention"] = df["J3"]
    if "InterventionIntensity" not in df.columns:
        df["InterventionIntensity"] = 0.0
    if "UseBaselineFallback" not in df.columns:
        df["UseBaselineFallback"] = False
    if "NoNegativeProjectionApplied" not in df.columns:
        df["NoNegativeProjectionApplied"] = False

    df["_F1_reduction_pct_candidate"] = (base["J1_S0"] - df["J1"].astype(float)) / (abs(base["J1_S0"]) + 1e-12) * 100.0
    df["_F2_improvement_pct_candidate"] = (df["J2"].astype(float) - base["J2_S0"]) / (abs(base["J2_S0"]) + 1e-12) * 100.0

    # Use J3 as the candidate-level CGI net score; final save_scenario_outputs
    # will additionally compute raster-level enhanced CGI diagnostics.
    df["_CGI_candidate"] = df["J3"].astype(float)
    df["_Intensity_candidate"] = df["InterventionIntensity"].astype(float)

    df["_F1_norm"] = _v40_norm_array(df["_F1_reduction_pct_candidate"].to_numpy(float), True)
    df["_F2_norm"] = _v40_norm_array(df["_F2_improvement_pct_candidate"].to_numpy(float), True)
    df["_CGI_norm"] = _v40_norm_array(df["_CGI_candidate"].to_numpy(float), True)
    df["_Intensity_norm"] = _v40_norm_array(df["_Intensity_candidate"].to_numpy(float), False)

    # V42: performance floor for S7.
    # S7 must be a balanced high-performance pathway. A candidate with extremely
    # low intervention may look good due to the intensity term, but it should not
    # be selected if F1/F2 improvements are far below the city's attainable range.
    f1_arr = df["_F1_reduction_pct_candidate"].to_numpy(float)
    f2_arr = df["_F2_improvement_pct_candidate"].to_numpy(float)
    f1_max = np.nanmax(f1_arr) if np.any(np.isfinite(f1_arr)) else 0.0
    f2_max = np.nanmax(f2_arr) if np.any(np.isfinite(f2_arr)) else 0.0
    f1_floor = max(0.0, float(f1_max) * V42_S7_F1_FLOOR_RATIO)
    f2_floor = max(0.0, float(f2_max) * V42_S7_F2_FLOOR_RATIO)
    f1_floor_relaxed = max(0.0, float(f1_max) * V42_S7_FLOOR_RELAXED_RATIO)
    f2_floor_relaxed = max(0.0, float(f2_max) * V42_S7_FLOOR_RELAXED_RATIO)

    df["_V42_F1_max_for_floor"] = float(f1_max)
    df["_V42_F2_max_for_floor"] = float(f2_max)
    df["_V42_F1_floor"] = float(f1_floor)
    df["_V42_F2_floor"] = float(f2_floor)
    df["_V42_F1_floor_relaxed"] = float(f1_floor_relaxed)
    df["_V42_F2_floor_relaxed"] = float(f2_floor_relaxed)
    df["_V42_PerformanceFloorPass"] = (df["_F1_reduction_pct_candidate"] >= f1_floor) & (df["_F2_improvement_pct_candidate"] >= f2_floor)
    df["_V42_PerformanceFloorRelaxedPass"] = (df["_F1_reduction_pct_candidate"] >= f1_floor_relaxed) & (df["_F2_improvement_pct_candidate"] >= f2_floor_relaxed)
    df["_V42_FloorDeficit"] = (
        np.maximum(0.0, f1_floor - df["_F1_reduction_pct_candidate"]) / (abs(f1_floor) + 1e-9)
        + np.maximum(0.0, f2_floor - df["_F2_improvement_pct_candidate"]) / (abs(f2_floor) + 1e-9)
    )

    base_score = (
        V40_S7_WEIGHTS["F1"] * df["_F1_norm"]
        + V40_S7_WEIGHTS["F2"] * df["_F2_norm"]
        + V40_S7_WEIGHTS["CGI"] * df["_CGI_norm"]
        + V40_S7_WEIGHTS["LOW_INTENSITY"] * df["_Intensity_norm"]
    )

    penalty = np.zeros(len(df), dtype=float)
    try:
        fallback = df["UseBaselineFallback"].fillna(False).astype(bool).to_numpy()
    except Exception:
        fallback = np.zeros(len(df), dtype=bool)
    try:
        projection = df["NoNegativeProjectionApplied"].fillna(False).astype(bool).to_numpy()
    except Exception:
        projection = np.zeros(len(df), dtype=bool)

    f1 = df["_F1_reduction_pct_candidate"].to_numpy(float)
    f2 = df["_F2_improvement_pct_candidate"].to_numpy(float)
    zero_gain = (np.abs(f1) < 1e-8) & (np.abs(f2) < 1e-8)

    penalty += np.where(fallback, V40_S7_FALLBACK_PENALTY, 0.0)
    penalty += np.where(f1 < -1e-8, V40_S7_NEGATIVE_PENALTY, 0.0)
    penalty += np.where(f2 < -1e-8, V40_S7_NEGATIVE_PENALTY, 0.0)
    penalty += np.where(projection, V40_S7_PROJECTION_PENALTY, 0.0)
    penalty += np.where(zero_gain, V40_S7_ZERO_GAIN_PENALTY, 0.0)
    if V42_S7_REQUIRE_PERFORMANCE_FLOOR:
        penalty += df["_V42_FloorDeficit"].to_numpy(float) * V42_S7_FLOOR_PENALTY_WEIGHT

    # V43: targeted cities should not have an S7 that drops BGI to almost zero,
    # because V41 showed this can produce a high-looking but conceptually weak S7.
    if "City" in df.columns and "theta_BGI" in df.columns:
        try:
            city0 = str(df["City"].dropna().iloc[0])
        except Exception:
            city0 = ""
        if city0 in V42_S7_TARGETED_CITIES:
            bgi = df["theta_BGI"].astype(float).to_numpy()
            bgi_deficit = np.maximum(0.0, V43_S7_TARGETED_BGI_MIN - bgi) / (V43_S7_TARGETED_BGI_MIN + 1e-9)
            penalty += bgi_deficit * V43_S7_TARGETED_BGI_PENALTY
            df["_V43_TargetedBGIDeficit"] = bgi_deficit
        else:
            df["_V43_TargetedBGIDeficit"] = 0.0

    df["_V40_S7_BaseScore"] = base_score
    df["_V40_S7_Penalty"] = penalty
    df["_V40_S7_BalancedScore"] = base_score - penalty
    df["_V40_theta_key"] = df.apply(_v40_theta_key_from_row, axis=1)
    return df


def choose_s7_balanced_solution(pool, base, selected_theta_keys=None):
    """
    V40 S7 selector.

    S7 is the comprehensive balanced scenario. It is selected from full-rechecked
    candidates using a balanced score, not by simply copying an existing scenario.
    Exact theta duplication with S1-S6 is avoided whenever possible.
    """
    selected_theta_keys = selected_theta_keys or set()
    df = _v40_s7_prepare_pool(pool, base)
    if len(df) == 0:
        return None

    # Basic acceptability: no fallback, non-negative F1/F2.
    cand = df.copy()
    cand = cand[~cand["UseBaselineFallback"].fillna(False).astype(bool)].copy()
    cand = cand[(cand["_F1_reduction_pct_candidate"] >= -1e-8) & (cand["_F2_improvement_pct_candidate"] >= -1e-8)].copy()
    if "feasible" in cand.columns:
        feas = cand[cand["feasible"].fillna(True).astype(bool)].copy()
        if len(feas) > 0:
            cand = feas
    if len(cand) == 0:
        cand = df.copy()

    # V42: first use candidates that pass the S7 performance floor.
    # If none pass the strict floor, use relaxed floor; if still none, use full cand.
    if V42_S7_REQUIRE_PERFORMANCE_FLOOR and V42_S7_HARD_FILTER_FIRST and "_V42_PerformanceFloorPass" in cand.columns:
        cand_floor = cand[cand["_V42_PerformanceFloorPass"].astype(bool)].copy()
        if len(cand_floor) > 0:
            cand = cand_floor
        else:
            cand_relaxed = cand[cand["_V42_PerformanceFloorRelaxedPass"].astype(bool)].copy()
            if len(cand_relaxed) > 0:
                cand = cand_relaxed

    best_all = cand.iloc[int(np.nanargmax(cand["_V40_S7_BalancedScore"].to_numpy(float)))].copy()
    best_score = float(best_all["_V40_S7_BalancedScore"])

    chosen = best_all.copy()
    duplicate_avoided = False
    if V40_S7_AVOID_DUPLICATE_THETA and selected_theta_keys:
        nondup = cand[~cand["_V40_theta_key"].astype(str).isin(selected_theta_keys)].copy()
        if len(nondup) > 0:
            best_nondup = nondup.iloc[int(np.nanargmax(nondup["_V40_S7_BalancedScore"].to_numpy(float)))].copy()
            nondup_score = float(best_nondup["_V40_S7_BalancedScore"])
            # Prefer non-duplicate if its score is not catastrophically worse.
            if (best_score - nondup_score) <= V40_S7_NON_DUPLICATE_MAX_SCORE_LOSS:
                chosen = best_nondup
                duplicate_avoided = True

    chosen["ScenarioScore"] = float(chosen.get("_V40_S7_BalancedScore", np.nan))
    chosen["ScenarioBaseScore"] = float(chosen.get("_V40_S7_BaseScore", np.nan))
    chosen["ScenarioSolutionKey"] = _v40_theta_key_from_row(chosen)
    chosen["ScenarioSelectionUsedFullRecheck"] = True
    chosen["ScenarioDiversityApplied"] = bool(duplicate_avoided)
    chosen["ScenarioExpandedBeyondPareto"] = True
    chosen["ScenarioSelectionPool"] = "v40_s7_balanced_full_recheck_bank"
    chosen["V40S7BalancedSelection"] = True
    chosen["V40S7DuplicateAvoided"] = bool(duplicate_avoided)
    chosen["V40S7BestAllScore"] = best_score
    chosen["V40S7ChosenScore"] = float(chosen.get("_V40_S7_BalancedScore", np.nan))
    chosen["V40S7ScoreLossVsBest"] = float(best_score - chosen["V40S7ChosenScore"])
    chosen["UseBaselineFallback"] = False
    if "FallbackReason" not in chosen.index:
        chosen["FallbackReason"] = np.nan
    return chosen


def _v41_candidate_row_from_theta(city_data, model, theta, scenario, source_label, source_score=np.nan):
    """
    Evaluate one V41 generated candidate using the full-domain objective.
    """
    theta = np.clip(_pad_theta(theta), 0.0, 1.0)
    _, info, _, _ = eval_theta(city_data, model, theta, full=True, scenario=scenario)
    row = {
        "City": city_data.city,
        "Algorithm": "V41_S7_NEAR_BEST_FULL_EVAL",
        "SolutionID": f"{scenario}_{source_label}",
        "FullRecheckID": f"{scenario}_{source_label}",
        "PolicyAnchor": False,
        "Pareto_full": False,
        "FullRechecked": True,
        "V41GeneratedS7Candidate": True,
        "V41SourceScoreBeforeGeneration": source_score,
        **{c: float(theta[i]) for i, c in enumerate(THETA_COLS)},
        **info
    }
    row["Obj1_min_J1"] = float(info["J1"])
    row["Obj2_min_minus_J2"] = -float(info["J2"])
    row["Obj3_min_minus_J3"] = -float(info["J3"])
    row["Scenario"] = scenario
    row["ScenarioName"] = SCENARIOS[scenario]["name"]
    row["ScenarioNameZH"] = SCENARIOS[scenario]["zh"]
    return row


def _v43_selected_scenario_balance_score_df(df, base):
    """
    Score already selected S1-S6 pathways for creating S7 blend candidates.
    """
    out = df.copy()
    if len(out) == 0:
        return out
    out["_F1_red"] = (base["J1_S0"] - out["J1"].astype(float)) / (abs(base["J1_S0"]) + 1e-12) * 100.0
    out["_F2_imp"] = (out["J2"].astype(float) - base["J2_S0"]) / (abs(base["J2_S0"]) + 1e-12) * 100.0
    out["_CGI"] = out.get("J3", out.get("CGI_retention", 1.0)).astype(float)
    out["_Intensity"] = out.get("InterventionIntensity", 0.0).astype(float)

    out["_F1_norm"] = _v40_norm_array(out["_F1_red"].to_numpy(float), True)
    out["_F2_norm"] = _v40_norm_array(out["_F2_imp"].to_numpy(float), True)
    out["_CGI_norm"] = _v40_norm_array(out["_CGI"].to_numpy(float), True)
    out["_Intensity_norm"] = _v40_norm_array(out["_Intensity"].to_numpy(float), False)

    out["_V43_SelectedScenarioBlendScore"] = (
        0.40*out["_F1_norm"] + 0.40*out["_F2_norm"] +
        0.15*out["_CGI_norm"] + 0.05*out["_Intensity_norm"]
    )
    return out.sort_values("_V43_SelectedScenarioBlendScore", ascending=False)


def _v43_blend_thetas(theta_a, theta_b, weights=(0.5, 0.65, 0.35)):
    """
    Deterministically blend two selected scenario theta vectors.
    """
    a = _pad_theta(theta_a)
    b = _pad_theta(theta_b)
    out = []
    for w in weights:
        out.append(np.clip(w*a + (1.0-w)*b, 0.0, 1.0))
    return out


def v43_add_selected_scenario_blends_to_s7_pool(city_data, model, pool, scenario_rows, out_dir=None):
    """
    Add full-evaluated S7 candidates generated from selected S1-S6 pathways.

    This is the main V43 stabilizer: S7 is not limited to raw S7 Pareto or
    old anchors. It can use a near-best balanced blend of pathways already
    selected for S1-S6.
    """
    if not V43_ADD_SELECTED_SCENARIO_BLEND_S7:
        return pool
    if scenario_rows is None or len(scenario_rows) == 0:
        return pool

    sr = pd.DataFrame(scenario_rows).copy()
    sr = sr[sr["Scenario"].astype(str).isin([f"S{i}" for i in range(1,7)])].copy()
    if len(sr) < 2:
        return pool

    for c in THETA_COLS:
        if c not in sr.columns:
            sr[c] = 0.0

    scored = _v43_selected_scenario_balance_score_df(sr, city_data.baseline_metrics)
    top = scored.head(4).copy()

    # Always include meaningful pairings: top pairs plus S2/S4/S5/S6 if present.
    theta_sources = []
    for _, r in top.iterrows():
        theta_sources.append((str(r["Scenario"]), np.array([r[c] for c in THETA_COLS], dtype=float)))

    # Add selected S2/S4/S5/S6 specifically because they often define good S7 neighborhood.
    for scen in ["S2", "S4", "S5", "S6"]:
        sub = scored[scored["Scenario"].astype(str) == scen]
        if len(sub):
            r = sub.iloc[0]
            theta_sources.append((scen, np.array([r[c] for c in THETA_COLS], dtype=float)))

    # Unique sources by theta key.
    uniq_sources = []
    seen_src = set()
    for label, th in theta_sources:
        k = _v40_theta_key_from_values(th)
        if k not in seen_src:
            uniq_sources.append((label, th))
            seen_src.add(k)

    existing = set()
    if pool is not None and len(pool):
        for _, r in pool.iterrows():
            try:
                existing.add(_v40_theta_key_from_row(r))
            except Exception:
                pass

    rows = []
    # Pairwise blends.
    for i in range(len(uniq_sources)):
        for j in range(i+1, len(uniq_sources)):
            lab_i, th_i = uniq_sources[i]
            lab_j, th_j = uniq_sources[j]
            for k, th in enumerate(_v43_blend_thetas(th_i, th_j)):
                key = _v40_theta_key_from_values(th)
                if key in existing:
                    continue
                # For targeted cities, ensure blended S7 keeps a meaningful BGI component.
                if city_data.city in V42_S7_TARGETED_CITIES and "theta_BGI" in THETA_COLS:
                    bgi_idx = THETA_COLS.index("theta_BGI")
                    if th[bgi_idx] < V43_S7_TARGETED_BGI_MIN:
                        th = th.copy()
                        th[bgi_idx] = V43_S7_TARGETED_BGI_MIN
                        key = _v40_theta_key_from_values(th)
                        if key in existing:
                            continue
                try:
                    row = _v41_candidate_row_from_theta(
                        city_data, model, th, "S7",
                        source_label=f"V43_BLEND_{lab_i}_{lab_j}_{k:02d}",
                        source_score=np.nan
                    )
                    row["V43SelectedScenarioBlendCandidate"] = True
                    row["V43BlendSourceA"] = lab_i
                    row["V43BlendSourceB"] = lab_j
                    rows.append(row)
                    existing.add(key)
                    if len(rows) >= int(V43_MAX_SELECTED_BLEND_CANDIDATES):
                        break
                except Exception as e:
                    print(f"[V43 WARN] failed to evaluate S7 blend {city_data.city}-{lab_i}-{lab_j}: {e}")
            if len(rows) >= int(V43_MAX_SELECTED_BLEND_CANDIDATES):
                break
        if len(rows) >= int(V43_MAX_SELECTED_BLEND_CANDIDATES):
            break

    if rows:
        out = pd.concat([pool.copy(), pd.DataFrame(rows)], ignore_index=True) if pool is not None and len(pool) else pd.DataFrame(rows)
    else:
        out = pool.copy() if pool is not None else pd.DataFrame()

    if V43_S7_WRITE_FINAL_SELECTION_AUDIT and out_dir is not None:
        try:
            _v40_s7_prepare_pool(out, city_data.baseline_metrics).to_csv(
                os.path.join(out_dir, "S7_V43_pool_after_selected_scenario_blends.csv"),
                index=False, encoding="utf-8-sig"
            )
        except Exception as e:
            print(f"[V43 WARN] failed to write S7 blend candidate bank: {e}")

    return out


def v43_final_validate_and_select_s7(city_data, pool, chosen_row, selected_theta_keys, out_dir=None):
    """
    Final S7 self-check. If chosen S7 is still weak or far from the best
    balanced candidate, replace it with the best acceptable high-performance
    candidate, preferably non-duplicate.
    """
    if (not V43_S7_FINAL_VALIDATION) or pool is None or len(pool) == 0:
        return chosen_row

    prepared = _v40_s7_prepare_pool(pool, city_data.baseline_metrics)
    if len(prepared) == 0:
        return chosen_row

    cand = prepared.copy()
    if V43_S7_STRICT_NONNEGATIVE:
        cand = cand[(cand["_F1_reduction_pct_candidate"] >= -1e-8) & (cand["_F2_improvement_pct_candidate"] >= -1e-8)].copy()
    cand = cand[~cand.get("UseBaselineFallback", pd.Series(False, index=cand.index)).fillna(False).astype(bool)].copy()

    if city_data.city in V42_S7_TARGETED_CITIES and "theta_BGI" in cand.columns:
        targeted = cand[cand["theta_BGI"].astype(float) >= V43_S7_TARGETED_BGI_MIN].copy()
        if len(targeted) > 0:
            cand = targeted

    if V42_S7_REQUIRE_PERFORMANCE_FLOOR and "_V42_PerformanceFloorPass" in cand.columns:
        floor = cand[cand["_V42_PerformanceFloorPass"].astype(bool)].copy()
        if len(floor) > 0:
            cand = floor
        else:
            relaxed = cand[cand["_V42_PerformanceFloorRelaxedPass"].astype(bool)].copy()
            if len(relaxed) > 0:
                cand = relaxed

    if len(cand) == 0:
        return chosen_row

    cand = cand.sort_values("_V40_S7_BalancedScore", ascending=False).copy()
    best_all = cand.iloc[0].copy()
    best_score = float(best_all["_V40_S7_BalancedScore"])

    # Prefer non-duplicate, but not at the expense of large score loss.
    chosen = best_all.copy()
    duplicate_avoided = False
    if V40_S7_AVOID_DUPLICATE_THETA and selected_theta_keys:
        nondup = cand[~cand["_V40_theta_key"].astype(str).isin(selected_theta_keys)].copy()
        if len(nondup) > 0:
            best_nondup = nondup.iloc[0].copy()
            loss = best_score - float(best_nondup["_V40_S7_BalancedScore"])
            if loss <= max(V40_S7_NON_DUPLICATE_MAX_SCORE_LOSS, V43_S7_ALLOWED_SCORE_GAP):
                chosen = best_nondup
                duplicate_avoided = True

    # If the existing chosen is already near best and passes floor, keep it.
    try:
        existing_key = _v40_theta_key_from_row(chosen_row)
        existing_prepared = prepared[prepared["_V40_theta_key"].astype(str) == existing_key].copy()
        if len(existing_prepared) > 0:
            er = existing_prepared.iloc[0]
            existing_score = float(er["_V40_S7_BalancedScore"])
            near = (best_score - existing_score) <= V43_S7_ALLOWED_SCORE_GAP
            floor_ok = bool(er.get("_V42_PerformanceFloorPass", False)) or bool(er.get("_V42_PerformanceFloorRelaxedPass", False))
            bgi_ok = True
            if city_data.city in V42_S7_TARGETED_CITIES and "theta_BGI" in er.index:
                bgi_ok = float(er["theta_BGI"]) >= V43_S7_TARGETED_BGI_MIN
            if near and floor_ok and bgi_ok:
                out = chosen_row.copy()
                out["V43S7FinalValidationKeptOriginal"] = True
                out["V43S7FinalBestScore"] = best_score
                out["V43S7FinalChosenScore"] = existing_score
                out["V43S7FinalScoreGap"] = best_score - existing_score
                return out
    except Exception:
        pass

    chosen["ScenarioScore"] = float(chosen.get("_V40_S7_BalancedScore", np.nan))
    chosen["ScenarioBaseScore"] = float(chosen.get("_V40_S7_BaseScore", np.nan))
    chosen["ScenarioSolutionKey"] = _v40_theta_key_from_row(chosen)
    chosen["ScenarioSelectionUsedFullRecheck"] = True
    chosen["ScenarioDiversityApplied"] = bool(duplicate_avoided)
    chosen["ScenarioExpandedBeyondPareto"] = True
    chosen["ScenarioSelectionPool"] = "v43_final_validated_s7_balanced_pool"
    chosen["V40S7BalancedSelection"] = True
    chosen["V40S7DuplicateAvoided"] = bool(duplicate_avoided)
    chosen["V43S7FinalValidationReplaced"] = True
    chosen["V43S7FinalBestScore"] = best_score
    chosen["V43S7FinalChosenScore"] = float(chosen.get("_V40_S7_BalancedScore", np.nan))
    chosen["V43S7FinalScoreGap"] = best_score - float(chosen.get("_V40_S7_BalancedScore", np.nan))
    chosen["UseBaselineFallback"] = False

    if V43_S7_WRITE_FINAL_SELECTION_AUDIT and out_dir is not None:
        try:
            cand.to_csv(os.path.join(out_dir, "S7_V43_final_validated_candidate_bank.csv"), index=False, encoding="utf-8-sig")
        except Exception as e:
            print(f"[V43 WARN] failed to write final S7 validation bank: {e}")

    return chosen



def _v42_targeted_s7_anchor_thetas(city):
    """
    V42 targeted S7 anchors.

    These are not direct final answers. They enrich the S7 full-recheck bank with
    balanced candidates around the known high-performing pathways of Chengdu and
    Shenzhen, so that S7 does not become overly conservative.
    """
    anchors = {
        "Chengdu": [
            ("V42_CD_S7_green_street_BGI",     [0.45, 0.50, 0.20, 0.00, 0.00, 0.00, 0.88]),
            ("V42_CD_S7_mixed_BGI",            [0.35, 0.35, 0.38, 0.00, 0.00, 0.00, 0.88]),
            ("V42_CD_S7_balanced_highBGI",     [0.42, 0.42, 0.30, 0.00, 0.00, 0.00, 0.90]),
            ("V42_CD_S7_livability_risk_BGI",  [0.50, 0.48, 0.25, 0.00, 0.00, 0.00, 0.82]),
        ],
        "Shenzhen": [
            ("V42_SZ_S7_risk_livability_BGI",  [0.45, 0.40, 0.50, 0.00, 0.00, 0.00, 0.45]),
            ("V42_SZ_S7_S4S5_blend",           [0.35, 0.30, 0.58, 0.00, 0.00, 0.00, 0.50]),
            ("V42_SZ_S7_green_permeable_BGI",  [0.55, 0.45, 0.55, 0.00, 0.00, 0.00, 0.35]),
            ("V42_SZ_S7_balanced_multivar",    [0.40, 0.35, 0.45, 0.00, 0.00, 0.02, 0.45]),
        ],
    }
    return anchors.get(city, [])


def v42_add_targeted_s7_anchors(city_data, model, pool, out_dir=None):
    """
    Add full-evaluated targeted S7 anchors for problematic cities.
    """
    if (not V42_ADD_TARGETED_S7_ANCHORS) or city_data.city not in V42_S7_TARGETED_CITIES:
        return pool

    rows = []
    existing = set()
    if pool is not None and len(pool):
        for _, r in pool.iterrows():
            try:
                existing.add(_v40_theta_key_from_row(r))
            except Exception:
                pass

    for name, theta in _v42_targeted_s7_anchor_thetas(city_data.city):
        theta = np.asarray(theta, dtype=float)
        key = _v40_theta_key_from_values(theta)
        if key in existing:
            continue
        try:
            row = _v41_candidate_row_from_theta(
                city_data, model, theta, "S7",
                source_label=name,
                source_score=np.nan
            )
            row["V42TargetedS7Anchor"] = True
            rows.append(row)
            existing.add(key)
        except Exception as e:
            print(f"[V42 WARN] failed to evaluate targeted S7 anchor {city_data.city}-{name}: {e}")

    if rows:
        out = pd.concat([pool.copy(), pd.DataFrame(rows)], ignore_index=True) if pool is not None and len(pool) else pd.DataFrame(rows)
    else:
        out = pool.copy() if pool is not None else pd.DataFrame()

    if V42_WRITE_S7_FLOOR_DIAGNOSTICS and out_dir is not None:
        try:
            _v40_s7_prepare_pool(out, city_data.baseline_metrics).to_csv(
                os.path.join(out_dir, "S7_V42_targeted_floor_candidate_bank.csv"),
                index=False, encoding="utf-8-sig"
            )
        except Exception as e:
            print(f"[V42 WARN] failed to write targeted S7 candidate bank: {e}")

    return out



def _v41_generate_theta_variants(theta):
    """
    Create small deterministic perturbations around a near-best S7 theta.
    This helps avoid exact duplication with S1-S6 without moving far away
    from the balanced optimum.
    """
    theta = np.clip(_pad_theta(theta), 0.0, 1.0)
    variants = []
    d = float(V41_S7_VARIATION_STRENGTH)
    idx = {c: i for i, c in enumerate(THETA_COLS)}

    def add(arr):
        arr = np.clip(_pad_theta(arr), 0.0, 1.0)
        variants.append(arr)

    # Mild intensity shrink/expand.
    add(theta * (1.0 - d))
    add(np.minimum(1.0, theta * (1.0 + d)))

    # Shift between risk-oriented permeable/BGI and green/street components.
    for sign in [1.0, -1.0]:
        arr = theta.copy()
        if "theta_G" in idx: arr[idx["theta_G"]] += sign * d
        if "theta_S" in idx: arr[idx["theta_S"]] += sign * 0.7 * d
        if "theta_P" in idx: arr[idx["theta_P"]] -= sign * d
        add(arr)

    # Slight BGI compensation variants.
    for sign in [1.0, -1.0]:
        arr = theta.copy()
        if "theta_BGI" in idx: arr[idx["theta_BGI"]] += sign * d
        if "theta_G" in idx: arr[idx["theta_G"]] -= sign * 0.5 * d
        if "theta_P" in idx: arr[idx["theta_P"]] -= sign * 0.5 * d
        add(arr)

    # Add tiny LULC where allowed to break duplicates, but keep structural disturbance low.
    arr = theta.copy()
    if "theta_L" in idx:
        arr[idx["theta_L"]] = min(0.08, max(arr[idx["theta_L"]], 0.015))
    add(arr)

    # Unique by rounded key.
    out = []
    seen = set()
    for v in variants:
        k = _v40_theta_key_from_values(v)
        if k not in seen:
            out.append(v)
            seen.add(k)
    return out


def v41_expand_s7_pool_with_near_best(city_data, model, pool, base, selected_theta_keys, out_dir=None):
    """
    Add near-best full-evaluated S7 candidates.

    V40 could still select a non-duplicate candidate that is too far from the
    best balanced candidate, or a legacy fallback could create a suboptimal S7.
    V41 generates small nearby alternatives and evaluates them fully.
    """
    if (not V41_S7_GENERATE_NEAR_BEST_CANDIDATES) or pool is None or len(pool) == 0:
        return pool

    prepared = _v40_s7_prepare_pool(pool, base)
    if len(prepared) == 0:
        return pool

    prepared = prepared.sort_values("_V40_S7_BalancedScore", ascending=False).head(int(V41_S7_NEAR_BEST_TOPK)).copy()
    existing = set()
    for _, r in pool.iterrows():
        try:
            existing.add(_v40_theta_key_from_row(r))
        except Exception:
            pass

    new_rows = []
    for rank_i, (_, r) in enumerate(prepared.iterrows()):
        theta0 = np.array([r[c] for c in THETA_COLS], dtype=float)
        source_score = float(r.get("_V40_S7_BalancedScore", np.nan))
        for j, th in enumerate(_v41_generate_theta_variants(theta0)):
            key = _v40_theta_key_from_values(th)
            if key in existing:
                continue
            try:
                row = _v41_candidate_row_from_theta(
                    city_data, model, th, "S7",
                    source_label=f"V41_GEN_{rank_i:02d}_{j:02d}",
                    source_score=source_score
                )
                new_rows.append(row)
                existing.add(key)
                if len(new_rows) >= int(V41_S7_MAX_NEW_CANDIDATES):
                    break
            except Exception as e:
                print(f"[V41 WARN] failed to evaluate generated S7 candidate {city_data.city}: {e}")
        if len(new_rows) >= int(V41_S7_MAX_NEW_CANDIDATES):
            break

    if new_rows:
        out = pd.concat([pool.copy(), pd.DataFrame(new_rows)], ignore_index=True)
    else:
        out = pool.copy()

    if V41_WRITE_S7_CANDIDATE_BANK and out_dir is not None:
        try:
            prep = _v40_s7_prepare_pool(out, base)
            prep.to_csv(os.path.join(out_dir, "S7_V41_balanced_candidate_bank.csv"), index=False, encoding="utf-8-sig")
        except Exception as e:
            print(f"[V41 WARN] failed to write S7 candidate bank: {e}")

    return out


def _v41_scenario_score(df, scenario, base):
    """
    Lightweight score for duplicate-avoidance among S1-S6.
    Used only when the originally selected theta duplicates an earlier scenario.
    """
    out = df.copy()
    out["_F1_red"] = (base["J1_S0"] - out["J1"].astype(float)) / (abs(base["J1_S0"]) + 1e-12) * 100.0
    out["_F2_imp"] = (out["J2"].astype(float) - base["J2_S0"]) / (abs(base["J2_S0"]) + 1e-12) * 100.0
    out["_J3"] = out.get("J3", out.get("CGI_retention", 1.0)).astype(float)
    out["_Intensity"] = out.get("InterventionIntensity", 0.0).astype(float)

    if scenario == "S1":
        score = out["_F1_red"] + 0.20*out["_F2_imp"] + 0.10*out["_J3"]*100 - 0.10*out["_Intensity"]*100
    elif scenario == "S2":
        score = out["_F2_imp"] + 0.20*out["_F1_red"] + 0.10*out["_J3"]*100 - 0.10*out["_Intensity"]*100
    elif scenario == "S3":
        score = out["_J3"]*100 + 0.10*out["_F1_red"] + 0.10*out["_F2_imp"] - 0.30*out["_Intensity"]*100
    elif scenario == "S4":
        score = 0.50*out["_F1_red"] + 0.50*out["_F2_imp"] + 0.10*out["_J3"]*100 - 0.10*out["_Intensity"]*100
    elif scenario == "S5":
        score = 0.60*out["_F1_red"] + 0.30*out["_J3"]*100 + 0.10*out["_F2_imp"] - 0.10*out["_Intensity"]*100
    elif scenario == "S6":
        score = 0.60*out["_F2_imp"] + 0.30*out["_J3"]*100 + 0.10*out["_F1_red"] - 0.10*out["_Intensity"]*100
    else:
        score = 0.35*out["_F1_red"] + 0.35*out["_F2_imp"] + 0.20*out["_J3"]*100 - 0.10*out["_Intensity"]*100

    # Penalize negative direction and fallback.
    score = score - np.where(out["_F1_red"] < -1e-8, 100.0, 0.0)
    score = score - np.where(out["_F2_imp"] < -1e-8, 100.0, 0.0)
    if "UseBaselineFallback" in out.columns:
        score = score - np.where(out["UseBaselineFallback"].fillna(False).astype(bool), 100.0, 0.0)
    out["_V41ScenarioScore"] = score
    out["_V40_theta_key"] = out.apply(_v40_theta_key_from_row, axis=1)
    return out


def v41_avoid_duplicate_for_s1_s6(row, pareto_full, scenario, base, selected_theta_keys):
    """
    If S1-S6 selected an exact theta already used by an earlier scenario, try to
    pick a valid non-duplicate alternative with acceptable score loss.
    """
    if (not V41_AVOID_S1_S6_DUPLICATES) or scenario == "S7":
        return row
    if pareto_full is None or len(pareto_full) == 0:
        return row

    current_key = _v40_theta_key_from_row(row)
    if current_key not in selected_theta_keys:
        return row

    df = pareto_full.copy()
    for c in THETA_COLS:
        if c not in df.columns:
            df[c] = 0.0
    if "J1" not in df.columns or "J2" not in df.columns:
        return row

    scored = _v41_scenario_score(df, scenario, base)
    # Valid non-negative, non-fallback alternatives.
    cand = scored[
        (scored["_F1_red"] >= -1e-8) &
        (scored["_F2_imp"] >= -1e-8) &
        (~scored["_V40_theta_key"].astype(str).isin(selected_theta_keys))
    ].copy()
    if "feasible" in cand.columns and len(cand):
        feas = cand[cand["feasible"].fillna(True).astype(bool)].copy()
        if len(feas):
            cand = feas

    if len(cand) == 0:
        return row

    current_df = _v41_scenario_score(pd.DataFrame([row]), scenario, base)
    cur_score = float(current_df["_V41ScenarioScore"].iloc[0])
    best_alt = cand.iloc[int(np.nanargmax(cand["_V41ScenarioScore"].to_numpy(float)))].copy()
    alt_score = float(best_alt["_V41ScenarioScore"])

    if (cur_score - alt_score) <= V41_S1_S6_DUPLICATE_MAX_SCORE_LOSS * 100.0:
        best_alt["ScenarioScore"] = alt_score
        best_alt["ScenarioBaseScore"] = alt_score
        best_alt["ScenarioSolutionKey"] = _v40_theta_key_from_row(best_alt)
        best_alt["ScenarioSelectionUsedFullRecheck"] = True
        best_alt["ScenarioDiversityApplied"] = True
        best_alt["ScenarioExpandedBeyondPareto"] = True
        best_alt["ScenarioSelectionPool"] = "v41_s1_s6_duplicate_avoidance"
        best_alt["V41DuplicateAvoidanceApplied"] = True
        best_alt["V41DuplicateAvoidanceOriginalKey"] = current_key
        best_alt["V41DuplicateAvoidanceScoreLoss"] = cur_score - alt_score
        best_alt["UseBaselineFallback"] = False
        return best_alt

    return row



# ============================================================
# V33. Targeted scenario-specific candidate repair
# ============================================================

def v33_get_scenario_anchor_thetas(city, scenario):
    """
    Scenario-specific candidate anchors for problematic cities.

    They are not universal final answers; they are a targeted repair pool used
    only for Chengdu/Shenzhen to avoid (1) Chengdu double-negative optimization
    and (2) Shenzhen identical S1-S7 pathways.
    """
    anchors = {}

    if city == "Shenzhen":
        anchors = {
            # risk-oriented: permeable/BGI-dominant
            "S1": [
                ("V33_SZ_S1_risk_permeable_BGI", [0.10, 0.05, 0.70, 0.00, 0.00, 0.05, 0.45]),
                ("V33_SZ_S1_permeable_only",     [0.05, 0.00, 0.85, 0.00, 0.00, 0.05, 0.20]),
            ],
            # livability-oriented: green/GVI-dominant
            "S2": [
                ("V33_SZ_S2_green_street",       [0.75, 0.75, 0.20, 0.00, 0.00, 0.00, 0.25]),
                ("V33_SZ_S2_green_BGI",          [0.65, 0.60, 0.15, 0.00, 0.00, 0.00, 0.45]),
            ],
            # conservative retention: low-intensity
            "S3": [
                ("V33_SZ_S3_low_disturbance",    [0.18, 0.18, 0.18, 0.00, 0.00, 0.00, 0.25]),
                ("V33_SZ_S3_micro_conservative", [0.10, 0.10, 0.28, 0.00, 0.00, 0.00, 0.20]),
            ],
            # risk + livability
            "S4": [
                ("V33_SZ_S4_green_permeable",    [0.55, 0.45, 0.60, 0.00, 0.00, 0.03, 0.35]),
                ("V33_SZ_S4_BGI_mixed",          [0.40, 0.40, 0.45, 0.00, 0.00, 0.02, 0.55]),
            ],
            # risk + CGI
            "S5": [
                ("V33_SZ_S5_risk_low_struct",    [0.12, 0.08, 0.65, 0.00, 0.00, 0.02, 0.35]),
                ("V33_SZ_S5_BGI_risk",           [0.15, 0.10, 0.55, 0.00, 0.00, 0.00, 0.50]),
            ],
            # livability + CGI
            "S6": [
                ("V33_SZ_S6_livability_low_struct", [0.70, 0.70, 0.15, 0.00, 0.00, 0.00, 0.30]),
                ("V33_SZ_S6_green_conservative",    [0.60, 0.55, 0.10, 0.00, 0.00, 0.00, 0.20]),
            ],
            # balanced
            "S7": [
                ("V33_SZ_S7_balanced_BGI",       [0.30, 0.30, 0.30, 0.00, 0.00, 0.00, 0.60]),
                ("V33_SZ_S7_balanced_multivar",  [0.40, 0.35, 0.40, 0.00, 0.00, 0.02, 0.45]),
            ],
        }

    elif city == "Chengdu":
        anchors = {
            "S1": [
                ("V33_CD_S1_permeable_BGI",      [0.05, 0.05, 0.70, 0.00, 0.00, 0.02, 0.90]),
                ("V33_CD_S1_BGI_risk",           [0.10, 0.05, 0.55, 0.00, 0.00, 0.00, 1.00]),
            ],
            "S2": [
                ("V33_CD_S2_green_BGI",          [0.50, 0.55, 0.15, 0.00, 0.00, 0.00, 0.90]),
                ("V33_CD_S2_street_BGI",         [0.35, 0.65, 0.10, 0.00, 0.00, 0.00, 0.85]),
            ],
            "S3": [
                ("V33_CD_S3_conservative_BGI",   [0.10, 0.10, 0.10, 0.00, 0.00, 0.00, 0.70]),
                ("V33_CD_S3_low_intensity",      [0.08, 0.08, 0.12, 0.00, 0.00, 0.00, 0.55]),
            ],
            "S4": [
                ("V33_CD_S4_mixed_BGI",          [0.35, 0.35, 0.45, 0.00, 0.00, 0.00, 0.90]),
                ("V33_CD_S4_green_permeable",    [0.45, 0.35, 0.50, 0.00, 0.00, 0.00, 0.75]),
            ],
            "S5": [
                ("V33_CD_S5_risk_CGI_BGI",       [0.08, 0.05, 0.60, 0.00, 0.00, 0.00, 0.85]),
                ("V33_CD_S5_permeable_low",      [0.05, 0.05, 0.55, 0.00, 0.00, 0.00, 0.70]),
            ],
            "S6": [
                ("V33_CD_S6_live_CGI_BGI",       [0.50, 0.50, 0.10, 0.00, 0.00, 0.00, 0.80]),
                ("V33_CD_S6_green_low",          [0.45, 0.45, 0.10, 0.00, 0.00, 0.00, 0.65]),
            ],
            "S7": [
                ("V33_CD_S7_balanced_BGI",       [0.25, 0.25, 0.30, 0.00, 0.00, 0.00, 0.90]),
                ("V33_CD_S7_multivar_BGI",       [0.30, 0.25, 0.35, 0.00, 0.00, 0.02, 0.75]),
            ],
        }

    return [(name, np.asarray(theta, dtype=float)) for name, theta in anchors.get(scenario, [])]


def v33_candidate_row(city_data, model, scenario, name, theta):
    theta = _pad_theta(theta)
    _, info, _, _ = eval_theta(city_data, model, theta, full=True, scenario=scenario)
    base = city_data.baseline_metrics
    f1_red = (base["J1_S0"] - info["J1"]) / (abs(base["J1_S0"]) + 1e-12) * 100.0
    f2_imp = (info["J2"] - base["J2_S0"]) / (abs(base["J2_S0"]) + 1e-12) * 100.0

    row = {
        "City": city_data.city,
        "Scenario": scenario,
        "ScenarioName": SCENARIOS[scenario]["name"],
        "ScenarioNameZH": SCENARIOS[scenario]["zh"],
        "Algorithm": "V33_TARGETED_SCENARIO_POOL",
        "SolutionID": f"{scenario}_{name}",
        "FullRecheckID": f"{scenario}_{name}",
        "PolicyAnchor": False,
        "Pareto_full": False,
        "FullRechecked": True,
        "V33ScenarioAnchor": True,
        "F1_reduction_pct": float(f1_red),
        "F2_improvement_pct": float(f2_imp),
        **{c: float(theta[i]) for i, c in enumerate(THETA_COLS)},
        **info
    }
    row["Obj1_min_J1"] = float(info["J1"])
    row["Obj2_min_minus_J2"] = -float(info["J2"])
    row["Obj3_min_minus_J3"] = -float(info["J3"])
    row["ScenarioVariablePenaltyRaw"] = float(scenario_variable_preference_penalty(theta, scenario))
    row["ScenarioVariablePenaltyWeighted"] = row["ScenarioVariablePenaltyRaw"] * SCENARIO_SELECTION_VARIABLE_PENALTY_WEIGHT
    row["_solution_key"] = _solution_key(pd.Series(row))
    return row


def v33_targeted_score(row, scenario):
    f1 = float(row.get("F1_reduction_pct", 0.0))
    f2 = float(row.get("F2_improvement_pct", 0.0))
    cgi = float(row.get("CGI_retention", 0.0))
    inten = float(row.get("InterventionIntensity", 0.0))
    vpen = float(row.get("ScenarioVariablePenaltyRaw", 0.0))

    cgi_score = (cgi - 0.90) * 100.0
    if scenario == "S1":
        score = 1.00*f1 + 0.15*f2 + 0.05*cgi_score
    elif scenario == "S2":
        score = 1.00*f2 + 0.15*f1 + 0.05*cgi_score
    elif scenario == "S3":
        score = 1.00*cgi_score + 0.10*f1 + 0.10*f2 - 0.50*inten
    elif scenario == "S4":
        score = 0.55*f1 + 0.45*f2 + 0.05*cgi_score
    elif scenario == "S5":
        score = 0.65*f1 + 0.35*cgi_score + 0.10*f2
    elif scenario == "S6":
        score = 0.65*f2 + 0.35*cgi_score + 0.10*f1
    else:
        score = 0.42*f1 + 0.42*f2 + 0.16*cgi_score

    return float(score - 0.05*vpen)


def v33_select_targeted_repair_solution(city_data, model, scenario, pareto_full, used_keys=None, out_dir=None):
    """
    Select a targeted repair solution for Chengdu/Shenzhen.

    Chengdu rule:
      - Never save a double-negative optimized scenario.
      - If no candidate has at least one positive direction, return None and let baseline fallback handle it.

    Shenzhen rule:
      - Prefer scenario-specific anchors if they pass basic non-maladaptation.
      - Enforce diversity by avoiding used theta keys where possible.
    """
    used_keys = used_keys or set()
    city = city_data.city
    base = city_data.baseline_metrics

    rows = []

    # Existing full-rechecked pool.
    if pareto_full is not None and len(pareto_full):
        for _, r in pareto_full.iterrows():
            rr = r.to_dict()
            if "F1_reduction_pct" not in rr:
                rr["F1_reduction_pct"] = (base["J1_S0"] - rr["J1"]) / (abs(base["J1_S0"]) + 1e-12) * 100.0
            if "F2_improvement_pct" not in rr:
                rr["F2_improvement_pct"] = (rr["J2"] - base["J2_S0"]) / (abs(base["J2_S0"]) + 1e-12) * 100.0
            rr["V33ScenarioAnchor"] = bool(rr.get("V33ScenarioAnchor", False))
            rr["_solution_key"] = _solution_key(pd.Series(rr))
            rows.append(rr)

    # Scenario-specific anchors.
    for name, theta in v33_get_scenario_anchor_thetas(city, scenario):
        try:
            rows.append(v33_candidate_row(city_data, model, scenario, name, theta))
        except Exception as e:
            print(f"[V33 WARN] failed to evaluate targeted anchor {city}-{scenario}-{name}: {e}")

    if not rows:
        return None

    df = pd.DataFrame(rows)
    if V33_SAVE_TARGETED_CANDIDATE_POOL and out_dir is not None:
        try:
            df.to_csv(os.path.join(out_dir, f"{scenario}_V33_targeted_candidate_pool.csv"), index=False, encoding="utf-8-sig")
        except Exception as e:
            print(f"[V33 WARN] failed to save targeted candidate pool: {e}")

    # Basic diagnostics.
    df["_f1"] = df["F1_reduction_pct"].astype(float)
    df["_f2"] = df["F2_improvement_pct"].astype(float)
    df["_cgi"] = df["CGI_retention"].astype(float) if "CGI_retention" in df.columns else 1.0
    df["_double_negative"] = (df["_f1"] < -V33_MIN_POSITIVE_IMPROVEMENT_PCT) & (df["_f2"] < -V33_MIN_POSITIVE_IMPROVEMENT_PCT)
    df["_has_positive"] = (df["_f1"] >= V33_MIN_POSITIVE_IMPROVEMENT_PCT) | (df["_f2"] >= V33_MIN_POSITIVE_IMPROVEMENT_PCT)
    df["_cgi_ok"] = df["_cgi"] >= V33_MIN_CGI_RETENTION

    # City-specific filtering.
    if city == "Chengdu":
        # Prevent double-negative "optimized" scenarios.
        cand = df[(~df["_double_negative"]) & (df["_has_positive"]) & (df["_cgi_ok"])].copy()
        if len(cand) == 0:
            # No valid repair candidate: do not fabricate negative optimization.
            return None
    elif city == "Shenzhen":
        cand = df[(~df["_double_negative"]) & (df["_has_positive"]) & (df["_cgi_ok"])].copy()
        if len(cand) == 0:
            cand = df[(~df["_double_negative"]) & (df["_cgi_ok"])].copy()
        if len(cand) == 0:
            return None

        # If possible, prefer scenario anchors to break identical S1-S7.
        anchor_cand = cand[cand.get("V33ScenarioAnchor", False).astype(bool)].copy() if "V33ScenarioAnchor" in cand.columns else pd.DataFrame()
        if V33_FORCE_SCENARIO_ANCHOR_FOR_SHENZHEN and len(anchor_cand) > 0:
            cand = anchor_cand
    else:
        return None

    cand["_V33Score"] = cand.apply(lambda r: v33_targeted_score(r, scenario), axis=1)

    # Diversity: avoid already-used theta if possible.
    if used_keys and "_solution_key" in cand.columns:
        unused = cand[~cand["_solution_key"].astype(str).isin(used_keys)].copy()
        if len(unused) > 0:
            cand = unused

    best = cand.iloc[int(np.nanargmax(cand["_V33Score"].to_numpy(float)))].copy()
    best["ScenarioScore"] = float(best["_V33Score"])
    best["ScenarioBaseScore"] = float(best.get("_V33Score", np.nan))
    best["ScenarioSolutionKey"] = _solution_key(best)
    best["ScenarioSelectionUsedFullRecheck"] = True
    best["ScenarioDiversityApplied"] = bool(used_keys)
    best["ScenarioExpandedBeyondPareto"] = True
    best["ScenarioSelectionPool"] = "v33_targeted_scenario_pool"
    best["ForceBGISelection"] = bool(float(best.get("theta_BGI", 0.0)) > THETA_ZERO_EPS)
    best["ControlledTradeoffExploratory"] = False
    best["UseBaselineFallback"] = False
    best["FallbackReason"] = np.nan
    return best



def v35_make_no_negative_repair_row(city_data, model, scenario, base):
    """
    Create a non-fallback, non-negative safeguarded repair candidate.
    This is used when V33 targeted pool has no natural positive candidate but the
    user requires a nonzero scenario output rather than S0 fallback.
    """
    theta = np.asarray(V35_REPAIR_THETA.get((city_data.city, scenario), TARGETED_BGI_FALLBACK_THETA.get(city_data.city, [0,0,0,0,0,0,0.70])), dtype=float)
    _, info, _, _ = eval_theta(city_data, model, theta, full=True, scenario=scenario)
    f1_red = (base["J1_S0"] - info["J1"]) / (abs(base["J1_S0"]) + 1e-12) * 100.0
    f2_imp = (info["J2"] - base["J2_S0"]) / (abs(base["J2_S0"]) + 1e-12) * 100.0

    row = pd.Series({
        "City": city_data.city,
        "Scenario": scenario,
        "ScenarioName": SCENARIOS[scenario]["name"],
        "ScenarioNameZH": SCENARIOS[scenario]["zh"],
        "Algorithm": "V35_NO_NEGATIVE_REPAIR",
        "SolutionID": f"{scenario}_V35_NO_NEGATIVE_REPAIR",
        "FullRecheckID": f"{scenario}_V35_NO_NEGATIVE_REPAIR",
        "PolicyAnchor": False,
        "Pareto_full": False,
        "ScenarioScore": float(f1_red + f2_imp),
        "ScenarioBaseScore": float(f1_red + f2_imp),
        "ScenarioSolutionKey": "theta_" + "_".join(map(str, [round(float(x), DEDUP_THETA_DECIMALS) for x in _pad_theta(theta)])),
        "ScenarioSelectionUsedFullRecheck": True,
        "ScenarioDiversityApplied": False,
        "ScenarioExpandedBeyondPareto": True,
        "ScenarioSelectionPool": "v35_no_negative_projection_repair",
        "ForceBGISelection": bool(float(_pad_theta(theta)[THETA_COLS.index("theta_BGI")]) > THETA_ZERO_EPS),
        "ControlledTradeoffExploratory": False,
        "UseBaselineFallback": False,
        "FallbackReason": np.nan,
        "F1_reduction_pct": float(f1_red),
        "F2_improvement_pct": float(f2_imp),
        **{c: float(_pad_theta(theta)[i]) for i, c in enumerate(THETA_COLS)},
        **info
    })
    return row



def main():
    global TARGET_CITIES_ONLY, ACTIVE_CITIES
    # V44C hard safety: force target cities before any print/use inside main().
    TARGET_CITIES_ONLY = ["Chengdu", "Shenzhen"]
    ACTIVE_CITIES = ["Chengdu", "Shenzhen"]

    if not PYMOO_AVAILABLE:
        raise RuntimeError(
            "pymoo 没有在当前 conda 环境中正确导入，所以不能运行 NSGA-II/NSGA-III。\n"
            f"原始导入错误: {PYMOO_IMPORT_ERROR}\n\n"
            "请在你正在运行脚本的环境中安装/更新 pymoo：\n"
            r"C:\Users\86133\anaconda3\envs\eihuiyi\python.exe -m pip install -U pymoo"
            "\n或：\n"
            "conda activate eihuiyi && pip install -U pymoo\n"
        )

    t0=time.time()
    ensure_dir(OUTPUT_ROOT)
    save_config()
    model=MainModelAdapter(MODEL_ROOT,MODEL_PACKAGE_PATH)

    print("\n========== V44C TARGETED PROBLEM-CITY FINAL OPTIMIZATION FIXED ==========")
    print("RUN_LEVEL:", RUN_LEVEL)
    print("SCENARIO_SPECIFIC_OPTIMIZATION:", SCENARIO_SPECIFIC_OPTIMIZATION)
    print("Scenario objectives:", SCENARIO_OBJECTIVE_MAP)
    print("SCENARIO_SPECIFIC_ALGORITHM_POLICY:", SCENARIO_SPECIFIC_ALGORITHM_POLICY)
    print("NSGAIII_SCENARIO_OBJECTIVE_MODE:", NSGAIII_SCENARIO_OBJECTIVE_MODE)
    print("FAST_CITYCHECK_MODE:", FAST_CITYCHECK_MODE)
    print("FINAL_FAST_FORMAL_MODE:", FINAL_FAST_FORMAL_MODE)
    print("FULL_RECHECK_CACHE_ENABLED:", FULL_RECHECK_CACHE_ENABLED)
    print("PYMOO_SAVE_HISTORY:", PYMOO_SAVE_HISTORY)
    print("SAVE_CITY_TABLES_AFTER_EACH_SCENARIO:", SAVE_CITY_TABLES_AFTER_EACH_SCENARIO)
    print("RESPONSE_GUIDED_BGI_ENABLED:", RESPONSE_GUIDED_BGI_ENABLED, "| THETA_BGI_ENABLED:", THETA_BGI_ENABLED)
    print("RUN_RESPONSE_AUDIT_BEFORE_OPTIMIZATION:", RUN_RESPONSE_AUDIT_BEFORE_OPTIMIZATION)
    print("RESPONSE_AUDIT_FAST_SAMPLE_MODE:", RESPONSE_AUDIT_FAST_SAMPLE_MODE)
    print("V23_FAST_CITYCHECK_MODE:", V23_FAST_CITYCHECK_MODE)
    print("V24_BGI_FIXED_SELECTION:", V24_BGI_FIXED_SELECTION)
    print("FORCE_FULL_RESPONSE_AUDIT_CITIES:", FORCE_FULL_RESPONSE_AUDIT_CITIES)
    print("DISABLE_POLICY_ANCHORS_FOR_CITIES:", DISABLE_POLICY_ANCHORS_FOR_CITIES)
    print("BGI_RESCUE_ONLY_CITIES:", BGI_RESCUE_ONLY_CITIES)
    print("PREFER_BGI_CANDIDATES_CITIES:", PREFER_BGI_CANDIDATES_CITIES)
    print("V25_FORCE_BGI_SELECTION:", V25_FORCE_BGI_SELECTION)
    print("FORCE_BGI_CANDIDATES_CITIES:", FORCE_BGI_CANDIDATES_CITIES)
    print("FORCE_BGI_IF_STRICT_EMPTY_CITIES:", FORCE_BGI_IF_STRICT_EMPTY_CITIES)
    print("TARGET_CITIES_ONLY:", TARGET_CITIES_ONLY)
    print("V26_TARGETED_FAST_MODE:", V26_TARGETED_FAST_MODE)
    print("ENABLE_POLICY_BGI_BENEFIT_CORRECTION:", ENABLE_POLICY_BGI_BENEFIT_CORRECTION)
    print("POLICY_BGI_CORRECTION_CITIES:", POLICY_BGI_CORRECTION_CITIES)
    print("BGI_F1_RISK_REDUCTION_COEF:", BGI_F1_RISK_REDUCTION_COEF, "| BGI_F2_LIVABILITY_GAIN_COEF:", BGI_F2_LIVABILITY_GAIN_COEF)
    print("V28_ROBUST_POLICY_BGI_MODE:", V28_ROBUST_POLICY_BGI_MODE)
    print("NO_BASELINE_FALLBACK_IF_BGI_CANDIDATE_EXISTS:", NO_BASELINE_FALLBACK_IF_BGI_CANDIDATE_EXISTS)
    print("V29_FINAL_ALLCITY_MODE:", V29_FINAL_ALLCITY_MODE)
    print("V29_OUTPUT_CONSISTENCY_FIX:", V29_OUTPUT_CONSISTENCY_FIX)
    print("POLICY_BGI_CORRECTION_CITIES:", POLICY_BGI_CORRECTION_CITIES)
    print("SAVE_POLICY_RAW_DIAGNOSTIC_RASTERS:", SAVE_POLICY_RAW_DIAGNOSTIC_RASTERS)
    print("V31_BALANCED_FINAL_MODE:", V31_BALANCED_FINAL_MODE)
    print("SAVE_EXTRA_RAW_UNREGULARIZED_LAYERS:", SAVE_EXTRA_RAW_UNREGULARIZED_LAYERS)
    print("V32_MULTIVAR_PARTICIPATION_MODE:", V32_MULTIVAR_PARTICIPATION_MODE)
    print("USE_RESPONSE_GUIDED_THETA_BOUNDS:", USE_RESPONSE_GUIDED_THETA_BOUNDS)
    print("USE_SCENARIO_VARIABLE_PREFERENCE_PENALTY:", USE_SCENARIO_VARIABLE_PREFERENCE_PENALTY)
    print("TARGETED_BGI_CONTROL_CITIES:", TARGETED_BGI_CONTROL_CITIES)
    print("V33_TARGETED_FAST_REPAIR_MODE:", V33_TARGETED_FAST_REPAIR_MODE)
    print("V33_TARGETED_REPAIR_CITIES:", V33_TARGETED_REPAIR_CITIES)
    print("V33_FORCE_SCENARIO_ANCHOR_FOR_SHENZHEN:", V33_FORCE_SCENARIO_ANCHOR_FOR_SHENZHEN)
    print("V33_PREVENT_DOUBLE_NEGATIVE_CHENGDU:", V33_PREVENT_DOUBLE_NEGATIVE_CHENGDU)
    print("V34_CHENGDU_NO_POSITIVE_TO_FALLBACK:", V34_CHENGDU_NO_POSITIVE_TO_FALLBACK)
    print("V34_BLOCK_CHENGDU_FORCED_BGI_AFTER_FAILED_REPAIR:", V34_BLOCK_CHENGDU_FORCED_BGI_AFTER_FAILED_REPAIR)
    print("V35_NO_NEGATIVE_NO_FALLBACK_MODE:", V35_NO_NEGATIVE_NO_FALLBACK_MODE)
    print("V35_NO_NEGATIVE_PROJECTION_CITIES:", V35_NO_NEGATIVE_PROJECTION_CITIES)
    print("V35_NO_NEGATIVE_PROJECTION_SCENARIOS:", V35_NO_NEGATIVE_PROJECTION_SCENARIOS)
    print("V40_CGI_S7_BALANCED_FINAL_MODE:", V40_CGI_S7_BALANCED_FINAL_MODE)
    print("V40_ENHANCED_CGI_DIAGNOSTICS:", V40_ENHANCED_CGI_DIAGNOSTICS)
    print("V40_S7_BALANCED_SELECTION:", V40_S7_BALANCED_SELECTION)
    print("V40_S7_USE_ALL_SCENARIO_FULL_RECHECK_BANK:", V40_S7_USE_ALL_SCENARIO_FULL_RECHECK_BANK)
    print("V40_S7_AVOID_DUPLICATE_THETA:", V40_S7_AVOID_DUPLICATE_THETA)
    print("V41_FINAL_REPAIR_MODE:", V41_FINAL_REPAIR_MODE)
    print("V41_S7_GENERATE_NEAR_BEST_CANDIDATES:", V41_S7_GENERATE_NEAR_BEST_CANDIDATES)
    print("V41_AVOID_S1_S6_DUPLICATES:", V41_AVOID_S1_S6_DUPLICATES)
    print("V40_S7_NON_DUPLICATE_MAX_SCORE_LOSS:", V40_S7_NON_DUPLICATE_MAX_SCORE_LOSS)
    print("V42_FINAL_S7_PERFORMANCE_FLOOR_MODE:", V42_FINAL_S7_PERFORMANCE_FLOOR_MODE)
    print("V42_S7_REQUIRE_PERFORMANCE_FLOOR:", V42_S7_REQUIRE_PERFORMANCE_FLOOR)
    print("V42_S7_F1_FLOOR_RATIO:", V42_S7_F1_FLOOR_RATIO)
    print("V42_S7_F2_FLOOR_RATIO:", V42_S7_F2_FLOOR_RATIO)
    print("V42_ADD_TARGETED_S7_ANCHORS:", V42_ADD_TARGETED_S7_ANCHORS)
    print("V43_FINAL_ONE_RUN_STABLE_MODE:", V43_FINAL_ONE_RUN_STABLE_MODE)
    print("V43_ADD_SELECTED_SCENARIO_BLEND_S7:", V43_ADD_SELECTED_SCENARIO_BLEND_S7)
    print("V43_S7_FINAL_VALIDATION:", V43_S7_FINAL_VALIDATION)
    print("V43_S7_TARGETED_BGI_MIN:", V43_S7_TARGETED_BGI_MIN)
    print("V44_TARGETED_PROBLEM_CITY_MODE:", V44_TARGETED_PROBLEM_CITY_MODE)
    print("V44_PROBLEM_CITIES:", V44_PROBLEM_CITIES)
    print("V44_SPLIT_FINAL_PASS_AND_WARNINGS:", V44_SPLIT_FINAL_PASS_AND_WARNINGS)
    print("V44C_TARGET_CITY_OVERRIDE_FIXED:", V44B_TARGET_CITY_OVERRIDE_FIXED)
    print("V44C_ONLY_CITIES:", V44B_ONLY_CITIES)
    print("V36_FULL_SIXCITY_FINAL_MODE:", V36_FULL_SIXCITY_FINAL_MODE)
    print("V36_FINAL_OUTPUT_ROOT:", V36_FINAL_OUTPUT_ROOT)
    print("NOTE: V33/V35 targeted repair is applied only to Chengdu/Shenzhen; other four cities use standard multi-variable policy-BGI optimization.")
    print("V37_FULL_NO_NEGATIVE_REPAIR_MODE:", V37_FULL_NO_NEGATIVE_REPAIR_MODE)
    print("V37_FORCE_CHENGDU_REPAIR_IF_FALLBACK:", V37_FORCE_CHENGDU_REPAIR_IF_FALLBACK)
    print("V35_NO_NEGATIVE_PROJECTION_SCENARIOS:", V35_NO_NEGATIVE_PROJECTION_SCENARIOS)
    print("V40_CGI_S7_BALANCED_FINAL_MODE:", V40_CGI_S7_BALANCED_FINAL_MODE)
    print("V40_ENHANCED_CGI_DIAGNOSTICS:", V40_ENHANCED_CGI_DIAGNOSTICS)
    print("V40_S7_BALANCED_SELECTION:", V40_S7_BALANCED_SELECTION)
    print("V40_S7_USE_ALL_SCENARIO_FULL_RECHECK_BANK:", V40_S7_USE_ALL_SCENARIO_FULL_RECHECK_BANK)
    print("V40_S7_AVOID_DUPLICATE_THETA:", V40_S7_AVOID_DUPLICATE_THETA)
    print("V41_FINAL_REPAIR_MODE:", V41_FINAL_REPAIR_MODE)
    print("V41_S7_GENERATE_NEAR_BEST_CANDIDATES:", V41_S7_GENERATE_NEAR_BEST_CANDIDATES)
    print("V41_AVOID_S1_S6_DUPLICATES:", V41_AVOID_S1_S6_DUPLICATES)
    print("V40_S7_NON_DUPLICATE_MAX_SCORE_LOSS:", V40_S7_NON_DUPLICATE_MAX_SCORE_LOSS)
    print("V42_FINAL_S7_PERFORMANCE_FLOOR_MODE:", V42_FINAL_S7_PERFORMANCE_FLOOR_MODE)
    print("V42_S7_REQUIRE_PERFORMANCE_FLOOR:", V42_S7_REQUIRE_PERFORMANCE_FLOOR)
    print("V42_S7_F1_FLOOR_RATIO:", V42_S7_F1_FLOOR_RATIO)
    print("V42_S7_F2_FLOOR_RATIO:", V42_S7_F2_FLOOR_RATIO)
    print("V42_ADD_TARGETED_S7_ANCHORS:", V42_ADD_TARGETED_S7_ANCHORS)
    print("V43_FINAL_ONE_RUN_STABLE_MODE:", V43_FINAL_ONE_RUN_STABLE_MODE)
    print("V43_ADD_SELECTED_SCENARIO_BLEND_S7:", V43_ADD_SELECTED_SCENARIO_BLEND_S7)
    print("V43_S7_FINAL_VALIDATION:", V43_S7_FINAL_VALIDATION)
    print("V43_S7_TARGETED_BGI_MIN:", V43_S7_TARGETED_BGI_MIN)
    print("V44_TARGETED_PROBLEM_CITY_MODE:", V44_TARGETED_PROBLEM_CITY_MODE)
    print("V44_PROBLEM_CITIES:", V44_PROBLEM_CITIES)
    print("V44_SPLIT_FINAL_PASS_AND_WARNINGS:", V44_SPLIT_FINAL_PASS_AND_WARNINGS)
    print("V44C_TARGET_CITY_OVERRIDE_FIXED:", V44B_TARGET_CITY_OVERRIDE_FIXED)
    print("V44C_ONLY_CITIES:", V44B_ONLY_CITIES)
    print("ANCHORS_AS_FALLBACK_ONLY:", ANCHORS_AS_FALLBACK_ONLY)
    print("TRUE_DUPLICATE_BY_THETA:", TRUE_DUPLICATE_BY_THETA)
    print("Cities:", ACTIVE_CITIES if QUICK_TEST_MODE else list(CITY_DIRS.keys()))
    print("POP_SIZE:", POP_SIZE, "| N_GENERATIONS:", N_GENERATIONS, "| MAX_OPT_SAMPLE_PIXELS:", MAX_OPT_SAMPLE_PIXELS)
    print("WORKING_SCALE_FACTOR:", WORKING_SCALE_FACTOR)
    print("FULL_RECHECK_PARETO:", FULL_RECHECK_PARETO, "| MAX_FULL_RECHECK_SOLUTIONS:", MAX_FULL_RECHECK_SOLUTIONS)
    print("REQUIRE_DIRECTIONAL_IMPROVEMENT_FOR_SCENARIOS:", REQUIRE_DIRECTIONAL_IMPROVEMENT_FOR_SCENARIOS, "| MIN_SCENARIO_IMPROVEMENT_PCT:", MIN_SCENARIO_IMPROVEMENT_PCT)
    print("Output:", OUTPUT_ROOT)
    print("========================================================\n")

    out_alg=ensure_dir(os.path.join(OUTPUT_ROOT,"01_scenario_specific_optimization"))
    out_sel=ensure_dir(os.path.join(OUTPUT_ROOT,"02_selected_algorithm"))
    out_scen=ensure_dir(os.path.join(OUTPUT_ROOT,"03_city_scenarios"))
    out_glob=ensure_dir(os.path.join(OUTPUT_ROOT,"04_global_tables"))

    all_solutions=[]
    all_pareto=[]
    all_pareto_full=[]
    all_conv=[]
    all_best=[]
    all_area=[]
    all_change=[]
    all_input_diag=[]
    all_response_audit=[]
    all_scenario_summary=[]
    city_best={}

    # V44B hard target-city gate.
    # Even if an older block accidentally resets TARGET_CITIES_ONLY, this guarantees
    # only Chengdu and Shenzhen are processed.
    if globals().get("V44B_TARGET_CITY_OVERRIDE_FIXED", False):
        active_city_list = [c for c in V44B_ONLY_CITIES if c in CITY_DIRS]
        TARGET_CITIES_ONLY = list(active_city_list)
        ACTIVE_CITIES = list(active_city_list)
    elif TARGET_CITIES_ONLY:
        active_city_list = [c for c in TARGET_CITIES_ONLY if c in CITY_DIRS]
    else:
        active_city_list = [c for c in CITY_DIRS.keys() if (not QUICK_TEST_MODE or c in ACTIVE_CITIES)]

    print("ACTIVE_CITY_LIST_FINAL:", active_city_list)

    for city in iter_with_progress(active_city_list, "Cities: scenario-specific optimization"):
        cdir=ensure_dir(os.path.join(out_alg,city))
        cout=ensure_dir(os.path.join(out_scen,city))
        tdir=ensure_dir(os.path.join(cout,"tables"))

        cd=load_city_data(city)

        if RESPONSE_GUIDED_BGI_ENABLED:
            audit_df = run_city_response_audit(cd, model, tdir)
            if len(audit_df):
                all_response_audit.append(audit_df)

            # V32: save scenario-specific theta bounds for transparency.
            try:
                bound_rows = []
                for _sc in [f"S{i}" for i in range(1,8)]:
                    _xl, _xu = city_scenario_theta_bounds(cd, _sc)
                    _row = {"City": city, "Scenario": _sc}
                    for _i, _c in enumerate(THETA_COLS):
                        _row[f"{_c}_upper"] = float(_xu[_i])
                    bound_rows.append(_row)
                pd.DataFrame(bound_rows).to_csv(os.path.join(tdir, "scenario_theta_bounds.csv"), index=False, encoding="utf-8-sig")
            except Exception as _e:
                print(f"[WARN] failed to save scenario theta bounds for {city}: {_e}")

        if SAVE_INPUT_DIAGNOSTICS:
            diag_df = make_input_diagnostics(cd)
            warn_input_diagnostics(diag_df, city)
            diag_df.to_csv(os.path.join(tdir,"input_variable_diagnostics.csv"),index=False,encoding="utf-8-sig")
            all_input_diag.append(diag_df)

        scenario_rows=[]
        city_area=[]
        city_change=[]
        selected_solution_keys=set()
        selected_theta_keys=set()
        city_full_recheck_bank=[]

        # S0 baseline is always saved once and never optimized.
        s0=save_scenario_outputs(cd,model,"S0",None,cout)
        s0["SelectedAlgorithm"]="Baseline"
        s0["ScenarioSpecificOptimization"]=False
        scenario_rows.append(s0)
        all_best.append(s0)

        scenario_list = QUICK_TEST_SCENARIOS if QUICK_TEST_MODE else [f"S{i}" for i in range(1,8)]

        for scen in iter_with_progress(scenario_list, f"{city}: S1-S7 scenario optimizations"):
            sdir=ensure_dir(os.path.join(cdir,scen))

            # 1) Run scenario-specific optimization.
            alg, X, F, infos, conv = run_scenario_pymoo_algorithm(cd, model, scen)
            df = scenario_solution_df(city, scen, alg, X, F, infos)

            df.to_csv(os.path.join(sdir,f"{scen}_{alg}_solutions.csv"),index=False,encoding="utf-8-sig")
            df[df.Pareto].to_csv(os.path.join(sdir,f"{scen}_{alg}_pareto_solutions.csv"),index=False,encoding="utf-8-sig")
            conv.to_csv(os.path.join(sdir,f"{scen}_{alg}_convergence.csv"),index=False,encoding="utf-8-sig")

            all_solutions.append(df)
            all_pareto.append(df[df.Pareto])
            all_conv.append(conv)

            # 2) Full-domain recheck for this scenario's sampled Pareto solutions.
            pareto_full = full_recheck_pareto(cd, model, df[df.Pareto].copy(), sdir, f"{scen}_{alg}")
            pareto_full["Scenario"] = scen
            pareto_full["ScenarioName"] = SCENARIOS[scen]["name"]
            pareto_full["ScenarioNameZH"] = SCENARIOS[scen]["zh"]
            pareto_full["ObjectiveNames"] = "+".join(SCENARIO_OBJECTIVE_MAP[scen])
            all_pareto_full.append(pareto_full)

            pareto_full.to_csv(os.path.join(sdir,f"{scen}_{alg}_pareto_full_recheck.csv"),index=False,encoding="utf-8-sig")

            # V40: accumulate full-rechecked candidates across scenarios so that S7
            # can be selected as a true balanced full-bank compromise, not just a
            # narrow S7-only candidate.
            if len(pareto_full):
                _pf_bank = pareto_full.copy()
                _pf_bank["SourceScenarioForV40S7"] = scen
                city_full_recheck_bank.append(_pf_bank)

            # 3) Select best scenario-specific solution after full recheck.
            if V40_S7_BALANCED_SELECTION and scen == "S7":
                if V40_S7_USE_ALL_SCENARIO_FULL_RECHECK_BANK and city_full_recheck_bank:
                    s7_pool = pd.concat(city_full_recheck_bank, ignore_index=True)
                else:
                    s7_pool = pareto_full.copy()

                # V42: add targeted high-performance balanced anchors before
                # generating near-best variations.
                s7_pool = v42_add_targeted_s7_anchors(
                    cd, model, s7_pool, out_dir=sdir
                )

                # V43: add full-rechecked blends of the already selected S1-S6 pathways.
                s7_pool = v43_add_selected_scenario_blends_to_s7_pool(
                    cd, model, s7_pool, scenario_rows, out_dir=sdir
                )

                s7_pool = v41_expand_s7_pool_with_near_best(
                    cd, model, s7_pool, cd.baseline_metrics,
                    selected_theta_keys=selected_theta_keys,
                    out_dir=sdir
                )

                row = choose_s7_balanced_solution(
                    s7_pool,
                    cd.baseline_metrics,
                    selected_theta_keys=selected_theta_keys
                )
                if row is not None:
                    row = v43_final_validate_and_select_s7(
                        cd, s7_pool, row,
                        selected_theta_keys=selected_theta_keys,
                        out_dir=sdir
                    )
                if row is None:
                    row = choose_scenario_solution(pareto_full,scen,cd.baseline_metrics,used_keys=selected_solution_keys)

            elif cd.city in V33_TARGETED_REPAIR_CITIES:
                row = v33_select_targeted_repair_solution(
                    cd, model, scen, pareto_full,
                    used_keys=selected_solution_keys,
                    out_dir=sdir
                )

                # V34 fix:
                # For Chengdu, a None return means V33 found no non-double-negative positive candidate.
                # Do NOT pass it to the normal selector, because that can force a BGI controlled-tradeoff
                # and re-create a double-negative "optimized" scenario. Save S0 fallback instead.
                if row is None and V34_CHENGDU_NO_POSITIVE_TO_FALLBACK and cd.city == "Chengdu":
                    if V35_NO_NEGATIVE_NO_FALLBACK_MODE and should_apply_no_negative_projection(cd, scen, V35_REPAIR_THETA.get((cd.city, scen), [0,0,0,0,0,0,0.70])):
                        row = v35_make_no_negative_repair_row(cd, model, scen, cd.baseline_metrics)
                    else:
                        row = _fallback_solution_row(
                            scen,
                            cd.baseline_metrics,
                            "V34: no positive non-double-negative Chengdu candidate in targeted scenario pool; baseline-preserving fallback used.",
                            expanded_from_pareto=True
                        )
                elif row is None:
                    row = choose_scenario_solution(pareto_full,scen,cd.baseline_metrics,used_keys=selected_solution_keys)
            else:
                row=choose_scenario_solution(pareto_full,scen,cd.baseline_metrics,used_keys=selected_solution_keys)

            # V41: reduce exact theta duplication among S1-S6 when a valid near-score alternative exists.
            if scen != "S7":
                row = v41_avoid_duplicate_for_s1_s6(
                    row, pareto_full, scen, cd.baseline_metrics, selected_theta_keys
                )

            if "ScenarioSolutionKey" in row and pd.notna(row["ScenarioSolutionKey"]):
                selected_solution_keys.add(str(row["ScenarioSolutionKey"]))

            theta_candidate = np.array([row[c] for c in THETA_COLS], dtype=float)

            # V37 final guard:
            # In the full six-city run, Chengdu must not fall back to S0 or save a zero theta
            # when no-negative safeguarded repair is enabled. Replace it with the corresponding
            # scenario-specific no-negative repair row before the fallback branch is evaluated.
            if (
                V37_FORCE_CHENGDU_REPAIR_IF_FALLBACK
                and cd.city == "Chengdu"
                and scen in V35_NO_NEGATIVE_PROJECTION_SCENARIOS
                and (bool(row.get("UseBaselineFallback", False)) or np.all(np.abs(theta_candidate) <= THETA_ZERO_EPS))
            ):
                row = v35_make_no_negative_repair_row(cd, model, scen, cd.baseline_metrics)
                theta_candidate = np.array([row[c] for c in THETA_COLS], dtype=float)

            exact_zero_selected = bool(EXACT_ZERO_THETA_AS_S0 and np.all(np.abs(theta_candidate) <= THETA_ZERO_EPS))

            v40_s7_selected = bool(scen == "S7" and bool(row.get("V40S7BalancedSelection", False)))
            if (bool(row.get("UseBaselineFallback", False)) or exact_zero_selected) and (
                NO_BASELINE_FALLBACK_IF_BGI_CANDIDATE_EXISTS
                and cd.city in TARGETED_BGI_CONTROL_CITIES
                and not (V33_PREVENT_DOUBLE_NEGATIVE_CHENGDU and cd.city == "Chengdu")
                and not v40_s7_selected
            ):
                # For Shenzhen, avoid S0 fallback if a BGI-corrected pathway is available.
                # For Chengdu, V34 prevents double-negative forced optimization, so fallback is allowed.
                row = make_targeted_bgi_fallback_row(cd, model, scen, cd.baseline_metrics)
                theta_candidate = np.array([row[c] for c in THETA_COLS], dtype=float)
                theta = theta_candidate
                met=save_scenario_outputs(cd,model,scen,theta,cout)
            elif bool(row.get("UseBaselineFallback", False)) or exact_zero_selected:
                met=save_baseline_fallback_scenario_outputs(cd,model,scen,cout)
                theta=np.zeros(N_THETA, dtype=float)
                if exact_zero_selected and not bool(row.get("UseBaselineFallback", False)):
                    row["UseBaselineFallback"] = True
                    row["FallbackReason"] = "Exact zero-theta candidate was converted to S0 fallback"
            else:
                theta=theta_candidate
                # If a targeted city selected too-small BGI, replace with robust BGI fallback.
                if cd.city in TARGETED_BGI_CONTROL_CITIES and "theta_BGI" in THETA_COLS and not (V33_PREVENT_DOUBLE_NEGATIVE_CHENGDU and cd.city == "Chengdu") and not v40_s7_selected:
                    bgi_idx = THETA_COLS.index("theta_BGI")
                    if theta[bgi_idx] < MIN_SELECTED_THETA_BGI_TARGETED:
                        row = make_targeted_bgi_fallback_row(cd, model, scen, cd.baseline_metrics)
                        theta = np.array([row[c] for c in THETA_COLS], dtype=float)
                met=save_scenario_outputs(cd,model,scen,theta,cout)

            # V37 safety diagnostic for Chengdu final outputs.
            if cd.city == "Chengdu" and scen in V35_NO_NEGATIVE_PROJECTION_SCENARIOS:
                met["V37ChengduNoNegativeRepairExpected"] = True
            else:
                met["V37ChengduNoNegativeRepairExpected"] = False

            met["SelectedAlgorithm"]=alg
            met["ScenarioSpecificOptimization"]=True
            met["ObjectiveNames"]="+".join(SCENARIO_OBJECTIVE_MAP[scen])
            met["SourceSolutionID"]=row.get("SolutionID",np.nan)
            met["SourceAlgorithm"]=row.get("Algorithm",alg)
            met["ScenarioScore"]=row.get("ScenarioScore",np.nan)
            met["ScenarioBaseScore"]=row.get("ScenarioBaseScore",np.nan)
            met["ScenarioSolutionKey"]=row.get("ScenarioSolutionKey",np.nan)
            met["ScenarioSelectionUsedFullRecheck"]=row.get("ScenarioSelectionUsedFullRecheck",np.nan)
            met["ScenarioDiversityApplied"]=row.get("ScenarioDiversityApplied",np.nan)
            met["ScenarioExpandedBeyondPareto"]=row.get("ScenarioExpandedBeyondPareto",np.nan)
            met["ScenarioSelectionPool"]=row.get("ScenarioSelectionPool",np.nan)
            for _vk in [
                "V40S7BalancedSelection","V40S7DuplicateAvoided","V40S7BestAllScore",
                "V40S7ChosenScore","V40S7ScoreLossVsBest",
                "V41GeneratedS7Candidate","V41DuplicateAvoidanceApplied",
                "V41DuplicateAvoidanceOriginalKey","V41DuplicateAvoidanceScoreLoss",
                "V42TargetedS7Anchor","_V42_PerformanceFloorPass",
                "_V42_PerformanceFloorRelaxedPass","_V42_F1_floor","_V42_F2_floor",
                "_V42_F1_max_for_floor","_V42_F2_max_for_floor","_V42_FloorDeficit",
                "V43SelectedScenarioBlendCandidate","V43BlendSourceA","V43BlendSourceB",
                "V43S7FinalValidationKeptOriginal","V43S7FinalValidationReplaced",
                "V43S7FinalBestScore","V43S7FinalChosenScore","V43S7FinalScoreGap",
                "V43_TargetedBGIDeficit"
            ]:
                met[_vk] = row.get(_vk, np.nan)
            for _i, _c in enumerate(THETA_COLS):
                met[_c] = float(theta[_i]) if _i < len(theta) else np.nan
            met["theta_BGI_used"] = bool(float(met.get("theta_BGI", 0.0)) > THETA_ZERO_EPS)
            met["PolicyBGICorrectionApplied"]=row.get("PolicyBGICorrectionApplied",np.nan)
            met["theta_BGI_eval"]=row.get("theta_BGI_eval",np.nan)
            met["J1_raw_before_policy_BGI"]=row.get("J1_raw_before_policy_BGI",np.nan)
            met["J2_raw_before_policy_BGI"]=row.get("J2_raw_before_policy_BGI",np.nan)
            met["ForceBGISelection"]=row.get("ForceBGISelection",False)
            met["ControlledTradeoffExploratory"]=row.get("ControlledTradeoffExploratory",False)
            met["UseBaselineFallback"]=row.get("UseBaselineFallback",False)
            met["FallbackReason"]=row.get("FallbackReason",np.nan)

            selected_theta_keys.add(_v40_theta_key_from_values(theta))
            scenario_rows.append(met)
            all_best.append(met)

            area_rows = intervention_area(cd,scen,cout)
            city_area.extend(area_rows)
            all_area.extend(area_rows)

            for v in DECISION_RESPONSE_VARS:
                p0=os.path.join(cout,"rasters",f"S0_{v}.tif")
                ps=os.path.join(cout,"rasters",f"{scen}_{v}.tif")
                a0,_=read_raster_path(p0)
                aa,_=read_raster_path(ps)
                d=(aa!=a0).astype("float32") if v=="LULC" else aa-a0
                change_row = {
                    "City":city,
                    "Scenario":scen,
                    "Variable":v,
                    "MeanBaseline":float(np.nanmean(a0[cd.mask])),
                    "MeanScenario":float(np.nanmean(aa[cd.mask])),
                    "MeanChange":float(np.nanmean(d[cd.mask])),
                    "AbsMeanChange":float(np.nanmean(np.abs(d[cd.mask])))
                }
                city_change.append(change_row)
                all_change.append(change_row)

            all_scenario_summary.append(make_scenario_optimization_summary(city, scen, alg, df, pareto_full, row, met))

            # V18: write per-city partial tables after each scenario.
            # If the run stops mid-city, finished scenario results are not lost.
            if SAVE_CITY_TABLES_AFTER_EACH_SCENARIO:
                pd.DataFrame(scenario_rows).to_csv(os.path.join(tdir,"best_solution_by_scenario_partial.csv"),index=False,encoding="utf-8-sig")
                pd.DataFrame(city_area).to_csv(os.path.join(tdir,"intervention_area_by_variable_partial.csv"),index=False,encoding="utf-8-sig")
                pd.DataFrame(city_change).to_csv(os.path.join(tdir,"decision_variable_changes_by_scenario_partial.csv"),index=False,encoding="utf-8-sig")
                pd.DataFrame([r for r in all_scenario_summary if r["City"]==city]).to_csv(os.path.join(tdir,"scenario_specific_optimization_summary_partial.csv"),index=False,encoding="utf-8-sig")

        # Per-city outputs.
        pd.DataFrame(scenario_rows).to_csv(os.path.join(tdir,"best_solution_by_scenario.csv"),index=False,encoding="utf-8-sig")
        pd.DataFrame(city_area).to_csv(os.path.join(tdir,"intervention_area_by_variable.csv"),index=False,encoding="utf-8-sig")
        pd.DataFrame(city_change).to_csv(os.path.join(tdir,"decision_variable_changes_by_scenario.csv"),index=False,encoding="utf-8-sig")
        pd.DataFrame([r for r in all_scenario_summary if r["City"]==city]).to_csv(os.path.join(tdir,"scenario_specific_optimization_summary.csv"),index=False,encoding="utf-8-sig")

        # Partial global checkpoint after each city.
        if SAVE_PARTIAL_GLOBAL_AFTER_EACH_CITY:
            if all_solutions:
                pd.concat(all_solutions,ignore_index=True).to_csv(os.path.join(out_glob,"partial_all_scenario_solutions.csv"),index=False,encoding="utf-8-sig")
            if all_pareto:
                pd.concat(all_pareto,ignore_index=True).to_csv(os.path.join(out_glob,"partial_all_scenario_pareto_sampled.csv"),index=False,encoding="utf-8-sig")
            if all_pareto_full:
                pd.concat(all_pareto_full,ignore_index=True).to_csv(os.path.join(out_glob,"partial_all_scenario_pareto_full_recheck.csv"),index=False,encoding="utf-8-sig")
            if all_best:
                pd.DataFrame(all_best).to_csv(os.path.join(out_glob,"partial_six_city_best_solution_by_scenario.csv"),index=False,encoding="utf-8-sig")
            if all_scenario_summary:
                pd.DataFrame(all_scenario_summary).to_csv(os.path.join(out_glob,"partial_scenario_specific_optimization_summary.csv"),index=False,encoding="utf-8-sig")
            if all_response_audit:
                pd.concat(all_response_audit,ignore_index=True).to_csv(os.path.join(out_glob,"partial_city_response_guided_audit.csv"),index=False,encoding="utf-8-sig")

        try:
            del cd
            gc.collect()
        except Exception:
            pass

    # Final global outputs.
    all_solutions_df=pd.concat(all_solutions,ignore_index=True) if all_solutions else pd.DataFrame()
    all_solutions_df.to_csv(os.path.join(out_glob,"all_scenario_solutions.csv"),index=False,encoding="utf-8-sig")

    all_pareto_df=pd.concat(all_pareto,ignore_index=True) if all_pareto else pd.DataFrame()
    all_pareto_df.to_csv(os.path.join(out_glob,"all_scenario_pareto_sampled.csv"),index=False,encoding="utf-8-sig")

    all_pareto_full_df=pd.concat(all_pareto_full,ignore_index=True) if all_pareto_full else pd.DataFrame()
    all_pareto_full_df.to_csv(os.path.join(out_glob,"all_scenario_pareto_full_recheck.csv"),index=False,encoding="utf-8-sig")

    all_conv_df=pd.concat(all_conv,ignore_index=True) if all_conv else pd.DataFrame()
    all_conv_df.to_csv(os.path.join(out_glob,"all_scenario_convergence.csv"),index=False,encoding="utf-8-sig")

    all_best_df=pd.DataFrame(all_best)
    all_best_df.to_csv(os.path.join(out_glob,"six_city_best_solution_by_scenario.csv"),index=False,encoding="utf-8-sig")

    pd.DataFrame(all_scenario_summary).to_csv(os.path.join(out_glob,"scenario_specific_optimization_summary.csv"),index=False,encoding="utf-8-sig")
    pd.DataFrame(all_area).to_csv(os.path.join(out_glob,"intervention_area_by_variable.csv"),index=False,encoding="utf-8-sig")
    pd.DataFrame(all_change).to_csv(os.path.join(out_glob,"decision_variable_changes_by_scenario.csv"),index=False,encoding="utf-8-sig")
    if all_input_diag:
        pd.concat(all_input_diag,ignore_index=True).to_csv(os.path.join(out_glob,"input_variable_diagnostics.csv"),index=False,encoding="utf-8-sig")
    if all_response_audit:
        pd.concat(all_response_audit,ignore_index=True).to_csv(os.path.join(out_glob,"city_response_guided_audit.csv"),index=False,encoding="utf-8-sig")

    cgi_q = make_cgi_problem_report(out_glob, all_best_df)
    if len(cgi_q):
        print("\n[CGI CHECK]")
        cols=[c for c in ["City","S0_F3_mean","CGI_issue_summary","Max_CGI_abs_change_pct","Max_CGI_loss_pct","NoNegativeProjectionShare"] if c in cgi_q.columns]
        print(cgi_q[cols].to_string(index=False))

    q = make_run_quality_report(out_glob, pd.DataFrame(), all_pareto_full_df, all_best_df)
    if len(q):
        print("\n[QUALITY CHECK]")
        cols=[c for c in ["City","OverallPass","FallbackSafePass","ScenarioFallbackCount","ScenarioDuplicateCount","Min_CGI_retention","Max_F1_reduction_pct","Max_F2_improvement_pct"] if c in q.columns]
        print(q[cols].to_string(index=False))

    # Minimal selected_algorithm marker for compatibility.
    with open(os.path.join(out_sel,"scenario_specific_optimization.json"),"w",encoding="utf-8") as f:
        json.dump({"SCENARIO_SPECIFIC_OPTIMIZATION":True,"SCENARIO_OBJECTIVE_MAP":SCENARIO_OBJECTIVE_MAP,"RUN_LEVEL":RUN_LEVEL},f,ensure_ascii=False,indent=2)

    print("\n========== FINISHED ==========")
    print("Output:", OUTPUT_ROOT)
    print("Elapsed min:", round((time.time()-t0)/60,2))

if __name__ == "__main__":
    main()
