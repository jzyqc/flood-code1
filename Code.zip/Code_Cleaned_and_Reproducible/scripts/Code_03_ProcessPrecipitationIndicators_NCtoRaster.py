import xarray as xr
import os
import rioxarray  # 必须有这个库

# ================= 配置区域 =================
# 1. 你刚刚算好的结果文件 (请确认文件名是否正确)
# 假设是上一步生成的 BioClim 指标文件
input_nc_file = r"C:\Users\86133\Desktop\ChinaMet_2022_BioClim.nc"

# 2. 想要保存 Tif 的文件夹 (E盘)
output_folder = r"E:\中国特大城市洪水\pythonProject1\2022_Raster_Result"


# ===========================================

def convert_nc_to_tif():
    print(f"1. 读取结果文件: {input_nc_file}")

    if not os.path.exists(input_nc_file):
        print("❌ 找不到文件！请检查桌面上的文件名是叫 'ChinaMet_2022_BioClim.nc' 吗？")
        return

    # 创建输出目录
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)
        print(f"   已新建目录: {output_folder}")

    try:
        # 打开数据集
        ds = xr.open_dataset(input_nc_file)
        print(f"   成功加载！包含变量: {list(ds.data_vars)}")

        # 准备导出
        print("\n2. 开始转换 (NC -> Tif)...")

        for var_name in ds.data_vars:
            print(f"   正在处理: {var_name} ...")

            # 提取单个变量
            da = ds[var_name]

            # ⚠️ 关键步骤：赋予坐标系 (WGS84)
            # 这一步是为了让 GIS 软件能识别经纬度
            da = da.rio.write_crs("EPSG:4326")

            # 确保维度名称正确 (rioxarray 需要 x, y)
            # 如果你的 nc 里是 lon, lat，这里指明一下
            da.rio.set_spatial_dims(x_dim="lon", y_dim="lat", inplace=True)

            # 保存路径
            save_path = os.path.join(output_folder, f"{var_name}.tif")

            # 写入 Tif (使用 LZW 压缩)
            da.rio.to_raster(save_path, compress='LZW')

        print(f"\n🎉 全部转换完成！")
        print(f"📂 结果都在这里: {output_folder}")

    except ImportError:
        print("\n❌ 缺少库！请先安装 rioxarray: pip install rioxarray")
    except Exception as e:
        print(f"\n❌ 发生错误: {e}")


if __name__ == "__main__":
    convert_nc_to_tif()