
# -*- coding: utf-8 -*-
"""
RF-stabilized Hydro-ConTex GNNWRL - v11 robustness-diagnostics final version

Purpose
-------
This script returns to the GNNWRL main line without adding physics-informed or
causal constraints. It uses Random Forest only as a stable nonlinear anchor,
not as a replacement of GNNWRL. This robustness-diagnostics version keeps the v10 architecture and additionally adds source-city-only LOCO sigmoid calibration, fair source-threshold reporting for all models, paired fold/city diagnostics, bootstrap confidence intervals, and manuscript-ready robustness summaries.

Main model:
    RF-stabilized Hydro-ConTex GNNWRL

Core design:
    1) Hydro-ConTex context grouping for mechanism-oriented representation
    2) Spatial graph propagation using within-city spatial KNN edges
    3) GNN message passing
    4) WRL local context-weighted regression head
    5) RF anchor probability + validation-optimized safe blending
       p_final = alpha * p_gnnwrl + (1 - alpha) * p_rf
       alpha is selected on internal validation; alpha=0 is allowed,
       so the model is protected from being obviously worse than RF on validation.

Outputs:
    - model comparison metrics
    - holdout / ordinary CV / spatial CV / leave-one-city-out validation
    - full ablation results
    - plot_data files for supplementary figures
    - final trained model package

Author note:
    PopD, GDP, RD, and NTL are NOT included here. They are reserved for EI and
    F1 = P_flood × EI to avoid exposure double counting.
"""

import os
import glob
import json
import math
import time
import warnings
import random
from pathlib import Path
from typing import Dict, List, Tuple, Optional

warnings.filterwarnings("ignore")

import numpy as np
import pandas as pd

import geopandas as gpd
import rasterio

import joblib

from sklearn.model_selection import train_test_split, StratifiedKFold, GroupKFold
from sklearn.preprocessing import StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.metrics import (
    roc_auc_score, average_precision_score, accuracy_score, precision_score,
    recall_score, f1_score, cohen_kappa_score, matthews_corrcoef,
    brier_score_loss, confusion_matrix, roc_curve, precision_recall_curve
)
from sklearn.calibration import calibration_curve
from sklearn.isotonic import IsotonicRegression

from sklearn.dummy import DummyClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.naive_bayes import GaussianNB
from sklearn.neighbors import KNeighborsClassifier, NearestNeighbors
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import (
    RandomForestClassifier, ExtraTreesClassifier, GradientBoostingClassifier,
    HistGradientBoostingClassifier, AdaBoostClassifier, BaggingClassifier
)
from sklearn.svm import SVC
from sklearn.neural_network import MLPClassifier

try:
    import torch
    import torch.nn as nn
    import torch.nn.functional as F
except Exception as e:
    raise ImportError(
        "This script requires PyTorch. Please install torch in your environment first. "
        f"Original error: {e}"
    )


# =========================================================
# 0. Global configuration
# =========================================================

RANDOM_STATE = 42
np.random.seed(RANDOM_STATE)
random.seed(RANDOM_STATE)
torch.manual_seed(RANDOM_STATE)

DEVICE = "cuda" if torch.cuda.is_available() else "cpu"

# Paths
CITY_DIRS = {
    "Beijing": r"E:\中国特大城市洪水\北京市数据",
    "Chengdu": r"E:\中国特大城市洪水\成都市数据",
    "Guangzhou": r"E:\中国特大城市洪水\广州市数据",
    "Shanghai": r"E:\中国特大城市洪水\上海市数据",
    "Shenzhen": r"E:\中国特大城市洪水\深圳市数据",
    "Tianjin": r"E:\中国特大城市洪水\天津市数据",
}

POINT_DIR = r"E:\中国特大城市洪水\最终点数据"

POINT_FILES = {
    "Beijing": os.path.join(POINT_DIR, "Beijing_样本数据.shp"),
    "Chengdu": os.path.join(POINT_DIR, "chengdu_样本数据.shp"),
    "Guangzhou": os.path.join(POINT_DIR, "guangzhou_样本数据.shp"),
    "Shanghai": os.path.join(POINT_DIR, "Shanghai_样本数据.shp"),
    "Shenzhen": os.path.join(POINT_DIR, "Shenzhen_样本数据.shp"),
    "Tianjin": os.path.join(POINT_DIR, "Tianjin_样本数据.shp"),
}

OUT_DIR = r"E:\中国特大城市洪水\RF_Stabilized_HydroConTex_GNNWRL_v11_robust_diagnostics"
PLOT_DIR = os.path.join(OUT_DIR, "plot_data")
MODEL_DIR = os.path.join(OUT_DIR, "models")
for d in [OUT_DIR, PLOT_DIR, MODEL_DIR]:
    os.makedirs(d, exist_ok=True)

LABEL_COL = "label"

# 24 Hydro-ConTex model variables
MODEL_VARS = [
    "Rx1day", "Rx5day", "CWD",
    "EV", "SL", "PRC", "TWI", "TPI",
    "ST", "NDVI", "LULC",
    "BD", "PD", "BH", "BVI",
    "CFI", "FOE", "GVI",
    "Micro_ISA", "Micro_PSA",
    "SCE", "SEL", "SVF", "TAE"
]

# Context groups
CONTEXT_GROUPS = {
    "Climate": ["Rx1day", "Rx5day", "CWD"],
    "Terrain": ["EV", "SL", "PRC", "TWI", "TPI", "ST"],
    "LandCover": ["NDVI", "LULC"],
    "Built": ["BD", "PD", "BH", "BVI", "Micro_ISA", "Micro_PSA"],
    "Streetscape": ["CFI", "FOE", "GVI", "SCE", "SEL", "SVF", "TAE"],
}

CONTEXT_ORDER = ["Climate", "Terrain", "LandCover", "Built", "Streetscape"]

# Decision variables are NOT constrained in this predictor.
# They are used later for SDG-oriented optimization and F1/F2/F3 construction.
DECISION_POSITIVE_PROTECTIVE = ["NDVI", "GVI", "Micro_PSA"]
DECISION_POSITIVE_RISK = ["Micro_ISA"]

# Some missing values may mean "absence" instead of true missing.
# This is particularly important for building / micro surface variables.
ZERO_FILL_VARS = ["BD", "PD", "BH", "BVI", "Micro_ISA", "Micro_PSA"]

# Missing indicators are added for high-missing built-environment variables.
# This lets the model distinguish true zero/absence from data-coverage missingness.
MISSING_INDICATOR_BASE_VARS = ["BD", "PD", "BH", "BVI", "Micro_ISA", "Micro_PSA"]
MISSING_INDICATOR_VARS = [f"{v}_missing" for v in MISSING_INDICATOR_BASE_VARS]
FEATURE_VARS = MODEL_VARS + MISSING_INDICATOR_VARS

# Include missingness indicators in the built-environment context for GNNWRL.
CONTEXT_GROUPS["Built"] = CONTEXT_GROUPS["Built"] + MISSING_INDICATOR_VARS

RASTER_STEMS = {
    "Rx1day": ["Rx1day", "Rx1 day"],
    "Rx5day": ["Rx5day", "Rx5 day"],
    "CWD": ["CWD"],
    "EV": ["EV"],
    "SL": ["SL"],
    "PRC": ["PRC"],
    "TWI": ["TWI"],
    "TPI": ["TPI"],
    "ST": ["ST"],
    "NDVI": ["NDVI"],
    "LULC": ["LULC", "LU"],
    "BD": ["BD"],
    "PD": ["PD"],
    "BH": ["BH"],
    "BVI": ["BVI"],
    "CFI": ["CFI"],
    "FOE": ["FOE"],
    "GVI": ["GVI"],
    "Micro_ISA": ["Micro_ISA"],
    "Micro_PSA": ["Micro_PSA"],
    "SCE": ["SCE"],
    "SEL": ["SEL", "SEI"],
    "SVF": ["SVF"],
    "TAE": ["TAE"],
}

# Sample filtering
MIN_VALID_FEATURE_RATIO = 0.70

# Experiments
TEST_SIZE = 0.30
RUN_ORDINARY_CV = True
RUN_SPATIAL_CV = True
RUN_LOCO = True
N_SPLITS_CV = 5
N_SPLITS_SPATIAL_CV = 5
SPATIAL_GRID_N = 5

# Graph settings
# Final main model uses only the spatial graph, because previous ablation showed that
# the Hydro-ConTex feature-similarity graph did not provide stable performance gains.
# We keep a diagnostic context-graph variant only for supplementary ablation.
K_SPATIAL = 8
K_CONTEXT = 0
K_CONTEXT_DIAGNOSTIC = 8
GRAPH_ETA_SPATIAL = 1.00
GRAPH_ETA_SPATIAL_DIAGNOSTIC = 0.55
DIST_KERNEL_QUANTILE = 0.50  # median distance as kernel scale

# Neural training
MAX_EPOCHS = 450
PATIENCE = 45
LR = 1e-3
WEIGHT_DECAY = 1e-4
HIDDEN_DIM = 48
DROPOUT = 0.20

# Loss weights
GRAPH_SMOOTH_WEIGHT = 0.005
ADAPT_REG_WEIGHT = 0.0  # disabled: no physical/causal/adaptation-response constraint is used in the predictor
RF_DISTILL_WEIGHT = 0.02  # small teacher constraint only
# Conservative RF-stabilized blending grid.
# Earlier repaired variants selected high alpha_gnn (~0.60), which improved Holdout/Spatial CV
# but weakened leave-one-city-out transferability. The final manuscript version keeps RF
# as the dominant stabilizing anchor and treats GNNWRL as a spatial-context correction.
ALPHA_GNN_MAX_FINAL = 0.40
RF_BLEND_GRID = np.round(np.arange(0.0, ALPHA_GNN_MAX_FINAL + 0.001, 0.05), 2)  # alpha for p = alpha*p_gnn + (1-alpha)*p_rf
ALPHA_COMPLEXITY_PENALTY = 0.020  # mild penalty for larger GNN contribution, preserving cross-city robustness

# Optional safe probability calibration for the final RF-GNN blended output.
# Calibration is learned only from the internal validation split of each training fold.
# It is used only when it improves a validation criterion dominated by Brier/ECE
# without causing a meaningful AUC drop. This keeps P_flood suitable for F1 = P_flood × EI.
USE_SAFE_BLEND_CALIBRATION = True
CALIBRATION_AUC_TOLERANCE = 0.003
# Manuscript-safe default: sigmoid calibration is allowed; isotonic is disabled by default
# because earlier runs showed overly hard probabilities in some variants.
ALLOW_ISOTONIC_CALIBRATION = False
# Threshold for recall-constrained operating point used in supplementary threshold tables.
RECALL_CONSTRAINT_MIN = 0.75

# LOCO repair: threshold-dependent metrics in leave-one-city-out validation are
# sensitive to cross-city probability-scale shifts. To avoid target-city leakage,
# v10 additionally selects operating thresholds from source-city internal validation
# predictions only, and then applies those thresholds to the held-out city.
RUN_LOCO_SOURCE_THRESHOLD_REPAIR = True
SOURCE_THRESHOLD_VAL_SIZE = 0.25
SOURCE_THRESHOLD_RANDOM_OFFSET = 1307

# v11 robustness diagnostics. These do not change the main model architecture.
# They only make LOCO threshold/calibration reporting fairer and manuscript-ready.
RUN_LOCO_SOURCE_CALIBRATION_REPAIR = True
LOCO_SOURCE_CALIBRATION_METHODS = ["none", "sigmoid"]
RUN_POSTHOC_BOOTSTRAP_CI = True
BOOTSTRAP_N = 1000
BOOTSTRAP_RANDOM_STATE = 20260525
RUN_POSTHOC_PAIRED_DIAGNOSTICS = True


# Traditional model pool
RUN_MORE_TRADITIONAL_MODELS = True

# Accuracy/ablation optimization settings
# v4/v5 strategy:
#   v4 = fixed RandomForest anchor. This is the cleanest manuscript version and
#        keeps the model strictly consistent with the name "RF-stabilized".
#   v5 = RF-family average anchor, i.e., mean probability of RandomForest and
#        ExtraTrees. This is used as a robustness / sensitivity version because
#        it often improves stability without drifting to CatBoost/XGBoost.
# We intentionally do NOT automatically choose CatBoost/XGBoost as anchor in
# the final line, because previous results showed that CatBoost anchor improved
# Holdout but weakened cross-city robustness.
ANCHOR_MODE_V4_RF_ONLY = "RF_ONLY"
ANCHOR_MODE_V5_RF_FAMILY = "RF_FAMILY_AVERAGE"
ALPHA_SCORE_WEIGHTS = {"AUC": 0.30, "PR_AUC": 0.25, "F1": 0.15, "Recall": 0.15, "Brier": -0.15}

# Main model keeps a fixed spatial K for comparability across model comparison and ablation.
# If you want K sensitivity, rerun with K_SPATIAL = 4, 6, 8, 10, 12 as supplementary robustness.

# Ablation settings for sub-journal style evidence chain
RUN_ABLATION_HOLDOUT = True
RUN_ABLATION_SPATIAL_CV = True
RUN_ABLATION_LOCO = False  # optional; expensive. Turn on if you need full supplementary robustness.
RUN_CONTEXT_GRAPH_DIAGNOSTIC_IN_ABLATION = False  # previous tests showed no stable gain; use only as supplementary diagnostic

# v9 module-validation strategy
# Constructive ablation adds modules step by step to prove the evidence chain:
# RF anchor only -> +Hydro-ConTex encoder correction -> +spatial graph -> +WRL.
# This is more reviewer-friendly than relying only on leave-one-out deletion.
RUN_CONSTRUCTIVE_ABLATION = True
# Keep expensive optional diagnostics off by default for the final manuscript line.
RUN_GLOBAL_BRANCH_DIAGNOSTIC = False


MAIN_MODEL_NAME = "RF_Stabilized_HydroConTex_GNNWRL"
V4_MODEL_NAME = MAIN_MODEL_NAME
V5_MODEL_NAME = "RF_Family_Anchor_Diagnostic"

# Final manuscript line: use fixed RandomForest anchor only.
# V5 / RF-family anchors and CatBoost/XGBoost anchors are intentionally removed
# from the main comparison to keep the model name, mechanism and validation logic consistent.
NEURAL_COMPARISON_VARIANTS = [
    {
        "name": MAIN_MODEL_NAME,
        "anchor_mode": ANCHOR_MODE_V4_RF_ONLY,
        "description": "Fixed RandomForest anchor; final manuscript version."
    },
]

FINAL_ANCHOR_MODE = ANCHOR_MODE_V4_RF_ONLY
FINAL_MODEL_NAME = MAIN_MODEL_NAME


# =========================================================
# 1. Utility functions
# =========================================================

def ensure_dir(path: str):
    os.makedirs(path, exist_ok=True)
    return path


def log(msg: str):
    print(msg, flush=True)


def sigmoid_np(x):
    x = np.clip(x, -30, 30)
    return 1.0 / (1.0 + np.exp(-x))


def logit_np(p, eps=1e-6):
    p = np.clip(p, eps, 1 - eps)
    return np.log(p / (1 - p))


def apply_probability_calibrator(prob, calibrator_info):
    """Apply a stored safe calibrator to a probability vector."""
    prob = np.asarray(prob, dtype=float)
    if calibrator_info is None:
        return np.clip(prob, 1e-6, 1 - 1e-6)
    method = str(calibrator_info.get("method", "none"))
    model = calibrator_info.get("model", None)
    if method == "sigmoid" and model is not None:
        x = logit_np(prob).reshape(-1, 1)
        out = model.predict_proba(x)[:, 1]
        return np.clip(out, 1e-6, 1 - 1e-6)
    if method == "isotonic" and model is not None:
        out = model.predict(prob)
        return np.clip(out, 1e-6, 1 - 1e-6)
    return np.clip(prob, 1e-6, 1 - 1e-6)


def _calibration_selection_score(y_true, prob, auc_reference=None):
    """Validation score for safe calibration: keep discrimination, improve calibration."""
    auc = safe_auc(y_true, prob)
    ap = safe_ap(y_true, prob)
    try:
        br = brier_score_loss(y_true, np.clip(prob, 1e-6, 1 - 1e-6))
    except Exception:
        br = np.nan
    try:
        ece, _, _ = expected_calibration_error(y_true, prob, n_bins=10)
    except Exception:
        ece = np.nan
    # Do not accept a calibrator that clearly damages AUC.
    if auc_reference is not None and np.isfinite(auc_reference) and np.isfinite(auc):
        if auc < auc_reference - CALIBRATION_AUC_TOLERANCE:
            return -np.inf, auc, ap, br, ece
    score = (auc if np.isfinite(auc) else 0.0) + 0.05 * (ap if np.isfinite(ap) else 0.0) \
            - 0.35 * (br if np.isfinite(br) else 1.0) - 0.10 * (ece if np.isfinite(ece) else 1.0)
    return score, auc, ap, br, ece


def fit_safe_blend_calibrator(y_val, prob_val):
    """
    Fit optional sigmoid / isotonic calibration on internal validation only.
    Return the safest calibrator and a selection table. The selected method may be 'none'.
    """
    y_val = np.asarray(y_val).astype(int)
    prob_val = np.clip(np.asarray(prob_val, dtype=float), 1e-6, 1 - 1e-6)
    rows = []

    base_score, base_auc, base_ap, base_br, base_ece = _calibration_selection_score(y_val, prob_val)
    rows.append({
        "CalibrationMethod": "none", "AUC": base_auc, "PR_AUC": base_ap,
        "Brier": base_br, "ECE": base_ece, "CalibrationScore": base_score,
        "Selected": False
    })
    best = {"method": "none", "model": None}
    best_score = base_score
    best_prob = prob_val

    # Sigmoid / Platt-style calibration on logit(prob).
    try:
        sig = LogisticRegression(max_iter=1000, solver="lbfgs")
        sig.fit(logit_np(prob_val).reshape(-1, 1), y_val)
        p_sig = sig.predict_proba(logit_np(prob_val).reshape(-1, 1))[:, 1]
        score, auc, ap, br, ece = _calibration_selection_score(y_val, p_sig, auc_reference=base_auc)
        rows.append({
            "CalibrationMethod": "sigmoid", "AUC": auc, "PR_AUC": ap,
            "Brier": br, "ECE": ece, "CalibrationScore": score, "Selected": False
        })
        if score > best_score + 1e-8:
            best = {"method": "sigmoid", "model": sig}
            best_score = score
            best_prob = p_sig
    except Exception as e:
        rows.append({"CalibrationMethod": "sigmoid", "Error": str(e), "Selected": False})

    # Isotonic calibration may help Brier/ECE but can be over-flexible; it is disabled by default
    # in v7 because overly hard probabilities are undesirable for F1 = P_flood × EI.
    if ALLOW_ISOTONIC_CALIBRATION:
        try:
            iso = IsotonicRegression(out_of_bounds="clip", y_min=1e-6, y_max=1-1e-6)
            iso.fit(prob_val, y_val)
            p_iso = iso.predict(prob_val)
            score, auc, ap, br, ece = _calibration_selection_score(y_val, p_iso, auc_reference=base_auc)
            rows.append({
                "CalibrationMethod": "isotonic", "AUC": auc, "PR_AUC": ap,
                "Brier": br, "ECE": ece, "CalibrationScore": score, "Selected": False
            })
            if score > best_score + 1e-8:
                best = {"method": "isotonic", "model": iso}
                best_score = score
                best_prob = p_iso
        except Exception as e:
            rows.append({"CalibrationMethod": "isotonic", "Error": str(e), "Selected": False})
    else:
        rows.append({"CalibrationMethod": "isotonic", "Skipped": "disabled_by_default_in_v7", "Selected": False})

    table = pd.DataFrame(rows)
    if "CalibrationMethod" in table.columns:
        table.loc[table["CalibrationMethod"] == best["method"], "Selected"] = True
    best["validation_score"] = float(best_score) if np.isfinite(best_score) else np.nan
    best["validation_prob_calibrated"] = best_prob
    return best, table


def find_raster_exact(folder: str, aliases: List[str]) -> Optional[str]:
    tif_files = []
    tif_files.extend(glob.glob(os.path.join(folder, "**", "*.tif"), recursive=True))
    tif_files.extend(glob.glob(os.path.join(folder, "**", "*.tiff"), recursive=True))
    alias_lower = [a.lower() for a in aliases]
    candidates = []
    for file in tif_files:
        stem = Path(file).stem.lower()
        if stem in alias_lower:
            candidates.append(file)
    candidates = sorted(list(set(candidates)))
    return candidates[0] if candidates else None


def build_city_raster_paths(city: str, folder: str, model_vars: List[str]) -> Dict[str, Optional[str]]:
    paths = {}
    log(f"\n========== Scan rasters: {city} ==========")
    for var in model_vars:
        path = find_raster_exact(folder, RASTER_STEMS.get(var, [var]))
        paths[var] = path
        if path is None:
            log(f"[Missing] {city} - {var}")
        else:
            log(f"[Matched] {city} - {var}: {path}")
    missing = [v for v, p in paths.items() if p is None]
    if missing:
        raise FileNotFoundError(f"{city} missing rasters: {missing}")
    return paths


def find_label_column(gdf: gpd.GeoDataFrame, label_col: str = LABEL_COL) -> str:
    for c in gdf.columns:
        if c.lower() == label_col.lower():
            return c
    raise ValueError(f"Cannot find label column `{label_col}`. Existing fields: {list(gdf.columns)}")


def representative_point_geometry(gdf: gpd.GeoDataFrame) -> gpd.GeoDataFrame:
    gdf = gdf.copy()
    if not all(gdf.geometry.geom_type == "Point"):
        gdf["geometry"] = gdf.geometry.representative_point()
    return gdf


def sample_rasters_for_points(city: str, point_path: str, raster_paths: Dict[str, str], model_vars: List[str]) -> pd.DataFrame:
    if not os.path.exists(point_path):
        raise FileNotFoundError(f"{city} point file not found: {point_path}")

    gdf = gpd.read_file(point_path)
    gdf = representative_point_geometry(gdf)

    label_real_col = find_label_column(gdf, LABEL_COL)
    gdf[label_real_col] = pd.to_numeric(gdf[label_real_col], errors="coerce")
    gdf = gdf[gdf[label_real_col].isin([0, 1])].copy()
    if gdf.empty:
        raise ValueError(f"{city}: no valid label=0/1 samples.")

    if gdf.crs is None:
        raise ValueError(f"{city}: point file has no CRS. Please define projection first.")

    # Use first raster CRS for coordinates and graph construction
    first_raster = raster_paths[model_vars[0]]
    with rasterio.open(first_raster) as src0:
        target_crs = src0.crs
    gdf_r0 = gdf.to_crs(target_crs)

    result = pd.DataFrame(index=np.arange(len(gdf)))
    result["sample_id"] = [f"{city}_{i:06d}" for i in range(len(gdf))]
    result["City"] = city
    result["label"] = gdf[label_real_col].astype(int).to_numpy()
    result["x"] = gdf_r0.geometry.x.to_numpy()
    result["y"] = gdf_r0.geometry.y.to_numpy()

    try:
        gdf_wgs = gdf.to_crs("EPSG:4326")
        result["lon"] = gdf_wgs.geometry.x.to_numpy()
        result["lat"] = gdf_wgs.geometry.y.to_numpy()
    except Exception:
        result["lon"] = np.nan
        result["lat"] = np.nan

    for var in model_vars:
        path = raster_paths[var]
        with rasterio.open(path) as src:
            gdf_r = gdf.to_crs(src.crs) if gdf.crs != src.crs else gdf
            coords = [(geom.x, geom.y) for geom in gdf_r.geometry]
            vals = []
            for val in src.sample(coords):
                v = float(val[0])
                if src.nodata is not None and v == src.nodata:
                    v = np.nan
                if not np.isfinite(v):
                    v = np.nan
                vals.append(v)
        result[var] = vals

    return result


def load_all_samples() -> pd.DataFrame:
    all_rows = []
    for city, folder in CITY_DIRS.items():
        raster_paths = build_city_raster_paths(city, folder, MODEL_VARS)
        log(f"\n========== Extract point samples: {city} ==========")
        df_city = sample_rasters_for_points(city, POINT_FILES[city], raster_paths, MODEL_VARS)
        log(f"{city}: sample count = {len(df_city)}")
        log(str(df_city["label"].value_counts()))
        all_rows.append(df_city)

    df = pd.concat(all_rows, ignore_index=True)
    # Round categorical-like LULC if it has small classes.
    if "LULC" in df.columns:
        df["LULC"] = np.rint(df["LULC"]).where(df["LULC"].notna(), np.nan)

    before = len(df)
    df["Valid_feature_ratio"] = df[MODEL_VARS].notna().mean(axis=1)
    df_before = df.copy()
    df = df[df["Valid_feature_ratio"] >= MIN_VALID_FEATURE_RATIO].copy()
    log(f"\nSamples retained after valid feature ratio filter: {len(df)} / {before}")

    # Save diagnostics
    df_before.groupby(["City", "label"]).size().reset_index(name="Count_before_filter").to_csv(
        os.path.join(OUT_DIR, "Sample_summary_by_city_label_BEFORE_filter.csv"),
        index=False, encoding="utf-8-sig"
    )
    df.groupby(["City", "label"]).size().reset_index(name="Count").to_csv(
        os.path.join(OUT_DIR, "Sample_summary_by_city_label_AFTER_filter.csv"),
        index=False, encoding="utf-8-sig"
    )

    diag = []
    before_counts = df_before.groupby(["City", "label"]).size()
    after_counts = df.groupby(["City", "label"]).size()
    for key, n_before in before_counts.items():
        n_after = int(after_counts.get(key, 0))
        diag.append({
            "City": key[0],
            "label": key[1],
            "Count_before": int(n_before),
            "Count_after": n_after,
            "Removed_by_filter": int(n_before - n_after),
            "Retained_ratio": n_after / n_before if n_before > 0 else np.nan,
        })
    pd.DataFrame(diag).to_csv(
        os.path.join(OUT_DIR, "Sample_filter_diagnostics_by_city_label.csv"),
        index=False, encoding="utf-8-sig"
    )

    if df["label"].nunique() < 2:
        raise ValueError("Only one label class remains after filtering.")

    log("\n========== Sample summary after valid filter ==========")
    log(str(df.groupby(["City", "label"]).size().reset_index(name="Count")))
    log(f"\nTotal samples: {len(df)}")
    log("Label distribution:")
    log(str(df["label"].value_counts()))
    return df.reset_index(drop=True)


# =========================================================
# 2. Preprocessing
# =========================================================

class TabularPreprocessor:
    """
    Numeric preprocessing with zero-fill, median-fill, standardization, and
    explicit missing indicators for selected high-missing variables.

    Raw rasters remain MODEL_VARS. The transformed feature table is FEATURE_VARS.
    """
    def __init__(self, model_vars: List[str], zero_fill_vars: List[str]):
        self.model_vars = model_vars
        self.zero_fill_vars = zero_fill_vars
        self.missing_indicator_base_vars = [v for v in MISSING_INDICATOR_BASE_VARS if v in model_vars]
        self.missing_indicator_vars = [f"{v}_missing" for v in self.missing_indicator_base_vars]
        self.feature_vars = self.model_vars + self.missing_indicator_vars
        self.median_fill_vars = [v for v in model_vars if v not in zero_fill_vars]
        self.medians_ = {}
        self.scaler_ = StandardScaler()

    def _prepare_unscaled(self, df: pd.DataFrame) -> pd.DataFrame:
        X_raw = df[self.model_vars].copy()
        X = pd.DataFrame(index=df.index)

        # Missing indicators are created before imputation.
        for v in self.model_vars:
            X[v] = X_raw[v]

        for v in self.missing_indicator_base_vars:
            X[f"{v}_missing"] = X_raw[v].isna().astype(float)

        # For absence-like built/micro variables, NaN is treated as zero but the
        # missing indicator preserves the data-coverage information.
        for v in self.zero_fill_vars:
            if v in X.columns:
                X[v] = X[v].fillna(0.0)

        # Other variables use train-fold medians.
        for v in self.median_fill_vars:
            fill = self.medians_.get(v, np.nan)
            if not np.isfinite(fill):
                fill = float(X[v].median(skipna=True))
                if not np.isfinite(fill):
                    fill = 0.0
            X[v] = X[v].fillna(fill)

        X = X[self.feature_vars].astype(float)
        return X

    def fit(self, df: pd.DataFrame):
        X_raw = df[self.model_vars].copy()
        for v in self.median_fill_vars:
            med = float(X_raw[v].median(skipna=True))
            if not np.isfinite(med):
                med = 0.0
            self.medians_[v] = med
        X = self._prepare_unscaled(df)
        self.scaler_.fit(X.values)
        return self

    def transform(self, df: pd.DataFrame) -> pd.DataFrame:
        X = self._prepare_unscaled(df)
        arr = self.scaler_.transform(X.values)
        return pd.DataFrame(arr, columns=self.feature_vars, index=df.index)

    def fit_transform(self, df: pd.DataFrame) -> pd.DataFrame:
        self.fit(df)
        return self.transform(df)

def context_indices(groups: Optional[Dict[str, List[str]]] = None) -> Dict[str, List[int]]:
    groups = CONTEXT_GROUPS if groups is None else groups
    idx = {}
    for cname, vars_ in groups.items():
        idx[cname] = [FEATURE_VARS.index(v) for v in vars_ if v in FEATURE_VARS]
    return idx


def city_codes(city_series: pd.Series) -> Tuple[np.ndarray, Dict[str, int]]:
    cities = sorted(city_series.astype(str).unique())
    mapping = {c: i for i, c in enumerate(cities)}
    codes = city_series.astype(str).map(mapping).to_numpy(dtype=int)
    return codes, mapping


def stratified_city_label_split(df: pd.DataFrame, test_size=0.30, random_state=42):
    key = df["City"].astype(str) + "_" + df["label"].astype(str)
    counts = key.value_counts()
    if (counts < 2).any():
        stratify = df["label"].values
    else:
        stratify = key.values
    idx = np.arange(len(df))
    train_idx, test_idx = train_test_split(
        idx, test_size=test_size, random_state=random_state, stratify=stratify
    )
    return train_idx, test_idx


# =========================================================
# 3. Metrics and plot-data helpers
# =========================================================

def safe_auc(y_true, prob):
    try:
        if len(np.unique(y_true)) < 2:
            return np.nan
        return roc_auc_score(y_true, prob)
    except Exception:
        return np.nan


def safe_ap(y_true, prob):
    try:
        if len(np.unique(y_true)) < 2:
            return np.nan
        return average_precision_score(y_true, prob)
    except Exception:
        return np.nan


def expected_calibration_error(y_true, prob, n_bins=10):
    y_true = np.asarray(y_true).astype(int)
    prob = np.asarray(prob).astype(float)
    bins = np.linspace(0, 1, n_bins + 1)
    ece = 0.0
    mce = 0.0
    rows = []
    n = len(y_true)
    for i in range(n_bins):
        lo, hi = bins[i], bins[i + 1]
        if i == n_bins - 1:
            mask = (prob >= lo) & (prob <= hi)
        else:
            mask = (prob >= lo) & (prob < hi)
        if mask.sum() == 0:
            rows.append({
                "bin": i, "bin_left": lo, "bin_right": hi,
                "n": 0, "mean_pred": np.nan, "obs_freq": np.nan, "abs_gap": np.nan
            })
            continue
        mean_pred = float(prob[mask].mean())
        obs_freq = float(y_true[mask].mean())
        gap = abs(mean_pred - obs_freq)
        ece += (mask.sum() / n) * gap
        mce = max(mce, gap)
        rows.append({
            "bin": i, "bin_left": lo, "bin_right": hi,
            "n": int(mask.sum()), "mean_pred": mean_pred,
            "obs_freq": obs_freq, "abs_gap": gap
        })
    return ece, mce, pd.DataFrame(rows)


def metrics_at_threshold(y_true, prob, threshold=0.5):
    y_true = np.asarray(y_true).astype(int)
    prob = np.asarray(prob).astype(float)
    pred = (prob >= threshold).astype(int)
    tn, fp, fn, tp = confusion_matrix(y_true, pred, labels=[0, 1]).ravel()
    specificity = tn / (tn + fp) if (tn + fp) > 0 else np.nan
    ece, mce, _ = expected_calibration_error(y_true, prob, n_bins=10)
    return {
        "AUC": safe_auc(y_true, prob),
        "PR_AUC": safe_ap(y_true, prob),
        "Accuracy": accuracy_score(y_true, pred),
        "Precision": precision_score(y_true, pred, zero_division=0),
        "Recall": recall_score(y_true, pred, zero_division=0),
        "Specificity": specificity,
        "F1": f1_score(y_true, pred, zero_division=0),
        "Kappa": cohen_kappa_score(y_true, pred),
        "MCC": matthews_corrcoef(y_true, pred),
        "Brier": brier_score_loss(y_true, prob),
        "ECE": ece,
        "MCE": mce,
        "TN": tn, "FP": fp, "FN": fn, "TP": tp,
        "Threshold": threshold,
    }


def threshold_table(y_true, prob, model_name, experiment, thresholds=None):
    if thresholds is None:
        thresholds = np.round(np.linspace(0.05, 0.95, 91), 3)
    rows = []
    for th in thresholds:
        m = metrics_at_threshold(y_true, prob, threshold=th)
        m["Model"] = model_name
        m["Experiment"] = experiment
        rows.append(m)
    return pd.DataFrame(rows)


def optimal_thresholds_from_table(df_th):
    """Return multiple operating thresholds for supplementary reporting.

    v11 robustness-diagnostics repair: threshold-dependent metrics are no longer restricted to 0.5.
    We save max-F1, max-Youden, and a recall-constrained threshold
    so flood omission errors can be inspected transparently.
    """
    out = []
    if df_th is None or df_th.empty:
        return pd.DataFrame(out)

    # Max F1
    tmp = df_th.copy()
    best = tmp.sort_values("F1", ascending=False).iloc[0].to_dict()
    best["Criterion"] = "Max_F1"
    out.append(best)

    # Max Youden index
    tmp = df_th.copy()
    tmp["Youden"] = tmp["Recall"] + tmp["Specificity"] - 1
    best = tmp.sort_values("Youden", ascending=False).iloc[0].to_dict()
    best["Criterion"] = "Max_Youden"
    out.append(best)

    # Recall-constrained F1. If no threshold satisfies the constraint, fall back to max F1.
    tmp = df_th[df_th["Recall"] >= RECALL_CONSTRAINT_MIN].copy()
    if tmp.empty:
        tmp = df_th.copy()
        crit_name = f"Recall_constrained_F1_fallback_maxF1_target_{RECALL_CONSTRAINT_MIN}"
    else:
        crit_name = f"Recall_ge_{RECALL_CONSTRAINT_MIN}_max_F1"
    best = tmp.sort_values(["F1", "Precision"], ascending=[False, False]).iloc[0].to_dict()
    best["Criterion"] = crit_name
    out.append(best)

    return pd.DataFrame(out)


def curve_data(y_true, prob, model_name, experiment):
    roc_df = pd.DataFrame()
    pr_df = pd.DataFrame()
    if len(np.unique(y_true)) >= 2:
        fpr, tpr, roc_th = roc_curve(y_true, prob)
        roc_df = pd.DataFrame({
            "FPR": fpr, "TPR": tpr, "Threshold": roc_th,
            "Model": model_name, "Experiment": experiment
        })
        prec, rec, pr_th = precision_recall_curve(y_true, prob)
        pr_df = pd.DataFrame({
            "Recall": rec, "Precision": prec,
            "Threshold": np.r_[pr_th, np.nan],
            "Model": model_name, "Experiment": experiment
        })
    return roc_df, pr_df


def save_eval_artifacts(
    y_true, prob, meta_df, model_name, experiment, out_prefix,
    threshold=0.5, extra_cols: Optional[Dict[str, np.ndarray]] = None
):
    metrics = metrics_at_threshold(y_true, prob, threshold=threshold)
    metrics["Model"] = model_name
    metrics["Experiment"] = experiment

    pred = (prob >= threshold).astype(int)
    pred_df = meta_df.copy().reset_index(drop=True)
    pred_df["Model"] = model_name
    pred_df["Experiment"] = experiment
    pred_df["y_true"] = y_true
    pred_df["P_flood"] = prob
    pred_df["pred_label"] = pred
    pred_df["residual"] = y_true - prob
    if extra_cols:
        for k, v in extra_cols.items():
            pred_df[k] = v
    pred_df.to_csv(out_prefix + "_prediction_data.csv", index=False, encoding="utf-8-sig")

    roc_df, pr_df = curve_data(y_true, prob, model_name, experiment)
    roc_df.to_csv(out_prefix + "_roc_curve_data.csv", index=False, encoding="utf-8-sig")
    pr_df.to_csv(out_prefix + "_pr_curve_data.csv", index=False, encoding="utf-8-sig")

    cm = confusion_matrix(y_true, pred, labels=[0, 1])
    cm_df = pd.DataFrame({
        "True": [0, 0, 1, 1],
        "Pred": [0, 1, 0, 1],
        "Count": [cm[0, 0], cm[0, 1], cm[1, 0], cm[1, 1]],
        "Model": model_name,
        "Experiment": experiment
    })
    cm_df.to_csv(out_prefix + "_confusion_matrix_data.csv", index=False, encoding="utf-8-sig")

    th_df = threshold_table(y_true, prob, model_name, experiment)
    th_df.to_csv(out_prefix + "_threshold_metrics_data.csv", index=False, encoding="utf-8-sig")
    opt_df = optimal_thresholds_from_table(th_df)
    opt_df.to_csv(out_prefix + "_optimal_thresholds.csv", index=False, encoding="utf-8-sig")

    ece, mce, cal_df = expected_calibration_error(y_true, prob, n_bins=10)
    cal_df["Model"] = model_name
    cal_df["Experiment"] = experiment
    cal_df.to_csv(out_prefix + "_calibration_curve_data.csv", index=False, encoding="utf-8-sig")

    # Citywise metrics
    city_rows = []
    if "City" in meta_df.columns:
        for city, subidx in meta_df.reset_index(drop=True).groupby("City").groups.items():
            idx = np.array(list(subidx))
            if len(idx) == 0:
                continue
            m = metrics_at_threshold(np.asarray(y_true)[idx], np.asarray(prob)[idx], threshold=threshold)
            m["City"] = city
            m["Model"] = model_name
            m["Experiment"] = experiment
            m["N"] = len(idx)
            city_rows.append(m)
    city_df = pd.DataFrame(city_rows)
    city_df.to_csv(out_prefix + "_citywise_metrics.csv", index=False, encoding="utf-8-sig")

    return metrics, pred_df, roc_df, pr_df, cm_df, th_df, opt_df, cal_df, city_df


# =========================================================
# 4. Graph construction
# =========================================================

def normalize_edge_weights(src, dst, weight, n_nodes):
    """Row-normalize edge weights by destination node."""
    weight = np.asarray(weight, dtype=np.float32)
    dst = np.asarray(dst, dtype=np.int64)
    denom = np.zeros(n_nodes, dtype=np.float32)
    np.add.at(denom, dst, weight)
    denom = np.maximum(denom, 1e-8)
    return weight / denom[dst]


def build_knn_edges_by_city(
    coords: np.ndarray,
    X_context: np.ndarray,
    city: np.ndarray,
    k_spatial: int = K_SPATIAL,
    k_context: int = K_CONTEXT,
    eta_spatial: float = GRAPH_ETA_SPATIAL,
) -> Tuple[np.ndarray, np.ndarray, pd.DataFrame]:
    """
    Build graph edges within each city.

    The final main model uses spatial KNN edges only. The optional context KNN
    branch is retained for supplementary diagnostics, but is not emphasized as a
    validated component because earlier ablation showed no stable gain.

    edge_type is explicitly saved for plotting and ablation:
      - spatial: distance-based spatial neighbourhood edge
      - context: optional Hydro-ConTex covariate-similarity edge
      - self: fallback self-loop
    """
    src_all, dst_all, w_all, type_all = [], [], [], []
    raw_w_all = []

    n = len(coords)
    for c in np.unique(city):
        idx = np.where(city == c)[0]
        if len(idx) <= 1:
            continue

        # spatial KNN
        if k_spatial is not None and k_spatial > 0:
            k_s = min(k_spatial + 1, len(idx))
            nbr_s = NearestNeighbors(n_neighbors=k_s, algorithm="auto").fit(coords[idx])
            dist_s, ind_s = nbr_s.kneighbors(coords[idx])
            positive_d = dist_s[:, 1:].ravel()
            positive_d = positive_d[positive_d > 0]
            bw = np.quantile(positive_d, DIST_KERNEL_QUANTILE) if len(positive_d) else 1.0
            bw = max(bw, 1e-6)

            for row_pos, row_global in enumerate(idx):
                for jj in range(1, k_s):  # skip self
                    neigh_global = idx[ind_s[row_pos, jj]]
                    d = dist_s[row_pos, jj]
                    w_raw = math.exp(-(d * d) / (2 * bw * bw))
                    w = eta_spatial * w_raw
                    src_all.append(neigh_global)
                    dst_all.append(row_global)
                    w_all.append(w)
                    raw_w_all.append(w_raw)
                    type_all.append("spatial")

        # Hydro-ConTex feature similarity KNN
        if k_context is not None and k_context > 0:
            k_c = min(k_context + 1, len(idx))
            nbr_c = NearestNeighbors(n_neighbors=k_c, algorithm="auto").fit(X_context[idx])
            dist_c, ind_c = nbr_c.kneighbors(X_context[idx])
            positive_dc = dist_c[:, 1:].ravel()
            positive_dc = positive_dc[positive_dc > 0]
            bwc = np.quantile(positive_dc, DIST_KERNEL_QUANTILE) if len(positive_dc) else 1.0
            bwc = max(bwc, 1e-6)

            for row_pos, row_global in enumerate(idx):
                for jj in range(1, k_c):
                    neigh_global = idx[ind_c[row_pos, jj]]
                    d = dist_c[row_pos, jj]
                    w_raw = math.exp(-(d * d) / (2 * bwc * bwc))
                    w = (1.0 - eta_spatial) * w_raw
                    src_all.append(neigh_global)
                    dst_all.append(row_global)
                    w_all.append(w)
                    raw_w_all.append(w_raw)
                    type_all.append("context")

    if len(src_all) == 0:
        src_all = list(range(n))
        dst_all = list(range(n))
        w_all = [1.0] * n
        raw_w_all = [1.0] * n
        type_all = ["self"] * n

    src = np.asarray(src_all, dtype=np.int64)
    dst = np.asarray(dst_all, dtype=np.int64)
    w_norm = normalize_edge_weights(src, dst, w_all, n)

    edge_index = np.vstack([src, dst])
    edge_weight = w_norm.astype(np.float32)
    edges_df = pd.DataFrame({
        "src": src,
        "dst": dst,
        "edge_type": type_all,
        "raw_weight": np.asarray(raw_w_all, dtype=np.float32),
        "weighted_before_norm": np.asarray(w_all, dtype=np.float32),
        "weight": edge_weight,
    })
    return edge_index, edge_weight, edges_df


def make_spatial_blocks(df: pd.DataFrame, grid_n=5) -> pd.Series:
    blocks = []
    for city, sub in df.groupby("City"):
        x = sub["x"].to_numpy()
        y = sub["y"].to_numpy()
        if len(sub) == 0:
            continue
        xmin, xmax = np.nanmin(x), np.nanmax(x)
        ymin, ymax = np.nanmin(y), np.nanmax(y)
        xbin = np.floor((x - xmin) / max(xmax - xmin, 1e-9) * grid_n).astype(int)
        ybin = np.floor((y - ymin) / max(ymax - ymin, 1e-9) * grid_n).astype(int)
        xbin = np.clip(xbin, 0, grid_n - 1)
        ybin = np.clip(ybin, 0, grid_n - 1)
        bid = [f"{city}_G{grid_n}_{xb}_{yb}" for xb, yb in zip(xbin, ybin)]
        blocks.append(pd.Series(bid, index=sub.index, name=f"SpatialBlock_G{grid_n}"))
    return pd.concat(blocks).sort_index()


# =========================================================
# 5. Neural model: RF-stabilized Hydro-ConTex GNNWRL
# =========================================================

class GraphConv(nn.Module):
    def __init__(self, dim):
        super().__init__()
        self.lin_self = nn.Linear(dim, dim)
        self.lin_neigh = nn.Linear(dim, dim)
        self.norm = nn.LayerNorm(dim)

    def forward(self, h, edge_index, edge_weight):
        src, dst = edge_index[0], edge_index[1]
        msg = self.lin_neigh(h[src]) * edge_weight.view(-1, 1)
        agg = torch.zeros_like(h)
        agg.index_add_(0, dst, msg)
        out = self.lin_self(h) + agg
        out = self.norm(out)
        return F.relu(out)


class RFStabilizedHydroConTexGNNWRL(nn.Module):
    def __init__(
        self,
        input_dim: int,
        context_idx: Dict[str, List[int]],
        hidden_dim: int = HIDDEN_DIM,
        dropout: float = DROPOUT,
        use_graph: bool = True,
        use_wrl: bool = True,
        use_global_branch: bool = True,
    ):
        super().__init__()
        self.context_idx = context_idx
        self.context_names = list(context_idx.keys())
        self.use_graph = use_graph
        self.use_wrl = use_wrl
        self.use_global_branch = use_global_branch

        self.encoders = nn.ModuleDict()
        self.gconvs = nn.ModuleDict()
        self.context_logits = nn.ModuleDict()

        for cname in self.context_names:
            in_dim = len(context_idx[cname])
            self.encoders[cname] = nn.Sequential(
                nn.Linear(in_dim, hidden_dim),
                nn.ReLU(),
                nn.Dropout(dropout),
                nn.Linear(hidden_dim, hidden_dim),
                nn.ReLU(),
            )
            self.gconvs[cname] = GraphConv(hidden_dim)
            self.context_logits[cname] = nn.Linear(hidden_dim, 1)

        fusion_in = hidden_dim * len(self.context_names) + 2
        self.global_branch = nn.Sequential(
            nn.Linear(fusion_in, hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, max(hidden_dim // 2, 4)),
            nn.ReLU(),
            nn.Linear(max(hidden_dim // 2, 4), 1),
        )

        self.wrl_gate = nn.Sequential(
            nn.Linear(fusion_in, hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, len(self.context_names)),
        )

    def forward(self, x, coords_norm, edge_index, edge_weight, return_details=False):
        context_embeds = []
        context_logits = []

        for cname in self.context_names:
            idx = self.context_idx[cname]
            hx = self.encoders[cname](x[:, idx])
            if self.use_graph:
                hg = self.gconvs[cname](hx, edge_index, edge_weight)
            else:
                hg = hx
            context_embeds.append(hg)
            context_logits.append(self.context_logits[cname](hg))

        H = torch.cat(context_embeds, dim=1)
        Hc = torch.cat([H, coords_norm], dim=1)

        logits_stack = torch.cat(context_logits, dim=1)  # [N, K]
        if self.use_wrl:
            alpha = F.softmax(self.wrl_gate(Hc), dim=1)
        else:
            alpha = torch.ones_like(logits_stack) / logits_stack.shape[1]
        local_logit = torch.sum(alpha * logits_stack, dim=1, keepdim=True)

        if self.use_global_branch:
            global_logit = self.global_branch(Hc)
        else:
            global_logit = torch.zeros_like(local_logit)

        base_logit = local_logit + global_logit
        if return_details:
            details = {
                "context_weights": alpha,
                "context_logits": logits_stack,
                "global_logit": global_logit,
                "local_logit": local_logit,
            }
            return base_logit.squeeze(1), details
        return base_logit.squeeze(1)


def coords_normalize(coords_train, coords_all):
    mu = coords_train.mean(axis=0)
    sd = coords_train.std(axis=0)
    sd = np.where(sd < 1e-8, 1.0, sd)
    return (coords_all - mu) / sd, mu, sd


def tensorize_graph(X_scaled, coords_norm, edge_index_np, edge_weight_np, y=None):
    x = torch.tensor(X_scaled, dtype=torch.float32, device=DEVICE)
    c = torch.tensor(coords_norm, dtype=torch.float32, device=DEVICE)
    edge_index = torch.tensor(edge_index_np, dtype=torch.long, device=DEVICE)
    edge_weight = torch.tensor(edge_weight_np, dtype=torch.float32, device=DEVICE)
    yt = None if y is None else torch.tensor(y, dtype=torch.float32, device=DEVICE)
    return x, c, edge_index, edge_weight, yt


def graph_smooth_loss(prob, edge_index, edge_weight):
    src, dst = edge_index[0], edge_index[1]
    diff = prob[src] - prob[dst]
    return torch.mean(edge_weight * diff * diff)


def adaptation_regularization(model, x, coords_norm, edge_index, edge_weight, preprocessor: TabularPreprocessor):
    """
    Soft monotonic adaptation response penalty.
    Uses gradients of probability w.r.t. standardized input features.
    Positive protective variables: dP/dx should not be systematically positive.
    Positive risk variables: dP/dx should not be systematically negative.
    """
    if ADAPT_REG_WEIGHT <= 0:
        return torch.tensor(0.0, device=DEVICE)

    x_req = x.detach().clone().requires_grad_(True)
    logit = model(x_req, coords_norm, edge_index, edge_weight)
    prob = torch.sigmoid(logit)
    grads = torch.autograd.grad(prob.mean(), x_req, create_graph=True)[0]

    penalty = torch.tensor(0.0, device=DEVICE)
    count = 0

    for v in DECISION_POSITIVE_PROTECTIVE:
        if v in FEATURE_VARS:
            j = FEATURE_VARS.index(v)
            # protective variable higher should not increase P; penalize positive gradient
            penalty = penalty + F.relu(grads[:, j]).mean()
            count += 1

    for v in DECISION_POSITIVE_RISK:
        if v in FEATURE_VARS:
            j = FEATURE_VARS.index(v)
            # risk variable higher should not decrease P; penalize negative gradient
            penalty = penalty + F.relu(-grads[:, j]).mean()
            count += 1

    if count > 0:
        penalty = penalty / count
    return penalty


def make_anchor_model_by_name(name: str, seed: int = RANDOM_STATE):
    """Create a tree-based probability anchor.

    The anchor is used only as a stable nonlinear probability reference.
    The final model remains a GNNWRL-based model with safe probability blending.
    """
    name = str(name)
    if name == "RandomForest":
        return RandomForestClassifier(
            n_estimators=900, max_features="sqrt", min_samples_leaf=2,
            class_weight=None, random_state=seed, n_jobs=-1
        )
    if name == "ExtraTrees":
        return ExtraTreesClassifier(
            n_estimators=900, max_features="sqrt", min_samples_leaf=2,
            class_weight=None, random_state=seed, n_jobs=-1
        )
    if name == "HGB_Tuned":
        return HistGradientBoostingClassifier(
            max_iter=650, learning_rate=0.03, max_leaf_nodes=31,
            l2_regularization=0.01, min_samples_leaf=12,
            random_state=seed
        )
    if name == "XGBoost":
        try:
            from xgboost import XGBClassifier
            return XGBClassifier(
                n_estimators=800, max_depth=4, learning_rate=0.025,
                subsample=0.88, colsample_bytree=0.88,
                objective="binary:logistic", eval_metric="logloss",
                random_state=seed, n_jobs=-1
            )
        except Exception as e:
            raise RuntimeError(f"XGBoost unavailable: {e}")
    if name == "CatBoost":
        try:
            from catboost import CatBoostClassifier
            return CatBoostClassifier(
                iterations=800, learning_rate=0.025, depth=5,
                loss_function="Logloss", eval_metric="AUC",
                random_seed=seed, verbose=False
            )
        except Exception as e:
            raise RuntimeError(f"CatBoost unavailable: {e}")
    raise ValueError(f"Unknown anchor model: {name}")


def anchor_selection_score(y_true, prob):
    auc = safe_auc(y_true, prob)
    ap = safe_ap(y_true, prob)
    f1 = metrics_at_threshold(y_true, prob, 0.5)["F1"]
    br = brier_score_loss(y_true, np.clip(prob, 1e-6, 1 - 1e-6))
    score = (ALPHA_SCORE_WEIGHTS["AUC"] * (auc if np.isfinite(auc) else 0) +
             ALPHA_SCORE_WEIGHTS["PR_AUC"] * (ap if np.isfinite(ap) else 0) +
             ALPHA_SCORE_WEIGHTS["F1"] * f1 +
             ALPHA_SCORE_WEIGHTS["Brier"] * br)
    return score, auc, ap, f1, br


def fit_anchor_model(name: str, X_train: pd.DataFrame, y_train: np.ndarray, sample_weight=None):
    model = make_anchor_model_by_name(name)
    try:
        model.fit(X_train, y_train, sample_weight=sample_weight)
    except TypeError:
        model.fit(X_train, y_train)
    return model


class AveragedProbabilityAnchor:
    """Simple probability-averaging wrapper for RF-family anchors."""
    def __init__(self, models: Dict[str, object]):
        self.models = models
        self.model_names = list(models.keys())

    def predict_proba(self, X):
        probs = []
        for _, model in self.models.items():
            probs.append(model.predict_proba(X)[:, 1])
        p1 = np.mean(np.vstack(probs), axis=0)
        p1 = np.clip(p1, 1e-6, 1 - 1e-6)
        return np.column_stack([1 - p1, p1])


def fit_tree_anchor_by_mode(
    X_train: pd.DataFrame,
    y_train: np.ndarray,
    X_val: pd.DataFrame,
    y_val: np.ndarray,
    sample_weight=None,
    anchor_mode: str = ANCHOR_MODE_V4_RF_ONLY,
):
    """Fit a stable RF-family anchor according to a pre-defined mode.

    v4 uses fixed RandomForest.
    v5 uses a mean probability ensemble of RandomForest and ExtraTrees.

    This intentionally avoids selecting CatBoost/XGBoost as the final anchor,
    because previous experiments showed that non-RF anchors may improve a single
    holdout split while weakening robust/cross-city validation.
    """
    anchor_mode = str(anchor_mode)
    rows = []

    if anchor_mode == ANCHOR_MODE_V4_RF_ONLY:
        model = fit_anchor_model("RandomForest", X_train, y_train, sample_weight=sample_weight)
        prob = model.predict_proba(X_val)[:, 1]
        score, auc, ap, f1, br = anchor_selection_score(y_val, prob)
        rows.append({
            "AnchorMode": anchor_mode, "AnchorModel": "RandomForest",
            "AUC": auc, "PR_AUC": ap, "F1": f1, "Brier": br,
            "AnchorScore": score, "Selected": True
        })
        return model, "RandomForest", pd.DataFrame(rows)

    if anchor_mode == ANCHOR_MODE_V5_RF_FAMILY:
        fitted = {}
        indiv_probs = {}
        for name in ["RandomForest", "ExtraTrees"]:
            model = fit_anchor_model(name, X_train, y_train, sample_weight=sample_weight)
            fitted[name] = model
            prob = model.predict_proba(X_val)[:, 1]
            indiv_probs[name] = prob
            score, auc, ap, f1, br = anchor_selection_score(y_val, prob)
            rows.append({
                "AnchorMode": anchor_mode, "AnchorModel": name,
                "AUC": auc, "PR_AUC": ap, "F1": f1, "Brier": br,
                "AnchorScore": score, "Selected": False
            })
        avg_prob = np.mean(np.vstack([indiv_probs["RandomForest"], indiv_probs["ExtraTrees"]]), axis=0)
        score, auc, ap, f1, br = anchor_selection_score(y_val, avg_prob)
        rows.append({
            "AnchorMode": anchor_mode, "AnchorModel": "RF_ExtraTrees_Average",
            "AUC": auc, "PR_AUC": ap, "F1": f1, "Brier": br,
            "AnchorScore": score, "Selected": True
        })
        return AveragedProbabilityAnchor(fitted), "RF_ExtraTrees_Average", pd.DataFrame(rows)

    raise ValueError(f"Unknown anchor_mode: {anchor_mode}")


def fit_tree_anchor_final_by_mode(
    selected_anchor_name: str,
    X_train: pd.DataFrame,
    y_train: np.ndarray,
    sample_weight=None,
    anchor_mode: str = ANCHOR_MODE_V4_RF_ONLY,
):
    """Refit final anchor on all training nodes using the same v4/v5 mode."""
    if anchor_mode == ANCHOR_MODE_V4_RF_ONLY:
        return fit_anchor_model("RandomForest", X_train, y_train, sample_weight=sample_weight)
    if anchor_mode == ANCHOR_MODE_V5_RF_FAMILY:
        fitted = {}
        for name in ["RandomForest", "ExtraTrees"]:
            fitted[name] = fit_anchor_model(name, X_train, y_train, sample_weight=sample_weight)
        return AveragedProbabilityAnchor(fitted)
    raise ValueError(f"Unknown anchor_mode: {anchor_mode}")


def compute_balanced_sample_weight(y, city=None):
    y = np.asarray(y).astype(int)
    n = len(y)
    # class weight
    cls, cnt = np.unique(y, return_counts=True)
    cw = {c: n / (len(cls) * cnt[i]) for i, c in enumerate(cls)}
    w = np.array([cw[v] for v in y], dtype=np.float32)

    if city is not None:
        city = np.asarray(city).astype(str)
        cities, ccnt = np.unique(city, return_counts=True)
        ctw = {c: n / (len(cities) * ccnt[i]) for i, c in enumerate(cities)}
        w_city = np.array([ctw[c] for c in city], dtype=np.float32)
        w = w * w_city

    w = w / np.mean(w)
    return w.astype(np.float32)


def train_rf_stabilized_hydrocontex_gnnwrl(
    df_train: pd.DataFrame,
    feature_train_scaled: pd.DataFrame,
    y_train: np.ndarray,
    train_meta: pd.DataFrame,
    sample_weight: Optional[np.ndarray] = None,
    internal_val_size: float = 0.20,
    verbose: bool = False,
    variant_name: str = MAIN_MODEL_NAME,
    context_groups_override: Optional[Dict[str, List[str]]] = None,
    k_spatial: int = K_SPATIAL,
    k_context: int = K_CONTEXT,
    eta_spatial: float = GRAPH_ETA_SPATIAL,
    use_graph: bool = True,
    use_wrl: bool = True,
    use_global_branch: bool = True,
    alpha_mode: str = "select",  # select, gnn_only, rf_only, or fixed numeric string/float
    anchor_mode: str = ANCHOR_MODE_V4_RF_ONLY,
):
    """
    Train:
      - RF anchor
      - GNNWRL model
      - choose safe blend alpha by internal validation:
          p_blend = alpha*p_gnn + (1-alpha)*p_rf
    Returns a package dict.
    """
    # raw imputed/scaled features for RF: use scaled features for consistency
    X_all = feature_train_scaled.values.astype(np.float32)
    coords_all = df_train[["x", "y"]].to_numpy(dtype=float)
    city_all = df_train["City"].astype(str).to_numpy()
    y_all = y_train.astype(int)

    # internal train/val split
    idx_all = np.arange(len(df_train))
    strat_key = df_train["City"].astype(str) + "_" + df_train["label"].astype(str)
    if (strat_key.value_counts() < 2).any():
        strat = y_all
    else:
        strat = strat_key.to_numpy()
    idx_tr, idx_val = train_test_split(
        idx_all, test_size=internal_val_size, random_state=RANDOM_STATE, stratify=strat
    )

    # RF anchor trained on internal training split, validate alpha on internal val
    w_tr = None
    if sample_weight is not None:
        w_tr = sample_weight[idx_tr]

    X_anchor_tr = pd.DataFrame(X_all[idx_tr], columns=FEATURE_VARS)
    X_anchor_val = pd.DataFrame(X_all[idx_val], columns=FEATURE_VARS)
    rf_anchor, selected_anchor_name, anchor_selection_table = fit_tree_anchor_by_mode(
        X_anchor_tr, y_all[idx_tr], X_anchor_val, y_all[idx_val], sample_weight=w_tr,
        anchor_mode=anchor_mode
    )

    # internal anchor probabilities for distillation and alpha search
    rf_prob_train_all = rf_anchor.predict_proba(pd.DataFrame(X_all, columns=FEATURE_VARS))[:, 1]

    # Build graph on all training nodes (transductive within training set, no test nodes)
    edge_index_np, edge_weight_np, edges_df = build_knn_edges_by_city(
        coords=coords_all,
        X_context=X_all,
        city=city_all,
        k_spatial=k_spatial,
        k_context=k_context,
        eta_spatial=eta_spatial,
    )

    coords_norm_all, coord_mu, coord_sd = coords_normalize(coords_all[idx_tr], coords_all)

    x_t, c_t, edge_i_t, edge_w_t, y_t = tensorize_graph(X_all, coords_norm_all, edge_index_np, edge_weight_np, y_all)
    train_mask = torch.tensor(idx_tr, dtype=torch.long, device=DEVICE)
    val_mask = torch.tensor(idx_val, dtype=torch.long, device=DEVICE)
    sw = torch.ones(len(y_all), dtype=torch.float32, device=DEVICE)
    if sample_weight is not None:
        sw = torch.tensor(sample_weight, dtype=torch.float32, device=DEVICE)

    ctx_idx = context_indices(context_groups_override)
    ctx_order = list(ctx_idx.keys())
    model = RFStabilizedHydroConTexGNNWRL(
        input_dim=len(FEATURE_VARS),
        context_idx=ctx_idx,
        hidden_dim=HIDDEN_DIM,
        dropout=DROPOUT,
        use_graph=use_graph,
        use_wrl=use_wrl,
        use_global_branch=use_global_branch,
    ).to(DEVICE)

    opt = torch.optim.AdamW(model.parameters(), lr=LR, weight_decay=WEIGHT_DECAY)

    best_state = None
    best_val_auc = -np.inf
    best_epoch = 0
    no_improve = 0
    history_rows = []

    rf_prob_t = torch.tensor(rf_prob_train_all, dtype=torch.float32, device=DEVICE)

    for epoch in range(1, MAX_EPOCHS + 1):
        model.train()
        opt.zero_grad()

        logit, details = model(x_t, c_t, edge_i_t, edge_w_t, return_details=True)
        prob = torch.sigmoid(logit)

        bce_raw = F.binary_cross_entropy_with_logits(logit[train_mask], y_t[train_mask], reduction="none")
        bce = torch.mean(bce_raw * sw[train_mask])

        # small RF distillation on internal train only, not enough to collapse to RF
        distill = F.mse_loss(prob[train_mask], rf_prob_t[train_mask])

        smooth = graph_smooth_loss(prob, edge_i_t, edge_w_t)
        adapt = adaptation_regularization(model, x_t, c_t, edge_i_t, edge_w_t, None)

        loss = bce + RF_DISTILL_WEIGHT * distill + GRAPH_SMOOTH_WEIGHT * smooth + ADAPT_REG_WEIGHT * adapt
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=5.0)
        opt.step()

        model.eval()
        with torch.no_grad():
            val_logit = model(x_t, c_t, edge_i_t, edge_w_t)
            val_prob = torch.sigmoid(val_logit).detach().cpu().numpy()
        val_auc = safe_auc(y_all[idx_val], val_prob[idx_val])
        val_ap = safe_ap(y_all[idx_val], val_prob[idx_val])
        val_brier = brier_score_loss(y_all[idx_val], np.clip(val_prob[idx_val], 1e-6, 1 - 1e-6))

        history_rows.append({
            "epoch": epoch,
            "loss": float(loss.detach().cpu().item()),
            "bce": float(bce.detach().cpu().item()),
            "distill": float(distill.detach().cpu().item()),
            "smooth": float(smooth.detach().cpu().item()),
            "adapt": float(adapt.detach().cpu().item()) if torch.is_tensor(adapt) else float(adapt),
            "val_auc": val_auc,
            "val_pr_auc": val_ap,
            "val_brier": val_brier,
        })

        score = val_auc if np.isfinite(val_auc) else -np.inf
        if score > best_val_auc + 1e-5:
            best_val_auc = score
            best_epoch = epoch
            best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
            no_improve = 0
        else:
            no_improve += 1

        if verbose and epoch % 50 == 0:
            log(f"Epoch {epoch:04d} loss={loss.item():.4f} val_auc={val_auc:.4f} val_ap={val_ap:.4f}")

        if no_improve >= PATIENCE:
            break

    if best_state is not None:
        model.load_state_dict(best_state)

    # Select safe alpha on internal validation.
    # v8 repair: alpha is selected with a conservative robust objective and an RF-dominant cap.
    # This avoids the earlier problem where high GNNWRL weights improved Holdout/Spatial AUC but weakened leave-one-city-out transferability.
    model.eval()
    with torch.no_grad():
        gnn_logit, det = model(x_t, c_t, edge_i_t, edge_w_t, return_details=True)
        p_gnn_all = torch.sigmoid(gnn_logit).detach().cpu().numpy()
        context_weights = det["context_weights"].detach().cpu().numpy()
        context_logits = det["context_logits"].detach().cpu().numpy()

    p_rf_val = rf_prob_train_all[idx_val]
    p_gnn_val = p_gnn_all[idx_val]

    alpha_rows = []
    best_alpha = 0.0
    best_alpha_score = -np.inf
    for alpha in RF_BLEND_GRID:
        p_bl = alpha * p_gnn_val + (1 - alpha) * p_rf_val
        auc = safe_auc(y_all[idx_val], p_bl)
        ap = safe_ap(y_all[idx_val], p_bl)
        mt = metrics_at_threshold(y_all[idx_val], p_bl, 0.5)
        f1 = mt["F1"]
        rec = mt["Recall"]
        br = brier_score_loss(y_all[idx_val], np.clip(p_bl, 1e-6, 1 - 1e-6))
        base_score = (
            ALPHA_SCORE_WEIGHTS["AUC"] * (auc if np.isfinite(auc) else 0.0)
            + ALPHA_SCORE_WEIGHTS["PR_AUC"] * (ap if np.isfinite(ap) else 0.0)
            + ALPHA_SCORE_WEIGHTS["F1"] * (f1 if np.isfinite(f1) else 0.0)
            + ALPHA_SCORE_WEIGHTS["Recall"] * (rec if np.isfinite(rec) else 0.0)
            + ALPHA_SCORE_WEIGHTS["Brier"] * (br if np.isfinite(br) else 1.0)
        )
        score = base_score - ALPHA_COMPLEXITY_PENALTY * float(alpha)
        alpha_rows.append({
            "alpha_gnn": alpha,
            "alpha_rf": 1 - alpha,
            "AUC": auc,
            "PR_AUC": ap,
            "F1": f1,
            "Recall": rec,
            "Brier": br,
            "BaseRobustAlphaScore": base_score,
            "AlphaComplexityPenalty": ALPHA_COMPLEXITY_PENALTY * float(alpha),
            "RobustAlphaScore": score,
            "SafeScore": score,
            "AlphaGNNMaxFinal": ALPHA_GNN_MAX_FINAL,
        })
        if score > best_alpha_score:
            best_alpha_score = score
            best_alpha = float(alpha)

    alpha_table = pd.DataFrame(alpha_rows)

    # Force alpha for ablation settings if requested.
    if str(alpha_mode).lower() in ["gnn_only", "no_rf", "1", "1.0"]:
        best_alpha = 1.0
    elif str(alpha_mode).lower() in ["rf_only", "rf", "0", "0.0"]:
        best_alpha = 0.0
    elif str(alpha_mode).lower() not in ["select", "auto"]:
        try:
            best_alpha = float(alpha_mode)
        except Exception:
            pass
    # For the final selected model we keep alpha within the conservative RF-stabilized range.
    # Ablation modes (gnn_only / rf_only / fixed values) are allowed to override this.
    if str(alpha_mode).lower() in ["select", "auto"]:
        best_alpha = float(np.clip(best_alpha, 0.0, ALPHA_GNN_MAX_FINAL))
    else:
        best_alpha = float(np.clip(best_alpha, 0.0, 1.0))
    alpha_table["Selected_alpha_gnn"] = best_alpha
    alpha_table["Variant"] = variant_name
    alpha_table["SelectedAnchorModel"] = selected_anchor_name
    alpha_table["AnchorMode"] = anchor_mode

    # Optional safe calibration of the selected blended probability, based only on the internal validation split.
    p_blend_val_selected = best_alpha * p_gnn_val + (1 - best_alpha) * p_rf_val
    if USE_SAFE_BLEND_CALIBRATION:
        blend_calibrator, blend_calibration_table = fit_safe_blend_calibrator(y_all[idx_val], p_blend_val_selected)
    else:
        blend_calibrator = {"method": "none", "model": None}
        blend_calibration_table = pd.DataFrame([{
            "CalibrationMethod": "none", "Selected": True
        }])
    blend_calibration_table["Variant"] = variant_name
    blend_calibration_table["Selected_alpha_gnn"] = best_alpha
    blend_calibration_table["SelectedAnchorModel"] = selected_anchor_name
    blend_calibration_table["AnchorMode"] = anchor_mode

    # Refit the same v4/v5 anchor mode on all training data
    rf_final = fit_tree_anchor_final_by_mode(
        selected_anchor_name,
        pd.DataFrame(X_all, columns=FEATURE_VARS),
        y_all,
        sample_weight=sample_weight,
        anchor_mode=anchor_mode
    )

    package = {
        "model": model,
        "rf_anchor": rf_final,
        "selected_anchor_name": selected_anchor_name,
        "anchor_mode": anchor_mode,
        "anchor_selection_table": anchor_selection_table,
        "preprocessor_placeholder": None,
        "coord_mu": coord_mu,
        "coord_sd": coord_sd,
        "alpha_gnn": best_alpha,
        "alpha_rf": 1.0 - best_alpha,
        "edge_index_train": edge_index_np,
        "edge_weight_train": edge_weight_np,
        "edges_train_df": edges_df,
        "history": pd.DataFrame(history_rows),
        "alpha_table": alpha_table,
        "blend_calibrator": blend_calibrator,
        "blend_calibration_table": blend_calibration_table,
        "best_epoch": best_epoch,
        "best_val_auc": best_val_auc,
        "train_context_weights": context_weights,
        "train_context_logits": context_logits,
        "train_p_gnn": p_gnn_all,
        "train_p_rf_anchor_internal": rf_prob_train_all,
        "train_idx_internal": idx_tr,
        "val_idx_internal": idx_val,
        "variant_name": variant_name,
        "context_groups": CONTEXT_GROUPS if context_groups_override is None else context_groups_override,
        "context_order": ctx_order,
        "k_spatial": k_spatial,
        "k_context": k_context,
        "eta_spatial": eta_spatial,
        "use_graph": use_graph,
        "use_wrl": use_wrl,
        "use_global_branch": use_global_branch,
        "alpha_mode": alpha_mode,
    }
    return package


def predict_rf_stabilized_hydrocontex_gnnwrl_package(package, feature_scaled_df: pd.DataFrame, df_meta: pd.DataFrame):
    """
    Predict for a set of nodes. Build graph within this prediction set by city.
    This is inductive enough for holdout/test because labels are not used.
    """
    X = feature_scaled_df[FEATURE_VARS].values.astype(np.float32)
    coords = df_meta[["x", "y"]].to_numpy(dtype=float)
    city = df_meta["City"].astype(str).to_numpy()

    edge_index_np, edge_weight_np, edges_df = build_knn_edges_by_city(
        coords=coords,
        X_context=X,
        city=city,
        k_spatial=package.get("k_spatial", K_SPATIAL),
        k_context=package.get("k_context", K_CONTEXT),
        eta_spatial=package.get("eta_spatial", GRAPH_ETA_SPATIAL),
    )
    coords_norm = (coords - package["coord_mu"]) / package["coord_sd"]
    x_t, c_t, edge_i_t, edge_w_t, _ = tensorize_graph(X, coords_norm, edge_index_np, edge_weight_np, y=None)

    model = package["model"]
    model.eval()
    with torch.no_grad():
        logit, details = model(x_t, c_t, edge_i_t, edge_w_t, return_details=True)
        p_gnn = torch.sigmoid(logit).detach().cpu().numpy()
        context_weights = details["context_weights"].detach().cpu().numpy()
        context_logits = details["context_logits"].detach().cpu().numpy()

    p_rf = package["rf_anchor"].predict_proba(pd.DataFrame(X, columns=FEATURE_VARS))[:, 1]
    alpha = package["alpha_gnn"]
    p_uncalibrated = alpha * p_gnn + (1 - alpha) * p_rf
    p_uncalibrated = np.clip(p_uncalibrated, 1e-6, 1 - 1e-6)
    calibrator_info = package.get("blend_calibrator", {"method": "none", "model": None})
    p_final = apply_probability_calibrator(p_uncalibrated, calibrator_info)
    p_final = np.clip(p_final, 1e-6, 1 - 1e-6)

    extra = {
        "P_gnnwrl": p_gnn,
        "P_rf_anchor": p_rf,
        "P_blend_uncalibrated": p_uncalibrated,
        "P_blend_calibrated": p_final,
        "CalibrationMethod": np.full(len(p_final), str(calibrator_info.get("method", "none"))),
        "alpha_gnn": np.full(len(p_final), alpha),
        "alpha_rf": np.full(len(p_final), 1 - alpha),
    }
    for i, cname in enumerate(package.get("context_order", CONTEXT_ORDER)):
        extra[f"WRL_weight_{cname}"] = context_weights[:, i]
        extra[f"context_logit_{cname}"] = context_logits[:, i]

    return p_final, extra, edges_df


# =========================================================
# 6. Traditional model pool
# =========================================================

def make_traditional_models():
    models = {}
    models["Dummy"] = DummyClassifier(strategy="stratified", random_state=RANDOM_STATE)
    models["LogisticRegression"] = LogisticRegression(
        max_iter=2000, class_weight="balanced", random_state=RANDOM_STATE
    )
    models["GaussianNB"] = GaussianNB()
    models["KNN"] = KNeighborsClassifier(n_neighbors=15, weights="distance")
    models["DecisionTree"] = DecisionTreeClassifier(
        max_depth=None, min_samples_leaf=5, class_weight="balanced", random_state=RANDOM_STATE
    )
    models["RandomForest"] = RandomForestClassifier(
        n_estimators=800, max_features="sqrt", min_samples_leaf=2,
        class_weight="balanced_subsample", random_state=RANDOM_STATE, n_jobs=-1
    )
    models["ExtraTrees"] = ExtraTreesClassifier(
        n_estimators=800, max_features="sqrt", min_samples_leaf=2,
        class_weight="balanced", random_state=RANDOM_STATE, n_jobs=-1
    )
    models["GradientBoosting"] = GradientBoostingClassifier(
        n_estimators=400, learning_rate=0.035, max_depth=3, random_state=RANDOM_STATE
    )
    models["HGB_Default"] = HistGradientBoostingClassifier(random_state=RANDOM_STATE)
    models["HGB_Tuned"] = HistGradientBoostingClassifier(
        max_iter=500, learning_rate=0.035, max_leaf_nodes=31,
        l2_regularization=0.01, min_samples_leaf=15,
        random_state=RANDOM_STATE
    )
    try:
        models["BaggingTree"] = BaggingClassifier(
            estimator=DecisionTreeClassifier(min_samples_leaf=5, random_state=RANDOM_STATE),
            n_estimators=300, random_state=RANDOM_STATE, n_jobs=-1
        )
    except TypeError:
        models["BaggingTree"] = BaggingClassifier(
            base_estimator=DecisionTreeClassifier(min_samples_leaf=5, random_state=RANDOM_STATE),
            n_estimators=300, random_state=RANDOM_STATE, n_jobs=-1
        )
    models["AdaBoost"] = AdaBoostClassifier(
        n_estimators=400, learning_rate=0.035, random_state=RANDOM_STATE
    )
    models["SVM_Linear"] = SVC(
        kernel="linear", C=1.0, probability=True, class_weight="balanced", random_state=RANDOM_STATE
    )
    models["SVM_RBF"] = SVC(
        kernel="rbf", C=1.0, gamma="scale", probability=True, class_weight="balanced", random_state=RANDOM_STATE
    )
    models["MLP"] = MLPClassifier(
        hidden_layer_sizes=(128, 64), alpha=0.0005, learning_rate_init=0.001,
        max_iter=600, random_state=RANDOM_STATE
    )

    try:
        from xgboost import XGBClassifier
        models["XGBoost"] = XGBClassifier(
            n_estimators=700, max_depth=4, learning_rate=0.025,
            subsample=0.85, colsample_bytree=0.85,
            objective="binary:logistic", eval_metric="logloss",
            random_state=RANDOM_STATE, n_jobs=-1
        )
    except Exception as e:
        log(f"[Skip XGBoost] {e}")

    try:
        from lightgbm import LGBMClassifier
        models["LightGBM"] = LGBMClassifier(
            n_estimators=700, learning_rate=0.025, num_leaves=31,
            subsample=0.85, colsample_bytree=0.85,
            class_weight="balanced", random_state=RANDOM_STATE, n_jobs=-1
        )
    except Exception as e:
        log(f"[Skip LightGBM] {e}")

    try:
        from catboost import CatBoostClassifier
        models["CatBoost"] = CatBoostClassifier(
            iterations=700, learning_rate=0.025, depth=5,
            loss_function="Logloss", eval_metric="AUC",
            random_seed=RANDOM_STATE, verbose=False
        )
    except Exception as e:
        log(f"[Skip CatBoost] {e}")

    return models


def fit_predict_traditional(model, X_train, y_train, X_test, sample_weight=None):
    try:
        if sample_weight is not None:
            model.fit(X_train, y_train, sample_weight=sample_weight)
        else:
            model.fit(X_train, y_train)
    except TypeError:
        model.fit(X_train, y_train)

    if hasattr(model, "predict_proba"):
        prob = model.predict_proba(X_test)[:, 1]
    else:
        # fallback using decision_function
        score = model.decision_function(X_test)
        prob = sigmoid_np(score)
    return model, np.clip(prob, 1e-6, 1 - 1e-6)


# =========================================================
# 7. Experiment runners
# =========================================================

GLOBAL_ARTIFACTS = {
    "metrics": [],
    "predictions": [],
    "roc": [],
    "pr": [],
    "confusion": [],
    "threshold": [],
    "optimal_threshold": [],
    "calibration": [],
    "blend_calibration_selection": [],
    "citywise": [],
    "cv_fold_metrics": [],
    "cv_summary": [],
    "loco_source_thresholds": [],
    "loco_source_threshold_metrics": [],
    "loco_source_threshold_summary": [],
}


def add_artifacts(metrics, pred, roc, pr, cm, th, opt, cal, city):
    GLOBAL_ARTIFACTS["metrics"].append(pd.DataFrame([metrics]))
    if pred is not None and len(pred):
        GLOBAL_ARTIFACTS["predictions"].append(pred)
    if roc is not None and len(roc):
        GLOBAL_ARTIFACTS["roc"].append(roc)
    if pr is not None and len(pr):
        GLOBAL_ARTIFACTS["pr"].append(pr)
    if cm is not None and len(cm):
        GLOBAL_ARTIFACTS["confusion"].append(cm)
    if th is not None and len(th):
        GLOBAL_ARTIFACTS["threshold"].append(th)
    if opt is not None and len(opt):
        GLOBAL_ARTIFACTS["optimal_threshold"].append(opt)
    if cal is not None and len(cal):
        GLOBAL_ARTIFACTS["calibration"].append(cal)
    if city is not None and len(city):
        GLOBAL_ARTIFACTS["citywise"].append(city)


def run_holdout(df, X_scaled, preprocessor):
    log("\n========== HOLDOUT experiment ==========")
    out_dir = ensure_dir(os.path.join(OUT_DIR, "01_Holdout"))
    train_idx, test_idx = stratified_city_label_split(df, TEST_SIZE, RANDOM_STATE)

    y = df["label"].astype(int).to_numpy()
    y_train, y_test = y[train_idx], y[test_idx]

    meta_test = df.iloc[test_idx][["sample_id", "City", "x", "y", "lon", "lat", "label"]].copy()
    sw_train = compute_balanced_sample_weight(y_train, city=df.iloc[train_idx]["City"].values)

    # Traditional models
    models = make_traditional_models()
    X_train = X_scaled.iloc[train_idx].values
    X_test = X_scaled.iloc[test_idx].values

    for name, model in models.items():
        log(f"[Holdout] Train traditional: {name}")
        try:
            fitted, prob = fit_predict_traditional(model, X_train, y_train, X_test, sample_weight=sw_train)
            prefix = os.path.join(out_dir, f"Holdout_{name}")
            artifacts = save_eval_artifacts(
                y_test, prob, meta_test, name, "Holdout", prefix, threshold=0.5
            )
            add_artifacts(*artifacts)
        except Exception as e:
            log(f"[Holdout Failed] {name}: {e}")
            GLOBAL_ARTIFACTS["metrics"].append(pd.DataFrame([{
                "Model": name, "Experiment": "Holdout", "Error": str(e)
            }]))

    # v4/v5 neural variants
    for variant in NEURAL_COMPARISON_VARIANTS:
        name = variant["name"]
        anchor_mode = variant["anchor_mode"]
        log(f"[Holdout] Train neural: {name} | anchor_mode={anchor_mode}")
        try:
            package = train_rf_stabilized_hydrocontex_gnnwrl(
                df_train=df.iloc[train_idx].reset_index(drop=True),
                feature_train_scaled=X_scaled.iloc[train_idx].reset_index(drop=True),
                y_train=y_train,
                train_meta=df.iloc[train_idx].reset_index(drop=True),
                sample_weight=sw_train,
                verbose=False,
                variant_name=name,
                anchor_mode=anchor_mode,
            )
            prob, extra, edges_df = predict_rf_stabilized_hydrocontex_gnnwrl_package(
                package,
                X_scaled.iloc[test_idx].reset_index(drop=True),
                df.iloc[test_idx].reset_index(drop=True)
            )
            prefix = os.path.join(out_dir, f"Holdout_{name}")
            artifacts = save_eval_artifacts(
                y_test, prob, meta_test, name, "Holdout", prefix, threshold=0.5, extra_cols=extra
            )
            add_artifacts(*artifacts)

            # Save holdout training details per variant
            package["history"].to_csv(os.path.join(out_dir, f"Holdout_{name}_training_history.csv"),
                                      index=False, encoding="utf-8-sig")
            package["alpha_table"].to_csv(os.path.join(out_dir, f"Holdout_{name}_alpha_selection.csv"),
                                          index=False, encoding="utf-8-sig")
            package.get("blend_calibration_table", pd.DataFrame()).to_csv(
                os.path.join(out_dir, f"Holdout_{name}_blend_calibration_selection.csv"),
                index=False, encoding="utf-8-sig"
            )
            if len(package.get("blend_calibration_table", pd.DataFrame())):
                GLOBAL_ARTIFACTS["blend_calibration_selection"].append(package["blend_calibration_table"])
            package["anchor_selection_table"].to_csv(os.path.join(out_dir, f"Holdout_{name}_anchor_table.csv"),
                                                     index=False, encoding="utf-8-sig")
            edges_df.to_csv(os.path.join(out_dir, f"Holdout_{name}_test_graph_edges.csv"),
                            index=False, encoding="utf-8-sig")

            log(f"[Holdout] {name}: anchor={package['selected_anchor_name']} alpha_gnn={package['alpha_gnn']:.2f}, alpha_rf={package['alpha_rf']:.2f}")
        except Exception as e:
            log(f"[Holdout Failed] {name}: {e}")
            GLOBAL_ARTIFACTS["metrics"].append(pd.DataFrame([{
                "Model": name, "Experiment": "Holdout", "Error": str(e)
            }]))

    return train_idx, test_idx


def cv_splits_ordinary(df):
    y = df["label"].astype(int).to_numpy()
    skf = StratifiedKFold(n_splits=N_SPLITS_CV, shuffle=True, random_state=RANDOM_STATE)
    return list(skf.split(np.arange(len(df)), y))


def cv_splits_spatial(df, grid_n=SPATIAL_GRID_N):
    block = make_spatial_blocks(df, grid_n=grid_n)
    df = df.copy()
    df[f"SpatialBlock_G{grid_n}"] = block.values
    blocks = df[f"SpatialBlock_G{grid_n}"].to_numpy()
    y = df["label"].astype(int).to_numpy()

    # GroupKFold on blocks
    gkf = GroupKFold(n_splits=min(N_SPLITS_SPATIAL_CV, len(np.unique(blocks))))
    splits = list(gkf.split(np.arange(len(df)), y, groups=blocks))
    # Save block assignment for plotting
    block_df = df[["sample_id", "City", "x", "y", "lon", "lat", "label", f"SpatialBlock_G{grid_n}"]].copy()
    block_df.to_csv(os.path.join(PLOT_DIR, f"spatial_block_assignments_G{grid_n}.csv"),
                    index=False, encoding="utf-8-sig")
    # Save fold train/test assignment for spatial CV maps
    fold_rows = []
    for fold_no, (tr, te) in enumerate(splits, 1):
        tmp_train = df.iloc[tr][["sample_id", "City", "x", "y", "lon", "lat", "label"]].copy()
        tmp_train["Fold"] = f"fold_{fold_no}"
        tmp_train["Role"] = "train"
        tmp_test = df.iloc[te][["sample_id", "City", "x", "y", "lon", "lat", "label"]].copy()
        tmp_test["Fold"] = f"fold_{fold_no}"
        tmp_test["Role"] = "test"
        fold_rows.append(pd.concat([tmp_train, tmp_test], ignore_index=True))
    if fold_rows:
        pd.concat(fold_rows, ignore_index=True).to_csv(
            os.path.join(PLOT_DIR, f"spatial_cv_fold_train_test_assignments_G{grid_n}.csv"),
            index=False, encoding="utf-8-sig"
        )
    return splits


def cv_splits_loco(df):
    splits = []
    for city in sorted(df["City"].unique()):
        test_idx = df.index[df["City"] == city].to_numpy()
        train_idx = df.index[df["City"] != city].to_numpy()
        if len(np.unique(df.loc[test_idx, "label"])) < 2:
            log(f"[LOCO skip warning] {city} has only one label class.")
        splits.append((train_idx, test_idx, city))
    return splits



def is_loco_experiment(experiment_name: str) -> bool:
    return str(experiment_name).strip() == "Leave_One_City_Out_CV"


def source_internal_validation_split(df_source: pd.DataFrame, y_source: np.ndarray):
    """Create a source-city-only internal validation split for threshold selection.

    No held-out target-city labels are used. The split is stratified by city+label
    whenever possible, falling back to label stratification if rare strata exist.
    """
    idx = np.arange(len(df_source))
    y_source = np.asarray(y_source).astype(int)
    strat_key = df_source["City"].astype(str) + "_" + pd.Series(y_source, index=df_source.index).astype(str)
    if (strat_key.value_counts() < 2).any():
        strat = y_source
    else:
        strat = strat_key.to_numpy()
    tr, val = train_test_split(
        idx,
        test_size=SOURCE_THRESHOLD_VAL_SIZE,
        random_state=RANDOM_STATE + SOURCE_THRESHOLD_RANDOM_OFFSET,
        stratify=strat,
    )
    return tr, val


def source_validation_predictions_traditional(model_name: str, X_source: pd.DataFrame, y_source: np.ndarray, df_source: pd.DataFrame):
    """Fit a fresh traditional model on source-internal train and predict source-internal val."""
    models = make_traditional_models()
    if model_name not in models:
        return None, None, pd.DataFrame()
    tr, val = source_internal_validation_split(df_source.reset_index(drop=True), y_source)
    sw = compute_balanced_sample_weight(y_source[tr], city=df_source.iloc[tr]["City"].values)
    try:
        _, p_val = fit_predict_traditional(
            models[model_name],
            X_source.iloc[tr].values,
            y_source[tr],
            X_source.iloc[val].values,
            sample_weight=sw,
        )
        meta_val = df_source.iloc[val][["sample_id", "City", "x", "y", "lon", "lat", "label"]].copy().reset_index(drop=True)
        return y_source[val], p_val, meta_val
    except Exception as e:
        log(f"[Source threshold traditional failed] {model_name}: {e}")
        return None, None, pd.DataFrame()


def source_validation_predictions_neural_from_package(package: Dict, y_source: np.ndarray):
    """Use the neural package's source-internal validation split for threshold selection.

    This uses only source-city labels because the package was trained within the
    current outer fold. It is therefore valid for LOCO threshold repair.
    """
    try:
        val_idx = np.asarray(package.get("val_idx_internal"), dtype=int)
        p_gnn_all = np.asarray(package.get("train_p_gnn"), dtype=float)
        p_rf_all = np.asarray(package.get("train_p_rf_anchor_internal"), dtype=float)
        alpha = float(package.get("alpha_gnn", 0.0))
        p_val = alpha * p_gnn_all[val_idx] + (1.0 - alpha) * p_rf_all[val_idx]
        p_val = np.clip(p_val, 1e-6, 1 - 1e-6)
        p_val = apply_probability_calibrator(p_val, package.get("blend_calibrator", {"method": "none", "model": None}))
        return np.asarray(y_source)[val_idx], np.clip(p_val, 1e-6, 1 - 1e-6)
    except Exception as e:
        log(f"[Source threshold neural failed] {e}")
        return None, None


def make_source_threshold_table(y_source_val, p_source_val, model_name: str, experiment_name: str, fold_name: str):
    if y_source_val is None or p_source_val is None:
        return pd.DataFrame()
    if len(np.unique(y_source_val)) < 2:
        return pd.DataFrame()
    th_df = threshold_table(y_source_val, p_source_val, model_name, experiment_name)
    opt = optimal_thresholds_from_table(th_df)
    if opt.empty:
        return opt
    opt = opt.copy()
    opt["Fold"] = fold_name
    opt["ThresholdSource"] = "source_internal_validation"
    opt["SourceValidation_N"] = len(y_source_val)
    # Preserve source-validation metrics using explicit names to avoid confusion
    rename_map = {
        "Threshold": "SourceThreshold",
        "Accuracy": "Source_Accuracy",
        "Precision": "Source_Precision",
        "Recall": "Source_Recall",
        "Specificity": "Source_Specificity",
        "F1": "Source_F1",
        "Brier": "Source_Brier",
        "AUC": "Source_AUC",
        "PR_AUC": "Source_PR_AUC",
        "ECE": "Source_ECE",
        "MCE": "Source_MCE",
        "TN": "Source_TN",
        "FP": "Source_FP",
        "FN": "Source_FN",
        "TP": "Source_TP",
    }
    opt = opt.rename(columns={k: v for k, v in rename_map.items() if k in opt.columns})
    return opt


def evaluate_test_with_source_thresholds(y_test, p_test, source_threshold_df, model_name: str, experiment_name: str, fold_name: str):
    rows = []
    if source_threshold_df is None or source_threshold_df.empty:
        return pd.DataFrame(rows)
    for _, r in source_threshold_df.iterrows():
        if "SourceThreshold" not in r or pd.isna(r["SourceThreshold"]):
            continue
        th = float(r["SourceThreshold"])
        mt = metrics_at_threshold(y_test, p_test, threshold=th)
        mt["Model"] = model_name
        mt["Experiment"] = experiment_name
        mt["Fold"] = fold_name
        mt["ThresholdSource"] = "source_internal_validation"
        mt["ThresholdCriterion"] = r.get("Criterion", "unknown")
        mt["AppliedThreshold"] = th
        # Attach source-validation operating point for transparency
        for c in source_threshold_df.columns:
            if str(c).startswith("Source_") or c in ["SourceValidation_N"]:
                mt[c] = r.get(c, np.nan)
        rows.append(mt)
    return pd.DataFrame(rows)


def save_loco_source_threshold_artifacts(out_dir, experiment_name, fold_name, model_name, source_df, test_df):
    if source_df is not None and not source_df.empty:
        p = os.path.join(out_dir, f"{experiment_name}_{fold_name}_{model_name}_source_internal_thresholds.csv")
        source_df.to_csv(p, index=False, encoding="utf-8-sig")
        GLOBAL_ARTIFACTS["loco_source_thresholds"].append(source_df)
    if test_df is not None and not test_df.empty:
        p = os.path.join(out_dir, f"{experiment_name}_{fold_name}_{model_name}_source_threshold_test_metrics.csv")
        test_df.to_csv(p, index=False, encoding="utf-8-sig")
        GLOBAL_ARTIFACTS["loco_source_threshold_metrics"].append(test_df)



def fit_source_only_sigmoid_calibrator(y_source_val, p_source_val):
    """Fit a source-city-only Platt/sigmoid calibrator for LOCO transfer.

    The calibrator is fitted only on source-city internal validation predictions.
    Held-out target-city labels are never used. This repairs probability-scale
    shifts without changing the main RF-stabilized Hydro-ConTex GNNWRL model.
    """
    if y_source_val is None or p_source_val is None:
        return {"method": "none", "model": None}, pd.DataFrame()
    y_source_val = np.asarray(y_source_val).astype(int)
    p_source_val = np.clip(np.asarray(p_source_val, dtype=float), 1e-6, 1 - 1e-6)
    if len(y_source_val) < 10 or len(np.unique(y_source_val)) < 2:
        return {"method": "none", "model": None}, pd.DataFrame()

    rows = []
    base_auc = safe_auc(y_source_val, p_source_val)
    base_ap = safe_ap(y_source_val, p_source_val)
    base_brier = brier_score_loss(y_source_val, p_source_val)
    base_ece, _, _ = expected_calibration_error(y_source_val, p_source_val, n_bins=10)
    base_score = (base_auc if np.isfinite(base_auc) else 0.0) + 0.05 * (base_ap if np.isfinite(base_ap) else 0.0) - 0.35 * base_brier - 0.10 * base_ece
    rows.append({
        "SourceCalibrationMode": "none", "AUC": base_auc, "PR_AUC": base_ap,
        "Brier": base_brier, "ECE": base_ece, "CalibrationScore": base_score, "Selected": False
    })
    best = {"method": "none", "model": None}
    best_score = base_score

    if "sigmoid" in LOCO_SOURCE_CALIBRATION_METHODS:
        try:
            sig = LogisticRegression(max_iter=1000, solver="lbfgs")
            sig.fit(logit_np(p_source_val).reshape(-1, 1), y_source_val)
            p_sig = sig.predict_proba(logit_np(p_source_val).reshape(-1, 1))[:, 1]
            auc = safe_auc(y_source_val, p_sig)
            ap = safe_ap(y_source_val, p_sig)
            br = brier_score_loss(y_source_val, p_sig)
            ece, _, _ = expected_calibration_error(y_source_val, p_sig, n_bins=10)
            if np.isfinite(base_auc) and np.isfinite(auc) and auc < base_auc - CALIBRATION_AUC_TOLERANCE:
                score = -np.inf
            else:
                score = (auc if np.isfinite(auc) else 0.0) + 0.05 * (ap if np.isfinite(ap) else 0.0) - 0.35 * br - 0.10 * ece
            rows.append({
                "SourceCalibrationMode": "sigmoid", "AUC": auc, "PR_AUC": ap,
                "Brier": br, "ECE": ece, "CalibrationScore": score, "Selected": False
            })
            if score > best_score + 1e-8:
                best = {"method": "sigmoid", "model": sig}
                best_score = score
        except Exception as e:
            rows.append({"SourceCalibrationMode": "sigmoid", "Error": str(e), "CalibrationScore": -np.inf, "Selected": False})

    table = pd.DataFrame(rows)
    if not table.empty:
        table["Selected"] = table["SourceCalibrationMode"].eq(str(best.get("method", "none")))
    return best, table


def append_loco_source_repair_rows(out_dir, experiment_name, fold_name, model_name,
                                   y_src_val, p_src_val, y_test, p_test,
                                   loco_source_threshold_rows, loco_source_metric_rows,
                                   extra_diag: Optional[Dict] = None):
    """Append LOCO source-threshold rows for both uncalibrated and source-calibrated probabilities."""
    if y_src_val is None or p_src_val is None:
        return
    extra_diag = extra_diag or {}

    # Uncalibrated source-threshold repair.
    src_th = make_source_threshold_table(y_src_val, p_src_val, model_name, experiment_name, fold_name)
    test_src_metrics = evaluate_test_with_source_thresholds(y_test, p_test, src_th, model_name, experiment_name, fold_name)
    if not src_th.empty:
        src_th["SourceCalibrationMode"] = "none"
        for k, v in extra_diag.items():
            src_th[k] = v
    if not test_src_metrics.empty:
        test_src_metrics["SourceCalibrationMode"] = "none"
        test_src_metrics["ProbabilityUsedForTest"] = "uncalibrated_outer_test_probability"
        for k, v in extra_diag.items():
            test_src_metrics[k] = v
    save_loco_source_threshold_artifacts(out_dir, experiment_name, fold_name, model_name, src_th, test_src_metrics)
    if not src_th.empty:
        loco_source_threshold_rows.append(src_th)
    if not test_src_metrics.empty:
        loco_source_metric_rows.append(test_src_metrics)

    # Source-only sigmoid calibration repair.
    if RUN_LOCO_SOURCE_CALIBRATION_REPAIR:
        cal_info, cal_table = fit_source_only_sigmoid_calibrator(y_src_val, p_src_val)
        cal_method = str(cal_info.get("method", "none"))
        if not cal_table.empty:
            cal_table = cal_table.copy()
            cal_table["Experiment"] = experiment_name
            cal_table["Model"] = model_name
            cal_table["Fold"] = fold_name
            for k, v in extra_diag.items():
                cal_table[k] = v
            cal_table.to_csv(
                os.path.join(out_dir, f"{experiment_name}_{fold_name}_{model_name}_source_calibration_selection.csv"),
                index=False, encoding="utf-8-sig"
            )
        if cal_method != "none":
            p_src_cal = apply_probability_calibrator(p_src_val, cal_info)
            p_test_cal = apply_probability_calibrator(p_test, cal_info)
            src_th_cal = make_source_threshold_table(y_src_val, p_src_cal, model_name, experiment_name, fold_name)
            test_src_metrics_cal = evaluate_test_with_source_thresholds(y_test, p_test_cal, src_th_cal, model_name, experiment_name, fold_name)
            if not src_th_cal.empty:
                src_th_cal["SourceCalibrationMode"] = cal_method
                for k, v in extra_diag.items():
                    src_th_cal[k] = v
            if not test_src_metrics_cal.empty:
                test_src_metrics_cal["SourceCalibrationMode"] = cal_method
                test_src_metrics_cal["ProbabilityUsedForTest"] = f"source_{cal_method}_calibrated_outer_test_probability"
                for k, v in extra_diag.items():
                    test_src_metrics_cal[k] = v
            save_loco_source_threshold_artifacts(
                out_dir, experiment_name, fold_name, f"{model_name}_source_{cal_method}_cal", src_th_cal, test_src_metrics_cal
            )
            if not src_th_cal.empty:
                loco_source_threshold_rows.append(src_th_cal)
            if not test_src_metrics_cal.empty:
                loco_source_metric_rows.append(test_src_metrics_cal)

def run_cv_for_selected_models(df, X_scaled, experiment_name, splits, use_neural=True, selected_trad=None):
    log(f"\n========== {experiment_name} ==========")
    out_dir = ensure_dir(os.path.join(OUT_DIR, "02_CV", experiment_name.replace(" ", "_")))

    y_all = df["label"].astype(int).to_numpy()
    if selected_trad is None:
        selected_trad = ["RandomForest", "ExtraTrees", "HGB_Tuned", "CatBoost", "XGBoost", "LightGBM"]

    fold_metrics_rows = []
    loco_source_metric_rows = []
    loco_source_threshold_rows = []
    do_loco_source_repair = RUN_LOCO_SOURCE_THRESHOLD_REPAIR and is_loco_experiment(experiment_name)

    for fold_no, split in enumerate(splits, 1):
        if len(split) == 3:
            train_idx, test_idx, fold_name = split
        else:
            train_idx, test_idx = split
            fold_name = f"fold_{fold_no}"

        y_train, y_test = y_all[train_idx], y_all[test_idx]
        if len(np.unique(y_train)) < 2 or len(np.unique(y_test)) < 2:
            log(f"[{experiment_name}] skip {fold_name}: one-class train or test.")
            continue

        source_df_for_threshold = df.iloc[train_idx].reset_index(drop=True)
        X_source_for_threshold = X_scaled.iloc[train_idx].reset_index(drop=True)
        meta_test = df.iloc[test_idx][["sample_id", "City", "x", "y", "lon", "lat", "label"]].copy()
        meta_test["Fold"] = fold_name
        sw_train = compute_balanced_sample_weight(y_train, city=df.iloc[train_idx]["City"].values)

        # Traditional selected models
        models = make_traditional_models()
        for name in selected_trad:
            if name not in models:
                continue
            log(f"[{experiment_name}] {fold_name}: {name}")
            try:
                _, prob = fit_predict_traditional(
                    models[name],
                    X_scaled.iloc[train_idx].values,
                    y_train,
                    X_scaled.iloc[test_idx].values,
                    sample_weight=sw_train
                )
                prefix = os.path.join(out_dir, f"{experiment_name}_{fold_name}_{name}")
                artifacts = save_eval_artifacts(
                    y_test, prob, meta_test, name, experiment_name, prefix, threshold=0.5
                )
                add_artifacts(*artifacts)
                m = artifacts[0]
                m["Fold"] = fold_name
                fold_metrics_rows.append(m)

                # LOCO repair: source-city-only threshold/calibration selection, applied to held-out city.
                if do_loco_source_repair:
                    y_src_val, p_src_val, _ = source_validation_predictions_traditional(
                        name, X_source_for_threshold, y_train, source_df_for_threshold
                    )
                    append_loco_source_repair_rows(
                        out_dir, experiment_name, fold_name, name,
                        y_src_val, p_src_val, y_test, prob,
                        loco_source_threshold_rows, loco_source_metric_rows,
                        extra_diag={"ModelFamily": "traditional"}
                    )
            except Exception as e:
                log(f"[CV Failed] {experiment_name} {fold_name} {name}: {e}")

        # v4/v5 neural variants
        if use_neural:
            for variant in NEURAL_COMPARISON_VARIANTS:
                name = variant["name"]
                anchor_mode = variant["anchor_mode"]
                log(f"[{experiment_name}] {fold_name}: {name} | anchor_mode={anchor_mode}")
                try:
                    package = train_rf_stabilized_hydrocontex_gnnwrl(
                        df_train=df.iloc[train_idx].reset_index(drop=True),
                        feature_train_scaled=X_scaled.iloc[train_idx].reset_index(drop=True),
                        y_train=y_train,
                        train_meta=df.iloc[train_idx].reset_index(drop=True),
                        sample_weight=sw_train,
                        verbose=False,
                        variant_name=name,
                        anchor_mode=anchor_mode,
                    )
                    prob, extra, _ = predict_rf_stabilized_hydrocontex_gnnwrl_package(
                        package,
                        X_scaled.iloc[test_idx].reset_index(drop=True),
                        df.iloc[test_idx].reset_index(drop=True)
                    )
                    prefix = os.path.join(out_dir, f"{experiment_name}_{fold_name}_{name}")
                    artifacts = save_eval_artifacts(
                        y_test, prob, meta_test, name, experiment_name, prefix, threshold=0.5, extra_cols=extra
                    )
                    add_artifacts(*artifacts)
                    m = artifacts[0]
                    m["Fold"] = fold_name
                    m["alpha_gnn"] = package["alpha_gnn"]
                    m["alpha_rf"] = package["alpha_rf"]
                    m["AnchorMode"] = anchor_mode
                    m["SelectedAnchorModel"] = package["selected_anchor_name"]
                    fold_metrics_rows.append(m)

                    # LOCO repair for the neural model: use the package's internal source-city validation split.
                    if do_loco_source_repair:
                        y_src_val, p_src_val = source_validation_predictions_neural_from_package(package, y_train)
                        append_loco_source_repair_rows(
                            out_dir, experiment_name, fold_name, name,
                            y_src_val, p_src_val, y_test, prob,
                            loco_source_threshold_rows, loco_source_metric_rows,
                            extra_diag={
                                "ModelFamily": "rf_stabilized_gnnwrl",
                                "alpha_gnn": package.get("alpha_gnn", np.nan),
                                "alpha_rf": package.get("alpha_rf", np.nan),
                                "SelectedAnchorModel": package.get("selected_anchor_name", "")
                            }
                        )
                except Exception as e:
                    log(f"[CV Neural Failed] {experiment_name} {fold_name} {name}: {e}")

    fold_df = pd.DataFrame(fold_metrics_rows)
    fold_df.to_csv(os.path.join(out_dir, f"{experiment_name}_fold_metrics.csv"), index=False, encoding="utf-8-sig")
    if not fold_df.empty:
        summary = fold_df.groupby(["Experiment", "Model"]).agg(
            AUC_mean=("AUC", "mean"),
            AUC_std=("AUC", "std"),
            PR_AUC_mean=("PR_AUC", "mean"),
            PR_AUC_std=("PR_AUC", "std"),
            F1_mean=("F1", "mean"),
            F1_std=("F1", "std"),
            Recall_mean=("Recall", "mean"),
            Brier_mean=("Brier", "mean"),
            ECE_mean=("ECE", "mean"),
            N_folds=("Fold", "nunique"),
        ).reset_index()
        summary.to_csv(os.path.join(out_dir, f"{experiment_name}_summary_metrics.csv"),
                       index=False, encoding="utf-8-sig")
        GLOBAL_ARTIFACTS["cv_fold_metrics"].append(fold_df)
        GLOBAL_ARTIFACTS["cv_summary"].append(summary)

    # Save LOCO threshold-repaired summaries separately. These are NOT based on target-city labels.
    if do_loco_source_repair and loco_source_metric_rows:
        src_metrics_df = pd.concat(loco_source_metric_rows, ignore_index=True)
        src_metrics_df.to_csv(
            os.path.join(out_dir, f"{experiment_name}_source_threshold_test_metrics_all.csv"),
            index=False, encoding="utf-8-sig"
        )
        group_cols = ["Experiment", "Model", "ThresholdCriterion"]
        if "SourceCalibrationMode" in src_metrics_df.columns:
            group_cols.append("SourceCalibrationMode")
        if "ProbabilityUsedForTest" in src_metrics_df.columns:
            group_cols.append("ProbabilityUsedForTest")
        src_summary = src_metrics_df.groupby(group_cols).agg(
            AUC_mean=("AUC", "mean"),
            AUC_std=("AUC", "std"),
            PR_AUC_mean=("PR_AUC", "mean"),
            PR_AUC_std=("PR_AUC", "std"),
            F1_mean=("F1", "mean"),
            F1_std=("F1", "std"),
            Precision_mean=("Precision", "mean"),
            Recall_mean=("Recall", "mean"),
            Specificity_mean=("Specificity", "mean"),
            Brier_mean=("Brier", "mean"),
            ECE_mean=("ECE", "mean"),
            AppliedThreshold_mean=("AppliedThreshold", "mean"),
            AppliedThreshold_std=("AppliedThreshold", "std"),
            N_folds=("Fold", "nunique"),
        ).reset_index().sort_values(["ThresholdCriterion", "AUC_mean"], ascending=[True, False])
        src_summary.to_csv(
            os.path.join(out_dir, f"{experiment_name}_source_threshold_summary_metrics.csv"),
            index=False, encoding="utf-8-sig"
        )
        GLOBAL_ARTIFACTS["loco_source_threshold_summary"].append(src_summary)

    if do_loco_source_repair and loco_source_threshold_rows:
        src_thresholds_df = pd.concat(loco_source_threshold_rows, ignore_index=True)
        src_thresholds_df.to_csv(
            os.path.join(out_dir, f"{experiment_name}_source_thresholds_by_fold.csv"),
            index=False, encoding="utf-8-sig"
        )

    return fold_df



def neural_variant_configs():
    """
    v9 module-validation ablation design.

    The final manuscript model is deliberately simple and defensible:
      RF anchor + Hydro-ConTex grouping + spatial graph + WRL local context weights.

    Two evidence chains are included:
      A. Constructive ablation: modules are added step by step.
      B. Deletion ablation: one key module is removed from the final model.

    This prevents the common reviewer criticism that every component is claimed to
    improve every metric. In the manuscript, RF anchor and spatial graph should be
    described as prediction/stability modules, while WRL and Hydro-ConTex grouping
    are primarily mechanism-interpretation modules.
    """
    configs = []

    # ---------- Constructive evidence chain ----------
    configs.append({
        "name": "C0_RF_Anchor_Only",
        "variant_name": "C0_RF_Anchor_Only",
        "anchor_mode": ANCHOR_MODE_V4_RF_ONLY,
        "alpha_mode": "rf_only",
        "k_spatial": 0,
        "k_context": 0,
        "eta_spatial": 1.0,
        "use_graph": False,
        "use_wrl": False,
        "use_global_branch": False,
        "context_groups_override": None,
        "ablation_role": "Constructive baseline: RandomForest probability anchor only",
        "evidence_chain": "constructive",
    })

    if RUN_CONSTRUCTIVE_ABLATION:
        configs.extend([
            {
                "name": "C1_RF_plus_HydroConTex_encoder_no_graph_no_WRL",
                "variant_name": "C1_RF_plus_HydroConTex_encoder_no_graph_no_WRL",
                "anchor_mode": ANCHOR_MODE_V4_RF_ONLY,
                "alpha_mode": "select",
                "k_spatial": 0,
                "k_context": 0,
                "eta_spatial": 1.0,
                "use_graph": False,
                "use_wrl": False,
                "use_global_branch": False,
                "context_groups_override": None,
                "ablation_role": "Adds Hydro-ConTex context encoders without spatial graph or WRL",
                "evidence_chain": "constructive",
            },
            {
                "name": "C2_RF_plus_HydroConTex_spatial_graph_no_WRL",
                "variant_name": "C2_RF_plus_HydroConTex_spatial_graph_no_WRL",
                "anchor_mode": ANCHOR_MODE_V4_RF_ONLY,
                "alpha_mode": "select",
                "k_spatial": K_SPATIAL,
                "k_context": 0,
                "eta_spatial": 1.0,
                "use_graph": True,
                "use_wrl": False,
                "use_global_branch": False,
                "context_groups_override": None,
                "ablation_role": "Adds spatial graph propagation; expected to improve Spatial CV robustness",
                "evidence_chain": "constructive",
            },
            {
                "name": MAIN_MODEL_NAME,
                "variant_name": MAIN_MODEL_NAME,
                "anchor_mode": ANCHOR_MODE_V4_RF_ONLY,
                "alpha_mode": "select",
                "k_spatial": K_SPATIAL,
                "k_context": 0,
                "eta_spatial": 1.0,
                "use_graph": True,
                "use_wrl": True,
                "use_global_branch": False,
                "context_groups_override": None,
                "ablation_role": "Full final model: RF anchor + spatial graph + WRL + Hydro-ConTex grouping",
                "evidence_chain": "constructive/full",
            },
        ])
    else:
        configs.append({
            "name": MAIN_MODEL_NAME,
            "variant_name": MAIN_MODEL_NAME,
            "anchor_mode": ANCHOR_MODE_V4_RF_ONLY,
            "alpha_mode": "select",
            "k_spatial": K_SPATIAL,
            "k_context": 0,
            "eta_spatial": 1.0,
            "use_graph": True,
            "use_wrl": True,
            "use_global_branch": False,
            "context_groups_override": None,
            "ablation_role": "Full final model",
            "evidence_chain": "full",
        })

    # ---------- Deletion ablations ----------
    configs.extend([
        {
            "name": "D1_GNNWRL_Only_without_RF_Stabilization",
            "variant_name": "D1_GNNWRL_Only_without_RF_Stabilization",
            "anchor_mode": ANCHOR_MODE_V4_RF_ONLY,
            "alpha_mode": "gnn_only",
            "k_spatial": K_SPATIAL,
            "k_context": 0,
            "eta_spatial": 1.0,
            "use_graph": True,
            "use_wrl": True,
            "use_global_branch": False,
            "context_groups_override": None,
            "ablation_role": "Deletion: tests contribution of RF-stabilized probability anchoring",
            "evidence_chain": "deletion",
        },
        {
            "name": "D2_w_o_spatial_graph",
            "variant_name": "D2_w_o_spatial_graph",
            "anchor_mode": ANCHOR_MODE_V4_RF_ONLY,
            "alpha_mode": "select",
            "k_spatial": 0,
            "k_context": 0,
            "eta_spatial": 1.0,
            "use_graph": False,
            "use_wrl": True,
            "use_global_branch": False,
            "context_groups_override": None,
            "ablation_role": "Deletion: tests contribution of spatial graph propagation",
            "evidence_chain": "deletion",
        },
        {
            "name": "D3_w_o_WRL_local_context_weights",
            "variant_name": "D3_w_o_WRL_local_context_weights",
            "anchor_mode": ANCHOR_MODE_V4_RF_ONLY,
            "alpha_mode": "select",
            "k_spatial": K_SPATIAL,
            "k_context": 0,
            "eta_spatial": 1.0,
            "use_graph": True,
            "use_wrl": False,
            "use_global_branch": False,
            "context_groups_override": None,
            "ablation_role": "Deletion: tests contribution of WRL; interpret mainly as local mechanism-weight module",
            "evidence_chain": "deletion",
        },
        {
            "name": "D4_w_o_HydroConTex_grouping_single_context_diagnostic",
            "variant_name": "D4_w_o_HydroConTex_grouping_single_context_diagnostic",
            "anchor_mode": ANCHOR_MODE_V4_RF_ONLY,
            "alpha_mode": "select",
            "k_spatial": K_SPATIAL,
            "k_context": 0,
            "eta_spatial": 1.0,
            "use_graph": True,
            "use_wrl": True,
            "use_global_branch": False,
            "context_groups_override": {"AllVariables": FEATURE_VARS},
            "ablation_role": "Diagnostic: Hydro-ConTex grouping is for mechanism-oriented interpretation, not claimed as isolated accuracy source",
            "evidence_chain": "diagnostic",
        },
    ])

    if RUN_CONTEXT_GRAPH_DIAGNOSTIC_IN_ABLATION:
        configs.append({
            "name": "Diag_with_HydroConTex_similarity_graph",
            "variant_name": "Diag_with_HydroConTex_similarity_graph",
            "anchor_mode": ANCHOR_MODE_V4_RF_ONLY,
            "alpha_mode": "select",
            "k_spatial": K_SPATIAL,
            "k_context": K_CONTEXT_DIAGNOSTIC,
            "eta_spatial": GRAPH_ETA_SPATIAL_DIAGNOSTIC,
            "use_graph": True,
            "use_wrl": True,
            "use_global_branch": False,
            "context_groups_override": None,
            "ablation_role": "Supplementary diagnostic only: Hydro-ConTex feature-similarity graph",
            "evidence_chain": "diagnostic",
        })

    if RUN_GLOBAL_BRANCH_DIAGNOSTIC:
        configs.append({
            "name": "Diag_with_global_branch",
            "variant_name": "Diag_with_global_branch",
            "anchor_mode": ANCHOR_MODE_V4_RF_ONLY,
            "alpha_mode": "select",
            "k_spatial": K_SPATIAL,
            "k_context": 0,
            "eta_spatial": 1.0,
            "use_graph": True,
            "use_wrl": True,
            "use_global_branch": True,
            "context_groups_override": None,
            "ablation_role": "Supplementary diagnostic only: global branch",
            "evidence_chain": "diagnostic",
        })

    # Drop accidental duplicate full model entries while preserving order.
    seen = set()
    unique = []
    for c in configs:
        if c["name"] not in seen:
            unique.append(c)
            seen.add(c["name"])
    return unique


def run_neural_ablation_holdout(df, X_scaled, preprocessor):
    log("\n========== ABLATION HOLDOUT experiment ==========")
    out_dir = ensure_dir(os.path.join(OUT_DIR, "03_Ablation_Holdout"))
    train_idx, test_idx = stratified_city_label_split(df, TEST_SIZE, RANDOM_STATE)

    y = df["label"].astype(int).to_numpy()
    y_train, y_test = y[train_idx], y[test_idx]
    meta_test = df.iloc[test_idx][["sample_id", "City", "x", "y", "lon", "lat", "label"]].copy()
    sw_train = compute_balanced_sample_weight(y_train, city=df.iloc[train_idx]["City"].values)

    rows = []
    for cfg in neural_variant_configs():
        name = cfg["name"]
        log(f"[Ablation Holdout] {name}")
        try:
            package = train_rf_stabilized_hydrocontex_gnnwrl(
                df_train=df.iloc[train_idx].reset_index(drop=True),
                feature_train_scaled=X_scaled.iloc[train_idx].reset_index(drop=True),
                y_train=y_train,
                train_meta=df.iloc[train_idx].reset_index(drop=True),
                sample_weight=sw_train,
                verbose=False,
                variant_name=cfg["variant_name"],
                context_groups_override=cfg["context_groups_override"],
                k_spatial=cfg["k_spatial"],
                k_context=cfg["k_context"],
                eta_spatial=cfg["eta_spatial"],
                use_graph=cfg["use_graph"],
                use_wrl=cfg["use_wrl"],
                use_global_branch=cfg["use_global_branch"],
                alpha_mode=cfg["alpha_mode"],
                anchor_mode=cfg.get("anchor_mode", ANCHOR_MODE_V4_RF_ONLY),
            )
            prob, extra, _ = predict_rf_stabilized_hydrocontex_gnnwrl_package(
                package,
                X_scaled.iloc[test_idx].reset_index(drop=True),
                df.iloc[test_idx].reset_index(drop=True)
            )
            prefix = os.path.join(out_dir, f"Ablation_Holdout_{name}")
            artifacts = save_eval_artifacts(
                y_test, prob, meta_test, name, "Ablation_Holdout", prefix, threshold=0.5, extra_cols=extra
            )
            add_artifacts(*artifacts)
            m = artifacts[0]
            m["alpha_gnn"] = package["alpha_gnn"]
            m["alpha_rf"] = package["alpha_rf"]
            m["Ablation_component"] = name
            m["Ablation_role"] = cfg.get("ablation_role", "")
            m["Evidence_chain"] = cfg.get("evidence_chain", "")
            rows.append(m)
        except Exception as e:
            log(f"[Ablation Failed] {name}: {e}")
            rows.append({"Model": name, "Experiment": "Ablation_Holdout", "Error": str(e)})
    pd.DataFrame(rows).to_csv(os.path.join(out_dir, "Ablation_Holdout_metrics.csv"), index=False, encoding="utf-8-sig")
    return pd.DataFrame(rows)


def run_neural_ablation_cv(df, X_scaled, experiment_name, splits):
    log(f"\n========== ABLATION {experiment_name} ==========")
    out_dir = ensure_dir(os.path.join(OUT_DIR, "04_Ablation_CV", experiment_name.replace(" ", "_")))
    y_all = df["label"].astype(int).to_numpy()
    rows = []
    for fold_no, split in enumerate(splits, 1):
        if len(split) == 3:
            train_idx, test_idx, fold_name = split
        else:
            train_idx, test_idx = split
            fold_name = f"fold_{fold_no}"
        y_train, y_test = y_all[train_idx], y_all[test_idx]
        if len(np.unique(y_train)) < 2 or len(np.unique(y_test)) < 2:
            log(f"[Ablation {experiment_name}] skip {fold_name}: one-class train or test.")
            continue
        meta_test = df.iloc[test_idx][["sample_id", "City", "x", "y", "lon", "lat", "label"]].copy()
        meta_test["Fold"] = fold_name
        sw_train = compute_balanced_sample_weight(y_train, city=df.iloc[train_idx]["City"].values)
        for cfg in neural_variant_configs():
            name = cfg["name"]
            log(f"[Ablation {experiment_name}] {fold_name}: {name}")
            try:
                package = train_rf_stabilized_hydrocontex_gnnwrl(
                    df_train=df.iloc[train_idx].reset_index(drop=True),
                    feature_train_scaled=X_scaled.iloc[train_idx].reset_index(drop=True),
                    y_train=y_train,
                    train_meta=df.iloc[train_idx].reset_index(drop=True),
                    sample_weight=sw_train,
                    verbose=False,
                    variant_name=cfg["variant_name"],
                    context_groups_override=cfg["context_groups_override"],
                    k_spatial=cfg["k_spatial"],
                    k_context=cfg["k_context"],
                    eta_spatial=cfg["eta_spatial"],
                    use_graph=cfg["use_graph"],
                    use_wrl=cfg["use_wrl"],
                    use_global_branch=cfg["use_global_branch"],
                    alpha_mode=cfg["alpha_mode"],
                    anchor_mode=cfg.get("anchor_mode", ANCHOR_MODE_V4_RF_ONLY),
                )
                prob, extra, _ = predict_rf_stabilized_hydrocontex_gnnwrl_package(
                    package,
                    X_scaled.iloc[test_idx].reset_index(drop=True),
                    df.iloc[test_idx].reset_index(drop=True)
                )
                prefix = os.path.join(out_dir, f"Ablation_{experiment_name}_{fold_name}_{name}")
                artifacts = save_eval_artifacts(
                    y_test, prob, meta_test, name, f"Ablation_{experiment_name}", prefix, threshold=0.5, extra_cols=extra
                )
                add_artifacts(*artifacts)
                m = artifacts[0]
                m["Fold"] = fold_name
                m["alpha_gnn"] = package["alpha_gnn"]
                m["alpha_rf"] = package["alpha_rf"]
                m["Ablation_component"] = name
                m["Ablation_role"] = cfg.get("ablation_role", "")
                m["Evidence_chain"] = cfg.get("evidence_chain", "")
                rows.append(m)
            except Exception as e:
                log(f"[Ablation CV Failed] {experiment_name} {fold_name} {name}: {e}")
                rows.append({"Model": name, "Experiment": f"Ablation_{experiment_name}", "Fold": fold_name, "Error": str(e)})
    fold_df = pd.DataFrame(rows)
    fold_df.to_csv(os.path.join(out_dir, f"Ablation_{experiment_name}_fold_metrics.csv"), index=False, encoding="utf-8-sig")
    if not fold_df.empty and "AUC" in fold_df.columns:
        valid = fold_df[fold_df["AUC"].notna()].copy()
        if not valid.empty:
            summary = valid.groupby(["Experiment", "Model"]).agg(
                AUC_mean=("AUC", "mean"), AUC_std=("AUC", "std"),
                PR_AUC_mean=("PR_AUC", "mean"), PR_AUC_std=("PR_AUC", "std"),
                F1_mean=("F1", "mean"), F1_std=("F1", "std"),
                Recall_mean=("Recall", "mean"), Brier_mean=("Brier", "mean"),
                ECE_mean=("ECE", "mean"), N_folds=("Fold", "nunique"),
                alpha_gnn_mean=("alpha_gnn", "mean"), alpha_rf_mean=("alpha_rf", "mean"),
            ).reset_index()
            summary.to_csv(os.path.join(out_dir, f"Ablation_{experiment_name}_summary_metrics.csv"), index=False, encoding="utf-8-sig")
            GLOBAL_ARTIFACTS["cv_fold_metrics"].append(fold_df)
            GLOBAL_ARTIFACTS["cv_summary"].append(summary)
    return fold_df

def fit_final_model(df, X_scaled, preprocessor):
    log("\n========== Fit final RF-stabilized Hydro-ConTex GNNWRL on all samples ==========")
    y = df["label"].astype(int).to_numpy()
    sw = compute_balanced_sample_weight(y, city=df["City"].values)

    package = train_rf_stabilized_hydrocontex_gnnwrl(
        df_train=df.reset_index(drop=True),
        feature_train_scaled=X_scaled.reset_index(drop=True),
        y_train=y,
        train_meta=df.reset_index(drop=True),
        sample_weight=sw,
        verbose=False,
        variant_name=FINAL_MODEL_NAME,
        anchor_mode=FINAL_ANCHOR_MODE,
    )

    prob, extra, edges_df = predict_rf_stabilized_hydrocontex_gnnwrl_package(
        package,
        X_scaled.reset_index(drop=True),
        df.reset_index(drop=True)
    )
    meta = df[["sample_id", "City", "x", "y", "lon", "lat", "label"]].copy()
    prefix = os.path.join(OUT_DIR, f"Final_InSample_{FINAL_MODEL_NAME}")
    artifacts = save_eval_artifacts(
        y, prob, meta, FINAL_MODEL_NAME,
        "Final_InSample", prefix, threshold=0.5, extra_cols=extra
    )
    add_artifacts(*artifacts)

    # Mechanism/context/residual data
    mech = artifacts[1].copy()
    mech.to_csv(os.path.join(PLOT_DIR, "final_context_weight_and_residual_data.csv"),
                index=False, encoding="utf-8-sig")
    # Add sample identifiers to graph edges for spatial network plotting.
    edges_plot = edges_df.copy()
    if "src" in edges_plot.columns and "dst" in edges_plot.columns:
        sid = df["sample_id"].reset_index(drop=True)
        city_arr = df["City"].astype(str).reset_index(drop=True)
        edges_plot["src_sample_id"] = edges_plot["src"].map(sid)
        edges_plot["dst_sample_id"] = edges_plot["dst"].map(sid)
        edges_plot["src_city"] = edges_plot["src"].map(city_arr)
        edges_plot["dst_city"] = edges_plot["dst"].map(city_arr)
    edges_plot.to_csv(os.path.join(PLOT_DIR, "final_graph_edges.csv"), index=False, encoding="utf-8-sig")
    package["history"].to_csv(os.path.join(PLOT_DIR, "final_training_history.csv"),
                              index=False, encoding="utf-8-sig")
    package["alpha_table"].to_csv(os.path.join(PLOT_DIR, "final_rf_safe_blend_alpha_selection.csv"),
                                  index=False, encoding="utf-8-sig")
    package.get("blend_calibration_table", pd.DataFrame()).to_csv(
        os.path.join(PLOT_DIR, "final_blend_calibration_selection.csv"),
        index=False, encoding="utf-8-sig"
    )
    if len(package.get("blend_calibration_table", pd.DataFrame())):
        GLOBAL_ARTIFACTS["blend_calibration_selection"].append(package["blend_calibration_table"])
    package["anchor_selection_table"].to_csv(os.path.join(PLOT_DIR, "final_tree_anchor_selection.csv"),
                                             index=False, encoding="utf-8-sig")

    # Save model package
    # Save PyTorch state separately and sklearn objects via joblib.
    torch.save(package["model"].state_dict(), os.path.join(MODEL_DIR, "Final_GNNWRL_state_dict.pt"))
    joblib.dump({
        "rf_anchor": package["rf_anchor"],
        "alpha_gnn": package["alpha_gnn"],
        "alpha_rf": package["alpha_rf"],
        "coord_mu": package["coord_mu"],
        "coord_sd": package["coord_sd"],
        "preprocessor": preprocessor,
        "MODEL_VARS": MODEL_VARS,
        "CONTEXT_GROUPS": CONTEXT_GROUPS,
        "CONTEXT_ORDER": CONTEXT_ORDER,
        "HIDDEN_DIM": HIDDEN_DIM,
        "DROPOUT": DROPOUT,
        "K_SPATIAL": K_SPATIAL,
        "K_CONTEXT": K_CONTEXT,
        "GRAPH_ETA_SPATIAL": GRAPH_ETA_SPATIAL,
        "description": "RF-stabilized Hydro-ConTex GNNWRL final package",
        "FINAL_ANCHOR_MODE": FINAL_ANCHOR_MODE,
        "FINAL_MODEL_NAME": FINAL_MODEL_NAME,
    }, os.path.join(MODEL_DIR, f"Final_{FINAL_MODEL_NAME}_package.joblib"))

    log(f"Final selected alpha_gnn={package['alpha_gnn']:.2f}, alpha_rf={package['alpha_rf']:.2f}")
    return package


def save_global_plot_data():
    log("\n========== Save global plot_data ==========")
    mapping = {
        "metrics": "metrics_all.csv",
        "predictions": "prediction_data_all.csv",
        "roc": "roc_curve_data_all.csv",
        "pr": "pr_curve_data_all.csv",
        "confusion": "confusion_matrix_data_all.csv",
        "threshold": "threshold_metrics_all.csv",
        "optimal_threshold": "optimal_thresholds_all.csv",
        "calibration": "calibration_curve_data_all.csv",
        "blend_calibration_selection": "blend_calibration_selection_all.csv",
        "citywise": "citywise_metrics_all.csv",
        "cv_fold_metrics": "cv_fold_metrics_all.csv",
        "cv_summary": "cv_summary_metrics_all.csv",
        "loco_source_thresholds": "loco_source_thresholds_all.csv",
        "loco_source_threshold_metrics": "loco_source_threshold_test_metrics_all.csv",
        "loco_source_threshold_summary": "loco_source_threshold_summary_metrics_all.csv",
    }
    for key, fname in mapping.items():
        frames = GLOBAL_ARTIFACTS.get(key, [])
        if frames:
            pd.concat(frames, ignore_index=True).to_csv(
                os.path.join(PLOT_DIR, fname), index=False, encoding="utf-8-sig"
            )

    # Fair model rankings for paper reporting
    if GLOBAL_ARTIFACTS["metrics"]:
        met = pd.concat(GLOBAL_ARTIFACTS["metrics"], ignore_index=True)
        if "AUC" in met.columns:
            valid = met[met["AUC"].notna()].copy()
        else:
            valid = met.copy()
        if not valid.empty:
            # 1) Holdout-only ranking: all models comparable under the same split.
            hold = valid[valid["Experiment"].eq("Holdout")].copy()
            if not hold.empty:
                for col in ["AUC", "PR_AUC", "F1", "Recall"]:
                    if col in hold.columns:
                        hold[f"rank_{col}"] = hold[col].rank(ascending=False, method="min")
                if "Brier" in hold.columns:
                    hold["rank_Brier"] = hold["Brier"].rank(ascending=True, method="min")
                rank_cols = [c for c in hold.columns if c.startswith("rank_")]
                hold["mean_rank"] = hold[rank_cols].mean(axis=1) if rank_cols else np.nan
                hold = hold.sort_values(["mean_rank", "AUC"], ascending=[True, False])
                hold.to_csv(os.path.join(OUT_DIR, "Model_selection_holdout_only_ranking.csv"),
                            index=False, encoding="utf-8-sig")

            # 2) Robust validation ranking: only models evaluated in all core validation experiments.
            core_experiments = [
                "Holdout",
                "Ordinary_StratifiedKFold_CV",
                f"Spatial_Block_CV_G{SPATIAL_GRID_N}",
                "Leave_One_City_Out_CV",
            ]
            core = valid[valid["Experiment"].isin(core_experiments)].copy()
            counts = core.groupby("Model")["Experiment"].nunique()
            eligible = counts[counts == len(core_experiments)].index.tolist()
            robust = core[core["Model"].isin(eligible)].copy()
            if not robust.empty:
                rank_rows = []
                for exp, sub in robust.groupby("Experiment"):
                    sub = sub.copy()
                    for col in ["AUC", "PR_AUC", "F1", "Recall"]:
                        if col in sub.columns:
                            sub[f"rank_{col}"] = sub[col].rank(ascending=False, method="min")
                    if "Brier" in sub.columns:
                        sub["rank_Brier"] = sub["Brier"].rank(ascending=True, method="min")
                    rank_cols = [c for c in sub.columns if c.startswith("rank_")]
                    sub["mean_rank"] = sub[rank_cols].mean(axis=1) if rank_cols else np.nan
                    rank_rows.append(sub)
                rank_df = pd.concat(rank_rows, ignore_index=True)
                robust_overall = rank_df.groupby("Model").agg(
                    mean_rank=("mean_rank", "mean"),
                    AUC_mean=("AUC", "mean"),
                    PR_AUC_mean=("PR_AUC", "mean"),
                    F1_mean=("F1", "mean"),
                    Recall_mean=("Recall", "mean"),
                    Brier_mean=("Brier", "mean"),
                    ECE_mean=("ECE", "mean"),
                    n_experiments=("Experiment", "nunique"),
                ).reset_index().sort_values(["mean_rank", "AUC_mean"], ascending=[True, False])
                robust_overall.to_csv(os.path.join(OUT_DIR, "Model_selection_robust_validation_ranking.csv"),
                                      index=False, encoding="utf-8-sig")
                rank_df.to_csv(os.path.join(OUT_DIR, "Model_selection_robust_validation_rank_details.csv"),
                               index=False, encoding="utf-8-sig")


            # 2b) Dedicated v4-v5 comparison table. This is the transparent
            # self-check requested for the final manuscript version.
            v45 = valid[valid["Model"].isin([V4_MODEL_NAME, V5_MODEL_NAME])].copy()
            if not v45.empty:
                v45_detail = v45.sort_values(["Experiment", "Model"])
                v45_detail.to_csv(os.path.join(OUT_DIR, "RF_anchor_final_diagnostic_details.csv"),
                                  index=False, encoding="utf-8-sig")
                v45_summary = v45.groupby("Model").agg(
                    AUC_mean=("AUC", "mean"),
                    PR_AUC_mean=("PR_AUC", "mean"),
                    F1_mean=("F1", "mean"),
                    Recall_mean=("Recall", "mean"),
                    Brier_mean=("Brier", "mean"),
                    ECE_mean=("ECE", "mean"),
                    n_experiments=("Experiment", "nunique"),
                ).reset_index()
                v45_summary["SelectionScore"] = (
                    v45_summary["AUC_mean"].fillna(0)
                    + 0.25 * v45_summary["PR_AUC_mean"].fillna(0)
                    + 0.25 * v45_summary["F1_mean"].fillna(0)
                    - 0.30 * v45_summary["Brier_mean"].fillna(0)
                )
                v45_summary = v45_summary.sort_values(["SelectionScore", "AUC_mean"], ascending=[False, False])
                v45_summary.to_csv(os.path.join(OUT_DIR, "RF_anchor_final_diagnostic_summary.csv"),
                                   index=False, encoding="utf-8-sig")
                rec_model = v45_summary.iloc[0]["Model"]
                rec_note = (
                    "Use V4 if performance is similar, because fixed RandomForest anchor is cleaner for manuscript; "
                    "use V5 only if its robust validation gain is clear and stable."
                )
                pd.DataFrame([{
                    "Recommended_by_numeric_score": rec_model,
                    "Default_manuscript_model": FINAL_MODEL_NAME,
                    "Note": rec_note
                }]).to_csv(os.path.join(OUT_DIR, "RF_anchor_final_recommendation_note.csv"),
                           index=False, encoding="utf-8-sig")

            # 3) Diagnostic all-experiment ranking: includes number of experiments and should not be used alone.
            rank_rows = []
            for exp, sub in valid.groupby("Experiment"):
                sub = sub.copy()
                for col in ["AUC", "PR_AUC", "F1", "Recall"]:
                    if col in sub.columns:
                        sub[f"rank_{col}"] = sub[col].rank(ascending=False, method="min")
                if "Brier" in sub.columns:
                    sub["rank_Brier"] = sub["Brier"].rank(ascending=True, method="min")
                rank_cols = [c for c in sub.columns if c.startswith("rank_")]
                sub["mean_rank"] = sub[rank_cols].mean(axis=1) if rank_cols else np.nan
                rank_rows.append(sub)
            rank_df = pd.concat(rank_rows, ignore_index=True)
            overall = rank_df.groupby("Model").agg(
                mean_rank=("mean_rank", "mean"),
                AUC_mean=("AUC", "mean"),
                PR_AUC_mean=("PR_AUC", "mean"),
                F1_mean=("F1", "mean"),
                Recall_mean=("Recall", "mean"),
                Brier_mean=("Brier", "mean"),
                n_experiments=("Experiment", "nunique"),
            ).reset_index().sort_values(["mean_rank", "AUC_mean"], ascending=[True, False])
            overall.to_csv(os.path.join(OUT_DIR, "Model_selection_all_experiments_rank_diagnostics.csv"),
                           index=False, encoding="utf-8-sig")

    # v7 final model adoption rationale table. This is a manuscript-facing diagnostic table,
    # not a performance claim. It explains why the fixed RF-anchor version is retained over
    # pure RF, pure GNNWRL, and more complex confidence-gated variants.
    pd.DataFrame([
        {"Candidate": "RandomForest", "Strength": "stable nonlinear baseline; strong tabular performance", "Limitation": "no spatial graph propagation; no WRL local context weights", "Role_in_final_study": "used as RF anchor"},
        {"Candidate": "GNNWRL only", "Strength": "spatial graph propagation and local context weights", "Limitation": "less stable than RF under limited samples", "Role_in_final_study": "not used alone"},
        {"Candidate": "Confidence-gated RF-GNNWRL", "Strength": "adaptive fusion can improve some AUC settings", "Limitation": "less stable F1/Recall/calibration and harder ablation interpretation in previous sensitivity runs", "Role_in_final_study": "supplementary sensitivity only"},
        {"Candidate": "v11 fixed RF-stabilized Hydro-ConTex GNNWRL", "Strength": "stable RF probability anchor plus spatial graph and WRL mechanism correction", "Limitation": "not claimed to dominate every metric in every validation; supported by source-threshold LOCO diagnostics and bootstrap/paired robustness checks", "Role_in_final_study": "final P_flood engine"},
    ]).to_csv(os.path.join(OUT_DIR, "Final_model_adoption_rationale.csv"), index=False, encoding="utf-8-sig")


# =========================================================
# 8. Main
# =========================================================


# =========================================================
# 7b. Post-hoc robustness diagnostics for manuscript reporting
# =========================================================

def bootstrap_ci_from_fold_metrics(df_metrics: pd.DataFrame, out_path: str, n_boot: int = BOOTSTRAP_N):
    """Bootstrap confidence intervals over validation folds/cities."""
    if df_metrics is None or df_metrics.empty:
        return pd.DataFrame()
    if "Fold" not in df_metrics.columns or "Model" not in df_metrics.columns:
        return pd.DataFrame()
    metrics = [m for m in ["AUC", "PR_AUC", "F1", "Recall", "Brier", "ECE"] if m in df_metrics.columns]
    rows = []
    rng = np.random.default_rng(BOOTSTRAP_RANDOM_STATE)
    for (exp, model), sub in df_metrics.groupby(["Experiment", "Model"]):
        if len(sub) < 2:
            continue
        for metric in metrics:
            vals = pd.to_numeric(sub[metric], errors="coerce").dropna().to_numpy()
            if len(vals) < 2:
                continue
            boot = [np.mean(rng.choice(vals, size=len(vals), replace=True)) for _ in range(n_boot)]
            lo, hi = np.percentile(boot, [2.5, 97.5])
            rows.append({
                "Experiment": exp, "Model": model, "Metric": metric,
                "Mean": float(np.mean(vals)), "Std": float(np.std(vals, ddof=1)),
                "CI95_low": float(lo), "CI95_high": float(hi),
                "N_units": int(len(vals)), "Bootstrap_N": int(n_boot)
            })
    out = pd.DataFrame(rows)
    if not out.empty:
        out.to_csv(out_path, index=False, encoding="utf-8-sig")
    return out


def paired_difference_diagnostics(df_metrics: pd.DataFrame, baseline_model: str = FINAL_MODEL_NAME):
    """Paired fold/city differences between the final model and each baseline."""
    if df_metrics is None or df_metrics.empty:
        return pd.DataFrame()
    if not {"Experiment", "Model", "Fold"}.issubset(df_metrics.columns):
        return pd.DataFrame()
    metrics = [m for m in ["AUC", "PR_AUC", "F1", "Recall", "Brier", "ECE"] if m in df_metrics.columns]
    rows = []
    for exp, sub in df_metrics.groupby("Experiment"):
        base = sub[sub["Model"].eq(baseline_model)].copy()
        if base.empty:
            continue
        for other_model, oth in sub[~sub["Model"].eq(baseline_model)].groupby("Model"):
            merged = base[["Fold"] + metrics].merge(oth[["Fold"] + metrics], on="Fold", suffixes=("_Final", "_Other"))
            if merged.empty:
                continue
            for metric in metrics:
                diff = pd.to_numeric(merged[f"{metric}_Final"], errors="coerce") - pd.to_numeric(merged[f"{metric}_Other"], errors="coerce")
                valid = diff.dropna()
                if len(valid) == 0:
                    continue
                if metric in ["Brier", "ECE"]:
                    wins = int((valid < 0).sum()); direction = "lower_is_better"
                else:
                    wins = int((valid > 0).sum()); direction = "higher_is_better"
                rows.append({
                    "Experiment": exp, "FinalModel": baseline_model, "ComparedModel": other_model,
                    "Metric": metric, "MeanDiff_FinalMinusOther": float(valid.mean()),
                    "MedianDiff_FinalMinusOther": float(valid.median()),
                    "StdDiff": float(valid.std(ddof=1)) if len(valid) > 1 else 0.0,
                    "N_pairs": int(len(valid)), "FinalWins": wins,
                    "WinRate": float(wins / len(valid)), "Direction": direction
                })
    out = pd.DataFrame(rows)
    if not out.empty:
        out.to_csv(os.path.join(OUT_DIR, "Paired_fold_city_difference_diagnostics.csv"), index=False, encoding="utf-8-sig")
    return out


def summarize_loco_source_threshold_modes():
    """Rank LOCO source-threshold and source-calibration modes fairly for all models."""
    frames = GLOBAL_ARTIFACTS.get("loco_source_threshold_summary", [])
    if not frames:
        return pd.DataFrame()
    df = pd.concat(frames, ignore_index=True)
    if df.empty:
        return df
    rank_cols = []
    for col, asc in [("AUC_mean", False), ("PR_AUC_mean", False), ("F1_mean", False), ("Recall_mean", False), ("Brier_mean", True), ("ECE_mean", True)]:
        if col in df.columns:
            rcol = "rank_" + col.replace("_mean", "")
            group_cols = [c for c in ["ThresholdCriterion", "SourceCalibrationMode"] if c in df.columns]
            if group_cols:
                df[rcol] = df.groupby(group_cols)[col].rank(ascending=asc, method="min")
            else:
                df[rcol] = df[col].rank(ascending=asc, method="min")
            rank_cols.append(rcol)
    if rank_cols:
        df["mean_rank"] = df[rank_cols].mean(axis=1)
    df.to_csv(os.path.join(OUT_DIR, "LOCO_source_threshold_mode_comparison_ranking.csv"), index=False, encoding="utf-8-sig")
    return df


def save_posthoc_robustness_diagnostics():
    log("\n========== Save post-hoc robustness diagnostics ==========")
    cv_frames = GLOBAL_ARTIFACTS.get("cv_fold_metrics", [])
    if cv_frames:
        fold_df = pd.concat(cv_frames, ignore_index=True)
        if RUN_POSTHOC_BOOTSTRAP_CI:
            bootstrap_ci_from_fold_metrics(fold_df, os.path.join(OUT_DIR, "Bootstrap_CI_fold_city_metrics.csv"), n_boot=BOOTSTRAP_N)
        if RUN_POSTHOC_PAIRED_DIAGNOSTICS:
            paired_difference_diagnostics(fold_df, baseline_model=FINAL_MODEL_NAME)
    summarize_loco_source_threshold_modes()

def main():
    t0 = time.time()
    log(f"Device: {DEVICE}")
    log(f"Output directory: {OUT_DIR}")

    # Reviewer-safe model-positioning notes.
    pd.DataFrame([
        {"Item": "Final model name", "Recommendation": "RF-stabilized Hydro-ConTex GNNWRL"},
        {"Item": "v4 default", "Recommendation": "V4 uses fixed RandomForest anchor and is the cleanest manuscript version."},
        {"Item": "v5 sensitivity", "Recommendation": "V5 uses RF-family averaging of RandomForest and ExtraTrees; use only if robust validation improves clearly."},
        {"Item": "Core contribution", "Recommendation": "Hydro-ConTex mechanism grouping, spatial graph propagation, WRL local context weighting, and RandomForest-stabilized probability anchoring"},
        {"Item": "Removed from final core", "Recommendation": "Hydro-ConTex feature-similarity graph is not used in the final main model because previous ablation did not show stable gains"},
        {"Item": "Hydro-ConTex grouping", "Recommendation": "Use as mechanism-oriented organization and local context-weight interpretation, not as a claim of guaranteed predictive improvement"},
        {"Item": "Avoided wording", "Recommendation": "Do not use physics-informed, causality-constrained, or causal-effect claims"},
        {"Item": "v11 robustness-diagnostics repair", "Recommendation": "Use fixed RF anchor; select alpha with a conservative RF-dominant robust objective; report validation-optimized thresholds; for LOCO, use source-city-only threshold and source-only sigmoid calibration diagnostics to avoid target-city leakage"},
        {"Item": "Calibration", "Recommendation": "Use no calibration or sigmoid calibration only when Brier/ECE improve without meaningful AUC loss; isotonic is disabled by default to avoid overly hard P_flood surfaces"},
        {"Item": "Ablation reporting", "Recommendation": "Use Spatial Block CV as the main ablation evidence; interpret WRL and Hydro-ConTex grouping mainly as mechanism-interpretation modules when accuracy gains are modest"},
    ]).to_csv(os.path.join(OUT_DIR, "Model_positioning_notes_for_manuscript.csv"), index=False, encoding="utf-8-sig")

    df = load_all_samples()
    df.to_csv(os.path.join(OUT_DIR, "HydroConTex_training_samples_extracted.csv"),
              index=False, encoding="utf-8-sig")

    # Preprocess once for all experiments. For strict CV, fit preprocessing within fold would be cleaner;
    # here imputation/scaling uses all covariates only, not labels. If strict reviewer asks,
    # you can refit preprocessor inside each fold later. For raster prediction this global transform is practical.
    preprocessor = TabularPreprocessor(MODEL_VARS, ZERO_FILL_VARS)
    X_scaled = preprocessor.fit_transform(df)

    # Missing ratio diagnostics
    miss = df[MODEL_VARS].isna().mean().reset_index()
    miss.columns = ["Variable", "Missing_ratio"]
    miss.to_csv(os.path.join(OUT_DIR, "Feature_missing_ratio.csv"), index=False, encoding="utf-8-sig")

    # Holdout
    run_holdout(df, X_scaled, preprocessor)

    # Neural ablation on the same holdout split
    if RUN_ABLATION_HOLDOUT:
        run_neural_ablation_holdout(df, X_scaled, preprocessor)

    # Ordinary CV
    if RUN_ORDINARY_CV:
        splits = cv_splits_ordinary(df)
        run_cv_for_selected_models(
            df, X_scaled,
            experiment_name="Ordinary_StratifiedKFold_CV",
            splits=splits,
            use_neural=True,
            selected_trad=["RandomForest", "ExtraTrees", "HGB_Tuned", "CatBoost", "XGBoost", "LightGBM"]
        )

    # Spatial CV
    if RUN_SPATIAL_CV:
        splits = cv_splits_spatial(df, grid_n=SPATIAL_GRID_N)
        run_cv_for_selected_models(
            df, X_scaled,
            experiment_name=f"Spatial_Block_CV_G{SPATIAL_GRID_N}",
            splits=splits,
            use_neural=True,
            selected_trad=["RandomForest", "ExtraTrees", "HGB_Tuned", "CatBoost", "XGBoost", "LightGBM"]
        )
        if RUN_ABLATION_SPATIAL_CV:
            run_neural_ablation_cv(df, X_scaled, experiment_name=f"Spatial_Block_CV_G{SPATIAL_GRID_N}", splits=splits)

    # LOCO
    if RUN_LOCO:
        splits_loco = cv_splits_loco(df)
        run_cv_for_selected_models(
            df, X_scaled,
            experiment_name="Leave_One_City_Out_CV",
            splits=splits_loco,
            use_neural=True,
            selected_trad=["RandomForest", "ExtraTrees", "HGB_Tuned", "CatBoost", "XGBoost", "LightGBM"]
        )
        if RUN_ABLATION_LOCO:
            run_neural_ablation_cv(df, X_scaled, experiment_name="Leave_One_City_Out_CV", splits=splits_loco)

    # Final model
    final_package = fit_final_model(df, X_scaled, preprocessor)

    # Save plot_data aggregates
    save_global_plot_data()

    # Post-hoc robustness diagnostics for manuscript / supplementary reporting
    save_posthoc_robustness_diagnostics()

    # Excel summary
    excel_path = os.path.join(OUT_DIR, "RF_Stabilized_HydroConTex_GNNWRL_summary.xlsx")
    with pd.ExcelWriter(excel_path) as writer:
        if GLOBAL_ARTIFACTS["metrics"]:
            pd.concat(GLOBAL_ARTIFACTS["metrics"], ignore_index=True).to_excel(writer, sheet_name="metrics_all", index=False)
        if GLOBAL_ARTIFACTS["cv_summary"]:
            pd.concat(GLOBAL_ARTIFACTS["cv_summary"], ignore_index=True).to_excel(writer, sheet_name="cv_summary", index=False)
        miss.to_excel(writer, sheet_name="feature_missing", index=False)
        df.groupby(["City", "label"]).size().reset_index(name="Count").to_excel(writer, sheet_name="sample_summary", index=False)
        final_package["alpha_table"].to_excel(writer, sheet_name="final_alpha_selection", index=False)
        final_package["anchor_selection_table"].to_excel(writer, sheet_name="final_anchor_selection", index=False)
        final_package["history"].to_excel(writer, sheet_name="final_training_history", index=False)

    log("\n========== DONE ==========")
    log(f"Elapsed time: {(time.time() - t0) / 60:.2f} min")
    log(f"Summary Excel: {excel_path}")
    log(f"Plot data folder: {PLOT_DIR}")
    log(f"Model folder: {MODEL_DIR}")
    log("Important output files:")
    log("  - Model_selection_holdout_only_ranking.csv")
    log("  - Model_selection_robust_validation_ranking.csv")
    log("  - Model_selection_all_experiments_rank_diagnostics.csv")
    log("  - plot_data/metrics_all.csv")
    log("  - plot_data/prediction_data_all.csv")
    log("  - plot_data/final_context_weight_and_residual_data.csv")
    log("  - plot_data/spatial_block_assignments_G5.csv")
    log(f"  - models/Final_{FINAL_MODEL_NAME}_package.joblib")
    log("  - RF_anchor_final_diagnostic_summary.csv")
    log("  - RF_anchor_final_recommendation_note.csv")
    log("  - models/Final_GNNWRL_state_dict.pt")


if __name__ == "__main__":
    main()
