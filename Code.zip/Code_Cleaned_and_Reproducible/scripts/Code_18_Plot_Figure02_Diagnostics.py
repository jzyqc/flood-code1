import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib import patches, colormaps
from matplotlib.colors import Normalize, TwoSlopeNorm, ListedColormap, BoundaryNorm
from matplotlib.cm import ScalarMappable
from matplotlib.gridspec import GridSpec
from mpl_toolkits.axes_grid1.inset_locator import inset_axes

plt.rcParams.update({
    "font.family": "serif",
    "font.serif": ["Times New Roman", "DejaVu Serif", "Liberation Serif"],
    "axes.unicode_minus": False,
    "font.size": 12,
    "font.weight": "bold",
    "axes.titlesize": 13,
    "axes.titleweight": "bold",
    "axes.labelsize": 12,
    "axes.labelweight": "bold",
    "xtick.labelsize": 10,
    "ytick.labelsize": 10,
    "legend.fontsize": 8.5,
    "axes.linewidth": 1.0,
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
    "figure.facecolor": "white",
    "axes.facecolor": "white",
    "savefig.facecolor": "white",
})
CMAP = colormaps["RdYlBu_r"]
C_DARK = "#0D2B4A"
C_GRID = "#DDE5EC"
city_order = ["Beijing", "Shanghai", "Guangzhou", "Shenzhen", "Tianjin", "Chengdu"]
city_short = {"Beijing":"BJ", "Shanghai":"SH", "Guangzhou":"GZ", "Shenzhen":"SZ", "Tianjin":"TJ", "Chengdu":"CD"}

def style_axes(ax, grid=True):
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_color("#7A8793")
    ax.spines["bottom"].set_color("#7A8793")
    ax.spines["left"].set_linewidth(1.0)
    ax.spines["bottom"].set_linewidth(1.0)
    if grid:
        ax.grid(True, color=C_GRID, linewidth=0.8, alpha=0.36, zorder=0)
    for t in ax.get_xticklabels() + ax.get_yticklabels():
        t.set_fontweight("bold")

def panel_title(ax, letter, title, fs=13.0):
    ax.set_title(f"{letter}  {title}", loc="left", fontsize=fs, fontweight="bold", color=C_DARK, pad=4)

def add_banded_background(ax, vmin, vmax):
    ax.axvspan(vmin, vmin + (vmax-vmin)*0.28, color=CMAP(0.92), alpha=0.13, zorder=0)
    ax.axvspan(vmin + (vmax-vmin)*0.28, vmin + (vmax-vmin)*0.62, color=CMAP(0.52), alpha=0.12, zorder=0)
    ax.axvspan(vmin + (vmax-vmin)*0.62, vmax, color=CMAP(0.12), alpha=0.13, zorder=0)

def build_figure2(target_csv, typology_csv, quintile_csv, or_csv, lorenz_csv, hex_csv, out_png="Figure2.png", out_pdf="Figure2.pdf"):
    city_colors = {city: CMAP(v) for city, v in zip(city_order, np.linspace(0.08, 0.92, len(city_order)))}
    quint_order = ["Q1","Q2","Q3","Q4","Q5"]
    quint_colors = {q: CMAP(v) for q, v in zip(quint_order, np.linspace(0.08, 0.90, len(quint_order)))}
    target_order = ["F1","F2","F3"]
    demand_order = ["Demand_Population", "Demand_Economic", "Demand_Built", "Demand_Composite", "Demand_RiskOnly"]
    demand_map = {"Demand_Population":"Population","Demand_Economic":"Economic","Demand_Built":"Built","Demand_Composite":"Composite","Demand_RiskOnly":"Risk-only"}

    city_delta = pd.read_csv(target_csv)
    typology = pd.read_csv(typology_csv)
    quint = pd.read_csv(quintile_csv)
    or_df = pd.read_csv(or_csv)
    lorenz = pd.read_csv(lorenz_csv)
    hex_df = pd.read_csv(hex_csv, usecols=["City","Scenario","Indicator","Mean"])

    def forest_panel(ax, outcome, title, letter, pooled=False):
        if not pooled:
            od = or_df[(or_df["Scenario"]=="S7") & (or_df["Outcome"]==outcome) & (or_df["Group"].isin(["worse_off","average"]))].copy()
            od["GroupOrder"] = od["Group"].map({"worse_off":0, "average":1})
            od["CityOrder"] = od["City"].map({c:i for i,c in enumerate(city_order)})
            od = od.sort_values(["CityOrder","GroupOrder"]).reset_index(drop=True)
            y = np.arange(len(od))[::-1]
            xmin = max(min(od["CI2_5"].min()*0.80, 0.50), 0.05)
            xmax = max(od["CI97_5"].max()*1.15, 2.2)
            for yi in y: ax.hlines(yi, xmin, xmax, color="#E6EDF2", lw=0.8, zorder=0)
            for yi, (_, r) in zip(y, od.iterrows()):
                col = city_colors[r["City"]]
                ax.errorbar(r["OddsRatio"], yi, xerr=[[r["OddsRatio"]-r["CI2_5"]],[r["CI97_5"]-r["OddsRatio"]]],
                            fmt="D", color=col, ecolor=col, elinewidth=1.6, capsize=2.8, capthick=1.6,
                            markersize=4.6, markeredgecolor="black", markeredgewidth=0.42, zorder=3)
            ax.set_yticks(y)
            ax.set_yticklabels([f"{city_short[c]} | {g.replace('_','-')}" for c,g in zip(od["City"], od["Group"])], fontsize=7)
        else:
            rows = []
            for outc, lab in [("ResidualHighRisk_F1_Top20","High F1 risk"),
                              ("InsufficientBenefit_Total_Bottom20","Insufficient benefit"),
                              ("ResidualDemand_Composite_Top20","Residual demand")]:
                for grp in ["worse_off","average"]:
                    sub = or_df[(or_df["Scenario"]=="S7") & (or_df["Outcome"]==outc) & (or_df["Group"]==grp)].copy()
                    se = (np.log(sub["CI97_5"]) - np.log(sub["CI2_5"])) / 3.92
                    w = 1/(se**2)
                    pooled_log = np.sum(w*np.log(sub["OddsRatio"])) / np.sum(w)
                    pooled_se = np.sqrt(1/np.sum(w))
                    rows.append({"label":f"{lab} | {grp.replace('_','-')}",
                                 "OR":np.exp(pooled_log),
                                 "lo":np.exp(pooled_log-1.96*pooled_se),
                                 "hi":np.exp(pooled_log+1.96*pooled_se),
                                 "group":grp})
            od = pd.DataFrame(rows)
            y = np.arange(len(od))[::-1]
            xmin = max(min(od["lo"].min()*0.80, 0.50), 0.05)
            xmax = max(od["hi"].max()*1.15, 2.2)
            for yi in y: ax.hlines(yi, xmin, xmax, color="#E6EDF2", lw=0.8, zorder=0)
            for yi, (_, r) in zip(y, od.iterrows()):
                col = CMAP(0.86) if r["group"]=="worse_off" else CMAP(0.34)
                ax.errorbar(r["OR"], yi, xerr=[[r["OR"]-r["lo"]],[r["hi"]-r["OR"]]],
                            fmt="D", color=col, ecolor=col, elinewidth=1.8, capsize=3.0, capthick=1.8,
                            markersize=5.2, markeredgecolor="black", markeredgewidth=0.48, zorder=3)
            ax.set_yticks(y)
            ax.set_yticklabels(od["label"], fontsize=7)
        ax.axvline(1, color="#6C7883", ls="--", lw=1.0)
        ax.set_xscale("log")
        ax.set_xlim(xmin, xmax)
        ax.set_xlabel("Odds ratio (95% CI)")
        panel_title(ax, letter, title, fs=12)
        style_axes(ax, grid=False)
        ax.grid(axis="x", color=C_GRID, linewidth=0.8, alpha=0.40)

    fig = plt.figure(figsize=(20.0, 20.6))
    gs = fig.add_gridspec(5, 4, hspace=0.45, wspace=0.30)
    fig.suptitle("Figure 2 | Integrated inequality diagnostics", fontsize=24, fontweight="bold", color=C_DARK, y=0.992)
    fig.text(0.5, 0.970, "Targeting, distribution, disadvantage, and concentration patterns under scenario transition",
             ha="center", va="top", fontsize=13.5, fontweight="bold", color=C_DARK)

    # a-d
    for k, target in enumerate(target_order):
        ax = fig.add_subplot(gs[0, k])
        sub = city_delta[city_delta["Target"] == target].copy()
        sub["City"] = pd.Categorical(sub["City"], city_order, ordered=True)
        sub = sub.sort_values("City")
        vals = sub["Gini_Delta_S7_minus_S0"].values
        y = np.arange(len(sub))[::-1]
        vmin = min(-0.15, vals.min()*1.15); vmax = max(0.12, vals.max()*1.15)
        add_banded_background(ax, vmin, vmax); ax.axvline(0, color="#333333", lw=1.0, ls="--")
        for yi in y: ax.hlines(yi, vmin, vmax, color="#E4EBF1", lw=0.8)
        for yi, v in zip(y, vals):
            col = CMAP(0.92) if v < 0 else CMAP(0.10)
            ax.plot([0, v], [yi, yi], color="#9FB0C0", lw=2.3)
            ax.scatter(v, yi, s=70, color=col, edgecolor="black", linewidth=0.55, zorder=3)
            ax.text(v + (vmax-vmin)*0.02*np.sign(v if v!=0 else 1), yi, f"{v:+.3f}",
                    va="center", ha="left" if v>=0 else "right", fontsize=7.7)
        ax.set_yticks(y)
        ax.set_yticklabels(sub["City"], fontsize=8 if k==0 else 0)
        ax.set_xlim(vmin, vmax)
        ax.set_xlabel("ΔGini (S7 − S0)")
        panel_title(ax, chr(ord("a")+k), f"{target} ΔGini", fs=12)
        style_axes(ax, grid=False)

    ax = fig.add_subplot(gs[0, 3])
    q5 = quint[quint["DemandQuintile"]=="Q5"].copy()
    q5_mean = q5.groupby(["DemandIndicator","Scenario"], observed=False)["ShareOfTotalBenefit"].mean().reset_index()
    wide = q5_mean[q5_mean["Scenario"].isin(["S1","S7"])].pivot(index="DemandIndicator", columns="Scenario", values="ShareOfTotalBenefit").reindex(demand_order)
    diff = (wide["S7"] - wide["S1"]) * 100
    y = np.arange(len(demand_order))[::-1]
    vmin, vmax = -12, 12
    add_banded_background(ax, vmin, vmax); ax.axvline(0, color="#333333", lw=1.0, ls="--")
    for yi in y: ax.hlines(yi, vmin, vmax, color="#E4EBF1", lw=0.8)
    for yi, d, v in zip(y, demand_order, diff.values):
        col = CMAP(0.92) if v < 0 else CMAP(0.10)
        ax.plot([0, v], [yi, yi], color="#9FB0C0", lw=2.3)
        ax.scatter(v, yi, s=70, color=col, edgecolor="black", linewidth=0.55, zorder=3)
        ax.text(v + 0.6*np.sign(v if v!=0 else 1), yi, f"{v:+.1f}",
                va="center", ha="left" if v>=0 else "right", fontsize=7.7)
    ax.set_yticks(y)
    ax.set_yticklabels([demand_map[d] for d in demand_order], fontsize=7.6)
    ax.set_xlim(vmin, vmax)
    ax.set_xlabel("Δ share of Q5 benefit (percentage points)")
    panel_title(ax, "d", "Q5 targeting shift", fs=12)
    style_axes(ax, grid=False)

    forest_panel(fig.add_subplot(gs[1,0]), "ResidualHighRisk_F1_Top20", "Residual high F1 risk", "e")
    forest_panel(fig.add_subplot(gs[1,1]), "InsufficientBenefit_Total_Bottom20", "Insufficient total benefit", "f")
    forest_panel(fig.add_subplot(gs[1,2]), "ResidualDemand_Composite_Top20", "Residual composite demand", "g")
    forest_panel(fig.add_subplot(gs[1,3]), None, "Pooled summary forest", "h", pooled=True)

    ax = fig.add_subplot(gs[2,0])
    s7_comp = quint[(quint["Scenario"]=="S7") & (quint["DemandIndicator"]=="Demand_Composite")]
    stack = s7_comp.pivot_table(index="City", columns="DemandQuintile", values="ShareOfTotalBenefit", observed=False).reindex(index=city_order, columns=quint_order)
    yy = np.arange(len(city_order))[::-1]
    left = np.zeros(len(city_order))
    for q in quint_order:
        vals = stack[q].values * 100
        ax.barh(yy, vals, left=left, height=0.62, color=quint_colors[q], edgecolor="white", linewidth=0.8, label=q)
        for ii, v in enumerate(vals):
            if v >= 8:
                ax.text(left[ii]+v/2, yy[ii], f"{v:.1f}", ha="center", va="center", fontsize=7.0, color="#111111")
        left += vals
    ax.set_yticks(yy); ax.set_yticklabels(city_order, fontsize=8.5); ax.set_xlim(0,100)
    ax.set_xlabel("Share of total allocation (%)")
    panel_title(ax, "i", "Allocation across quintiles", fs=12)
    style_axes(ax, grid=True)
    ax.legend(ncol=5, bbox_to_anchor=(0.50, -0.20), loc="lower center", frameon=False, fontsize=7)

    # j
    dist_gs = gs[2,1:3].subgridspec(1,3, wspace=0.28)
    for idx, (ind, title) in enumerate([("BenefitTotal","BenefitTotal"), ("ACRComposite","ACRComposite"), ("ResidualDemandComposite","ResidualDemand")]):
        ax = fig.add_subplot(dist_gs[0, idx])
        sub = hex_df[(hex_df["Scenario"]=="S7") & (hex_df["Indicator"]==ind)]
        data = [sub[sub["City"]==c]["Mean"].values for c in city_order]
        vp = ax.violinplot(data, positions=np.arange(1, len(city_order)+1), widths=0.82, showmeans=False, showextrema=False, showmedians=False)
        for body, c in zip(vp["bodies"], [city_colors[c] for c in city_order]):
            body.set_facecolor(c); body.set_edgecolor("white"); body.set_alpha(0.48)
        bp = ax.boxplot(data, positions=np.arange(1, len(city_order)+1), widths=0.24, patch_artist=True, showfliers=False)
        for patch, c in zip(bp["boxes"], [city_colors[c] for c in city_order]):
            patch.set(facecolor=c, edgecolor="black", linewidth=0.65, alpha=0.86)
        for line in bp["whiskers"] + bp["caps"] + bp["medians"]:
            line.set(color="black", linewidth=0.75)
        ax.set_xticks(range(1, len(city_order)+1))
        ax.set_xticklabels([city_short[c] for c in city_order], rotation=90, fontsize=7)
        ax.set_title(title, fontsize=10.0, fontweight="bold", color=C_DARK, pad=2)
        if idx == 0: ax.set_ylabel("Distribution")
        style_axes(ax, grid=True)
    fig.text(0.455, 0.562, "j  Distribution of key indicators by city", fontsize=12, fontweight="bold", color=C_DARK)

    # k
    host = fig.add_subplot(gs[2,3]); host.axis("off"); panel_title(host, "k", "Quintile mechanism profiles", fs=12)
    for idx, (metric, title) in enumerate([("ShareOfTotalBenefit","Benefit share"), ("MeanResidualDemand","Residual demand"), ("MeanACR","Benefit-to-demand ratio")]):
        ax = inset_axes(host, width="94%%", height="27%%", loc="upper left",
                        bbox_to_anchor=(0.03, 0.69-idx*0.32, 0.94, 0.28),
                        bbox_transform=host.transAxes, borderpad=0)
        sub = quint[(quint["Scenario"]=="S7") & (quint["DemandIndicator"]=="Demand_Composite")]
        m = sub.groupby(["DemandQuintile"], observed=False)[metric].mean().reindex(quint_order)
        city_profiles = sub.pivot_table(index="DemandQuintile", columns="City", values=metric, observed=False).reindex(quint_order)
        for city in city_order:
            ax.plot(quint_order, city_profiles[city].values, lw=0.9, alpha=0.25, color=city_colors[city])
        ax.plot(quint_order, m.values, marker="o", lw=2.2, ms=3.8, color=CMAP(0.90))
        ax.set_title(title, loc="left", fontsize=8.5, fontweight="bold", color=C_DARK, pad=1)
        ax.tick_params(labelsize=6.5)
        style_axes(ax, grid=True)

    # l
    ax = fig.add_subplot(gs[3,0])
    lz = lorenz[(lorenz["Scenario"]=="S7") & (lorenz["Target"].isin(target_order))].copy()
    lz["CellBin"] = (lz["CellShare"]*30).round()/30
    agg = lz.groupby(["City","CellBin"], observed=False)["ValueShare"].mean().reset_index()
    for city in city_order:
        s = agg[agg["City"]==city].sort_values("CellBin")
        ax.plot(s["CellBin"], s["ValueShare"], color=city_colors[city], lw=1.6, label=city_short[city])
    ax.plot([0,1], [0,1], color="#666666", lw=0.9, ls="--")
    ax.set_xlabel("Cumulative population share"); ax.set_ylabel("Cumulative benefit share")
    panel_title(ax, "l", "Lorenz curves of adaptation benefit", fs=12)
    style_axes(ax, grid=True); ax.legend(ncol=2, fontsize=6.8, frameon=False, loc="upper left")

    # m
    ax = fig.add_subplot(gs[3,1])
    tp = typology.copy().set_index("City").reindex(city_order).reset_index()
    sizes = 360*(tp["UnmetHighDemand"].astype(float)/tp["UnmetHighDemand"].astype(float).max()) + 70
    ax.scatter(tp["V50_Q5Demand_ShareOfTotalBenefit"]*100, tp["ResidualDemandComposite"], s=sizes, c=tp["ACRComposite"],
               cmap=CMAP, edgecolors="black", linewidths=0.65, alpha=0.90)
    for _, r in tp.iterrows():
        ax.text(r["V50_Q5Demand_ShareOfTotalBenefit"]*100, r["ResidualDemandComposite"], "  "+city_short[r["City"]], fontsize=8, va="center")
    ax.axvline((tp["V50_Q5Demand_ShareOfTotalBenefit"]*100).median(), color="#777777", ls="--", lw=0.9)
    ax.axhline(tp["ResidualDemandComposite"].median(), color="#777777", ls="--", lw=0.9)
    ax.set_xlabel("Targeting intensity (Q5 share, %)")
    ax.set_ylabel("Residual demand")
    panel_title(ax, "m", "City typology in inequality–targeting space", fs=12)
    style_axes(ax, grid=True)

    # n
    ax = fig.add_subplot(gs[3,2:]); ax.axis("off"); panel_title(ax, "n", "Comparative multi-metric summary", fs=12)
    summary = city_delta.pivot_table(index="City", columns="Target", values="Gini_Delta_S7_minus_S0", observed=False).reindex(city_order)
    q5_share = stack["Q5"].reindex(city_order) * 100
    bt_rc = (typology.set_index("City").reindex(city_order)["BenefitTotal"] / (typology.set_index("City").reindex(city_order)["ResidualDemandComposite"] + 1e-6)).clip(upper=3)
    cols = ["City","F1 ΔGini","F2 ΔGini","F3 ΔGini","Q5 share","BT/RC"]; xpos = [0.02,0.20,0.36,0.52,0.70,0.86]
    for x, c in zip(xpos, cols):
        ax.text(x, 0.92, c, ha="center", va="center", fontsize=8.5, fontweight="bold", transform=ax.transAxes)
    for ii, city in enumerate(city_order):
        y = 0.80 - ii*0.115
        ax.text(xpos[0], y, city_short[city], ha="center", va="center", fontsize=8.5, fontweight="bold", transform=ax.transAxes)
        for k, target in enumerate(target_order):
            v = summary.loc[city, target]
            x0 = xpos[1+k]
            ax.plot([x0-0.05, x0+0.05], [y, y], color="#999999", lw=0.8, transform=ax.transAxes)
            ax.plot([x0, x0], [y-0.025, y+0.025], color="#777777", lw=0.8, transform=ax.transAxes)
            px = x0 + np.clip(v/0.20, -0.45, 0.45)*0.08
            ax.scatter([px], [y], s=35, color=CMAP(0.92) if v<0 else CMAP(0.10), edgecolor="black", linewidth=0.4, transform=ax.transAxes, zorder=3)
        for x0, val, vmin, vmax in [(xpos[4], q5_share.loc[city], 30, 60), (xpos[5], bt_rc.loc[city], 1, 3)]:
            normv = (val-vmin)/(vmax-vmin)
            col = CMAP(np.clip(normv,0,1))
            ax.add_patch(patches.Rectangle((x0-0.055, y-0.035), 0.11, 0.07, facecolor=col, edgecolor="white", transform=ax.transAxes))
            ax.text(x0, y, f"{val:.1f}", ha="center", va="center", fontsize=8, fontweight="bold", transform=ax.transAxes)
    ax.text(0.36, 0.05, "Worse ←     ΔGini (S7−S0)     → Better", ha="center", va="center", fontsize=8, color=C_DARK, transform=ax.transAxes)

    # footer
    ax_foot = fig.add_subplot(gs[4,:]); ax_foot.axis("off")
    ax_foot.add_patch(patches.FancyBboxPatch((0.02,0.10),0.96,0.76,boxstyle="round,pad=0.01,rounding_size=0.015",
                                             facecolor="#FAFCFE", edgecolor="#C7D4E0", linewidth=0.8, transform=ax_foot.transAxes))
    ax_foot.text(0.04,0.68,"Color scale (RdYlBu_r)", fontsize=9.5, fontweight="bold", color=C_DARK, transform=ax_foot.transAxes)
    cax = inset_axes(ax_foot, width="18%%", height="24%%", loc="center", bbox_to_anchor=(0.035,0.24,0.22,0.5),
                     bbox_transform=ax_foot.transAxes, borderpad=0)
    cax.imshow(np.linspace(0,1,256).reshape(1,-1), aspect="auto", cmap=CMAP); cax.set_xticks([]); cax.set_yticks([])
    ax_foot.text(0.035,0.25,"Worse / Lower", fontsize=7.5, transform=ax_foot.transAxes)
    ax_foot.text(0.195,0.25,"Better / Higher", fontsize=7.5, transform=ax_foot.transAxes)
    fig.savefig(out_png, dpi=600, bbox_inches="tight")
    fig.savefig(out_pdf, dpi=600, bbox_inches="tight")
    plt.close(fig)

if __name__ == "__main__":
    build_figure2(
        target_csv="07_v50_s0_s7_target_inequality_change.csv",
        typology_csv="04_s7_city_equity_typology.csv",
        quintile_csv="08_v50_demand_quintile_benefit_distribution.csv",
        or_csv="09_v50_residual_disadvantage_odds_ratios.csv",
        lorenz_csv="02_lorenz_curve_points.csv",
        hex_csv="hex_plotting_data_scale_3000m.csv",
        out_png="Figure2_final_manuscript_diagnostics.png",
        out_pdf="Figure2_final_manuscript_diagnostics.pdf",
    )
