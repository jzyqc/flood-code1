#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
V52：多尺度蜂巢地图 + S0-S7 全情景 + 适应供需匹配全指标计算
================================================================

这个版本是完整“方案1”：
- 读取你的真实路径：
  E:\中国特大城市洪水\绘图汇总\第三组图\03_city_scenarios\<City>\rasters
- 计算 S0-S7 全部情景；
- 计算 F1/F2/F3 原始目标、适应收益、需求、供给、ACR、残余需求、错配、低收益组、高需求未覆盖等；
- 计算多个蜂巢尺度；
- 输出每个尺度/情景/城市/指标的 hex-level 绘图数据；
- 直接画多尺度蜂巢地图；
- 不画箱线图、散点图、森林图、Lorenz 图，只做地图数据和地图图件。

核心故事：
1. Adaptation demand：基准风险需求 = normalized S0_F1 × exposure
2. Adaptation supply：风险削减供给 = normalized max(S0_F1 - Sx_F1, 0)
3. ACR：适应供需覆盖率 = supply / demand
4. Residual demand：残余适应需求 = max(demand - supply, 0)
5. Benefit class：P20/P80 的 worse-off / average / better-off 空间分组
6. Unmet high-demand：高需求且供给不足区域

注意：
- F1 默认越低越好；
- F2 默认越高越好；
- F3 默认越高越好。如果你的 F3 是 CGI loss，请把 BENEFIT_DIRECTION["F3"] 改成 decrease_is_benefit。
"""

from __future__ import annotations

import argparse
import math
import os
import re
import warnings
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

import rasterio
from rasterio.warp import reproject, Resampling, transform as rio_transform
from rasterio.transform import xy

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.collections import PatchCollection
from matplotlib.patches import RegularPolygon
from matplotlib.colors import ListedColormap, BoundaryNorm

warnings.filterwarnings("ignore")

try:
    from tqdm import tqdm
except Exception:
    def tqdm(iterable=None, total=None, desc=None, unit=None, **kwargs):
        if desc:
            print(f"[{desc}] start", flush=True)
        return iterable if iterable is not None else range(total or 0)

# ============================================================
# 0. 固定路径与核心参数
# ============================================================
DEFAULT_PROJECT_ROOT = r"E:\中国特大城市洪水"
DEFAULT_SCENARIO_ROOT = r"E:\中国特大城市洪水\绘图汇总\第三组图\03_city_scenarios"
DEFAULT_OUTPUT_DIR = r"E:\中国特大城市洪水\hex_single_scale_outputs_v57"

CITY_ORDER = ["Beijing", "Chengdu", "Guangzhou", "Shanghai", "Shenzhen", "Tianjin"]
# 默认六城都计算。若只想单独测试深圳/天津，可改成：RUN_CITIES = ["Shenzhen", "Tianjin"]
RUN_CITIES = CITY_ORDER
CITY_CN_DIRS = {
    "Beijing": "北京市数据",
    "Chengdu": "成都市数据",
    "Guangzhou": "广州市数据",
    "Shanghai": "上海市数据",
    "Shenzhen": "深圳市数据",
    "Tianjin": "天津市数据",
}
SCENARIOS = [f"S{i}" for i in range(8)]
TARGETS = ["F1", "F2", "F3"]

# 多尺度蜂巢，单位为米。可按需要改。
HEX_SCALES_M = [3000]

# 默认全情景都计算、都画。如果图太多，可改成 ["S7"]。
SCENARIOS_TO_PLOT = ["S0", "S1", "S2", "S3", "S4", "S5", "S6", "S7"]
# 全部情景都会计算；默认只画 S7，避免画图过多。若要画全部情景，改成：PLOT_SCENARIOS = SCENARIOS_TO_PLOT
PLOT_SCENARIOS = ["S7"]

# 默认画这些指标，全部指标仍会计算并导出到 CSV。
MAP_INDICATORS_TO_PLOT = [
    "BenefitTotal",
    "DemandComposite",
    "RiskReductionSupplyNorm",
    "ACRComposite",
    "ResidualDemandComposite",
    "MismatchComposite",
    "BenefitDeviationClass",
    "UnmetHighDemand",
]

# 实际进行蜂巢聚合的指标。
# 注意：像元层所有指标都会算摘要；蜂巢层只聚合这些核心地图指标，以保证速度。
HEX_INDICATORS_TO_AGGREGATE = [
    "RawF1", "RawF2", "RawF3",
    "RiskReductionSupply",
    "RiskReductionSupplyNorm",
    "BenefitLive",
    "BenefitLiveNorm",
    "BenefitFunction",
    "BenefitFunctionNorm",
    "BenefitTotal",
    "DemandRiskOnly",
    "DemandPopulation",
    "DemandEconomic",
    "DemandBuilt",
    "DemandComposite",
    "ACRRiskOnly",
    "ACRPopulation",
    "ACREconomic",
    "ACRBuilt",
    "ACRComposite",
    "ResidualDemandComposite",
    "MismatchComposite",
    "DemandAlignedBenefitComposite",
    "PopExposureWeightedRiskReduction",
    "EconExposureWeightedRiskReduction",
    "BuiltExposureWeightedRiskReduction",
    "CompositeExposureWeightedRiskReduction",
    "BenefitDeviationClass",
    "UnmetHighDemand",
]

# 如果所有尺度、所有情景、所有指标都画图，输出会很多。
# True = 每个 scenario × scale 生成 2 张综合图 + 每个指标单图。
# False = 只生成综合图，不生成每个指标单图。
PLOT_SINGLE_INDICATORS = False

# 栅格采样步长。1 = 全像元；2/3 = 加速但略粗。正式建议 1，测试可用 2。
SAMPLE_STEP = 2

# 是否导出每个 hex 聚合表。建议 True。
EXPORT_HEX_CSV = True

# 是否导出单城市、单情景、单尺度、单指标的独立 CSV。数量很多，默认 False。
EXPORT_SPLIT_HEX_CSV = False

# 是否导出 GeoTIFF 栅格层。不是蜂巢，但是方便 ArcGIS 检查。默认 False。
EXPORT_RASTER_LAYERS = False

# 绘图分辨率
DPI = 450

# 字体。Times New Roman 若缺失会自动 fallback。
plt.rcParams["font.family"] = "Times New Roman"
plt.rcParams["axes.unicode_minus"] = False

# F3 方向
BENEFIT_DIRECTION = {
    "F1": "decrease_is_benefit",
    "F2": "increase_is_benefit",
    "F3": "increase_is_benefit",
}

# 情景内可控变量
SCENARIO_COVARIATE_NAMES = [
    "BD", "BH", "GVI", "LULC", "Micro_ISA", "Micro_PSA", "NDVI", "P",
    "SVF", "SCE", "SEL", "BVI", "CFI", "FOE", "TAE"
]

# 城市根目录中暴露/背景变量
BASE_COVARIATE_NAMES = [
    "PopD", "PD", "GDP", "NTL", "RD", "BD", "BH", "NDVI", "GVI",
    "Micro_ISA", "Micro_PSA", "LULC", "SVF"
]

# 坐标转换目标：Web Mercator，保证米制蜂巢尺度可用。
# 如果你更想用城市本地 UTM，可后续改进；这个版本先保证稳定可跑。
METRIC_CRS = "EPSG:3857"

# ============================================================
# 1. 文件识别
# ============================================================
def norm_text(s: str) -> str:
    return re.sub(r"[^A-Za-z0-9]+", "", str(s)).lower()

def infer_scenario(path_or_name: str) -> Optional[str]:
    text = str(path_or_name)
    for s in SCENARIOS:
        if re.search(rf"(^|[^A-Za-z0-9]){s}([^A-Za-z0-9]|$)", text, flags=re.I):
            return s
    n = norm_text(text)
    for s in SCENARIOS:
        if s.lower() in n:
            return s
    if any(k in n for k in ["bau", "baseline", "base", "current", "reference", "ref"]):
        return "S0"
    return None

def infer_target(path_or_name: str) -> Optional[str]:
    text = str(path_or_name)
    for t in TARGETS:
        if re.search(rf"(^|[^A-Za-z0-9]){t}([^A-Za-z0-9]|$)", text, flags=re.I):
            return t
    n = norm_text(text)
    if "safetyexpectedimpact" in n or "risk" in n or "flood" in n:
        return "F1"
    if "livableecological" in n or "livability" in n or "ecological" in n:
        return "F2"
    if "cgi" in n or "growthintensity" in n or "function" in n:
        return "F3"
    return None

def infer_covariate(path_or_name: str) -> Optional[str]:
    stem = Path(str(path_or_name)).stem
    stem = re.sub(r"^S[0-7]_", "", stem, flags=re.I)
    n = norm_text(stem)
    ordered = sorted(SCENARIO_COVARIATE_NAMES + BASE_COVARIATE_NAMES, key=len, reverse=True)
    for c in ordered:
        if norm_text(c) == n:
            return c
    for c in ordered:
        if norm_text(c) in n:
            return c
    return None

def scenario_folder(root: Path, city: str) -> Path:
    return root / city / "rasters"

def base_city_folder(project_root: Path, city: str) -> Path:
    return project_root / CITY_CN_DIRS[city]

def inventory_scenario_rasters(scenario_root: Path):
    target_rows, cov_rows, debug_rows = [], [], []
    for city in CITY_ORDER:
        folder = scenario_folder(scenario_root, city)
        if not folder.exists():
            debug_rows.append({
                "City": city, "FolderExists": False, "Path": str(folder),
                "RelativePath": "", "FileName": "", "Scenario": "", "Target": "", "Covariate": ""
            })
            continue

        for p in folder.rglob("*.tif"):
            rel = str(p.relative_to(folder))
            scenario = infer_scenario(p.name) or infer_scenario(rel)
            target = infer_target(p.name)
            cov = infer_covariate(p.name)
            debug_rows.append({
                "City": city,
                "FolderExists": True,
                "Path": str(p),
                "RelativePath": rel,
                "FileName": p.name,
                "Scenario": scenario or "",
                "Target": target or "",
                "Covariate": cov or "",
            })
            if scenario and target:
                target_rows.append({
                    "City": city, "Scenario": scenario, "Target": target,
                    "Path": str(p), "FileName": p.name
                })
            elif scenario and cov:
                cov_rows.append({
                    "City": city, "Scenario": scenario, "Covariate": cov,
                    "Path": str(p), "FileName": p.name
                })
    return pd.DataFrame(target_rows), pd.DataFrame(cov_rows), pd.DataFrame(debug_rows)

def inventory_base_covariates(project_root: Path):
    rows = []
    for city in CITY_ORDER:
        folder = base_city_folder(project_root, city)
        if not folder.exists():
            continue
        for p in folder.glob("*.tif"):
            cov = infer_covariate(p.name)
            if cov in BASE_COVARIATE_NAMES:
                rows.append({"City": city, "Covariate": cov, "Path": str(p), "FileName": p.name})
    df = pd.DataFrame(rows)
    if not df.empty:
        df = df.drop_duplicates(["City", "Covariate"], keep="first")
    return df

# ============================================================
# 2. 栅格读取和基础计算
# ============================================================
def read_raster(path: Path):
    with rasterio.open(path) as src:
        arr = src.read(1).astype("float64")
        nodata = src.nodata
        meta = src.meta.copy()
        meta["transform"] = src.transform
        meta["crs"] = src.crs
        meta["width"] = src.width
        meta["height"] = src.height
        meta["bounds"] = src.bounds
    if nodata is not None:
        arr = np.where(arr == nodata, np.nan, arr)
    arr = np.where(np.abs(arr) > 1e30, np.nan, arr)
    return arr, meta

def align_to_ref(path: Path, ref_meta: dict, categorical: bool = False):
    with rasterio.open(path) as src:
        arr = src.read(1).astype("float64")
        nodata = src.nodata
        if nodata is not None:
            arr = np.where(arr == nodata, np.nan, arr)

        dst = np.full((ref_meta["height"], ref_meta["width"]), np.nan, dtype="float64")
        reproject(
            source=arr,
            destination=dst,
            src_transform=src.transform,
            src_crs=src.crs,
            dst_transform=ref_meta["transform"],
            dst_crs=ref_meta["crs"],
            src_nodata=np.nan,
            dst_nodata=np.nan,
            resampling=Resampling.nearest if categorical else Resampling.bilinear,
        )
    return np.where(np.abs(dst) > 1e30, np.nan, dst)

def write_geotiff(path: Path, arr: np.ndarray, ref_meta: dict, dtype="float32"):
    meta = ref_meta.copy()
    meta.update({
        "driver": "GTiff",
        "count": 1,
        "dtype": dtype,
        "nodata": -9999.0 if dtype != "int16" else -9999,
        "compress": "lzw",
    })
    out = np.where(np.isfinite(arr), arr, meta["nodata"])
    path.parent.mkdir(parents=True, exist_ok=True)
    with rasterio.open(path, "w", **meta) as dst:
        dst.write(out.astype(dtype), 1)

def finite_vals(arr: np.ndarray) -> np.ndarray:
    v = arr[np.isfinite(arr)]
    return v.astype("float64")

def robust01(arr: np.ndarray, mask: np.ndarray, q=(2, 98)):
    out = np.full_like(arr, np.nan, dtype="float64")
    valid = mask & np.isfinite(arr)
    if valid.sum() == 0:
        return out
    lo, hi = np.nanpercentile(arr[valid], q)
    if not np.isfinite(lo) or not np.isfinite(hi) or hi <= lo:
        out[valid] = 0.5
    else:
        out[valid] = np.clip((arr[valid] - lo) / (hi - lo), 0, 1)
    return out

def normalize_positive_benefit(arr: np.ndarray, mask: np.ndarray):
    """
    专门用于收益层归一化。
    与 robust01 的区别：
    - 如果收益全为 0，归一化结果必须是 0，而不是 0.5；
    - 避免 S0 自身比较时 BenefitTotal=0.5、ACR=5 的错误。
    """
    out = np.full_like(arr, np.nan, dtype="float64")
    valid = mask & np.isfinite(arr)
    if valid.sum() == 0:
        return out

    vals = arr[valid]
    if np.nanmax(vals) <= 1e-12:
        out[valid] = 0.0
        return out

    lo, hi = np.nanpercentile(vals, [2, 98])
    if not np.isfinite(lo) or not np.isfinite(hi) or hi <= lo:
        # 如果是常数正收益，则视为统一有收益，设为 1
        out[valid] = 1.0
    else:
        out[valid] = np.clip((arr[valid] - lo) / (hi - lo), 0, 1)
    return out


def mean_stack(arrs: List[Optional[np.ndarray]]) -> Optional[np.ndarray]:
    arrs = [a for a in arrs if a is not None]
    if not arrs:
        return None
    return np.nanmean(np.stack(arrs, axis=0), axis=0)

def benefit(s0: np.ndarray, sx: np.ndarray, target: str):
    if BENEFIT_DIRECTION[target] == "decrease_is_benefit":
        return s0 - sx
    return sx - s0

def pos_benefit(arr: np.ndarray):
    return np.where(np.isfinite(arr), np.maximum(arr, 0), np.nan)

def load_city_targets(target_inv: pd.DataFrame, city: str):
    city_inv = target_inv[target_inv["City"] == city]
    ref_row = city_inv[(city_inv["Scenario"] == "S0") & (city_inv["Target"] == "F1")]
    if ref_row.empty:
        ref_row = city_inv.iloc[[0]]
    ref_arr, ref_meta = read_raster(Path(ref_row["Path"].iloc[0]))

    targets = {}
    for _, row in tqdm(list(city_inv.iterrows()), total=len(city_inv), desc=f"{city} load targets", unit="file"):
        arr, meta = read_raster(Path(row["Path"]))
        if arr.shape != ref_arr.shape or meta["transform"] != ref_meta["transform"] or meta["crs"] != ref_meta["crs"]:
            arr = align_to_ref(Path(row["Path"]), ref_meta, categorical=False)
        targets[(row["Scenario"], row["Target"])] = arr
    return targets, ref_meta

def load_covariates(city: str, scenario: str, scenario_cov_inv: pd.DataFrame, base_cov_inv: pd.DataFrame, ref_meta: dict):
    covs = {}

    # 情景变量优先
    sc = scenario_cov_inv[(scenario_cov_inv["City"] == city) & (scenario_cov_inv["Scenario"] == scenario)]
    for _, row in sc.iterrows():
        cov = row["Covariate"]
        categorical = cov == "LULC"
        covs[cov] = align_to_ref(Path(row["Path"]), ref_meta, categorical=categorical)

    # 城市根目录变量补充
    bc = base_cov_inv[base_cov_inv["City"] == city] if not base_cov_inv.empty else pd.DataFrame()
    for _, row in bc.iterrows():
        if row["Covariate"] not in covs:
            cov = row["Covariate"]
            categorical = cov == "LULC"
            covs[cov] = align_to_ref(Path(row["Path"]), ref_meta, categorical=categorical)

    return covs

def exposure_indices(covs: Dict[str, np.ndarray], mask: np.ndarray):
    z = {k: robust01(v, mask) for k, v in covs.items()}

    out = {}
    out["ExposurePopulation"] = mean_stack([z.get("PopD"), z.get("PD"), z.get("P")])
    out["ExposureEconomic"] = mean_stack([z.get("GDP"), z.get("NTL")])

    bd = z.get("BD")
    bh = z.get("BH")
    built = np.sqrt(np.maximum(bd, 0) * np.maximum(bh, 0)) if bd is not None and bh is not None else None
    out["ExposureBuilt"] = mean_stack([built, z.get("RD"), z.get("NTL")])

    out["ExposureComposite"] = mean_stack([
        out.get("ExposurePopulation"),
        out.get("ExposureEconomic"),
        out.get("ExposureBuilt"),
    ])
    out["EcologicalContext"] = mean_stack([z.get("NDVI"), z.get("GVI"), z.get("Micro_PSA"), z.get("SVF")])
    out["RunoffPressureContext"] = mean_stack([z.get("Micro_ISA"), z.get("BD"), z.get("RD")])

    return {k: v for k, v in out.items() if v is not None}

# ============================================================
# 3. 计算地图层
# ============================================================
def compute_layers_for_city_scenario(city: str, scenario: str, targets: Dict[Tuple[str, str], np.ndarray],
                                     covs: Dict[str, np.ndarray], mask: np.ndarray):
    layers = {}

    f1_s0 = targets.get(("S0", "F1"))
    f2_s0 = targets.get(("S0", "F2"))
    f3_s0 = targets.get(("S0", "F3"))
    f1 = targets.get((scenario, "F1"))
    f2 = targets.get((scenario, "F2"))
    f3 = targets.get((scenario, "F3"))

    if f1_s0 is None or f1 is None:
        return layers

    exposures = exposure_indices(covs, mask)

    # 原始层
    if f1 is not None:
        layers["RawF1"] = f1
    if f2 is not None:
        layers["RawF2"] = f2
    if f3 is not None:
        layers["RawF3"] = f3

    # 三目标适应收益
    b1 = pos_benefit(benefit(f1_s0, f1, "F1"))
    b2 = pos_benefit(benefit(f2_s0, f2, "F2")) if f2_s0 is not None and f2 is not None else None
    b3 = pos_benefit(benefit(f3_s0, f3, "F3")) if f3_s0 is not None and f3 is not None else None

    # 收益层必须使用专门归一化，避免 S0 零收益被归一化为 0.5
    b1n = normalize_positive_benefit(b1, mask)
    b2n = normalize_positive_benefit(b2, mask) if b2 is not None else None
    b3n = normalize_positive_benefit(b3, mask) if b3 is not None else None

    layers["RiskReductionSupply"] = b1
    layers["RiskReductionSupplyNorm"] = b1n
    if b2 is not None:
        layers["BenefitLive"] = b2
        layers["BenefitLiveNorm"] = b2n
    if b3 is not None:
        layers["BenefitFunction"] = b3
        layers["BenefitFunctionNorm"] = b3n

    benefit_total = mean_stack([b1n, b2n, b3n])
    if benefit_total is not None:
        layers["BenefitTotal"] = benefit_total

    # 适应需求：S0 风险 × 暴露
    f1_base_norm = robust01(f1_s0, mask)

    demand_layers = {}
    demand_layers["DemandRiskOnly"] = f1_base_norm
    if "ExposurePopulation" in exposures:
        demand_layers["DemandPopulation"] = f1_base_norm * exposures["ExposurePopulation"]
    if "ExposureEconomic" in exposures:
        demand_layers["DemandEconomic"] = f1_base_norm * exposures["ExposureEconomic"]
    if "ExposureBuilt" in exposures:
        demand_layers["DemandBuilt"] = f1_base_norm * exposures["ExposureBuilt"]
    if "ExposureComposite" in exposures:
        demand_layers["DemandComposite"] = f1_base_norm * exposures["ExposureComposite"]
    else:
        # 兜底，至少能计算
        demand_layers["DemandComposite"] = f1_base_norm

    for k, v in demand_layers.items():
        layers[k] = v

    # ACR / residual / mismatch / aligned
    for dname, demand_arr in demand_layers.items():
        suffix = dname.replace("Demand", "")
        supply = b1n
        acr = supply / (demand_arr + 1e-12)
        acr_raw = np.where(np.isfinite(acr), acr, np.nan)
        acr_cap = np.where(np.isfinite(acr), np.minimum(acr, 5), np.nan)
        residual = np.where(np.isfinite(demand_arr) & np.isfinite(supply), np.maximum(demand_arr - supply, 0), np.nan)
        mismatch = np.where(np.isfinite(demand_arr) & np.isfinite(supply), demand_arr - supply, np.nan)
        aligned = np.where(np.isfinite(demand_arr) & np.isfinite(supply), demand_arr * supply, np.nan)

        layers[f"ACR{suffix}"] = acr_cap
        layers[f"ACRRaw{suffix}"] = acr_raw
        layers[f"ResidualDemand{suffix}"] = residual
        layers[f"Mismatch{suffix}"] = mismatch
        layers[f"DemandAlignedBenefit{suffix}"] = aligned

    # 暴露耦合收益
    if "ExposurePopulation" in exposures:
        layers["PopExposureWeightedRiskReduction"] = b1 * exposures["ExposurePopulation"]
    if "ExposureEconomic" in exposures:
        layers["EconExposureWeightedRiskReduction"] = b1 * exposures["ExposureEconomic"]
    if "ExposureBuilt" in exposures:
        layers["BuiltExposureWeightedRiskReduction"] = b1 * exposures["ExposureBuilt"]
    if "ExposureComposite" in exposures:
        layers["CompositeExposureWeightedRiskReduction"] = b1 * exposures["ExposureComposite"]

    # 不平等分组：worse-off / average / better-off
    if benefit_total is not None:
        vals = benefit_total[mask & np.isfinite(benefit_total)]
        cls = np.full_like(benefit_total, np.nan, dtype="float64")
        if vals.size > 0:
            p20, p80 = np.nanpercentile(vals, [20, 80])
            cls[(benefit_total <= p20) & mask] = -1
            cls[(benefit_total > p20) & (benefit_total < p80) & mask] = 0
            cls[(benefit_total >= p80) & mask] = 1
        layers["BenefitDeviationClass"] = cls

    # 高需求但覆盖不足：DemandComposite top20 且 ACRComposite < 1
    demand_comp = layers.get("DemandComposite")
    acr_comp = layers.get("ACRComposite")
    unmet = np.full_like(f1_base_norm, np.nan, dtype="float64")
    if demand_comp is not None and acr_comp is not None:
        vals = demand_comp[mask & np.isfinite(demand_comp)]
        if vals.size > 0:
            high = demand_comp >= np.nanpercentile(vals, 80)
            unmet[(high) & (acr_comp < 1) & mask] = 1
            unmet[(~((high) & (acr_comp < 1))) & mask] = 0
    layers["UnmetHighDemand"] = unmet

    # 暴露层也输出
    for k, v in exposures.items():
        layers[k] = v

    return layers

# ============================================================
# 4. 坐标转换与蜂巢聚合
# ============================================================
def raster_pixel_xy(ref_meta: dict, valid_mask: np.ndarray, sample_step: int = 1):
    rows, cols = np.where(valid_mask)
    if sample_step > 1:
        rows = rows[::sample_step]
        cols = cols[::sample_step]
    xs, ys = xy(ref_meta["transform"], rows, cols, offset="center")
    return np.asarray(xs, dtype="float64"), np.asarray(ys, dtype="float64"), rows, cols

def transform_to_metric(xs: np.ndarray, ys: np.ndarray, src_crs):
    """
    将栅格坐标转换到米制坐标。
    如果原始 CRS 已经是投影坐标，也仍然转换到 EPSG:3857，保证 HEX_SCALES_M 是米。
    """
    if src_crs is None:
        # 没有 CRS，只能用原始坐标。此时 HEX_SCALES_M 实际不是米。
        return xs, ys, "SOURCE_UNDEFINED"

    try:
        src = rasterio.crs.CRS.from_user_input(src_crs)
        if str(src).upper() == METRIC_CRS:
            return xs, ys, METRIC_CRS
        x2, y2 = rio_transform(src, METRIC_CRS, xs.tolist(), ys.tolist())
        return np.asarray(x2, dtype="float64"), np.asarray(y2, dtype="float64"), METRIC_CRS
    except Exception:
        return xs, ys, "SOURCE_TRANSFORM_FAILED"

def hex_ids_metric(x: np.ndarray, y: np.ndarray, radius: float, origin_x: float, origin_y: float):
    """
    flat-top hex axial coordinates.
    """
    X = x - origin_x
    Y = y - origin_y

    q = (2.0 / 3.0 * X) / radius
    r = (-1.0 / 3.0 * X + np.sqrt(3) / 3.0 * Y) / radius

    cx = q
    cz = r
    cy = -cx - cz

    rx = np.round(cx)
    ry = np.round(cy)
    rz = np.round(cz)

    x_diff = np.abs(rx - cx)
    y_diff = np.abs(ry - cy)
    z_diff = np.abs(rz - cz)

    m_x = (x_diff > y_diff) & (x_diff > z_diff)
    m_y = (~m_x) & (y_diff > z_diff)
    m_z = ~(m_x | m_y)

    rx[m_x] = -ry[m_x] - rz[m_x]
    ry[m_y] = -rx[m_y] - rz[m_y]
    rz[m_z] = -rx[m_z] - ry[m_z]

    q_int = rx.astype(int)
    r_int = rz.astype(int)
    hex_key = np.char.add(np.char.add(q_int.astype(str), "_"), r_int.astype(str))
    return q_int, r_int, hex_key

def hex_center_metric(q: np.ndarray, r: np.ndarray, radius: float, origin_x: float, origin_y: float):
    cx = radius * (3.0 / 2.0 * q)
    cy = radius * (np.sqrt(3) * (r + q / 2.0))
    return origin_x + cx, origin_y + cy

def gini_1d(values: np.ndarray):
    v = np.asarray(values, dtype="float64")
    v = v[np.isfinite(v)]
    if v.size == 0:
        return np.nan
    if np.nanmin(v) < 0:
        v = v - np.nanmin(v)
    v = np.maximum(v, 0)
    s = np.sum(v)
    if s <= 0:
        return 0.0
    v = np.sort(v)
    n = len(v)
    i = np.arange(1, n + 1)
    return float((2 * np.sum(i * v) / (n * s)) - (n + 1) / n)

def theil_1d(values: np.ndarray):
    v = np.asarray(values, dtype="float64")
    v = v[np.isfinite(v)]
    if v.size == 0:
        return np.nan
    if np.nanmin(v) < 0:
        v = v - np.nanmin(v)
    v = np.maximum(v, 0) + 1e-12
    mu = np.mean(v)
    if mu <= 0:
        return 0.0
    r = v / mu
    return float(np.mean(r * np.log(r)))

def top20_share_1d(values: np.ndarray):
    v = np.asarray(values, dtype="float64")
    v = v[np.isfinite(v)]
    if v.size == 0:
        return np.nan
    if np.nanmin(v) < 0:
        v = v - np.nanmin(v)
    v = np.maximum(v, 0)
    s = np.sum(v)
    if s <= 0:
        return 0.0
    k = max(1, int(np.ceil(0.2 * len(v))))
    return float(np.sum(np.sort(v)[-k:]) / s)

def aggregate_indicator_to_hex(city: str, scenario: str, scale_m: float, indicator: str,
                               arr: np.ndarray, valid_mask: np.ndarray,
                               coords: dict, ref_meta: dict):
    """
    单尺度快速版 hex 聚合。
    只计算地图所需的 N_pix、Mean、Median、CenterX、CenterY；
    不再逐 hex 计算 Gini/Theil/Top20，从而大幅提速。
    """
    rows = coords["rows"]
    cols = coords["cols"]
    q = coords[f"q_{scale_m}"]
    r = coords[f"r_{scale_m}"]
    hkey = coords[f"hex_key_{scale_m}"]
    cx = coords[f"center_x_{scale_m}"]
    cy = coords[f"center_y_{scale_m}"]

    vals = arr[rows, cols]
    good = np.isfinite(vals)
    if good.sum() == 0:
        return pd.DataFrame()

    df = pd.DataFrame({
        "q": q[good],
        "r": r[good],
        "hex_key": hkey[good],
        "center_x": cx[good],
        "center_y": cy[good],
        "value": vals[good],
    })

    g = df.groupby(["q", "r", "hex_key"], sort=False)
    out = g.agg(
        N_pix=("value", "size"),
        Mean=("value", "mean"),
        Median=("value", "median"),
        CenterX=("center_x", "mean"),
        CenterY=("center_y", "mean"),
    ).reset_index()

    out["City"] = city
    out["Scenario"] = scenario
    out["Scale_m"] = scale_m
    out["Indicator"] = indicator
    return out

def build_city_hex_coordinates(ref_meta: dict, valid_mask: np.ndarray, scales_m: List[float], sample_step: int):
    xs, ys, rows, cols = raster_pixel_xy(ref_meta, valid_mask, sample_step=sample_step)
    xm, ym, metric_crs = transform_to_metric(xs, ys, ref_meta["crs"])

    origin_x = np.nanmin(xm)
    origin_y = np.nanmin(ym)

    coords = {
        "rows": rows,
        "cols": cols,
        "x_metric": xm,
        "y_metric": ym,
        "metric_crs": metric_crs,
        "origin_x": origin_x,
        "origin_y": origin_y,
    }

    for scale in scales_m:
        q, r, hkey = hex_ids_metric(xm, ym, scale, origin_x, origin_y)
        cx, cy = hex_center_metric(q, r, scale, origin_x, origin_y)
        coords[f"q_{scale}"] = q
        coords[f"r_{scale}"] = r
        coords[f"hex_key_{scale}"] = hkey
        coords[f"center_x_{scale}"] = cx
        coords[f"center_y_{scale}"] = cy

    return coords

# ============================================================
# 5. 绘图函数
# ============================================================
def robust_limits_from_hex(hex_df: pd.DataFrame, indicator: str, value_col="Mean", q=(2, 98)):
    sub = hex_df[hex_df["Indicator"] == indicator]
    vals = sub[value_col].to_numpy(dtype="float64")
    vals = vals[np.isfinite(vals)]
    if vals.size == 0:
        return 0, 1
    lo, hi = np.nanpercentile(vals, q)
    if not np.isfinite(lo) or not np.isfinite(hi) or hi <= lo:
        lo, hi = np.nanmin(vals), np.nanmax(vals)
    if hi <= lo:
        hi = lo + 1e-6
    return float(lo), float(hi)

def make_hex_patches(df: pd.DataFrame, scale_m: float, value_col="Mean"):
    patches = []
    values = []
    for _, row in df.iterrows():
        patches.append(
            RegularPolygon(
                (row["CenterX"], row["CenterY"]),
                numVertices=6,
                radius=scale_m * 0.96,
                orientation=np.radians(30)
            )
        )
        values.append(row[value_col])
    return patches, np.asarray(values, dtype="float64")

def plot_hex_panel(ax, df: pd.DataFrame, scale_m: float, indicator: str,
                   vmin=None, vmax=None, cmap="RdYlBu_r",
                   categorical=False, title=""):
    ax.set_aspect("equal")
    ax.set_xticks([])
    ax.set_yticks([])
    for s in ax.spines.values():
        s.set_linewidth(0.9)
        s.set_color("black")

    if df.empty:
        ax.set_title(title, fontsize=10, fontweight="bold")
        ax.text(0.5, 0.5, "No data", transform=ax.transAxes, ha="center", va="center")
        return None

    if categorical:
        # BenefitDeviationClass: -1 / 0 / 1
        cat_colors = {-1: "#d73027", 0: "#f0f0f0", 1: "#1a9850"}
        colors = []
        patches = []
        for _, row in df.iterrows():
            patches.append(
                RegularPolygon(
                    (row["CenterX"], row["CenterY"]),
                    numVertices=6,
                    radius=scale_m * 0.96,
                    orientation=np.radians(30)
                )
            )
            val = row["Mean"]
            # hex 内平均分类值，重新归到 -1/0/1
            if val <= -0.33:
                colors.append(cat_colors[-1])
            elif val >= 0.33:
                colors.append(cat_colors[1])
            else:
                colors.append(cat_colors[0])
        pc = PatchCollection(patches, facecolor=colors, edgecolor="none", linewidth=0.0)
        ax.add_collection(pc)
        ax.autoscale_view()
        ax.set_title(title, fontsize=10, fontweight="bold")
        return pc

    patches, values = make_hex_patches(df, scale_m, value_col="Mean")
    pc = PatchCollection(patches, cmap=cmap, edgecolor="none", linewidth=0.0)
    pc.set_array(values)
    pc.set_clim(vmin, vmax)
    ax.add_collection(pc)
    ax.autoscale_view()
    ax.set_title(title, fontsize=10, fontweight="bold")
    return pc

def plot_composite_map(hex_df: pd.DataFrame, scenario: str, scale_m: float, indicators: List[str],
                       out_path_base: Path, title: str):
    nrow = len(indicators)
    ncol = len(CITY_ORDER)
    fig, axes = plt.subplots(nrow, ncol, figsize=(2.45 * ncol, 2.45 * nrow))
    if nrow == 1:
        axes = np.asarray([axes])

    plt.subplots_adjust(left=0.065, right=0.925, top=0.92, bottom=0.04, wspace=0.04, hspace=0.10)

    last_pc_by_indicator = {}

    for r, indicator in enumerate(indicators):
        categorical = indicator == "BenefitDeviationClass"
        vmin, vmax = robust_limits_from_hex(hex_df, indicator)
        if indicator.startswith("ACR"):
            vmin, vmax = 0, 5

        for c, city in enumerate(CITY_ORDER):
            ax = axes[r, c]
            sub = hex_df[
                (hex_df["City"] == city) &
                (hex_df["Scenario"] == scenario) &
                (hex_df["Scale_m"] == scale_m) &
                (hex_df["Indicator"] == indicator)
            ]
            title_cell = city if r == 0 else ""
            pc = plot_hex_panel(
                ax, sub, scale_m, indicator,
                vmin=vmin, vmax=vmax,
                cmap="RdYlBu_r",
                categorical=categorical,
                title=title_cell
            )
            if pc is not None:
                last_pc_by_indicator[indicator] = pc
            if c == 0:
                ax.set_ylabel(indicator, fontsize=10.5, fontweight="bold")

        # colorbar per row
        pc = last_pc_by_indicator.get(indicator)
        if pc is not None and not categorical:
            pos = axes[r, -1].get_position()
            cax = fig.add_axes([0.935, pos.y0 + 0.01, 0.010, pos.height - 0.02])
            cb = fig.colorbar(pc, cax=cax)
            cb.ax.tick_params(labelsize=7)
        elif categorical:
            pos = axes[r, -1].get_position()
            cax = fig.add_axes([0.935, pos.y0 + 0.01, 0.055, pos.height - 0.02])
            cax.axis("off")
            cax.text(0, 0.72, "Better-off", fontsize=7, color="#1a9850")
            cax.text(0, 0.50, "Average", fontsize=7, color="#555555")
            cax.text(0, 0.28, "Worse-off", fontsize=7, color="#d73027")

    fig.suptitle(title, fontsize=16, fontweight="bold", y=0.985)
    out_path_base.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(str(out_path_base) + ".png", dpi=DPI, bbox_inches="tight")
    fig.savefig(str(out_path_base) + ".pdf", bbox_inches="tight")
    plt.close(fig)

def plot_single_indicator_map(hex_df: pd.DataFrame, scenario: str, scale_m: float, indicator: str, out_path_base: Path):
    fig, axes = plt.subplots(2, 3, figsize=(12.5, 7.6))
    axes = axes.ravel()
    plt.subplots_adjust(left=0.035, right=0.90, top=0.88, bottom=0.04, wspace=0.04, hspace=0.08)

    categorical = indicator == "BenefitDeviationClass"
    vmin, vmax = robust_limits_from_hex(hex_df, indicator)
    if indicator.startswith("ACR"):
        vmin, vmax = 0, 5

    last_pc = None
    for i, city in enumerate(CITY_ORDER):
        sub = hex_df[
            (hex_df["City"] == city) &
            (hex_df["Scenario"] == scenario) &
            (hex_df["Scale_m"] == scale_m) &
            (hex_df["Indicator"] == indicator)
        ]
        pc = plot_hex_panel(
            axes[i], sub, scale_m, indicator,
            vmin=vmin, vmax=vmax,
            cmap="RdYlBu_r",
            categorical=categorical,
            title=city
        )
        if pc is not None:
            last_pc = pc

    if last_pc is not None and not categorical:
        cax = fig.add_axes([0.915, 0.20, 0.014, 0.55])
        cb = fig.colorbar(last_pc, cax=cax)
        cb.ax.tick_params(labelsize=8)

    fig.suptitle(f"{scenario} | {indicator} | hex scale = {int(scale_m)} m", fontsize=15, fontweight="bold", y=0.98)
    out_path_base.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(str(out_path_base) + ".png", dpi=DPI, bbox_inches="tight")
    fig.savefig(str(out_path_base) + ".pdf", bbox_inches="tight")
    plt.close(fig)

# ============================================================
# 6. 主程序
# ============================================================
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--project-root", default=DEFAULT_PROJECT_ROOT)
    parser.add_argument("--scenario-root", default=DEFAULT_SCENARIO_ROOT)
    parser.add_argument("--output-dir", default=DEFAULT_OUTPUT_DIR)
    parser.add_argument("--sample-step", type=int, default=SAMPLE_STEP)
    parser.add_argument("--scenarios", nargs="*", default=SCENARIOS_TO_PLOT)
    parser.add_argument("--scales", nargs="*", type=float, default=HEX_SCALES_M)
    args = parser.parse_args()

    project_root = Path(args.project_root)
    scenario_root = Path(args.scenario_root)
    out_dir = Path(args.output_dir)

    table_dir = out_dir / "01_tables"
    hex_dir = out_dir / "02_hex_data"
    fig_dir = out_dir / "03_hex_figures"
    raster_dir = out_dir / "04_optional_raster_layers"

    for d in [table_dir, hex_dir, fig_dir, raster_dir]:
        d.mkdir(parents=True, exist_ok=True)

    target_inv, scenario_cov_inv, debug_df = inventory_scenario_rasters(scenario_root)
    base_cov_inv = inventory_base_covariates(project_root)

    debug_df.to_csv(table_dir / "00_DEBUG_all_tifs_in_city_scenario_rasters.csv", index=False, encoding="utf-8-sig")
    target_inv.to_csv(table_dir / "00_target_file_inventory.csv", index=False, encoding="utf-8-sig")
    scenario_cov_inv.to_csv(table_dir / "00_scenario_covariate_file_inventory.csv", index=False, encoding="utf-8-sig")
    base_cov_inv.to_csv(table_dir / "00_base_covariate_file_inventory.csv", index=False, encoding="utf-8-sig")

    print("\n[MATCHED TARGET FILES - first 80 rows only]", flush=True)
    print(target_inv.head(80).to_string(index=False), flush=True)

    if target_inv.empty:
        raise FileNotFoundError("没有匹配到 S0-S7 的 F1/F2/F3。请查看 00_DEBUG_all_tifs_in_city_scenario_rasters.csv")

    # 关键诊断：上面只是 head(80)，不代表只匹配了这些城市。
    # 这个表会明确显示六城 S0-S7 是否都匹配到 F1/F2/F3。
    target_count = (
        target_inv.groupby(["City", "Scenario"])["Target"]
        .nunique()
        .unstack(fill_value=0)
        .reindex(CITY_ORDER)
    )
    target_count.to_csv(table_dir / "00_city_scenario_target_count.csv", encoding="utf-8-sig")
    print("\n[PER-CITY TARGET COUNT] 每个格子应该是 3，表示 F1/F2/F3 都匹配到了", flush=True)
    print(target_count.to_string(), flush=True)

    missing_rows = []
    for _city in CITY_ORDER:
        for _scenario in SCENARIOS:
            sub = target_inv[(target_inv["City"] == _city) & (target_inv["Scenario"] == _scenario)]
            got = sorted(sub["Target"].unique().tolist())
            miss = [t for t in TARGETS if t not in got]
            if miss:
                missing_rows.append({
                    "City": _city,
                    "Scenario": _scenario,
                    "MatchedTargets": ",".join(got),
                    "MissingTargets": ",".join(miss)
                })
    missing_df = pd.DataFrame(missing_rows)
    missing_df.to_csv(table_dir / "00_missing_city_scenario_targets.csv", index=False, encoding="utf-8-sig")

    if not missing_df.empty:
        print("\n[WARNING] 有城市/情景缺少目标栅格，请查看 00_missing_city_scenario_targets.csv", flush=True)
        print(missing_df.to_string(index=False), flush=True)
    else:
        print("\n[OK] 六个城市 S0-S7 的 F1/F2/F3 都匹配到了。", flush=True)
        print("如果前面的 MATCHED TARGET FILES 里没看到 Shenzhen/Tianjin，只是因为 head(80) 截断显示。", flush=True)

    print("\n[RUN_CITIES] 本次实际计算城市：", RUN_CITIES, flush=True)

    all_layer_summary = []
    all_hex_rows = []

    for city in tqdm(RUN_CITIES, desc="Cities", unit="city"):
        city_targets = target_inv[target_inv["City"] == city]
        if city_targets.empty:
            continue

        print(f"\n[LOAD CITY] {city}", flush=True)
        targets, ref_meta = load_city_targets(target_inv, city)

        # 有效掩膜
        valid_mask = np.zeros((ref_meta["height"], ref_meta["width"]), dtype=bool)
        for arr in targets.values():
            valid_mask |= np.isfinite(arr)

        # 构建多尺度坐标，只做一次
        coords = build_city_hex_coordinates(ref_meta, valid_mask, args.scales, args.sample_step)

        for scenario in tqdm(args.scenarios, desc=f"{city} scenarios", unit="scenario"):
            # 加载该情景变量
            covs = load_covariates(city, scenario, scenario_cov_inv, base_cov_inv, ref_meta)
            layers = compute_layers_for_city_scenario(city, scenario, targets, covs, valid_mask)
            if not layers:
                continue

            # 栅格层摘要 + 可选输出
            for ind, arr in layers.items():
                vals = finite_vals(arr)
                row = {
                    "City": city,
                    "Scenario": scenario,
                    "Indicator": ind,
                    "N": int(vals.size),
                    "Mean": float(np.nanmean(vals)) if vals.size else np.nan,
                    "Median": float(np.nanmedian(vals)) if vals.size else np.nan,
                    "P10": float(np.nanpercentile(vals, 10)) if vals.size else np.nan,
                    "P90": float(np.nanpercentile(vals, 90)) if vals.size else np.nan,
                    "Min": float(np.nanmin(vals)) if vals.size else np.nan,
                    "Max": float(np.nanmax(vals)) if vals.size else np.nan,
                }
                all_layer_summary.append(row)

                if EXPORT_RASTER_LAYERS and ind in MAP_INDICATORS_TO_PLOT:
                    dtype = "int16" if ind in ["BenefitDeviationClass", "UnmetHighDemand"] else "float32"
                    write_geotiff(raster_dir / f"{city}_{scenario}_{ind}.tif", arr, ref_meta, dtype=dtype)

            # hex 聚合
            for scale in args.scales:
                for ind, arr in layers.items():
                    if ind not in HEX_INDICATORS_TO_AGGREGATE:
                        continue
                    hdf = aggregate_indicator_to_hex(
                        city=city,
                        scenario=scenario,
                        scale_m=scale,
                        indicator=ind,
                        arr=arr,
                        valid_mask=valid_mask,
                        coords=coords,
                        ref_meta=ref_meta,
                    )
                    if hdf.empty:
                        continue
                    all_hex_rows.append(hdf)

                    if EXPORT_SPLIT_HEX_CSV:
                        split_path = hex_dir / "split" / f"scale_{int(scale)}m" / scenario / city / f"{ind}.csv"
                        split_path.parent.mkdir(parents=True, exist_ok=True)
                        hdf.to_csv(split_path, index=False, encoding="utf-8-sig")

    # 汇总输出
    layer_summary_df = pd.DataFrame(all_layer_summary)
    layer_summary_df.to_csv(table_dir / "01_pixel_layer_summary_all_scenarios.csv", index=False, encoding="utf-8-sig")

    hex_all = pd.concat(all_hex_rows, ignore_index=True) if all_hex_rows else pd.DataFrame()
    if EXPORT_HEX_CSV and not hex_all.empty:
        # 全量表可能很大，按 scale 分开更稳
        for scale in args.scales:
            sub = hex_all[hex_all["Scale_m"] == scale]
            sub.to_csv(hex_dir / f"hex_plotting_data_scale_{int(scale)}m.csv", index=False, encoding="utf-8-sig")
        hex_all.to_csv(hex_dir / "hex_plotting_data_ALL_SCALES.csv", index=False, encoding="utf-8-sig")

    if not hex_all.empty:
        # 快速版蜂巢表默认只包含 N_pix / Mean / Median / CenterX / CenterY。
        # 不再强制要求 Gini / Theil_T / Top20_Share，避免 KeyError。
        agg_dict = {
            "HexN": ("hex_key", "nunique"),
            "Mean_of_hex_mean": ("Mean", "mean"),
            "Median_of_hex_median": ("Median", "median"),
        }
        if "N_pix" in hex_all.columns:
            agg_dict["Total_sampled_pixels"] = ("N_pix", "sum")
            agg_dict["Mean_pixels_per_hex"] = ("N_pix", "mean")
        if "Gini" in hex_all.columns:
            agg_dict["Mean_hex_gini"] = ("Gini", "mean")
        if "Theil_T" in hex_all.columns:
            agg_dict["Mean_hex_theil"] = ("Theil_T", "mean")
        if "Top20_Share" in hex_all.columns:
            agg_dict["Mean_hex_top20"] = ("Top20_Share", "mean")

        hs = hex_all.groupby(["City", "Scenario", "Scale_m", "Indicator"]).agg(**agg_dict).reset_index()
        hs.to_csv(table_dir / "02_hex_summary_all_scales.csv", index=False, encoding="utf-8-sig")

    # 画图
    if not hex_all.empty:
        for scale in args.scales:
            for scenario in PLOT_SCENARIOS:
                sub = hex_all[(hex_all["Scale_m"] == scale) & (hex_all["Scenario"] == scenario)]
                if sub.empty:
                    continue

                scale_dir = fig_dir / f"scale_{int(scale)}m" / scenario
                scale_dir.mkdir(parents=True, exist_ok=True)

                # 组图1：收益供给
                benefit_group = ["RiskReductionSupplyNorm", "BenefitLiveNorm", "BenefitFunctionNorm", "BenefitTotal"]
                plot_composite_map(
                    sub, scenario, scale, benefit_group,
                    scale_dir / f"{scenario}_scale_{int(scale)}m_MAP01_benefit_components",
                    title=f"{scenario}: benefit components | hex scale = {int(scale)} m"
                )

                # 组图2：供需匹配
                matching_group = ["DemandComposite", "RiskReductionSupplyNorm", "ACRComposite", "ResidualDemandComposite"]
                plot_composite_map(
                    sub, scenario, scale, matching_group,
                    scale_dir / f"{scenario}_scale_{int(scale)}m_MAP02_supply_demand_matching",
                    title=f"{scenario}: supply–demand matching | hex scale = {int(scale)} m"
                )

                # 组图3：残余诊断
                diagnostic_group = ["MismatchComposite", "DemandAlignedBenefitComposite", "BenefitDeviationClass", "UnmetHighDemand"]
                # DemandAlignedBenefitComposite 名字在层里是 DemandAlignedBenefitComposite，若不存在自动显示 No data。
                plot_composite_map(
                    sub, scenario, scale, diagnostic_group,
                    scale_dir / f"{scenario}_scale_{int(scale)}m_MAP03_residual_diagnostics",
                    title=f"{scenario}: residual gaps and benefit-deviation groups | hex scale = {int(scale)} m"
                )

                if PLOT_SINGLE_INDICATORS:
                    for ind in MAP_INDICATORS_TO_PLOT:
                        plot_single_indicator_map(
                            sub, scenario, scale, ind,
                            scale_dir / f"{scenario}_scale_{int(scale)}m_SINGLE_{ind}"
                        )

    readme = f"""V52 multiscale hex outputs

Input scenario root:
{scenario_root}

Output:
{out_dir}

Scenarios calculated:
{args.scenarios}

Hex scales in meters:
{args.scales}

Core output folders:
01_tables
02_hex_data
03_hex_figures
04_optional_raster_layers

Key tables:
01_tables/00_target_file_inventory.csv
01_tables/00_scenario_covariate_file_inventory.csv
01_tables/00_base_covariate_file_inventory.csv
01_tables/01_pixel_layer_summary_all_scenarios.csv
01_tables/02_hex_summary_all_scales.csv

Hex plotting data:
02_hex_data/hex_plotting_data_scale_1000m.csv
02_hex_data/hex_plotting_data_scale_2000m.csv
02_hex_data/hex_plotting_data_scale_3000m.csv
02_hex_data/hex_plotting_data_scale_5000m.csv
02_hex_data/hex_plotting_data_ALL_SCALES.csv

Main indicators:
RawF1, RawF2, RawF3
RiskReductionSupply, RiskReductionSupplyNorm
BenefitLive, BenefitLiveNorm
BenefitFunction, BenefitFunctionNorm
BenefitTotal
DemandRiskOnly, DemandPopulation, DemandEconomic, DemandBuilt, DemandComposite
ACRRiskOnly, ACRPopulation, ACREconomic, ACRBuilt, ACRComposite
ACRRawRiskOnly, ACRRawPopulation, ACRRawEconomic, ACRRawBuilt, ACRRawComposite
ResidualDemandRiskOnly, ResidualDemandPopulation, ResidualDemandEconomic, ResidualDemandBuilt, ResidualDemandComposite
MismatchRiskOnly, MismatchPopulation, MismatchEconomic, MismatchBuilt, MismatchComposite
DemandAlignedBenefitRiskOnly, DemandAlignedBenefitPopulation, DemandAlignedBenefitEconomic, DemandAlignedBenefitBuilt, DemandAlignedBenefitComposite
PopExposureWeightedRiskReduction, EconExposureWeightedRiskReduction, BuiltExposureWeightedRiskReduction, CompositeExposureWeightedRiskReduction
BenefitDeviationClass, UnmetHighDemand
ExposurePopulation, ExposureEconomic, ExposureBuilt, ExposureComposite, EcologicalContext, RunoffPressureContext

Interpretation:
- DemandComposite = normalized baseline flood-risk burden × composite exposure.
- RiskReductionSupplyNorm = normalized positive F1 risk-reduction benefit.
- ACRComposite = supply / demand, capped at 5 for mapping.
- ResidualDemandComposite = max(demand - supply, 0).
- BenefitDeviationClass: -1 = worse-off, 0 = average, 1 = better-off, based on BenefitTotal P20/P80.
- UnmetHighDemand: 1 = top-20% demand cells with ACR < 1.

If F3 is actually CGI loss, set:
BENEFIT_DIRECTION["F3"] = "decrease_is_benefit"
"""
    (out_dir / "README_V52_outputs.txt").write_text(readme, encoding="utf-8")

    print("\n[DONE] V52 multiscale hex outputs saved to:", out_dir, flush=True)
    print("Folders:", flush=True)
    for d in [table_dir, hex_dir, fig_dir, raster_dir]:
        print(" -", d, flush=True)

if __name__ == "__main__":
    main()
