import geopandas as gpd
import pandas as pd
import numpy as np
import rasterio
from rasterio.features import rasterize
from rasterio.transform import from_origin
from shapely.geometry import box
import os
import glob

# --- 1. 配置路径与参数 ---
# GBA.LoD1 示例数据路径 [cite: 21]
geojson_path = r"C:\Users\86133\Downloads\m1782307_rep\m1782307_rep\examples\LoD1\europe\e010_n50_e015_n45.geojson"
# 包含多个面图层（.shp）的文件夹路径
shp_input_folder = r"E:\中国特大城市洪水\全部市图层"
# 结果输出总目录
base_output_folder = r"E:\中国特大城市洪水\整体栅格"

if not os.path.exists(base_output_folder): os.makedirs(base_output_folder)

# 坐标系设置：请确保使用适合您研究区的投影坐标系（单位为米）
target_crs = "EPSG:32650"
resolution = 1000  # 1公里网格

# --- 2. 预加载 GBA 数据 ---
# 注意：如果 GBA 文件非常大，建议在循环内根据 bbox 动态读取以节省内存
print("正在加载 GBA.LoD1 基础数据...")
full_buildings = gpd.read_file(geojson_path)

# --- 3. 批量循环处理 ---
# 获取文件夹下所有的 .shp 文件
shp_files = glob.glob(os.path.join(shp_input_folder, "*.shp"))

for shp_path in shp_files:
    shp_name = os.path.splitext(os.path.basename(shp_path))[0]
    print(f"\n--- 正在处理研究区: {shp_name} ---")

    # 创建该研究区的专属输出文件夹
    area_output_dir = os.path.join(base_output_folder, shp_name)
    if not os.path.exists(area_output_dir): os.makedirs(area_output_dir)

    # 读取当前面图层并转换坐标系
    study_area = gpd.read_file(shp_path).to_crs(target_crs)

    # 裁剪当前区域内的建筑 [cite: 14, 149]
    area_bbox = study_area.total_bounds
    buildings = full_buildings.cx[area_bbox[0]:area_bbox[2], area_bbox[1]:area_bbox[3]].copy()
    buildings = buildings.to_crs(target_crs)

    if buildings.empty:
        print(f"警告：区域 {shp_name} 内没有发现建筑数据，跳过。")
        continue

    # 计算基础数值 [cite: 379]
    buildings['area'] = buildings.geometry.area
    buildings['volume'] = buildings['area'] * buildings['height']

    # --- 4. 定义栅格范围 ---
    xmin, ymin, xmax, ymax = study_area.total_bounds
    xmin, ymin = np.floor(xmin / resolution) * resolution, np.floor(ymin / resolution) * resolution
    xmax, ymax = np.ceil(xmax / resolution) * resolution, np.ceil(ymax / resolution) * resolution

    width = int((xmax - xmin) / resolution)
    height = int((ymax - ymin) / resolution)
    transform = from_origin(xmin, ymax, resolution, resolution)

    # --- 5. 聚合指标计算 ---
    grid_polygons = []
    for x in np.arange(xmin, xmax, resolution):
        for y in np.arange(ymin, ymax, resolution):
            grid_polygons.append(box(x, y, x + resolution, y + resolution))

    grid = gpd.GeoDataFrame({'geometry': grid_polygons}, crs=target_crs)
    grid['grid_id'] = grid.index

    # 空间关联聚合 [cite: 264, 287]
    joined = gpd.sjoin(buildings, grid, how='inner', predicate='within')
    grid_stats = joined.groupby('grid_id').agg(
        patch_density=('height', 'count'),  # 斑块密度（数量）[cite: 52, 295]
        avg_height=('height', 'mean'),  # 平均高度 [cite: 61, 398]
        total_area=('area', 'sum'),  # 建筑覆盖总面积 [cite: 31, 379]
        total_volume=('volume', 'sum')  # 建筑总体积 [cite: 16, 379]
    ).reset_index()

    # 计算衍生指标 [cite: 31, 763]
    grid_stats['building_density'] = grid_stats['total_area'] / (resolution ** 2)  # 建筑密度
    grid_stats['far'] = grid_stats['total_volume'] / (resolution ** 2 * 3.0)  # 容积率（假设标准层高3m）

    final_grid = grid.merge(grid_stats, on='grid_id', how='left').fillna(0)

    # --- 6. 导出栅格 ---
    metrics = {
        'building_density': '建筑密度',
        'patch_density': '斑块密度',
        'far': '容积率',
        'avg_height': '平均高度',
        'total_volume': '建筑总体积'
    }

    for col, label in metrics.items():
        out_tif = os.path.join(area_output_dir, f"{shp_name}_{col}_1km.tif")
        shapes = ((geom, value) for geom, value in zip(final_grid.geometry, final_grid[col]))
        raster = rasterize(shapes, out_shape=(height, width), transform=transform, fill=0, dtype='float32')

        with rasterio.open(out_tif, 'w', driver='GTiff', height=height, width=width, count=1,
                           dtype='float32', crs=target_crs, transform=transform) as dst:
            dst.write(raster, 1)

print("\n--- 所有面图层批量处理完成 ---")