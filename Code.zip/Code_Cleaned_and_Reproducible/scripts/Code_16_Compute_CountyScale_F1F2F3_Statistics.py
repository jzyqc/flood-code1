# -*- coding: utf-8 -*-
"""
统计六城市 S0-S7 下 F1/F2/F3 栅格的区县尺度统计值，并计算区县 Raw_Composite。

输入：
1. 全国县级 shp:
   E:\西辽河\shp格式\中国_县.shp

2. 六城市情景栅格根目录:
   E:\中国特大城市洪水\Cascade_Optimization_FINAL_SIXCITY_PHYSICAL_RASTERS\03_city_scenarios

目录结构示例：
03_city_scenarios/
    Beijing/rasters/S0_F1.tif
    Beijing/rasters/S0_F2.tif
    Beijing/rasters/S0_F3.tif
    ...
    Tianjin/rasters/S7_F3.tif

输出：
1. county_stats_long_F1F2F3.csv
2. county_stats_wide_median_F1.csv / F2 / F3 / Raw_Composite
3. county_stats_wide_mean_F1.csv / F2 / F3 / Raw_Composite
4. county_stats_all_F1F2F3.xlsx
5. used_counties_for_F1F2F3.shp
"""

import warnings
from pathlib import Path

import numpy as np
import pandas as pd
import geopandas as gpd
import rasterio
from rasterio.features import rasterize
from rasterio.warp import transform_bounds
from shapely.geometry import box

warnings.filterwarnings("ignore")


# ============================================================
# 1. 路径设置
# ============================================================

COUNTY_SHP = Path(r"E:\西辽河\shp格式\中国_县.shp")

RASTER_ROOT = Path(
    r"E:\中国特大城市洪水\Cascade_Optimization_FINAL_SIXCITY_PHYSICAL_RASTERS\03_city_scenarios"
)

OUT_DIR = Path(r"E:\中国特大城市洪水\county_F1F2F3_stats")
OUT_DIR.mkdir(parents=True, exist_ok=True)

CITIES = ["Beijing", "Chengdu", "Guangzhou", "Shanghai", "Shenzhen", "Tianjin"]

SCENARIOS = [f"S{i}" for i in range(8)]

TARGETS = ["F1", "F2", "F3"]


# ============================================================
# 2. 自动识别区县名称字段
# ============================================================

def guess_county_name_field(gdf):
    candidates = [
        "NAME", "Name", "name",
        "县", "县名", "区县", "区县名",
        "名称", "地名", "NAME_CHN",
        "县代码", "adcode", "ADCODE", "PAC"
    ]

    for c in candidates:
        if c in gdf.columns:
            return c

    non_geom_cols = [c for c in gdf.columns if c != "geometry"]

    if len(non_geom_cols) == 0:
        raise ValueError("没有找到区县名称字段，请手动指定 county_name_field。")

    return non_geom_cols[0]


# ============================================================
# 3. 收集所有 S0-S7 的 F1/F2/F3 栅格
# ============================================================

def collect_rasters():
    records = []

    for city in CITIES:
        raster_dir = RASTER_ROOT / city / "rasters"

        if not raster_dir.exists():
            print(f"警告：未找到城市栅格文件夹：{raster_dir}")
            continue

        for scen in SCENARIOS:
            for target in TARGETS:
                tif = raster_dir / f"{scen}_{target}.tif"

                if not tif.exists():
                    print(f"警告：未找到栅格：{tif}")
                    continue

                records.append({
                    "City": city,
                    "Scenario": scen,
                    "Indicator": target,
                    "RasterPath": tif
                })

    if len(records) == 0:
        raise FileNotFoundError(
            "没有找到任何 F1/F2/F3 栅格。请检查 RASTER_ROOT、城市文件夹名和 tif 文件名。"
        )

    return pd.DataFrame(records)


raster_table = collect_rasters()

print("找到栅格数量：", len(raster_table))
print(raster_table.head())


# ============================================================
# 4. 读取全国县级 shp，并筛选研究区相关区县
# ============================================================

print("\n读取全国县级 shp ...")
county_gdf = gpd.read_file(COUNTY_SHP)

if county_gdf.crs is None:
    raise ValueError("县级 shp 没有 CRS，请先定义投影。")

print("县级 shp 字段：")
print(list(county_gdf.columns))

county_name_field = guess_county_name_field(county_gdf)
print("识别到的区县名称字段：", county_name_field)

county_gdf = county_gdf[county_gdf.geometry.notna()].copy()
county_gdf["geometry"] = county_gdf.geometry.buffer(0)

county_gdf = county_gdf.reset_index(drop=True)
county_gdf["county_uid"] = np.arange(1, len(county_gdf) + 1)

# 以第一个栅格 CRS 作为基础 CRS
with rasterio.open(raster_table["RasterPath"].iloc[0]) as src0:
    base_crs = src0.crs

county_base = county_gdf.to_crs(base_crs)

# 汇总所有栅格范围，并统一转换到 base_crs
bounds_geoms = []

for tif in raster_table["RasterPath"]:
    with rasterio.open(tif) as src:
        b = transform_bounds(src.crs, base_crs, *src.bounds, densify_pts=21)
        bounds_geoms.append(box(*b))

total_bounds = gpd.GeoSeries(bounds_geoms, crs=base_crs).total_bounds
total_box = box(*total_bounds)

county_clip = county_base[county_base.intersects(total_box)].copy()

print("全国区县数量：", len(county_gdf))
print("与六城市栅格总范围相交的区县数量：", len(county_clip))

used_counties_path = OUT_DIR / "used_counties_for_F1F2F3.shp"
county_clip.to_file(used_counties_path, encoding="utf-8")
print("已保存参与统计的区县 shp：", used_counties_path)


# ============================================================
# 5. 单个栅格的区县统计函数
# ============================================================

def zonal_stats_one_raster(
    raster_path,
    city,
    scenario,
    indicator,
    county_gdf_base,
    county_name_field,
    all_touched=True
):
    with rasterio.open(raster_path) as src:
        raster_crs = src.crs
        arr = src.read(1).astype("float64")
        transform = src.transform
        out_shape = arr.shape
        nodata = src.nodata
        raster_bounds = box(*src.bounds)

        if nodata is not None:
            arr[arr == nodata] = np.nan

        arr[~np.isfinite(arr)] = np.nan

        if str(county_gdf_base.crs) != str(raster_crs):
            counties = county_gdf_base.to_crs(raster_crs)
        else:
            counties = county_gdf_base.copy()

        counties = counties[counties.intersects(raster_bounds)].copy()

        if len(counties) == 0:
            return pd.DataFrame()

        shapes = [
            (geom, uid)
            for geom, uid in zip(counties.geometry, counties["county_uid"])
            if geom is not None and not geom.is_empty
        ]

        zone_arr = rasterize(
            shapes=shapes,
            out_shape=out_shape,
            transform=transform,
            fill=0,
            dtype="int32",
            all_touched=all_touched
        )

        valid_mask = (zone_arr > 0) & np.isfinite(arr)

        if valid_mask.sum() == 0:
            return pd.DataFrame()

        temp = pd.DataFrame({
            "county_uid": zone_arr[valid_mask],
            "value": arr[valid_mask]
        })

        stats = temp.groupby("county_uid")["value"].agg(
            count="count",
            mean="mean",
            median="median",
            min="min",
            max="max",
            std="std"
        ).reset_index()

        q = temp.groupby("county_uid")["value"].quantile([0.25, 0.75]).unstack()
        q.columns = ["p25", "p75"]
        q = q.reset_index()

        stats = stats.merge(q, on="county_uid", how="left")

        attrs = counties[["county_uid", county_name_field, "geometry"]].copy()

        # 面积用等面积投影估算，避免经纬度下 area 不准
        try:
            attrs_area = counties[["county_uid", "geometry"]].to_crs("EPSG:6933")
            attrs["area_km2"] = attrs_area.geometry.area.values / 1e6
        except Exception:
            attrs["area_km2"] = np.nan

        attrs = attrs.drop(columns="geometry")
        stats = stats.merge(attrs, on="county_uid", how="left")
        stats = stats.rename(columns={county_name_field: "CountyName"})

        stats.insert(0, "City", city)
        stats.insert(1, "Scenario", scenario)
        stats.insert(2, "Indicator", indicator)
        stats.insert(3, "RasterPath", str(raster_path))

        return stats


# ============================================================
# 6. 循环统计所有城市 S0-S7 的 F1/F2/F3
# ============================================================

all_stats = []

for idx, row in raster_table.iterrows():
    city = row["City"]
    scenario = row["Scenario"]
    indicator = row["Indicator"]
    raster_path = row["RasterPath"]

    print(f"正在统计：{city} - {scenario} - {indicator}")

    stats = zonal_stats_one_raster(
        raster_path=raster_path,
        city=city,
        scenario=scenario,
        indicator=indicator,
        county_gdf_base=county_clip,
        county_name_field=county_name_field,
        all_touched=True
    )

    if len(stats) > 0:
        all_stats.append(stats)
    else:
        print(f"警告：{city} - {scenario} - {indicator} 没有统计到区县像元。")

if len(all_stats) == 0:
    raise RuntimeError("没有统计到任何区县结果，请检查 shp 与 raster 是否重叠。")

result_long = pd.concat(all_stats, ignore_index=True)

cols = [
    "City", "Scenario", "Indicator", "RasterPath",
    "county_uid", "CountyName", "area_km2",
    "count", "mean", "median", "min", "max", "std", "p25", "p75"
]
result_long = result_long[[c for c in cols if c in result_long.columns]]

print("\nF1/F2/F3 统计完成，总记录数：", len(result_long))
print(result_long.head())


# ============================================================
# 7. 生成 F1/F2/F3 宽表
# ============================================================

wide_tables = {}

for indicator in TARGETS:
    sub = result_long[result_long["Indicator"] == indicator].copy()

    wide_median = sub.pivot_table(
        index=["City", "county_uid", "CountyName"],
        columns="Scenario",
        values="median",
        aggfunc="first"
    ).reset_index()

    wide_mean = sub.pivot_table(
        index=["City", "county_uid", "CountyName"],
        columns="Scenario",
        values="mean",
        aggfunc="first"
    ).reset_index()

    wide_count = sub.pivot_table(
        index=["City", "county_uid", "CountyName"],
        columns="Scenario",
        values="count",
        aggfunc="first"
    ).reset_index()

    for df, name in [(wide_median, "median"), (wide_mean, "mean")]:
        if "S0" in df.columns and "S7" in df.columns:
            df[f"S7_minus_S0_{name}"] = df["S7"] - df["S0"]
            df[f"S7_relative_change_pct_{name}"] = (
                (df["S7"] - df["S0"]) / df["S0"].replace(0, np.nan)
            ) * 100

    wide_tables[(indicator, "median")] = wide_median
    wide_tables[(indicator, "mean")] = wide_mean
    wide_tables[(indicator, "count")] = wide_count


# ============================================================
# 8. 计算区县尺度 Raw_Composite
# ============================================================
# 这里用区县 median 计算：
# F1、F2 越大越好；
# F3 如果是 loss/cost，一般越小越好，所以默认对 F3 反向归一化。
# 如果你的 F3 本身是“越大越好”，把 F3_INVERSE = False。

F3_INVERSE = True

def minmax_norm(s, inverse=False):
    s = pd.to_numeric(s, errors="coerce")
    vmin = s.min()
    vmax = s.max()

    if pd.isna(vmin) or pd.isna(vmax) or vmax == vmin:
        out = pd.Series(np.nan, index=s.index)
    else:
        out = (s - vmin) / (vmax - vmin)

    if inverse:
        out = 1 - out

    return out

# 合并 F1/F2/F3 median 宽表
f1_med = wide_tables[("F1", "median")].copy()
f2_med = wide_tables[("F2", "median")].copy()
f3_med = wide_tables[("F3", "median")].copy()

id_cols = ["City", "county_uid", "CountyName"]

composite_rows = []

for scen in SCENARIOS:
    temp = f1_med[id_cols + [scen]].rename(columns={scen: "F1"})
    temp = temp.merge(
        f2_med[id_cols + [scen]].rename(columns={scen: "F2"}),
        on=id_cols,
        how="outer"
    )
    temp = temp.merge(
        f3_med[id_cols + [scen]].rename(columns={scen: "F3"}),
        on=id_cols,
        how="outer"
    )

    temp["Scenario"] = scen

    # 分城市归一化，避免不同城市数值范围差异过大
    out_parts = []

    for city, g in temp.groupby("City"):
        g = g.copy()
        g["F1_norm"] = minmax_norm(g["F1"], inverse=False)
        g["F2_norm"] = minmax_norm(g["F2"], inverse=False)
        g["F3_norm"] = minmax_norm(g["F3"], inverse=F3_INVERSE)
        g["Raw_Composite"] = g[["F1_norm", "F2_norm", "F3_norm"]].mean(axis=1)
        out_parts.append(g)

    temp = pd.concat(out_parts, ignore_index=True)
    composite_rows.append(temp)

county_composite_long = pd.concat(composite_rows, ignore_index=True)

composite_wide = county_composite_long.pivot_table(
    index=id_cols,
    columns="Scenario",
    values="Raw_Composite",
    aggfunc="first"
).reset_index()

if "S0" in composite_wide.columns and "S7" in composite_wide.columns:
    composite_wide["S7_minus_S0_Raw_Composite"] = composite_wide["S7"] - composite_wide["S0"]
    composite_wide["S7_relative_change_pct_Raw_Composite"] = (
        (composite_wide["S7"] - composite_wide["S0"]) / composite_wide["S0"].replace(0, np.nan)
    ) * 100


# ============================================================
# 9. 导出结果
# ============================================================

long_csv = OUT_DIR / "county_stats_long_F1F2F3.csv"
result_long.to_csv(long_csv, index=False, encoding="utf-8-sig")

# 单独导出各指标宽表
for (indicator, stat_name), df in wide_tables.items():
    out_csv = OUT_DIR / f"county_stats_wide_{stat_name}_{indicator}.csv"
    df.to_csv(out_csv, index=False, encoding="utf-8-sig")

composite_long_csv = OUT_DIR / "county_Raw_Composite_long.csv"
composite_wide_csv = OUT_DIR / "county_Raw_Composite_wide.csv"

county_composite_long.to_csv(composite_long_csv, index=False, encoding="utf-8-sig")
composite_wide.to_csv(composite_wide_csv, index=False, encoding="utf-8-sig")

xlsx_path = OUT_DIR / "county_stats_all_F1F2F3_RawComposite.xlsx"

with pd.ExcelWriter(xlsx_path, engine="openpyxl") as writer:
    result_long.to_excel(writer, sheet_name="long_F1F2F3", index=False)

    for indicator in TARGETS:
        wide_tables[(indicator, "median")].to_excel(
            writer, sheet_name=f"{indicator}_median", index=False
        )
        wide_tables[(indicator, "mean")].to_excel(
            writer, sheet_name=f"{indicator}_mean", index=False
        )
        wide_tables[(indicator, "count")].to_excel(
            writer, sheet_name=f"{indicator}_count", index=False
        )

    county_composite_long.to_excel(
        writer, sheet_name="RawComposite_long", index=False
    )
    composite_wide.to_excel(
        writer, sheet_name="RawComposite_wide", index=False
    )

print("\n全部导出完成：")
print(long_csv)

for (indicator, stat_name), df in wide_tables.items():
    print(OUT_DIR / f"county_stats_wide_{stat_name}_{indicator}.csv")

print(composite_long_csv)
print(composite_wide_csv)
print(xlsx_path)
print(used_counties_path)