# -*- coding: utf-8 -*-
"""
Complete RF-based SHAP / ablation extrapolation workflow for six-city flood samples

你现在的数据逻辑
----------------
1. 六城市样本点是 shp：
   label / City / SampType / ValidRat / geometry
2. 24 个解释变量是每个城市文件夹里的 tif 栅格；
3. 本脚本先从栅格提取点变量；
4. 用点数据重新训练一个 RF 模型；
5. 点尺度用 TreeSHAP 做机制解释；
6. 全域栅格外推参考你给的代码：
      P_original = model.predict(X_full)
      P_without_var = model.predict(X_full with variable set to baseline)
      Contribution_var = P_original - P_without_var
   这相当于 reference code 里的：
      SHAP_name = GNNWLR_pred - lack_name
   严格说这是 leave-one-variable-out ablation contribution，不是标准 Shapley TreeSHAP；
   但空间外推表达非常直观，和你给的代码逻辑一致。

输出
----
A. 点数据训练/解释
- Extracted_SHP_points_with_24vars.csv
- RF_ablation_model.joblib
- Point_TreeSHAP_values.csv
- SHAP_variable_importance_by_city.csv
- SHAP_group_importance_by_city.csv
- Figure_Point_TreeSHAP_Mechanism.png/pdf/tif

B. 全域 SHAP-like 空间外推
每个城市输出：
- <City>_AblationContribution_<var>.tif
- <City>_GroupContribution_<group>.tif
- <City>_Dominant_positive_group_code.tif
- <City>_Dominant_positive_group_strength.tif

说明：不再输出历史预测概率图；这里只做 SHAP/贡献类结果。

C. 六城市图
- Figure_Spatial_AblationSHAP_DominantDriver_SixCities.png/pdf/tif

注意
----
- 不调用 torch；
- 不使用你已有 GNNWRL；
- 不做模型对比；
- 不做 CV 验证；
- 只重新训练一个用于 SHAP/外推归因的 RF 模型。
"""

import os
import glob
import warnings
from pathlib import Path

warnings.filterwarnings("ignore")

import numpy as np
import pandas as pd
import geopandas as gpd
import rasterio
from rasterio.enums import Resampling
from rasterio.warp import reproject
from rasterio.transform import from_origin
from rasterio.features import geometry_mask

import joblib
import shap

from sklearn.ensemble import RandomForestClassifier
from sklearn.utils.class_weight import compute_sample_weight

import matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpec
from matplotlib.colors import ListedColormap, BoundaryNorm
from mpl_toolkits.axes_grid1.inset_locator import inset_axes

try:
    from scipy.ndimage import uniform_filter
except Exception:
    uniform_filter = None


# =========================================================
# 0. Paths
# =========================================================

CITY_DIRS = {
    "Beijing": r"E:\中国特大城市洪水\北京市数据",
    "Chengdu": r"E:\中国特大城市洪水\成都市数据",
    "Guangzhou": r"E:\中国特大城市洪水\广州市数据",
    "Shanghai": r"E:\中国特大城市洪水\上海市数据",
    "Shenzhen": r"E:\中国特大城市洪水\深圳市数据",
    "Tianjin": r"E:\中国特大城市洪水\天津市数据",
}

POINT_DIR = r"E:\中国特大城市洪水\最终点数据"

POINT_FILES = {
    "Beijing": os.path.join(POINT_DIR, "Beijing_样本数据.shp"),
    "Chengdu": os.path.join(POINT_DIR, "chengdu_样本数据.shp"),
    "Guangzhou": os.path.join(POINT_DIR, "guangzhou_样本数据.shp"),
    "Shanghai": os.path.join(POINT_DIR, "Shanghai_样本数据.shp"),
    "Shenzhen": os.path.join(POINT_DIR, "Shenzhen_样本数据.shp"),
    "Tianjin": os.path.join(POINT_DIR, "Tianjin_样本数据.shp"),
}

# 输出文件夹
OUT_ROOT = r"E:\中国特大城市洪水\RF_SHAP_and_Spatial_Extrapolation_Only"
os.makedirs(OUT_ROOT, exist_ok=True)

POINT_OUT_DIR = os.path.join(OUT_ROOT, "01_Point_RF_TreeSHAP")
RASTER_OUT_DIR = os.path.join(OUT_ROOT, "02_FullDomain_AblationContribution")
FIG_OUT_DIR = os.path.join(OUT_ROOT, "03_Figures")
MODEL_OUT_DIR = os.path.join(OUT_ROOT, "models")
for d in [POINT_OUT_DIR, RASTER_OUT_DIR, FIG_OUT_DIR, MODEL_OUT_DIR]:
    os.makedirs(d, exist_ok=True)

# 可选：行政区/研究区 mask。支持 shp/tif。
# 如果不填，会使用 Rx1day 栅格有效范围作为 mask。
CITY_MASK_FILES = {
    "Beijing": None,
    "Chengdu": None,
    "Guangzhou": None,
    "Shanghai": None,
    "Shenzhen": None,
    "Tianjin": None,
}


# =========================================================
# 1. Settings
# =========================================================

CITY_COL = "City"
LABEL_COL = "label"
X_COL = "x"
Y_COL = "y"
CITY_ORDER = ["Beijing", "Chengdu", "Guangzhou", "Shanghai", "Shenzhen", "Tianjin"]

RANDOM_STATE = 42
rng = np.random.default_rng(RANDOM_STATE)

# 是否重新提取点变量。
# False 时，如果缓存 CSV 已存在，则直接读取。
FORCE_REEXTRACT_POINTS = False

# 是否重新训练 RF。
# False 时，如果 RF 模型已存在，则直接读取。
FORCE_RETRAIN_RF = True

# 是否运行全域栅格外推。
RUN_FULL_DOMAIN_EXTRAPOLATION = True

# 全域外推模式：
# "all"：mask 内全部像元，正式出图；
# "sample"：只抽样像元，检查用，输出 tif 会是稀疏的。
FULL_DOMAIN_MODE = "all"
FULL_DOMAIN_SAMPLE_N = 120000

# 栅格分块大小。内存不够就调小到 10000。
PREDICT_BATCH_SIZE = 50000

# 点 TreeSHAP 每城最多点数。点很多时控制速度。
MAX_POINT_SHAP_N_PER_CITY = 10000
TREE_SHAP_BACKGROUND_N = 1200

# 全域变量贡献方式：
# "zero" 严格模仿你给的参考代码 temp[:, i] = 0；
# "median" 更稳健，把变量设为训练集 median。
ABLATION_BASELINE_MODE = "zero"

# 是否保存 24 个变量贡献 tif。正式分析建议 True；只要组图可设 False。
SAVE_VARIABLE_CONTRIBUTION_TIFS = True

# 是否保存 5 个变量组贡献 tif。
SAVE_GROUP_CONTRIBUTION_TIFS = True

# 不再输出历史预测概率 tif；只把 P_original 作为计算贡献的中间变量。
SAVE_RF_PROBABILITY_TIF = False

# 最低有效变量比例。低于此比例的像元不计算。
MIN_VALID_VAR_RATIO = 0.20


# =========================================================
# 2. Variables
# =========================================================

MODEL_VARS = [
    "Rx1day", "Rx5day", "CWD",
    "EV", "SL", "PRC", "TWI", "TPI",
    "ST", "NDVI", "LULC",
    "BD", "PD", "BH", "BVI",
    "CFI", "FOE", "GVI",
    "Micro_ISA", "Micro_PSA",
    "SCE", "SEL", "SVF", "TAE"
]

ZERO_FILL_VARS = ["BD", "PD", "BH", "BVI", "Micro_ISA", "Micro_PSA"]
MISSING_INDICATOR_BASE_VARS = ["BD", "PD", "BH", "BVI", "Micro_ISA", "Micro_PSA"]

GROUPS = {
    "Climate": ["Rx1day", "Rx5day", "CWD"],
    "Terrain": ["EV", "SL", "PRC", "TWI", "TPI", "ST"],
    "Land cover": ["NDVI", "LULC"],
    "Built form": ["BD", "PD", "BH", "BVI", "Micro_ISA", "Micro_PSA"],
    "Streetscape": ["CFI", "FOE", "GVI", "SCE", "SEL", "SVF", "TAE"],
}
GROUP_ORDER = ["Climate", "Terrain", "Land cover", "Built form", "Streetscape"]

GROUP_COLORS = {
    "Climate": "#C43B4D",
    "Terrain": "#5E8CBA",
    "Land cover": "#6FAE75",
    "Built form": "#D99A3D",
    "Streetscape": "#7B65A7",
}

CITY_COLORS = {
    "Beijing": "#C43B4D",
    "Chengdu": "#D99A3D",
    "Guangzhou": "#6FAE75",
    "Shanghai": "#5E8CBA",
    "Shenzhen": "#7B65A7",
    "Tianjin": "#5B8E8D",
}

GROUP_CMAP = ListedColormap([GROUP_COLORS[g] for g in GROUP_ORDER])
GROUP_NORM = BoundaryNorm(np.arange(0.5, len(GROUP_ORDER) + 1.5), GROUP_CMAP.N)

RESPONSE_VARS = ["Rx1day", "TWI", "BD", "GVI"]
DEPENDENCE_PAIRS = [
    ("Rx1day", "TWI"),
    ("Rx1day", "Micro_ISA"),
    ("BD", "GVI"),
    ("Micro_ISA", "Micro_PSA"),
]

RASTER_STEMS = {
    "Rx1day": ["Rx1day", "RX1DAY", "rx1day"],
    "Rx5day": ["Rx5day", "RX5DAY", "rx5day"],
    "CWD": ["CWD", "cwd"],
    "EV": ["EV", "ev"],
    "SL": ["SL", "sl", "Slope", "slope"],
    "PRC": ["PRC", "prc"],
    "TWI": ["TWI", "twi"],
    "TPI": ["TPI", "tpi"],
    "ST": ["ST", "st"],
    "NDVI": ["NDVI", "ndvi"],
    "LULC": ["LULC", "LU", "lulc", "lu"],
    "BD": ["BD", "bd"],
    "PD": ["PD", "pd"],
    "BH": ["BH", "bh"],
    "BVI": ["BVI", "bvi"],
    "CFI": ["CFI", "cfi"],
    "FOE": ["FOE", "foe"],
    "GVI": ["GVI", "gvi"],
    "Micro_ISA": ["Micro_ISA", "MICRO_ISA", "micro_isa", "MicroISA", "M_ISA"],
    "Micro_PSA": ["Micro_PSA", "MICRO_PSA", "micro_psa", "MicroPSA", "M_PSA"],
    "SCE": ["SCE", "sce"],
    "SEL": ["SEL", "sel", "SEI", "sei"],
    "SVF": ["SVF", "svf"],
    "TAE": ["TAE", "tae"],
}


# =========================================================
# 3. Preprocessor
# =========================================================

class RFPreprocessor:
    """
    轻量预处理：
    - 原始 24 变量；
    - 对建筑/微观变量添加 missing indicator；
    - ZERO_FILL_VARS 缺失填 0；
    - 其他变量缺失填训练集 median；
    - 不做标准化，因为 RF 不需要。
    """
    def __init__(self, model_vars, zero_fill_vars, missing_indicator_base_vars):
        self.model_vars = list(model_vars)
        self.zero_fill_vars = list(zero_fill_vars)
        self.missing_indicator_base_vars = [v for v in missing_indicator_base_vars if v in self.model_vars]
        self.missing_indicator_vars = [f"{v}_missing" for v in self.missing_indicator_base_vars]
        self.feature_vars = self.model_vars + self.missing_indicator_vars
        self.median_fill_vars = [v for v in self.model_vars if v not in self.zero_fill_vars]
        self.medians_ = {}

    def fit(self, df):
        for v in self.median_fill_vars:
            vals = pd.to_numeric(df[v], errors="coerce")
            med = float(vals.median(skipna=True))
            if not np.isfinite(med):
                med = 0.0
            self.medians_[v] = med
        return self

    def transform(self, df):
        X_raw = df[self.model_vars].copy()
        X = pd.DataFrame(index=df.index)

        for v in self.model_vars:
            X[v] = pd.to_numeric(X_raw[v], errors="coerce")

        for v in self.missing_indicator_base_vars:
            X[f"{v}_missing"] = X[v].isna().astype(float)

        for v in self.zero_fill_vars:
            if v in X.columns:
                X[v] = X[v].fillna(0.0)

        for v in self.median_fill_vars:
            fill = self.medians_.get(v, 0.0)
            X[v] = X[v].fillna(fill)

        return X[self.feature_vars].astype(np.float32)

    def fit_transform(self, df):
        self.fit(df)
        return self.transform(df)

    def make_ablation_raw(self, df, var):
        """
        按参考代码 temp[:, i] = 0 逻辑，构造去掉某变量后的 raw df。
        """
        out = df.copy()
        if ABLATION_BASELINE_MODE.lower() == "median":
            out[var] = self.medians_.get(var, 0.0)
        else:
            out[var] = 0.0
        return out


# =========================================================
# 4. Raster utilities
# =========================================================

def find_raster_exact(folder, aliases):
    tif_files = []
    tif_files.extend(glob.glob(os.path.join(folder, "**", "*.tif"), recursive=True))
    tif_files.extend(glob.glob(os.path.join(folder, "**", "*.tiff"), recursive=True))

    aliases_lower = [a.lower() for a in aliases]

    exact = []
    for f in tif_files:
        stem = Path(f).stem.lower()
        if stem in aliases_lower:
            exact.append(f)
    if exact:
        return sorted(exact, key=lambda x: len(str(x)))[0]

    contains = []
    for f in tif_files:
        stem = Path(f).stem.lower()
        for a in aliases_lower:
            if a in stem:
                contains.append(f)
                break
    if contains:
        return sorted(contains, key=lambda x: len(str(x)))[0]

    return None


def build_city_raster_paths(city, folder):
    paths = {}
    for var in MODEL_VARS:
        path = find_raster_exact(folder, RASTER_STEMS.get(var, [var]))
        if path is None:
            raise FileNotFoundError(f"{city} 缺少变量栅格: {var}，请检查 {folder}")
        paths[var] = path
    return paths


def read_as_template(src_path, template_profile, resampling):
    with rasterio.open(src_path) as src:
        arr = src.read(1, masked=True).astype("float32").filled(np.nan)
        if src.nodata is not None:
            arr[np.isclose(arr, src.nodata)] = np.nan
        arr[np.isinf(arr)] = np.nan

        same_grid = (
            src.height == template_profile["height"]
            and src.width == template_profile["width"]
            and src.crs == template_profile["crs"]
            and src.transform == template_profile["transform"]
        )

        if same_grid:
            return arr.astype(np.float32)

        dst = np.full((template_profile["height"], template_profile["width"]), np.nan, dtype=np.float32)
        reproject(
            source=arr,
            destination=dst,
            src_transform=src.transform,
            src_crs=src.crs,
            dst_transform=template_profile["transform"],
            dst_crs=template_profile["crs"],
            src_nodata=np.nan,
            dst_nodata=np.nan,
            resampling=resampling
        )
        return dst.astype(np.float32)


def write_float_tif(out_path, arr, profile, nodata=-9999.0):
    out_profile = profile.copy()
    out_profile.update(
        dtype="float32",
        count=1,
        nodata=nodata,
        compress="lzw",
        BIGTIFF="IF_SAFER"
    )

    arr_out = arr.astype(np.float32).copy()
    arr_out[~np.isfinite(arr_out)] = nodata

    os.makedirs(os.path.dirname(out_path), exist_ok=True)

    with rasterio.open(out_path, "w", **out_profile) as dst:
        dst.write(arr_out, 1)


def sample_raster_values_for_gdf(gdf, raster_path):
    with rasterio.open(raster_path) as src:
        gdf_proj = gdf
        if gdf.crs is not None and src.crs is not None and gdf.crs != src.crs:
            gdf_proj = gdf.to_crs(src.crs)

        coords = [(geom.x, geom.y) if geom is not None else (np.nan, np.nan) for geom in gdf_proj.geometry]
        vals = np.full(len(coords), np.nan, dtype=np.float32)

        valid_idx = [i for i, (x, y) in enumerate(coords) if np.isfinite(x) and np.isfinite(y)]
        valid_coords = [coords[i] for i in valid_idx]

        if valid_coords:
            sampled = list(src.sample(valid_coords))
            for j, val in zip(valid_idx, sampled):
                v = float(val[0])
                if src.nodata is not None and np.isclose(v, src.nodata):
                    v = np.nan
                if not np.isfinite(v):
                    v = np.nan
                vals[j] = v

    return vals


# =========================================================
# 5. Read points and extract raster features
# =========================================================

def read_city_points(city, shp_path):
    shp_path = Path(shp_path)
    if not shp_path.exists():
        raise FileNotFoundError(f"{city} 点 shp 不存在：{shp_path}")

    print(f"[Read SHP] {city}: {shp_path}")
    gdf = gpd.read_file(shp_path)
    if gdf.empty:
        raise ValueError(f"{city} shp 为空：{shp_path}")

    gdf[CITY_COL] = city

    # label 兼容
    if LABEL_COL not in gdf.columns:
        for cand in ["Label", "label", "y", "Y", "class", "Class", "flood", "Flood"]:
            if cand in gdf.columns:
                gdf[LABEL_COL] = gdf[cand]
                break

    if LABEL_COL not in gdf.columns:
        raise ValueError(f"{city} shp 缺少 label 字段。")

    try:
        gdf[X_COL] = gdf.geometry.x
        gdf[Y_COL] = gdf.geometry.y
    except Exception:
        pass

    return gdf


def extract_features_for_city_points(city):
    folder = CITY_DIRS[city]
    shp_path = POINT_FILES[city]
    gdf = read_city_points(city, shp_path)
    raster_paths = build_city_raster_paths(city, folder)

    for var in MODEL_VARS:
        vals = sample_raster_values_for_gdf(gdf, raster_paths[var])
        if var == "LULC":
            vals = np.rint(vals).astype(np.float32)
        gdf[var] = vals
        print(f"  [Extract] {var:<10} {Path(raster_paths[var]).name:<28} valid={np.isfinite(vals).mean():.3f}")

    keep_cols = [CITY_COL, X_COL, Y_COL, LABEL_COL] + MODEL_VARS
    keep_cols = [c for c in keep_cols if c in gdf.columns]

    df = pd.DataFrame(gdf[keep_cols].copy())

    df[LABEL_COL] = pd.to_numeric(df[LABEL_COL], errors="coerce")
    for v in MODEL_VARS:
        df[v] = pd.to_numeric(df[v], errors="coerce")

    return df


def read_or_extract_points():
    out_csv = os.path.join(POINT_OUT_DIR, "Extracted_SHP_points_with_24vars.csv")

    if os.path.exists(out_csv) and not FORCE_REEXTRACT_POINTS:
        print(f"[Use cached points] {out_csv}")
        return pd.read_csv(out_csv)

    parts = []
    for city in CITY_ORDER:
        parts.append(extract_features_for_city_points(city))

    df = pd.concat(parts, axis=0, ignore_index=True)

    # label 必须是 0/1
    df = df[df[LABEL_COL].notna()].copy()
    df[LABEL_COL] = df[LABEL_COL].astype(int)

    miss = df[MODEL_VARS].isna().mean().sort_values(ascending=False)
    miss.to_csv(os.path.join(POINT_OUT_DIR, "Extracted_variable_missing_ratio.csv"), encoding="utf-8-sig")

    print("\n[Point data summary]")
    print(f"total={len(df):,}")
    for city in CITY_ORDER:
        sub = df[df[CITY_COL] == city]
        print(f"  {city}: n={len(sub):,}, label={sub[LABEL_COL].value_counts(dropna=False).to_dict()}")
    print("\n[Missing ratio]")
    print(miss)

    df.to_csv(out_csv, index=False, encoding="utf-8-sig")
    print(f"[Saved points] {out_csv}")
    return df


# =========================================================
# 6. Train RF and point TreeSHAP
# =========================================================

def train_or_load_rf(points):
    model_path = os.path.join(MODEL_OUT_DIR, "RF_ablation_shap_model.joblib")

    if os.path.exists(model_path) and not FORCE_RETRAIN_RF:
        print(f"[Load RF model] {model_path}")
        pkg = joblib.load(model_path)
        return pkg["preprocessor"], pkg["rf_model"]

    print("\n[Train RF model for SHAP/ablation]")
    preprocessor = RFPreprocessor(MODEL_VARS, ZERO_FILL_VARS, MISSING_INDICATOR_BASE_VARS)
    X = preprocessor.fit_transform(points)
    y = points[LABEL_COL].astype(int).values

    sample_weight = compute_sample_weight(class_weight="balanced", y=y)

    rf = RandomForestClassifier(
        n_estimators=500,
        max_depth=None,
        min_samples_leaf=5,
        max_features="sqrt",
        class_weight=None,
        n_jobs=-1,
        random_state=RANDOM_STATE,
        bootstrap=True,
    )
    rf.fit(X, y, sample_weight=sample_weight)

    pkg = {
        "preprocessor": preprocessor,
        "rf_model": rf,
        "model_vars": MODEL_VARS,
        "feature_vars": preprocessor.feature_vars,
        "label_col": LABEL_COL,
        "ablation_baseline_mode": ABLATION_BASELINE_MODE,
    }
    joblib.dump(pkg, model_path)
    print(f"[Saved RF model] {model_path}")
    return preprocessor, rf


def sample_points_for_shap(points):
    parts = []
    for city in CITY_ORDER:
        sub = points[points[CITY_COL] == city].copy()
        if len(sub) == 0:
            continue

        if len(sub) > MAX_POINT_SHAP_N_PER_CITY:
            sampled = []
            for _, g in sub.groupby(LABEL_COL, dropna=False):
                n_g = max(1, int(MAX_POINT_SHAP_N_PER_CITY * len(g) / len(sub)))
                sampled.append(g.sample(min(n_g, len(g)), random_state=RANDOM_STATE))
            sub = pd.concat(sampled, axis=0)
            if len(sub) > MAX_POINT_SHAP_N_PER_CITY:
                sub = sub.sample(MAX_POINT_SHAP_N_PER_CITY, random_state=RANDOM_STATE)

        parts.append(sub)

    return pd.concat(parts, axis=0, ignore_index=True)


def get_positive_class_tree_shap(rf, X, X_bg):
    try:
        explainer = shap.TreeExplainer(
            rf,
            data=X_bg,
            model_output="probability",
            feature_perturbation="interventional"
        )
        shap_values = explainer.shap_values(X, check_additivity=False)
    except Exception:
        explainer = shap.TreeExplainer(
            rf,
            data=X_bg,
            feature_perturbation="interventional"
        )
        shap_values = explainer.shap_values(X, check_additivity=False)

    if isinstance(shap_values, list):
        sv = shap_values[1]
    else:
        arr = np.asarray(shap_values)
        if arr.ndim == 3 and arr.shape[-1] == 2:
            sv = arr[:, :, 1]
        elif arr.ndim == 3 and arr.shape[0] == 2:
            sv = arr[1, :, :]
        else:
            sv = arr

    return np.asarray(sv, dtype=np.float32)


def compute_point_tree_shap(points, preprocessor, rf):
    sample_df = sample_points_for_shap(points)

    bg_parts = []
    each = max(1, TREE_SHAP_BACKGROUND_N // len(CITY_ORDER))
    for city in CITY_ORDER:
        sub = points[points[CITY_COL] == city]
        if len(sub) == 0:
            continue
        bg_parts.append(sub.sample(min(each, len(sub)), random_state=RANDOM_STATE))
    bg_df = pd.concat(bg_parts, axis=0)

    X_sample = preprocessor.transform(sample_df)
    X_bg = preprocessor.transform(bg_df)

    print(f"\n[Point TreeSHAP] sample={len(sample_df):,}, background={len(bg_df):,}")

    prob = rf.predict_proba(X_sample)[:, 1]
    sample_df["P_RF"] = prob.astype(np.float32)

    sv = get_positive_class_tree_shap(rf, X_sample, X_bg)
    shap_df = pd.DataFrame(sv, columns=preprocessor.feature_vars)
    shap_df[CITY_COL] = sample_df[CITY_COL].values
    shap_df["P_RF"] = sample_df["P_RF"].values

    sample_df.to_csv(os.path.join(POINT_OUT_DIR, "Point_TreeSHAP_samples_raw.csv"), index=False, encoding="utf-8-sig")
    shap_df.to_csv(os.path.join(POINT_OUT_DIR, "Point_TreeSHAP_values.csv"), index=False, encoding="utf-8-sig")

    return sample_df.reset_index(drop=True), shap_df.reset_index(drop=True)


def summarize_point_shap(shap_df, preprocessor):
    feature_vars = [v for v in MODEL_VARS if v in shap_df.columns]

    var_rows = []
    for city in CITY_ORDER:
        sub = shap_df[shap_df[CITY_COL] == city]
        if len(sub) == 0:
            continue
        for v in feature_vars:
            var_rows.append({
                "City": city,
                "Variable": v,
                "mean_abs_SHAP": float(np.mean(np.abs(sub[v].values))),
                "mean_SHAP": float(np.mean(sub[v].values)),
            })
    var_imp = pd.DataFrame(var_rows)

    global_imp = (
        var_imp.groupby("Variable", as_index=False)["mean_abs_SHAP"]
        .mean()
        .sort_values("mean_abs_SHAP", ascending=False)
    )

    group_rows = []
    for city in CITY_ORDER:
        sub = shap_df[shap_df[CITY_COL] == city]
        if len(sub) == 0:
            continue
        for group in GROUP_ORDER:
            vars_in_group = [v for v in GROUPS[group] if v in sub.columns]
            val = sum(float(np.mean(np.abs(sub[v].values))) for v in vars_in_group)
            group_rows.append({"City": city, "Group": group, "mean_abs_SHAP": val})
    group_imp = pd.DataFrame(group_rows)

    global_group = (
        group_imp.groupby("Group", as_index=False)["mean_abs_SHAP"]
        .mean()
        .sort_values("mean_abs_SHAP", ascending=False)
    )

    var_imp.to_csv(os.path.join(POINT_OUT_DIR, "TreeSHAP_variable_importance_by_city.csv"), index=False, encoding="utf-8-sig")
    global_imp.to_csv(os.path.join(POINT_OUT_DIR, "TreeSHAP_top_variables_global.csv"), index=False, encoding="utf-8-sig")
    group_imp.to_csv(os.path.join(POINT_OUT_DIR, "TreeSHAP_group_importance_by_city.csv"), index=False, encoding="utf-8-sig")
    global_group.to_csv(os.path.join(POINT_OUT_DIR, "TreeSHAP_group_importance_global.csv"), index=False, encoding="utf-8-sig")

    return var_imp, global_imp, group_imp, global_group


# =========================================================
# 7. Full-domain ablation contribution extrapolation
# =========================================================

def find_city_mask_file(city, folder):
    manual = CITY_MASK_FILES.get(city, None)
    if manual is not None and str(manual).strip():
        if os.path.exists(manual):
            return manual
        raise FileNotFoundError(f"{city} 指定 mask 不存在: {manual}")

    files = []
    files.extend(glob.glob(os.path.join(folder, "**", "*.shp"), recursive=True))
    files.extend(glob.glob(os.path.join(folder, "**", "*.tif"), recursive=True))
    files.extend(glob.glob(os.path.join(folder, "**", "*.tiff"), recursive=True))

    include_keys = ["mask", "掩膜", "边界", "boundary", "市界", "行政", "范围", "study", "extent"]
    exclude_keys = ["样本", "sample", "point", "points", "点", "flood", "train", "test"] + MODEL_VARS

    candidates = []
    for f in files:
        stem = Path(f).stem.lower()
        if any(str(k).lower() in stem for k in exclude_keys):
            continue
        score = sum(2 for k in include_keys if k.lower() in stem)
        if f.lower().endswith(".shp"):
            score += 1
        if score > 0:
            candidates.append((score, f))

    if candidates:
        return sorted(candidates, key=lambda x: (-x[0], len(x[1])))[0][1]

    return None


def make_template_and_mask(city, folder, reference_raster_path):
    mask_path = find_city_mask_file(city, folder)

    if mask_path is None:
        with rasterio.open(reference_raster_path) as src:
            profile = src.profile.copy()
            arr = src.read(1, masked=True).astype("float32").filled(np.nan)
            if src.nodata is not None:
                arr[np.isclose(arr, src.nodata)] = np.nan
            mask = np.isfinite(arr)
            profile.update(count=1, dtype="float32", nodata=-9999.0, compress="lzw", BIGTIFF="IF_SAFER")
        print(f"[Mask] {city}: no boundary mask found, use valid extent of {Path(reference_raster_path).name}")
        return profile, mask

    print(f"[Mask] {city}: {mask_path}")
    suffix = Path(mask_path).suffix.lower()

    if suffix in [".tif", ".tiff"]:
        with rasterio.open(mask_path) as src:
            m = src.read(1, masked=True).astype("float32").filled(np.nan)
            if src.nodata is not None:
                m[np.isclose(m, src.nodata)] = np.nan
            mask = np.isfinite(m) & (m > 0)
            profile = src.profile.copy()
            profile.update(count=1, dtype="float32", nodata=-9999.0, compress="lzw", BIGTIFF="IF_SAFER")
        return profile, mask

    if suffix == ".shp":
        with rasterio.open(reference_raster_path) as ref:
            ref_crs = ref.crs
            ref_transform = ref.transform
            ref_profile = ref.profile.copy()
            xres = abs(ref_transform.a)
            yres = abs(ref_transform.e)

        gdf = gpd.read_file(mask_path)
        if gdf.crs is None:
            raise ValueError(f"mask shp 没有 CRS: {mask_path}")
        gdf = gdf.to_crs(ref_crs)

        minx, miny, maxx, maxy = gdf.total_bounds
        pad = 2
        minx -= pad * xres
        maxx += pad * xres
        miny -= pad * yres
        maxy += pad * yres

        width = int(np.ceil((maxx - minx) / xres))
        height = int(np.ceil((maxy - miny) / yres))
        transform = from_origin(minx, maxy, xres, yres)

        profile = ref_profile.copy()
        profile.update(
            height=height,
            width=width,
            transform=transform,
            crs=ref_crs,
            count=1,
            dtype="float32",
            nodata=-9999.0,
            compress="lzw",
            BIGTIFF="IF_SAFER"
        )

        mask = geometry_mask(
            list(gdf.geometry),
            out_shape=(height, width),
            transform=transform,
            invert=True,
            all_touched=True
        )
        return profile, mask

    raise ValueError(f"不支持的 mask 类型: {mask_path}")


def load_city_raster_stack(city):
    folder = CITY_DIRS[city]
    raster_paths = build_city_raster_paths(city, folder)
    reference_path = raster_paths[MODEL_VARS[0]]

    profile, boundary_mask = make_template_and_mask(city, folder, reference_path)

    arr_dict = {}
    valid_count = np.zeros((profile["height"], profile["width"]), dtype=np.float32)

    print(f"\n[Read rasters] {city}")
    for var in MODEL_VARS:
        rs = Resampling.nearest if var == "LULC" else Resampling.bilinear
        arr = read_as_template(raster_paths[var], profile, rs)
        if var == "LULC":
            arr = np.rint(arr).astype(np.float32)
        arr_dict[var] = arr
        valid_count += np.isfinite(arr).astype(np.float32)
        print(f"  {var:<10} {Path(raster_paths[var]).name}")

    valid_ratio = valid_count / float(len(MODEL_VARS))
    valid_mask = boundary_mask & (valid_ratio >= MIN_VALID_VAR_RATIO)

    print(f"[Valid pixels] {city}: {int(valid_mask.sum()):,} / {valid_mask.size:,}")
    return arr_dict, profile, valid_mask, valid_ratio


def arrdict_to_df(arr_dict, rows, cols):
    return pd.DataFrame({v: arr_dict[v][rows, cols] for v in MODEL_VARS})


def predict_prob(rf, preprocessor, df_raw):
    X = preprocessor.transform(df_raw)
    return rf.predict_proba(X)[:, 1].astype(np.float32)


def compute_city_full_domain_ablation(city, preprocessor, rf):
    city_out = os.path.join(RASTER_OUT_DIR, city)
    os.makedirs(city_out, exist_ok=True)

    arr_dict, profile, valid_mask, valid_ratio = load_city_raster_stack(city)

    rows, cols = np.where(valid_mask)
    n_all = len(rows)

    if FULL_DOMAIN_MODE.lower() == "sample" and n_all > FULL_DOMAIN_SAMPLE_N:
        idx = rng.choice(np.arange(n_all), size=FULL_DOMAIN_SAMPLE_N, replace=False)
        rows_run, cols_run = rows[idx], cols[idx]
        print(f"[Full domain] {city}: sample {len(rows_run):,} / {n_all:,}")
    else:
        rows_run, cols_run = rows, cols
        print(f"[Full domain] {city}: all {len(rows_run):,}")

    h, w = profile["height"], profile["width"]

    p_map = np.full((h, w), np.nan, dtype=np.float32)
    contrib_maps = {v: np.full((h, w), np.nan, dtype=np.float32) for v in MODEL_VARS}

    for start in range(0, len(rows_run), PREDICT_BATCH_SIZE):
        end = min(start + PREDICT_BATCH_SIZE, len(rows_run))
        rr = rows_run[start:end]
        cc = cols_run[start:end]

        df_raw = arrdict_to_df(arr_dict, rr, cc)
        p_origin = predict_prob(rf, preprocessor, df_raw)
        p_map[rr, cc] = p_origin

        # reference-style ablation contribution
        for var in MODEL_VARS:
            df_lack = preprocessor.make_ablation_raw(df_raw, var)
            p_lack = predict_prob(rf, preprocessor, df_lack)
            contrib = p_origin - p_lack
            contrib_maps[var][rr, cc] = contrib.astype(np.float32)

        print(f"  [Ablation] {city}: {start:,}–{end:,}")

    # 不保存历史预测概率图；p_map 只作为 ablation contribution 的中间变量。
    if SAVE_RF_PROBABILITY_TIF:
        write_float_tif(os.path.join(city_out, f"{city}_RF_probability.tif"), p_map, profile)

    # Save variable contributions
    if SAVE_VARIABLE_CONTRIBUTION_TIFS:
        var_dir = os.path.join(city_out, "Variable_Contributions")
        os.makedirs(var_dir, exist_ok=True)
        for var in MODEL_VARS:
            write_float_tif(
                os.path.join(var_dir, f"{city}_AblationContribution_{var}.tif"),
                contrib_maps[var],
                profile
            )

    # Group contributions
    group_maps = {}
    for group in GROUP_ORDER:
        group_arr = np.full((h, w), np.nan, dtype=np.float32)
        group_vars = GROUPS[group]
        stack = np.stack([contrib_maps[v] for v in group_vars], axis=0)
        group_arr = np.nansum(stack, axis=0).astype(np.float32)
        group_arr[~np.isfinite(np.nanmean(stack, axis=0))] = np.nan
        group_maps[group] = group_arr

        if SAVE_GROUP_CONTRIBUTION_TIFS:
            safe_group = group.replace(" ", "_")
            write_float_tif(
                os.path.join(city_out, f"{city}_GroupContribution_{safe_group}.tif"),
                group_arr,
                profile
            )

    # Dominant positive group
    G = np.stack([group_maps[g] for g in GROUP_ORDER], axis=0)
    G_pos = np.where(G > 0, G, 0.0)
    dominant_idx = np.nanargmax(G_pos, axis=0)
    dominant_strength = np.nanmax(G_pos, axis=0)

    dominant_code = dominant_idx.astype(np.float32) + 1
    dominant_code[dominant_strength <= 1e-8] = np.nan
    dominant_code[~valid_mask] = np.nan
    dominant_strength[~valid_mask] = np.nan

    write_float_tif(os.path.join(city_out, f"{city}_Dominant_positive_group_code.tif"), dominant_code, profile)
    write_float_tif(os.path.join(city_out, f"{city}_Dominant_positive_group_strength.tif"), dominant_strength.astype(np.float32), profile)

    # Summary table
    rows_summary = []
    for var in MODEL_VARS:
        vals = contrib_maps[var][np.isfinite(contrib_maps[var])]
        rows_summary.append({
            "City": city,
            "Type": "Variable",
            "Name": var,
            "mean_contribution": float(np.nanmean(vals)) if len(vals) else np.nan,
            "mean_abs_contribution": float(np.nanmean(np.abs(vals))) if len(vals) else np.nan,
            "positive_fraction": float(np.mean(vals > 0)) if len(vals) else np.nan,
        })

    for group in GROUP_ORDER:
        vals = group_maps[group][np.isfinite(group_maps[group])]
        rows_summary.append({
            "City": city,
            "Type": "Group",
            "Name": group,
            "mean_contribution": float(np.nanmean(vals)) if len(vals) else np.nan,
            "mean_abs_contribution": float(np.nanmean(np.abs(vals))) if len(vals) else np.nan,
            "positive_fraction": float(np.mean(vals > 0)) if len(vals) else np.nan,
        })

    summary_df = pd.DataFrame(rows_summary)
    summary_df.to_csv(os.path.join(city_out, f"{city}_AblationContribution_summary.csv"),
                      index=False, encoding="utf-8-sig")

    return {
        "city": city,
        "profile": profile,
        "p_map": p_map,
        "contrib_maps": contrib_maps,
        "group_maps": group_maps,
        "dominant_code": dominant_code,
        "dominant_strength": dominant_strength,
        "summary": summary_df,
    }


# =========================================================
# 8. Plotting
# =========================================================

def clean_axis(ax):
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    for sp in ax.spines.values():
        sp.set_linewidth(0.85)
        sp.set_color("#4B5563")
    ax.tick_params(axis="both", labelsize=8, width=0.7, length=2.5)


def panel_label(ax, label):
    ax.text(-0.10, 1.10, label, transform=ax.transAxes,
            fontsize=13, fontweight="bold", va="top", ha="left")


def smooth_curve(x, y, bins=80, frac=0.10):
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    m = np.isfinite(x) & np.isfinite(y)
    x, y = x[m], y[m]
    if len(x) < 20:
        return x, y

    edges = np.quantile(x, np.linspace(0, 1, bins + 1))
    edges = np.unique(edges)

    xs, ys = [], []
    for i in range(len(edges) - 1):
        mm = (x >= edges[i]) & (x <= edges[i + 1])
        if mm.sum() >= 5:
            xs.append(np.nanmedian(x[mm]))
            ys.append(np.nanmedian(y[mm]))

    xs = np.asarray(xs)
    ys = np.asarray(ys)

    if uniform_filter is not None and len(ys) > 5:
        k = max(3, int(len(ys) * frac))
        ys = uniform_filter(ys, size=k, mode="nearest")

    return xs, ys


def plot_response(ax, sample_df, shap_df, var):
    if var not in sample_df.columns or var not in shap_df.columns:
        ax.text(0.5, 0.5, f"{var}\nmissing", ha="center", va="center")
        return

    x = sample_df[var].values
    y = shap_df[var].values
    cities = sample_df[CITY_COL].astype(str).values

    for city in CITY_ORDER:
        m = cities == city
        if m.sum() == 0:
            continue
        ax.scatter(x[m], y[m], s=5, alpha=0.24,
                   color=CITY_COLORS.get(city, "#777777"), edgecolor="none")

    xs, ys = smooth_curve(x, y)
    if len(xs) > 0:
        ax.plot(xs, ys, color="#111827", lw=1.9)

    ax.axhline(0, color="#6B7280", lw=0.85, ls="--")
    ax.set_xlabel(var, fontsize=8.5, fontweight="bold")
    ax.set_ylabel("TreeSHAP value", fontsize=8.5, fontweight="bold")
    ax.set_title(f"{var} response", fontsize=10, fontweight="bold")
    clean_axis(ax)


def plot_dependence(ax, sample_df, shap_df, var, color_var):
    if var not in sample_df.columns or var not in shap_df.columns or color_var not in sample_df.columns:
        ax.text(0.5, 0.5, f"{var} × {color_var}\nmissing", ha="center", va="center")
        return

    sc = ax.scatter(
        sample_df[var].values,
        shap_df[var].values,
        c=sample_df[color_var].values,
        s=5,
        alpha=0.42,
        cmap="RdYlBu_r",
        edgecolor="none"
    )

    ax.axhline(0, color="#6B7280", lw=0.85, ls="--")
    ax.set_xlabel(var, fontsize=8.5, fontweight="bold")
    ax.set_ylabel(f"TreeSHAP({var})", fontsize=8.5, fontweight="bold")
    ax.set_title(f"{var} × {color_var}", fontsize=10, fontweight="bold")
    clean_axis(ax)

    cax = inset_axes(ax, width="3.5%", height="45%", loc="upper right", borderpad=0.55)
    cbar = plt.colorbar(sc, cax=cax)
    cbar.ax.tick_params(labelsize=6, length=2)
    cbar.set_label(color_var, fontsize=6.5, fontweight="bold")


def draw_point_treeshap_figure(sample_df, shap_df, global_imp, group_imp, global_group):
    plt.rcParams.update({
        "font.family": "Times New Roman",
        "font.size": 9,
        "font.weight": "bold",
        "axes.labelweight": "bold",
        "axes.titleweight": "bold",
        "figure.facecolor": "white",
        "axes.facecolor": "white",
    })

    fig = plt.figure(figsize=(15, 8.8), dpi=180)
    gs = GridSpec(3, 12, figure=fig, height_ratios=[1.05, 1.15, 1.15], hspace=0.50, wspace=0.60)

    # a Group contribution
    ax_a = fig.add_subplot(gs[0, 0:4])
    gdf = global_group.set_index("Group").reindex(GROUP_ORDER).reset_index()
    vals = gdf["mean_abs_SHAP"].values
    y = np.arange(len(GROUP_ORDER))
    ax_a.hlines(y, 0, vals, color="#D1D5DB", lw=4)
    ax_a.scatter(vals, y, s=95,
                 color=[GROUP_COLORS[g] for g in GROUP_ORDER],
                 edgecolor="black", linewidth=0.5, zorder=3)
    ax_a.set_yticks(y)
    ax_a.set_yticklabels(GROUP_ORDER, fontsize=8.5, fontweight="bold")
    ax_a.invert_yaxis()
    ax_a.set_xlabel("mean |TreeSHAP|", fontsize=8.5, fontweight="bold")
    ax_a.set_title("Grouped contribution", fontsize=10, fontweight="bold")
    panel_label(ax_a, "a")
    clean_axis(ax_a)

    # b City × group heatmap
    ax_b = fig.add_subplot(gs[0, 4:8])
    mat = group_imp.pivot(index="City", columns="Group", values="mean_abs_SHAP").reindex(index=CITY_ORDER, columns=GROUP_ORDER)
    mat_norm = mat.div(mat.sum(axis=1), axis=0)

    im = ax_b.imshow(mat_norm.values, cmap="YlOrRd", vmin=0, vmax=np.nanmax(mat_norm.values))
    ax_b.set_xticks(np.arange(len(GROUP_ORDER)))
    ax_b.set_xticklabels(["Climate", "Terrain", "Land\ncover", "Built\nform", "Street-\nscape"],
                         fontsize=7, fontweight="bold")
    ax_b.set_yticks(np.arange(len(CITY_ORDER)))
    ax_b.set_yticklabels(CITY_ORDER, fontsize=7.5, fontweight="bold")

    for i in range(mat_norm.shape[0]):
        for j in range(mat_norm.shape[1]):
            val = mat_norm.values[i, j]
            if np.isfinite(val):
                ax_b.text(j, i, f"{val:.2f}", ha="center", va="center",
                          fontsize=6.3, fontweight="bold", color="#111827")

    ax_b.set_title("City-specific group attribution", fontsize=10, fontweight="bold")
    panel_label(ax_b, "b")
    ax_b.tick_params(length=0)
    for sp in ax_b.spines.values():
        sp.set_visible(False)

    cax = inset_axes(ax_b, width="3%", height="80%", loc="center right", borderpad=-1.25)
    cbar = plt.colorbar(im, cax=cax)
    cbar.ax.tick_params(labelsize=6)
    cbar.set_label("relative contribution", fontsize=6.5, fontweight="bold")

    # c Top variables
    ax_c = fig.add_subplot(gs[0, 8:12])
    top = global_imp.head(12).iloc[::-1]
    ax_c.barh(top["Variable"], top["mean_abs_SHAP"],
              color="#8FBBD9", edgecolor="#334155", linewidth=0.4)
    ax_c.set_xlabel("mean |TreeSHAP|", fontsize=8.5, fontweight="bold")
    ax_c.set_title("Top variables", fontsize=10, fontweight="bold")
    ax_c.tick_params(axis="y", labelsize=7.5)
    panel_label(ax_c, "c")
    clean_axis(ax_c)

    # d-g responses
    axes_resp = [fig.add_subplot(gs[1, 0:3]), fig.add_subplot(gs[1, 3:6]),
                 fig.add_subplot(gs[1, 6:9]), fig.add_subplot(gs[1, 9:12])]
    for ax, var, lab in zip(axes_resp, RESPONSE_VARS, ["d", "e", "f", "g"]):
        plot_response(ax, sample_df, shap_df, var)
        panel_label(ax, lab)

    # h-k dependence
    axes_dep = [fig.add_subplot(gs[2, 0:3]), fig.add_subplot(gs[2, 3:6]),
                fig.add_subplot(gs[2, 6:9]), fig.add_subplot(gs[2, 9:12])]
    for ax, (var, color_var), lab in zip(axes_dep, DEPENDENCE_PAIRS, ["h", "i", "j", "k"]):
        plot_dependence(ax, sample_df, shap_df, var, color_var)
        panel_label(ax, lab)

    fig.suptitle("Point-based RF TreeSHAP mechanism interpretation",
                 fontsize=14, fontweight="bold", y=0.992)

    for ext in ["png", "pdf", "tif"]:
        out = os.path.join(FIG_OUT_DIR, f"Figure_Point_TreeSHAP_Mechanism.{ext}")
        fig.savefig(out, dpi=600 if ext != "pdf" else None, bbox_inches="tight")
        print(f"[Saved] {out}")

    plt.show()


def crop_to_finite(arr, pad=4):
    finite = np.isfinite(arr)
    if not finite.any():
        return arr
    r, c = np.where(finite)
    r0, r1 = max(r.min() - pad, 0), min(r.max() + pad + 1, arr.shape[0])
    c0, c1 = max(c.min() - pad, 0), min(c.max() + pad + 1, arr.shape[1])
    return arr[r0:r1, c0:c1]


def draw_six_city_dominant_map(results):
    plt.rcParams.update({
        "font.family": "Times New Roman",
        "font.size": 10,
        "font.weight": "bold",
        "axes.titleweight": "bold",
        "figure.facecolor": "white",
        "axes.facecolor": "white",
    })

    fig = plt.figure(figsize=(13.0, 8.0), dpi=180)
    gs = GridSpec(2, 3, figure=fig, hspace=0.18, wspace=0.08)

    for i, city in enumerate(CITY_ORDER):
        ax = fig.add_subplot(gs[i // 3, i % 3])
        arr = results[city]["dominant_code"]
        arr_show = crop_to_finite(arr, pad=5)
        masked = np.ma.masked_invalid(arr_show)

        ax.imshow(masked, cmap=GROUP_CMAP, norm=GROUP_NORM, interpolation="nearest")
        ax.set_title(city, fontsize=13, fontweight="bold", pad=5)
        ax.set_xticks([])
        ax.set_yticks([])
        ax.set_aspect("equal")
        ax.set_facecolor("#FBFBF8")
        for sp in ax.spines.values():
            sp.set_color("#94A3B8")
            sp.set_linewidth(0.7)

    handles = [
        plt.Line2D([0], [0], marker="s", linestyle="none", markersize=8,
                   markerfacecolor=GROUP_COLORS[g], markeredgecolor="black",
                   markeredgewidth=0.4, label=g)
        for g in GROUP_ORDER
    ]

    leg = fig.legend(handles=handles, loc="lower center", ncol=5, frameon=True,
                     bbox_to_anchor=(0.5, 0.015), fontsize=9,
                     columnspacing=0.8, handletextpad=0.35, borderpad=0.3)
    leg.get_frame().set_edgecolor("#9CA3AF")
    leg.get_frame().set_linewidth(0.6)

    fig.suptitle("Spatial extrapolation of dominant positive SHAP-like contribution groups",
                 fontsize=15, fontweight="bold", y=0.985)

    for ext in ["png", "pdf", "tif"]:
        out = os.path.join(FIG_OUT_DIR, f"Figure_Spatial_AblationSHAP_DominantDriver_SixCities.{ext}")
        fig.savefig(out, dpi=600 if ext != "pdf" else None, bbox_inches="tight")
        print(f"[Saved] {out}")

    plt.show()



def draw_selected_spatial_contribution_maps(results, selected_vars=None):
    """
    额外画一张 SHAP-like 空间外推图：
    行 = 选定变量，列 = 六城市。
    这张图只展示贡献值，不展示历史概率。
    """
    if selected_vars is None:
        selected_vars = ["Rx1day", "TWI", "BD", "GVI"]

    plt.rcParams.update({
        "font.family": "Times New Roman",
        "font.size": 9,
        "font.weight": "bold",
        "axes.titleweight": "bold",
        "figure.facecolor": "white",
        "axes.facecolor": "white",
    })

    nrows = len(selected_vars)
    ncols = len(CITY_ORDER)
    fig = plt.figure(figsize=(2.45 * ncols, 2.15 * nrows), dpi=180)
    gs = GridSpec(nrows, ncols, figure=fig, hspace=0.15, wspace=0.08)

    # 全局对称色带范围，避免每个子图颜色不可比
    all_vals = []
    for city in CITY_ORDER:
        for v in selected_vars:
            arr = results[city]["contrib_maps"][v]
            vals = arr[np.isfinite(arr)]
            if len(vals) > 0:
                all_vals.append(vals)
    if all_vals:
        all_vals = np.concatenate(all_vals)
        vmax = np.nanpercentile(np.abs(all_vals), 98)
        if not np.isfinite(vmax) or vmax <= 0:
            vmax = 1.0
    else:
        vmax = 1.0

    last_im = None
    for r, var in enumerate(selected_vars):
        for c, city in enumerate(CITY_ORDER):
            ax = fig.add_subplot(gs[r, c])
            arr = results[city]["contrib_maps"][var]
            arr_show = crop_to_finite(arr, pad=5)
            masked = np.ma.masked_invalid(arr_show)
            last_im = ax.imshow(masked, cmap="RdBu_r", vmin=-vmax, vmax=vmax, interpolation="nearest")
            ax.set_xticks([])
            ax.set_yticks([])
            ax.set_aspect("equal")
            ax.set_facecolor("#FBFBF8")
            if r == 0:
                ax.set_title(city, fontsize=10.5, fontweight="bold", pad=4)
            if c == 0:
                ax.text(-0.04, 0.5, var, transform=ax.transAxes, rotation=90,
                        ha="right", va="center", fontsize=10.5, fontweight="bold")
            for sp in ax.spines.values():
                sp.set_color("#CBD5E1")
                sp.set_linewidth(0.55)

    cax = fig.add_axes([0.92, 0.16, 0.014, 0.68])
    cbar = fig.colorbar(last_im, cax=cax)
    cbar.set_label("Ablation contribution to flood probability", fontsize=9, fontweight="bold")
    cbar.ax.tick_params(labelsize=8)

    fig.suptitle("Spatial extrapolation of selected SHAP-like ablation contributions",
                 fontsize=14, fontweight="bold", y=0.985)

    for ext in ["png", "pdf", "tif"]:
        out = os.path.join(FIG_OUT_DIR, f"Figure_Selected_Spatial_AblationContributions.{ext}")
        fig.savefig(out, dpi=600 if ext != "pdf" else None, bbox_inches="tight")
        print(f"[Saved] {out}")

    plt.show()



# =========================================================
# 9. Main
# =========================================================

points = read_or_extract_points()

preprocessor, rf = train_or_load_rf(points)

# Point TreeSHAP
sample_df, shap_df = compute_point_tree_shap(points, preprocessor, rf)
var_imp, global_imp, group_imp, global_group = summarize_point_shap(shap_df, preprocessor)
draw_point_treeshap_figure(sample_df, shap_df, global_imp, group_imp, global_group)

# Full-domain reference-style ablation contribution
spatial_results = {}
summary_all = []

if RUN_FULL_DOMAIN_EXTRAPOLATION:
    for city in CITY_ORDER:
        res = compute_city_full_domain_ablation(city, preprocessor, rf)
        spatial_results[city] = res
        summary_all.append(res["summary"])

    if summary_all:
        summary_df = pd.concat(summary_all, axis=0, ignore_index=True)
        summary_df.to_csv(
            os.path.join(RASTER_OUT_DIR, "AblationContribution_summary_6cities.csv"),
            index=False,
            encoding="utf-8-sig"
        )

    draw_six_city_dominant_map(spatial_results)
    draw_selected_spatial_contribution_maps(
        spatial_results,
        selected_vars=["Rx1day", "TWI", "BD", "GVI"]
    )

print("\n========== Finished: RF TreeSHAP + SHAP-like spatial extrapolation only ==========")
print(f"Output root: {OUT_ROOT}")
