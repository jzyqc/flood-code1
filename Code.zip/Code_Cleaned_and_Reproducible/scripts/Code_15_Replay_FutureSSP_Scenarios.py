# -*- coding: utf-8-sig -*-
"""
Future SSP x baseline-derived S0-S7 adaptation scenario replay.

This script directly reads future NetCDF files, replaces annual climate variables
Rx1day/Rx5day/CWD, predicts future P_flood with the trained RF-stabilized
Hydro-ConTex GNNWRL model, and recalculates annual F1. F2 and CGI are cached for
city-scenario because they are determined by the fixed S0-S7 decision-variable
configuration.

Important:
- This is NOT annual NSGA-III re-optimization.
- It is annual re-evaluation of fixed S0-S7 scenarios under SSP climate forcing.
- Keep TEST_MODE=True first. Change to False after the test run succeeds.
"""

import os
import sys
import glob
import shutil
import importlib.util
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
import xarray as xr
import rasterio
from rasterio.enums import Resampling
from rasterio.warp import reproject
from rasterio.transform import from_origin
from scipy.ndimage import uniform_filter, distance_transform_edt
import matplotlib.pyplot as plt

warnings.filterwarnings("ignore")

# =========================================================
# 0. Run settings
# =========================================================

TEST_MODE = False
# Full annual calculation. No rasters/PNGs are saved by default.
SAVE_RASTER_YEARS = [2015, 2020, 2030, 2040, 2050, 2060, 2070, 2080, 2090, 2100]
SAVE_DECADAL_TIF = True
SAVE_DECADAL_PNG = False
PREDICT_CHUNK_SIZE = 120_000
OUT_NODATA = -9999.0
EPS = 1e-6

# =========================================================
# 1. Paths
# =========================================================

NC_ROOT = Path("E:\\\u4e2d\u56fd\u7279\u5927\u57ce\u5e02\u6d2a\u6c34\\\u591a\u6a21\u5f0f\u5e73\u5747")
SAFE_NC_ROOT = Path("E:\\NC_SAFE_TEMP\\future_ssp_nc_safe")
SAFE_NC_ROOT.mkdir(parents=True, exist_ok=True)

MODEL_SCRIPT_PATH = Path("E:\\\u4e2d\u56fd\u7279\u5927\u57ce\u5e02\u6d2a\u6c34\\pythonProject1\\\u8ba1\u7b97flood\u6982\u7387.py")

MODEL_ROOT = Path(
    "E:\\\u4e2d\u56fd\u7279\u5927\u57ce\u5e02\u6d2a\u6c34\\RF_Stabilized_HydroConTex_GNNWRL_v11_robust_diagnostics\\RF_Stabilized_HydroConTex_GNNWRL_v11_robust_diagnostics"
)
MODEL_DIR = MODEL_ROOT / "models"
JOBLIB_PACKAGE = MODEL_DIR / "Final_RF_Stabilized_HydroConTex_GNNWRL_package.joblib"
GNN_STATE_DICT = MODEL_DIR / "Final_GNNWRL_state_dict.pt"

CITY_BASE_DIRS = {
    "Beijing":   Path("E:\\\u4e2d\u56fd\u7279\u5927\u57ce\u5e02\u6d2a\u6c34\\\u5317\u4eac\u5e02\u6570\u636e"),
    "Chengdu":   Path("E:\\\u4e2d\u56fd\u7279\u5927\u57ce\u5e02\u6d2a\u6c34\\\u6210\u90fd\u5e02\u6570\u636e"),
    "Guangzhou": Path("E:\\\u4e2d\u56fd\u7279\u5927\u57ce\u5e02\u6d2a\u6c34\\\u5e7f\u5dde\u5e02\u6570\u636e"),
    "Shanghai":  Path("E:\\\u4e2d\u56fd\u7279\u5927\u57ce\u5e02\u6d2a\u6c34\\\u4e0a\u6d77\u5e02\u6570\u636e"),
    "Shenzhen":  Path("E:\\\u4e2d\u56fd\u7279\u5927\u57ce\u5e02\u6d2a\u6c34\\\u6df1\u5733\u5e02\u6570\u636e"),
    "Tianjin":   Path("E:\\\u4e2d\u56fd\u7279\u5927\u57ce\u5e02\u6d2a\u6c34\\\u5929\u6d25\u5e02\u6570\u636e"),
}

# Change this to your real S0-S7 decision-variable raster directory.
# Supported structures:
#   SCENARIO_ROOT/S7/Beijing/NDVI.tif
#   SCENARIO_ROOT/Beijing/S7/NDVI.tif
# If not found, the script falls back to CITY_BASE_DIRS, so S1-S7 may equal S0.
SCENARIO_ROOT = Path("E:\\\u4e2d\u56fd\u7279\u5927\u57ce\u5e02\u6d2a\u6c34\\Cascade_Optimization_FINAL_SIXCITY_PHYSICAL_RASTERS\\03_city_scenarios")

NORMALIZATION_CSV = Path(
    "E:\\\u4e2d\u56fd\u7279\u5927\u57ce\u5e02\u6d2a\u6c34\\\u4e09\u76ee\u6807\u79ef\u5206\u6805\u683c_BAU_\u5168\u57dfHybrid\u5e73\u6ed1\u51fa\u56fe\u7248\\05_tables\\normalization_parameters.csv"
)

OUT_ROOT = Path("E:\\\u4e2d\u56fd\u7279\u5927\u57ce\u5e02\u6d2a\u6c34\\\u672a\u6765SSP_\u539fS0S7\u60c5\u666f\u9010\u5e74\u91cd\u8bc4\u4f30")
OUT_ROOT.mkdir(parents=True, exist_ok=True)

# =========================================================
# 2. Cities, scenarios, variables
# =========================================================

CITIES = ["Beijing", "Chengdu", "Guangzhou", "Shanghai", "Shenzhen", "Tianjin"]
SSPS = ["ssp126", "ssp245", "ssp585"]
SCENARIOS = ["S0", "S1", "S2", "S3", "S4", "S5", "S6", "S7"]
FUTURE_CLIMATE_VARS = ["Rx1day", "Rx5day", "CWD"]

MODEL_VARS = [
    "Rx1day", "Rx5day", "CWD",
    "EV", "SL", "PRC", "TWI", "TPI",
    "ST", "NDVI", "LULC",
    "BD", "PD", "BH", "BVI",
    "CFI", "FOE", "GVI",
    "Micro_ISA", "Micro_PSA",
    "SCE", "SEL", "SVF", "TAE"
]

TARGET_VARS = [
    "PopD", "PD", "NTL", "GDP", "RD",
    "GVI", "Micro_PSA", "Micro_ISA",
    "NDVI", "BD", "BH", "LULC"
]

RASTER_STEMS = {
    "Rx1day": ["Rx1day", "Rx1 day"],
    "Rx5day": ["Rx5day", "Rx5 day"],
    "CWD": ["CWD"],
    "EV": ["EV"],
    "SL": ["SL"],
    "PRC": ["PRC"],
    "TWI": ["TWI"],
    "TPI": ["TPI"],
    "ST": ["ST"],
    "NDVI": ["NDVI"],
    "LULC": ["LULC", "LU", "landuse", "landcover"],
    "BD": ["BD"],
    "PD": ["PD"],
    "BH": ["BH"],
    "BVI": ["BVI"],
    "CFI": ["CFI"],
    "FOE": ["FOE"],
    "GVI": ["GVI"],
    "Micro_ISA": ["Micro_ISA", "ISA"],
    "Micro_PSA": ["Micro_PSA", "PSA"],
    "SCE": ["SCE"],
    "SEL": ["SEL", "SEI"],
    "SVF": ["SVF"],
    "TAE": ["TAE"],
    "PopD": ["PopD", "PopulationDensity", "population_density"],
    "GDP": ["GDP"],
    "RD": ["RD", "road_density"],
    "NTL": ["NTL", "nightlight", "nighttime_light"],
    "P_flood": ["P_flood", "pflood", "Historical_P_flood", "flood_probability"],
}

LULC_ECO_MAP = {1: 0.70, 2: 0.95, 3: 0.60, 4: 0.85, 5: 1.00, 6: 0.20, 7: 0.30, 8: 0.05, 9: 0.90}
LULC_URBAN_MAP = {1: 0.15, 2: 0.00, 3: 0.05, 4: 0.05, 5: 0.00, 6: 0.00, 7: 0.25, 8: 1.00, 9: 0.00}
FOCAL_RADII_CELLS = [3, 10, 30]
FOCAL_WEIGHTS = [0.5, 0.3, 0.2]

# =========================================================
# 3. File and raster helpers
# =========================================================

def ensure_dir(p):
    Path(p).mkdir(parents=True, exist_ok=True)
    return Path(p)

_TIF_CACHE = {}

def all_tifs(folder):
    folder = Path(folder)
    key = str(folder)
    if key in _TIF_CACHE:
        return _TIF_CACHE[key]
    if not folder.exists():
        _TIF_CACHE[key] = []
        return []
    out = []
    out.extend(glob.glob(str(folder / "**" / "*.tif"), recursive=True))
    out.extend(glob.glob(str(folder / "**" / "*.tiff"), recursive=True))
    out = sorted(list(set(out)))
    _TIF_CACHE[key] = out
    return out

def find_raster(folder, var, scenario=None):
    """
    Match rasters in two situations:
    1) scenario folder such as 03_city_scenarios/Beijing/rasters/S0_BD.tif
       -> pass scenario='S0' and var='BD'. It will only match files starting with S0_.
    2) base city folder such as Beijing/Rx1day.tif
       -> pass scenario=None.
    """
    aliases = [a.lower() for a in RASTER_STEMS.get(var, [var])]
    files = all_tifs(folder)
    candidates = []

    for f in files:
        stem = Path(f).stem.lower()

        if scenario is not None:
            prefix = f"{scenario.lower()}_"
            if not stem.startswith(prefix):
                continue
            stem_no_s = stem[len(prefix):]
            if stem_no_s in aliases:
                candidates.append(f)
                continue
            if any(a in stem_no_s for a in aliases):
                candidates.append(f)
                continue
        else:
            if stem in aliases:
                candidates.append(f)
                continue
            if any(a in stem for a in aliases):
                candidates.append(f)
                continue

    if candidates:
        return Path(sorted(candidates, key=lambda x: (len(Path(x).stem), x))[0])
    return None


def get_scenario_folder(city, scenario):
    """
    Fit your actual folder structure:
    03_city_scenarios/Beijing/rasters/S0_Micro_PSA.tif
    """
    candidates = [
        SCENARIO_ROOT / city / "rasters",
        SCENARIO_ROOT / city,
        SCENARIO_ROOT / scenario / city / "rasters",
        SCENARIO_ROOT / scenario / city,
        SCENARIO_ROOT / city / scenario / "rasters",
        SCENARIO_ROOT / city / scenario,
    ]
    for p in candidates:
        if p.exists():
            return p
    return None


def find_var_path(city, scenario, var):
    """
    First search the real scenario rasters, for example S0_BD.tif / S7_Micro_PSA.tif.
    If missing, fall back to base city rasters.
    """
    scenario_folder = get_scenario_folder(city, scenario)
    if scenario_folder is not None:
        p = find_raster(scenario_folder, var, scenario=scenario)
        if p is not None and p.exists():
            return p

    p = find_raster(CITY_BASE_DIRS[city], var, scenario=None)
    if p is not None and p.exists():
        return p
    return None

def find_template_raster(city):
    for var in ["P_flood", "LULC", "Rx1day", "NDVI"]:
        p = find_var_path(city, "S0", var)
        if p is not None:
            return p
    raise FileNotFoundError(f"{city} template raster not found. Check CITY_BASE_DIRS.")

def read_align_as_float(path, ref_ds, categorical=False):
    resampling = Resampling.nearest if categorical else Resampling.bilinear
    with rasterio.open(path) as src:
        arr = src.read(1).astype("float32")
        if src.nodata is not None:
            arr[arr == src.nodata] = np.nan
        arr[~np.isfinite(arr)] = np.nan
        same_grid = (
            src.width == ref_ds.width
            and src.height == ref_ds.height
            and src.transform == ref_ds.transform
            and src.crs == ref_ds.crs
        )
        if same_grid:
            if categorical:
                arr = np.rint(arr).astype("float32")
            return arr
        src_tmp = np.where(np.isfinite(arr), arr, OUT_NODATA).astype("float32")
        dst_tmp = np.full((ref_ds.height, ref_ds.width), OUT_NODATA, dtype="float32")
        reproject(
            source=src_tmp,
            destination=dst_tmp,
            src_transform=src.transform,
            src_crs=src.crs,
            src_nodata=OUT_NODATA,
            dst_transform=ref_ds.transform,
            dst_crs=ref_ds.crs,
            dst_nodata=OUT_NODATA,
            resampling=resampling,
        )
        out = dst_tmp.astype("float32")
        out[out == OUT_NODATA] = np.nan
        if categorical:
            out = np.rint(out).astype("float32")
        return out

def read_city_scenario_var(city, scenario, var, ref_ds, required=False, categorical=False):
    p = find_var_path(city, scenario, var)
    if p is None:
        if required:
            raise FileNotFoundError(f"[{city}-{scenario}] Missing raster variable: {var}")
        return None, None
    arr = read_align_as_float(p, ref_ds, categorical=categorical)
    return arr, p

def write_raster(out_path, arr, ref_ds):
    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    profile = ref_ds.profile.copy()
    profile.update(driver="GTiff", dtype="float32", count=1, nodata=OUT_NODATA,
                   compress="lzw", tiled=True, BIGTIFF="IF_SAFER")
    out = np.where(np.isfinite(arr), arr, OUT_NODATA).astype("float32")
    with rasterio.open(out_path, "w", **profile) as dst:
        dst.write(out, 1)

def save_png_map(arr, title, out_png, cmap="RdYlBu_r"):
    out_png = Path(out_png)
    out_png.parent.mkdir(parents=True, exist_ok=True)
    data = arr.copy()
    data[~np.isfinite(data)] = np.nan
    plt.figure(figsize=(6.2, 5))
    im = plt.imshow(data, cmap=cmap)
    plt.colorbar(im, shrink=0.78)
    plt.title(title, fontsize=12, fontweight="bold")
    plt.xticks([])
    plt.yticks([])
    plt.tight_layout()
    plt.savefig(out_png, dpi=300)
    plt.close()

# =========================================================
# 4. NetCDF reading and reprojection
# =========================================================

def find_nc(city, ssp):
    city_dir = NC_ROOT / city
    candidates = list(city_dir.glob(f"*{city}*{ssp}*.nc"))
    if len(candidates) == 0:
        candidates = [p for p in NC_ROOT.rglob("*.nc") if city.lower() in p.name.lower() and ssp.lower() in p.name.lower()]
    if len(candidates) == 0:
        raise FileNotFoundError(f"NetCDF not found: {city} {ssp}")
    return candidates[0]

def safe_copy_nc(src):
    src = Path(src)
    dst = SAFE_NC_ROOT / src.name
    if not dst.exists():
        shutil.copy2(src, dst)
    return dst

def open_nc(city, ssp):
    src = find_nc(city, ssp)
    safe = safe_copy_nc(src)
    try:
        ds = xr.open_dataset(safe, decode_times=True)
    except Exception:
        ds = xr.open_dataset(safe, decode_times=False)
    return ds

def nc_da_to_ref_grid(da, ref_ds):
    lat = da["lat"].values
    lon = da["lon"].values
    data = da.values.astype("float32")
    if lat[0] < lat[-1]:
        data = np.flipud(data)
    lon_res = abs(float(np.nanmedian(np.diff(lon))))
    lat_res = abs(float(np.nanmedian(np.diff(lat))))
    west = float(np.nanmin(lon) - lon_res / 2)
    north = float(np.nanmax(lat) + lat_res / 2)
    src_transform = from_origin(west, north, lon_res, lat_res)
    src_tmp = np.where(np.isfinite(data), data, OUT_NODATA).astype("float32")
    dst = np.full((ref_ds.height, ref_ds.width), OUT_NODATA, dtype="float32")
    reproject(
        source=src_tmp,
        destination=dst,
        src_transform=src_transform,
        src_crs="EPSG:4326",
        src_nodata=OUT_NODATA,
        dst_transform=ref_ds.transform,
        dst_crs=ref_ds.crs,
        dst_nodata=OUT_NODATA,
        resampling=Resampling.bilinear,
    )
    dst[dst == OUT_NODATA] = np.nan
    return dst.astype("float32")

def get_future_climate_arrays(ds, year, ref_ds):
    out = {}
    for var in FUTURE_CLIMATE_VARS:
        if var not in ds.data_vars:
            raise KeyError(f"NetCDF variable missing: {var}")
        da = ds[var].sel(year=int(year))
        out[var] = nc_da_to_ref_grid(da, ref_ds)
    return out

# =========================================================
# 5. Target calculation helpers
# =========================================================

def valid_values(arr):
    return arr[np.isfinite(arr)]

def raster_stats(arr, prefix):
    vals = valid_values(arr)
    if vals.size == 0:
        return {f"{prefix}_valid_n": 0, f"{prefix}_mean": np.nan, f"{prefix}_median": np.nan,
                f"{prefix}_p10": np.nan, f"{prefix}_p90": np.nan, f"{prefix}_p95": np.nan}
    return {f"{prefix}_valid_n": int(vals.size), f"{prefix}_mean": float(np.nanmean(vals)),
            f"{prefix}_median": float(np.nanmedian(vals)), f"{prefix}_p10": float(np.nanpercentile(vals, 10)),
            f"{prefix}_p90": float(np.nanpercentile(vals, 90)), f"{prefix}_p95": float(np.nanpercentile(vals, 95))}

def mean_available(arrs):
    arrs = [a for a in arrs if a is not None]
    if len(arrs) == 0:
        return None
    total = np.zeros(arrs[0].shape, dtype="float32")
    count = np.zeros(arrs[0].shape, dtype="float32")
    for arr in arrs:
        m = np.isfinite(arr)
        total[m] += arr[m]
        count[m] += 1
    out = total / np.where(count > 0, count, np.nan)
    out[count <= 0] = np.nan
    return out.astype("float32")

def safe_sqrt_product(a, b):
    out = np.sqrt(np.clip(a, 0, 1) * np.clip(b, 0, 1)).astype("float32")
    out[~np.isfinite(a) | ~np.isfinite(b)] = np.nan
    return out

def focal_mean_nan(arr, radius):
    if radius <= 0:
        return arr.copy()
    size = int(radius) * 2 + 1
    finite = np.isfinite(arr).astype("float32")
    values = np.where(np.isfinite(arr), arr, 0).astype("float32")
    local_sum = uniform_filter(values, size=size, mode="constant", cval=0)
    local_cnt = uniform_filter(finite, size=size, mode="constant", cval=0)
    out = local_sum / np.where(local_cnt > 1e-6, local_cnt, np.nan)
    out[local_cnt <= 1e-6] = np.nan
    return out.astype("float32")

def multiscale_context(arr):
    out = np.zeros_like(arr, dtype="float32")
    wsum = 0.0
    for r, w in zip(FOCAL_RADII_CELLS, FOCAL_WEIGHTS):
        out += float(w) * focal_mean_nan(arr, r)
        wsum += float(w)
    out = out / max(wsum, EPS)
    out[~np.isfinite(out)] = np.nan
    return out.astype("float32")

def reclass_lulc(lulc, mapping):
    out = np.full(lulc.shape, np.nan, dtype="float32")
    for code, value in mapping.items():
        out[np.isclose(lulc, float(code), equal_nan=False)] = float(value)
    return out

def zscore_fixed(arr, params, var):
    if var not in params:
        raise KeyError(f"Normalization parameter missing: {var}")
    lo = params[var]["q_low"]
    hi = params[var]["q_high"]
    z = (arr - lo) / (hi - lo + EPS)
    z = np.clip(z, 0, 1).astype("float32")
    z[~np.isfinite(arr)] = np.nan
    return z

def nearest_fill(arr, mask, fill_value=0.0):
    out = arr.astype("float32").copy()
    out[~mask] = np.nan
    valid = np.isfinite(out) & mask
    missing = (~np.isfinite(out)) & mask
    if valid.any() and missing.any():
        _, inds = distance_transform_edt(~valid, return_indices=True)
        out[missing] = out[tuple(inds[:, missing])]
    elif not valid.any():
        out[mask] = fill_value
    out[~mask] = np.nan
    return out.astype("float32")

def load_normalization_params():
    if not NORMALIZATION_CSV.exists():
        raise FileNotFoundError(f"Normalization CSV not found: {NORMALIZATION_CSV}")
    df = pd.read_csv(NORMALIZATION_CSV)
    return {row["variable"]: {"q_low": float(row["q_low"]), "q_high": float(row["q_high"])} for _, row in df.iterrows()}

# =========================================================
# 6. Embedded model runtime definitions and loading
# =========================================================

# This section intentionally DOES NOT import your original "calculate flood probability" script.
# The previous version failed because that script runs top-level code and loads an old hard-coded model path.
# Here the minimal classes/functions needed by joblib + GNN prediction are embedded directly.

import types
import random

try:
    import torch
    import torch.nn as nn
    import torch.nn.functional as F
except Exception as e:
    raise ImportError("PyTorch is required for GNNWRL prediction. Install torch in this environment. Original error: " + str(e))

from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import NearestNeighbors

RANDOM_STATE = 42
np.random.seed(RANDOM_STATE)
random.seed(RANDOM_STATE)
torch.manual_seed(RANDOM_STATE)
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"

# Must match the original v11 feature construction.
MISSING_INDICATOR_BASE_VARS = ["BD", "PD", "BH", "BVI", "Micro_ISA", "Micro_PSA"]
MISSING_INDICATOR_VARS = [f"{v}_missing" for v in MISSING_INDICATOR_BASE_VARS]
FEATURE_VARS = MODEL_VARS + MISSING_INDICATOR_VARS
ZERO_FILL_VARS = ["BD", "PD", "BH", "BVI", "Micro_ISA", "Micro_PSA"]

CONTEXT_GROUPS = {
    "Climate": ["Rx1day", "Rx5day", "CWD"],
    "Terrain": ["EV", "SL", "PRC", "TWI", "TPI", "ST"],
    "LandCover": ["NDVI", "LULC"],
    "Built": ["BD", "PD", "BH", "BVI", "Micro_ISA", "Micro_PSA"] + MISSING_INDICATOR_VARS,
    "Streetscape": ["CFI", "FOE", "GVI", "SCE", "SEL", "SVF", "TAE"],
}
CONTEXT_ORDER = ["Climate", "Terrain", "LandCover", "Built", "Streetscape"]

K_SPATIAL = 8
K_CONTEXT = 0
GRAPH_ETA_SPATIAL = 1.0
DIST_KERNEL_QUANTILE = 0.50
HIDDEN_DIM = 48
DROPOUT = 0.20


def logit_np(p, eps=1e-6):
    p = np.clip(p, eps, 1 - eps)
    return np.log(p / (1 - p))


def apply_probability_calibrator(prob, calibrator_info):
    prob = np.asarray(prob, dtype=float)
    if calibrator_info is None:
        return np.clip(prob, 1e-6, 1 - 1e-6)
    method = str(calibrator_info.get("method", "none"))
    model = calibrator_info.get("model", None)
    if method == "sigmoid" and model is not None:
        x = logit_np(prob).reshape(-1, 1)
        out = model.predict_proba(x)[:, 1]
        return np.clip(out, 1e-6, 1 - 1e-6)
    if method == "isotonic" and model is not None:
        out = model.predict(prob)
        return np.clip(out, 1e-6, 1 - 1e-6)
    return np.clip(prob, 1e-6, 1 - 1e-6)


class TabularPreprocessor:
    """Compatible preprocessor class for loading the saved joblib package."""
    def __init__(self, model_vars=None, zero_fill_vars=None):
        self.model_vars = model_vars if model_vars is not None else MODEL_VARS
        self.zero_fill_vars = zero_fill_vars if zero_fill_vars is not None else ZERO_FILL_VARS
        self.missing_indicator_base_vars = [v for v in MISSING_INDICATOR_BASE_VARS if v in self.model_vars]
        self.missing_indicator_vars = [f"{v}_missing" for v in self.missing_indicator_base_vars]
        self.feature_vars = self.model_vars + self.missing_indicator_vars
        self.median_fill_vars = [v for v in self.model_vars if v not in self.zero_fill_vars]
        self.medians_ = {}
        self.scaler_ = StandardScaler()

    def _prepare_unscaled(self, df):
        X_raw = df[self.model_vars].copy()
        X = pd.DataFrame(index=df.index)
        for v in self.model_vars:
            X[v] = X_raw[v]
        for v in self.missing_indicator_base_vars:
            X[f"{v}_missing"] = X_raw[v].isna().astype(float)
        for v in self.zero_fill_vars:
            if v in X.columns:
                X[v] = X[v].fillna(0.0)
        for v in self.median_fill_vars:
            fill = self.medians_.get(v, np.nan)
            if not np.isfinite(fill):
                fill = float(X[v].median(skipna=True))
                if not np.isfinite(fill):
                    fill = 0.0
            X[v] = X[v].fillna(fill)
        X = X[self.feature_vars].astype(float)
        return X

    def fit(self, df):
        X_raw = df[self.model_vars].copy()
        for v in self.median_fill_vars:
            med = float(X_raw[v].median(skipna=True))
            if not np.isfinite(med):
                med = 0.0
            self.medians_[v] = med
        X = self._prepare_unscaled(df)
        self.scaler_.fit(X.values)
        return self

    def transform(self, df):
        X = self._prepare_unscaled(df)
        arr = self.scaler_.transform(X.values)
        return pd.DataFrame(arr, columns=self.feature_vars, index=df.index)

    def fit_transform(self, df):
        self.fit(df)
        return self.transform(df)


class AveragedProbabilityAnchor:
    """Compatible RF-family anchor wrapper for loading old packages if present."""
    def __init__(self, models=None):
        self.models = models or {}
        self.model_names = list(self.models.keys())

    def predict_proba(self, X):
        probs = []
        for _, model in self.models.items():
            probs.append(model.predict_proba(X)[:, 1])
        p1 = np.mean(np.vstack(probs), axis=0)
        p1 = np.clip(p1, 1e-6, 1 - 1e-6)
        return np.column_stack([1 - p1, p1])


def context_indices(groups=None):
    groups = CONTEXT_GROUPS if groups is None else groups
    idx = {}
    for cname, vars_ in groups.items():
        idx[cname] = [FEATURE_VARS.index(v) for v in vars_ if v in FEATURE_VARS]
    return idx


def normalize_edge_weights(src, dst, weight, n_nodes):
    weight = np.asarray(weight, dtype=np.float32)
    dst = np.asarray(dst, dtype=np.int64)
    denom = np.zeros(n_nodes, dtype=np.float32)
    np.add.at(denom, dst, weight)
    denom = np.maximum(denom, 1e-8)
    return weight / denom[dst]


def build_knn_edges_by_city(coords, X_context, city, k_spatial=K_SPATIAL, k_context=K_CONTEXT, eta_spatial=GRAPH_ETA_SPATIAL):
    src_all, dst_all, w_all, type_all = [], [], [], []
    raw_w_all = []
    n = len(coords)
    for c in np.unique(city):
        idx = np.where(city == c)[0]
        if len(idx) <= 1:
            continue
        if k_spatial is not None and k_spatial > 0:
            k_s = min(k_spatial + 1, len(idx))
            nbr_s = NearestNeighbors(n_neighbors=k_s, algorithm="auto").fit(coords[idx])
            dist_s, ind_s = nbr_s.kneighbors(coords[idx])
            positive_d = dist_s[:, 1:].ravel()
            positive_d = positive_d[positive_d > 0]
            bw = np.quantile(positive_d, DIST_KERNEL_QUANTILE) if len(positive_d) else 1.0
            bw = max(bw, 1e-6)
            for row_pos, row_global in enumerate(idx):
                for jj in range(1, k_s):
                    neigh_global = idx[ind_s[row_pos, jj]]
                    d = dist_s[row_pos, jj]
                    w_raw = np.exp(-(d * d) / (2 * bw * bw))
                    w = eta_spatial * w_raw
                    src_all.append(neigh_global)
                    dst_all.append(row_global)
                    w_all.append(w)
                    raw_w_all.append(w_raw)
                    type_all.append("spatial")
        if k_context is not None and k_context > 0:
            k_c = min(k_context + 1, len(idx))
            nbr_c = NearestNeighbors(n_neighbors=k_c, algorithm="auto").fit(X_context[idx])
            dist_c, ind_c = nbr_c.kneighbors(X_context[idx])
            positive_dc = dist_c[:, 1:].ravel()
            positive_dc = positive_dc[positive_dc > 0]
            bwc = np.quantile(positive_dc, DIST_KERNEL_QUANTILE) if len(positive_dc) else 1.0
            bwc = max(bwc, 1e-6)
            for row_pos, row_global in enumerate(idx):
                for jj in range(1, k_c):
                    neigh_global = idx[ind_c[row_pos, jj]]
                    d = dist_c[row_pos, jj]
                    w_raw = np.exp(-(d * d) / (2 * bwc * bwc))
                    w = (1.0 - eta_spatial) * w_raw
                    src_all.append(neigh_global)
                    dst_all.append(row_global)
                    w_all.append(w)
                    raw_w_all.append(w_raw)
                    type_all.append("context")
    if len(src_all) == 0:
        src_all = list(range(n))
        dst_all = list(range(n))
        w_all = [1.0] * n
        raw_w_all = [1.0] * n
        type_all = ["self"] * n
    src = np.asarray(src_all, dtype=np.int64)
    dst = np.asarray(dst_all, dtype=np.int64)
    w_norm = normalize_edge_weights(src, dst, w_all, n)
    edge_index = np.vstack([src, dst])
    edge_weight = w_norm.astype(np.float32)
    edges_df = pd.DataFrame({
        "src": src,
        "dst": dst,
        "edge_type": type_all,
        "raw_weight": np.asarray(raw_w_all, dtype=np.float32),
        "weighted_before_norm": np.asarray(w_all, dtype=np.float32),
        "weight": edge_weight,
    })
    return edge_index, edge_weight, edges_df


class GraphConv(nn.Module):
    def __init__(self, dim):
        super().__init__()
        self.lin_self = nn.Linear(dim, dim)
        self.lin_neigh = nn.Linear(dim, dim)
        self.norm = nn.LayerNorm(dim)

    def forward(self, h, edge_index, edge_weight):
        src, dst = edge_index[0], edge_index[1]
        msg = self.lin_neigh(h[src]) * edge_weight.view(-1, 1)
        agg = torch.zeros_like(h)
        agg.index_add_(0, dst, msg)
        out = self.lin_self(h) + agg
        out = self.norm(out)
        return F.relu(out)


class RFStabilizedHydroConTexGNNWRL(nn.Module):
    def __init__(self, input_dim, context_idx, hidden_dim=HIDDEN_DIM, dropout=DROPOUT,
                 use_graph=True, use_wrl=True, use_global_branch=True):
        super().__init__()
        self.context_idx = context_idx
        self.context_names = list(context_idx.keys())
        self.use_graph = use_graph
        self.use_wrl = use_wrl
        self.use_global_branch = use_global_branch
        self.encoders = nn.ModuleDict()
        self.gconvs = nn.ModuleDict()
        self.context_logits = nn.ModuleDict()
        for cname in self.context_names:
            in_dim = len(context_idx[cname])
            self.encoders[cname] = nn.Sequential(
                nn.Linear(in_dim, hidden_dim),
                nn.ReLU(),
                nn.Dropout(dropout),
                nn.Linear(hidden_dim, hidden_dim),
                nn.ReLU(),
            )
            self.gconvs[cname] = GraphConv(hidden_dim)
            self.context_logits[cname] = nn.Linear(hidden_dim, 1)
        fusion_in = hidden_dim * len(self.context_names) + 2
        self.global_branch = nn.Sequential(
            nn.Linear(fusion_in, hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, max(hidden_dim // 2, 4)),
            nn.ReLU(),
            nn.Linear(max(hidden_dim // 2, 4), 1),
        )
        self.wrl_gate = nn.Sequential(
            nn.Linear(fusion_in, hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, len(self.context_names)),
        )

    def forward(self, x, coords_norm, edge_index, edge_weight, return_details=False):
        context_embeds = []
        context_logits = []
        for cname in self.context_names:
            idx = self.context_idx[cname]
            hx = self.encoders[cname](x[:, idx])
            if self.use_graph:
                hg = self.gconvs[cname](hx, edge_index, edge_weight)
            else:
                hg = hx
            context_embeds.append(hg)
            context_logits.append(self.context_logits[cname](hg))
        H = torch.cat(context_embeds, dim=1)
        Hc = torch.cat([H, coords_norm], dim=1)
        logits_stack = torch.cat(context_logits, dim=1)
        if self.use_wrl:
            alpha = F.softmax(self.wrl_gate(Hc), dim=1)
        else:
            alpha = torch.ones_like(logits_stack) / logits_stack.shape[1]
        local_logit = torch.sum(alpha * logits_stack, dim=1, keepdim=True)
        if self.use_global_branch:
            global_logit = self.global_branch(Hc)
        else:
            global_logit = torch.zeros_like(local_logit)
        base_logit = local_logit + global_logit
        if return_details:
            details = {"context_weights": alpha, "context_logits": logits_stack,
                       "global_logit": global_logit, "local_logit": local_logit}
            return base_logit.squeeze(1), details
        return base_logit.squeeze(1)


# Make joblib able to resolve classes saved from a script run as __main__.
import __main__
for _name in ["TabularPreprocessor", "RFStabilizedHydroConTexGNNWRL", "AveragedProbabilityAnchor", "GraphConv"]:
    setattr(__main__, _name, globals()[_name])


def import_model_module():
    """Return a module-like namespace containing embedded runtime definitions."""
    mod = types.SimpleNamespace(
        DEVICE=DEVICE,
        FEATURE_VARS=FEATURE_VARS,
        CONTEXT_GROUPS=CONTEXT_GROUPS,
        CONTEXT_ORDER=CONTEXT_ORDER,
        HIDDEN_DIM=HIDDEN_DIM,
        DROPOUT=DROPOUT,
        K_SPATIAL=K_SPATIAL,
        K_CONTEXT=K_CONTEXT,
        GRAPH_ETA_SPATIAL=GRAPH_ETA_SPATIAL,
        TabularPreprocessor=TabularPreprocessor,
        RFStabilizedHydroConTexGNNWRL=RFStabilizedHydroConTexGNNWRL,
        AveragedProbabilityAnchor=AveragedProbabilityAnchor,
        GraphConv=GraphConv,
        context_indices=context_indices,
        build_knn_edges_by_city=build_knn_edges_by_city,
        apply_probability_calibrator=apply_probability_calibrator,
    )
    print("[Embedded runtime] Using built-in model definitions; no external model script is imported.")
    return mod


def load_gnnwrl_runtime_package(model_mod):
    import joblib
    import torch
    if not JOBLIB_PACKAGE.exists():
        raise FileNotFoundError(f"Joblib package not found: {JOBLIB_PACKAGE}")
    if not GNN_STATE_DICT.exists():
        raise FileNotFoundError(f"GNN state dict not found: {GNN_STATE_DICT}")
    saved = joblib.load(JOBLIB_PACKAGE)
    context_groups = saved.get("CONTEXT_GROUPS", model_mod.CONTEXT_GROUPS)
    ctx_idx = model_mod.context_indices(context_groups)
    state = torch.load(GNN_STATE_DICT, map_location=model_mod.DEVICE)
    gnn_model = None
    last_error = None
    for use_global_branch in [True, False]:
        try:
            tmp = model_mod.RFStabilizedHydroConTexGNNWRL(
                input_dim=len(model_mod.FEATURE_VARS),
                context_idx=ctx_idx,
                hidden_dim=saved.get("HIDDEN_DIM", model_mod.HIDDEN_DIM),
                dropout=saved.get("DROPOUT", model_mod.DROPOUT),
                use_graph=True,
                use_wrl=True,
                use_global_branch=use_global_branch,
            ).to(model_mod.DEVICE)
            tmp.load_state_dict(state, strict=True)
            tmp.eval()
            gnn_model = tmp
            print(f"[Model loaded] use_global_branch={use_global_branch}")
            break
        except Exception as e:
            last_error = e
    if gnn_model is None:
        raise RuntimeError(f"GNN state_dict loading failed: {last_error}")
    runtime_package = {
        "model": gnn_model,
        "rf_anchor": saved["rf_anchor"],
        "alpha_gnn": float(saved["alpha_gnn"]),
        "alpha_rf": float(saved["alpha_rf"]),
        "coord_mu": saved["coord_mu"],
        "coord_sd": saved["coord_sd"],
        "k_spatial": int(saved.get("K_SPATIAL", model_mod.K_SPATIAL)),
        "k_context": int(saved.get("K_CONTEXT", model_mod.K_CONTEXT)),
        "eta_spatial": float(saved.get("GRAPH_ETA_SPATIAL", model_mod.GRAPH_ETA_SPATIAL)),
        "blend_calibrator": saved.get("blend_calibrator", {"method": "none", "model": None}),
    }
    preprocessor = saved["preprocessor"]
    print("\n[Model package loaded]")
    print("JOBLIB_PACKAGE:", JOBLIB_PACKAGE)
    print("GNN_STATE_DICT:", GNN_STATE_DICT)
    print("alpha_gnn:", runtime_package["alpha_gnn"])
    print("alpha_rf:", runtime_package["alpha_rf"])
    print("preprocessor:", type(preprocessor))
    return runtime_package, preprocessor


def fallback_predict_package(model_mod, runtime_package, X_scaled, meta_df):
    import torch
    X_np = X_scaled.values.astype("float32")
    coords = meta_df[["x", "y"]].to_numpy(dtype=float)
    city_arr = meta_df["City"].astype(str).to_numpy()
    coord_mu = np.asarray(runtime_package["coord_mu"], dtype=float)
    coord_sd = np.asarray(runtime_package["coord_sd"], dtype=float)
    coord_sd = np.where(coord_sd < 1e-8, 1.0, coord_sd)
    coords_norm = (coords - coord_mu) / coord_sd
    edge_index_np, edge_weight_np, _ = model_mod.build_knn_edges_by_city(
        coords=coords,
        X_context=X_np,
        city=city_arr,
        k_spatial=runtime_package["k_spatial"],
        k_context=runtime_package["k_context"],
        eta_spatial=runtime_package["eta_spatial"],
    )
    x_t = torch.tensor(X_np, dtype=torch.float32, device=model_mod.DEVICE)
    c_t = torch.tensor(coords_norm, dtype=torch.float32, device=model_mod.DEVICE)
    edge_i_t = torch.tensor(edge_index_np, dtype=torch.long, device=model_mod.DEVICE)
    edge_w_t = torch.tensor(edge_weight_np, dtype=torch.float32, device=model_mod.DEVICE)
    runtime_package["model"].eval()
    with torch.no_grad():
        logit = runtime_package["model"](x_t, c_t, edge_i_t, edge_w_t)
        p_gnn = torch.sigmoid(logit).detach().cpu().numpy()
    p_rf = runtime_package["rf_anchor"].predict_proba(X_scaled)[:, 1]
    p = runtime_package["alpha_gnn"] * p_gnn + runtime_package["alpha_rf"] * p_rf
    if hasattr(model_mod, "apply_probability_calibrator"):
        p = model_mod.apply_probability_calibrator(p, runtime_package.get("blend_calibrator", None))
    p = np.clip(p, 1e-6, 1 - 1e-6)
    extra = {"P_gnn": p_gnn, "P_rf": p_rf, "P_blend": p}
    return p, extra, None
# =========================================================
# 7. Static city-scenario pack
# =========================================================

STATIC_CACHE = {}

def build_static_arrays(city, scenario, ref_ds, params):
    cache_key = (city, scenario)
    if cache_key in STATIC_CACHE:
        return STATIC_CACHE[cache_key]
    print(f"[Static build] {city} {scenario}")
    lulc, _ = read_city_scenario_var(city, scenario, "LULC", ref_ds, required=True, categorical=True)
    base_mask = np.isfinite(lulc)
    static_model = {}
    for var in MODEL_VARS:
        if var in FUTURE_CLIMATE_VARS:
            continue
        categorical = var == "LULC"
        arr, path = read_city_scenario_var(city, scenario, var, ref_ds, required=True, categorical=categorical)
        static_model[var] = arr.astype("float32")
        if var not in ["BD", "PD", "BH", "BVI", "Micro_ISA", "Micro_PSA"]:
            base_mask &= np.isfinite(arr)
    target_raw = {}
    for var in TARGET_VARS:
        categorical = var == "LULC"
        arr, path = read_city_scenario_var(city, scenario, var, ref_ds, required=(var == "LULC"), categorical=categorical)
        if arr is not None:
            target_raw[var] = arr.astype("float32")
    for var in ["BD", "BH", "PD", "BVI", "Micro_ISA", "Micro_PSA"]:
        if var in static_model:
            static_model[var] = static_model[var].copy()
            static_model[var][base_mask & ~np.isfinite(static_model[var])] = 0.0
        if var in target_raw:
            target_raw[var] = target_raw[var].copy()
            target_raw[var][base_mask & ~np.isfinite(target_raw[var])] = 0.0
    for var in list(target_raw.keys()):
        if var == "LULC":
            continue
        fill_value = 0.0
        if np.isfinite(target_raw[var]).any():
            fill_value = float(np.nanmedian(target_raw[var][np.isfinite(target_raw[var])]))
        target_raw[var] = nearest_fill(target_raw[var], base_mask, fill_value=fill_value)
    target_raw["LULC"] = lulc
    LULC_eco = nearest_fill(reclass_lulc(lulc, LULC_ECO_MAP), base_mask, fill_value=0.0)
    LULC_urban = nearest_fill(reclass_lulc(lulc, LULC_URBAN_MAP), base_mask, fill_value=0.0)
    U_live = np.where((lulc == 8) & base_mask, 1.0, 0.0).astype("float32")
    U_live[~base_mask] = np.nan
    z = {}
    for var in ["PopD", "PD", "NTL", "GDP", "RD", "GVI", "Micro_PSA", "Micro_ISA", "NDVI", "BD", "BH"]:
        if var in target_raw and var in params:
            z[var] = zscore_fixed(target_raw[var], params, var)
            z[var][~base_mask] = np.nan
    exposure_list = []
    if "PopD" in z:
        exposure_list.append(z["PopD"])
    elif "PD" in z:
        exposure_list.append(z["PD"])
    for var in ["NTL", "GDP", "RD"]:
        if var in z:
            exposure_list.append(z[var])
    Impact = mean_available(exposure_list)
    if Impact is None:
        raise ValueError(f"{city}-{scenario}: cannot calculate Impact; PopD/PD/NTL/GDP/RD needed.")
    Impact[~base_mask] = np.nan
    L_street = mean_available([z.get("GVI"), z.get("Micro_PSA"), None if "Micro_ISA" not in z else (1.0 - z["Micro_ISA"])])
    Eco = mean_available([z.get("NDVI"), LULC_eco])
    if L_street is None or Eco is None:
        raise ValueError(f"{city}-{scenario}: cannot calculate F2; streetscape and NDVI/LULC needed.")
    L_hybrid = U_live * L_street + (1.0 - U_live) * Eco
    C_live = safe_sqrt_product(Eco, L_hybrid)
    K_live = multiscale_context(C_live)
    F2 = safe_sqrt_product(C_live, K_live)
    F2[~base_mask] = np.nan
    if "BD" not in z or "BH" not in z:
        raise ValueError(f"{city}-{scenario}: cannot calculate CGI; BD and BH needed.")
    GI_base = safe_sqrt_product(z["BD"], z["BH"])
    GI_base[base_mask & ~np.isfinite(GI_base)] = 0.0
    GI = GI_base * LULC_urban
    GI[base_mask & ~np.isfinite(GI)] = 0.0
    GI[~base_mask] = np.nan
    K_GI = multiscale_context(GI)
    K_GI[base_mask & ~np.isfinite(K_GI)] = 0.0
    K_GI[~base_mask] = np.nan
    CGI = safe_sqrt_product(GI, K_GI)
    CGI[base_mask & ~np.isfinite(CGI)] = 0.0
    CGI[~base_mask] = np.nan
    out = {
        "base_mask": base_mask,
        "static_model": static_model,
        "Impact": Impact.astype("float32"),
        "F2": F2.astype("float32"),
        "CGI": CGI.astype("float32"),
        "target_raw": target_raw,
    }
    STATIC_CACHE[cache_key] = out
    return out

# =========================================================
# 8. Prediction and target calculation
# =========================================================

def build_prediction_dataframe(city, feature_arrays, mask, ref_ds):
    rows, cols = np.where(mask)
    data = {}
    for var in MODEL_VARS:
        arr = feature_arrays[var]
        data[var] = arr[rows, cols]
    df_raw = pd.DataFrame(data)
    xs, ys = rasterio.transform.xy(ref_ds.transform, rows, cols, offset="center")
    xs = np.asarray(xs, dtype=float)
    ys = np.asarray(ys, dtype=float)
    meta = pd.DataFrame({
        "sample_id": [f"{city}_future_{i:08d}" for i in range(len(rows))],
        "City": city,
        "x": xs,
        "y": ys,
        "row": rows,
        "col": cols,
        "lon": np.nan,
        "lat": np.nan,
        "label": -1,
    })
    return df_raw, meta, rows, cols

def predict_p_flood_future(model_mod, runtime_package, preprocessor, city, feature_arrays, mask, ref_ds):
    df_raw, meta, rows, cols = build_prediction_dataframe(city, feature_arrays, mask, ref_ds)
    X_scaled = preprocessor.transform(df_raw)
    p_all = np.full(len(df_raw), np.nan, dtype="float32")
    n = len(df_raw)
    if n == 0:
        raise ValueError(f"{city}: no valid pixels for prediction.")
    use_original_predict = hasattr(model_mod, "predict_rf_stabilized_hydrocontex_gnnwrl_package")
    for start in range(0, n, PREDICT_CHUNK_SIZE):
        end = min(start + PREDICT_CHUNK_SIZE, n)
        print(f"    Predict chunk {start:,}-{end:,} / {n:,}")
        X_chunk = X_scaled.iloc[start:end].reset_index(drop=True)
        meta_chunk = meta.iloc[start:end].reset_index(drop=True)
        if use_original_predict:
            prob, extra, _ = model_mod.predict_rf_stabilized_hydrocontex_gnnwrl_package(runtime_package, X_chunk, meta_chunk)
        else:
            prob, extra, _ = fallback_predict_package(model_mod, runtime_package, X_chunk, meta_chunk)
        p_all[start:end] = prob.astype("float32")
    P = np.full((ref_ds.height, ref_ds.width), np.nan, dtype="float32")
    P[rows, cols] = p_all
    P[~mask] = np.nan
    return np.clip(P, 0, 1).astype("float32")

def calculate_targets_from_p(P, static_pack, mask):
    Impact = static_pack["Impact"]
    F2 = static_pack["F2"]
    CGI = static_pack["CGI"]
    P2 = P.copy()
    P2[~mask] = np.nan
    C_safe = P2 * Impact
    C_safe[~np.isfinite(P2) | ~np.isfinite(Impact)] = np.nan
    K_safe = multiscale_context(C_safe)
    K_safe[~mask] = np.nan
    F1 = safe_sqrt_product(C_safe, K_safe)
    F1[~mask] = np.nan
    Composite_simple = mean_available([1.0 - F1, F2, CGI])
    Composite_simple[~mask] = np.nan
    return {
        "P_flood": P2.astype("float32"),
        "F1": F1.astype("float32"),
        "F2": F2.astype("float32"),
        "CGI": CGI.astype("float32"),
        "Composite_simple": Composite_simple.astype("float32"),
    }

# =========================================================
# 9. Main workflow
# =========================================================

def preflight_check():
    print("\n========== Preflight check ==========")
    print("MODEL_SCRIPT_PATH:", MODEL_SCRIPT_PATH, MODEL_SCRIPT_PATH.exists())
    print("JOBLIB_PACKAGE:", JOBLIB_PACKAGE, JOBLIB_PACKAGE.exists())
    print("GNN_STATE_DICT:", GNN_STATE_DICT, GNN_STATE_DICT.exists())
    print("NC_ROOT:", NC_ROOT, NC_ROOT.exists())
    print("SCENARIO_ROOT:", SCENARIO_ROOT, SCENARIO_ROOT.exists())
    print("NORMALIZATION_CSV:", NORMALIZATION_CSV, NORMALIZATION_CSV.exists())
    if not MODEL_SCRIPT_PATH.exists():
        raise FileNotFoundError(f"Model script does not exist: {MODEL_SCRIPT_PATH}")
    if not JOBLIB_PACKAGE.exists():
        raise FileNotFoundError(f"Joblib model package does not exist: {JOBLIB_PACKAGE}")
    if not GNN_STATE_DICT.exists():
        raise FileNotFoundError(f"GNN state_dict does not exist: {GNN_STATE_DICT}")
    if not NC_ROOT.exists():
        raise FileNotFoundError(f"NC_ROOT does not exist: {NC_ROOT}")
    if not NORMALIZATION_CSV.exists():
        raise FileNotFoundError(f"NORMALIZATION_CSV does not exist: {NORMALIZATION_CSV}")
    if not SCENARIO_ROOT.exists():
        print("[WARN] SCENARIO_ROOT does not exist. S1-S7 will fall back to base city rasters.")
        print("[WARN] If you want real S0-S7 replay, set SCENARIO_ROOT to the true scenario raster folder.")

def run_future_replay():
    preflight_check()
    model_mod = import_model_module()
    runtime_package, preprocessor = load_gnnwrl_runtime_package(model_mod)
    params = load_normalization_params()
    all_rows = []
    failed_rows = []
    cities = CITIES
    ssps = SSPS
    scenarios = SCENARIOS
    if TEST_MODE:
        cities = ["Beijing"]
        ssps = ["ssp585"]
        scenarios = ["S0", "S7"]
        test_years = [2015, 2050, 2100]
        print("\n[TEST_MODE=True] Running only Beijing + ssp585 + S0/S7 + 2015/2050/2100")
    else:
        test_years = None
    for city in cities:
        template_path = find_template_raster(city)
        print("\n" + "=" * 100)
        print(f"City: {city}")
        print(f"Template: {template_path}")
        with rasterio.open(template_path) as ref_ds:
            for ssp in ssps:
                ds = open_nc(city, ssp)
                years = ds["year"].values.astype(int)
                if test_years is not None:
                    years = np.array(test_years, dtype=int)
                print("\n" + "-" * 90)
                print(f"{city} | {ssp} | years={years[0]}-{years[-1]} | n={len(years)}")
                for scenario in scenarios:
                    print("\n" + "#" * 80)
                    print(f"Scenario: {scenario}")
                    try:
                        static_pack = build_static_arrays(city, scenario, ref_ds, params)
                    except Exception as e:
                        print(f"[FAILED static] {city} {scenario}: {e}")
                        failed_rows.append({"City": city, "SSP": ssp, "Scenario": scenario, "Year": None, "Stage": "static", "Error": str(e)})
                        continue
                    for year in years:
                        print(f"\n>>> {city} | {ssp} | {scenario} | {year}")
                        try:
                            future_climate = get_future_climate_arrays(ds, int(year), ref_ds)
                            feature_arrays = {}
                            for var in MODEL_VARS:
                                if var in FUTURE_CLIMATE_VARS:
                                    feature_arrays[var] = future_climate[var]
                                else:
                                    feature_arrays[var] = static_pack["static_model"][var]
                            mask = static_pack["base_mask"].copy()
                            for var in FUTURE_CLIMATE_VARS:
                                mask &= np.isfinite(feature_arrays[var])
                            P_future = predict_p_flood_future(model_mod, runtime_package, preprocessor, city, feature_arrays, mask, ref_ds)
                            targets = calculate_targets_from_p(P_future, static_pack, mask)
                            row = {"City": city, "SSP": ssp, "Scenario": scenario, "Year": int(year), "Valid_pixels": int(mask.sum())}
                            for key, arr in targets.items():
                                row.update(raster_stats(arr, key))
                            pixel_area = abs(ref_ds.transform.a * ref_ds.transform.e)
                            if np.isfinite(targets["F1"]).any():
                                f1_p90 = float(np.nanpercentile(targets["F1"][np.isfinite(targets["F1"])], 90))
                                row["F1_internal_p90_threshold"] = f1_p90
                                row["F1_top10_area_km2_internal"] = float(np.nansum((targets["F1"] >= f1_p90).astype("float32")) * pixel_area / 1e6)
                            all_rows.append(row)
                            if int(year) in SAVE_RASTER_YEARS:
                                out_dir = OUT_ROOT / "decadal_maps" / city / ssp / scenario / str(int(year))
                                out_dir.mkdir(parents=True, exist_ok=True)
                                if SAVE_DECADAL_TIF:
                                    write_raster(out_dir / f"{city}_{ssp}_{scenario}_{year}_P_flood.tif", targets["P_flood"], ref_ds)
                                    write_raster(out_dir / f"{city}_{ssp}_{scenario}_{year}_F1.tif", targets["F1"], ref_ds)
                                    write_raster(out_dir / f"{city}_{ssp}_{scenario}_{year}_F2_static.tif", targets["F2"], ref_ds)
                                    write_raster(out_dir / f"{city}_{ssp}_{scenario}_{year}_CGI_static.tif", targets["CGI"], ref_ds)
                                if SAVE_DECADAL_PNG:
                                    save_png_map(targets["P_flood"], f"{city} {ssp} {scenario} {year} P_flood", out_dir / f"{city}_{ssp}_{scenario}_{year}_P_flood.png")
                                    save_png_map(targets["F1"], f"{city} {ssp} {scenario} {year} F1", out_dir / f"{city}_{ssp}_{scenario}_{year}_F1.png")
                            pd.DataFrame(all_rows).to_csv(OUT_ROOT / "future_S0S7_annual_summary_RUNNING.csv", index=False, encoding="utf-8-sig")
                        except Exception as e:
                            print(f"[FAILED annual] {city} {ssp} {scenario} {year}: {e}")
                            failed_rows.append({"City": city, "SSP": ssp, "Scenario": scenario, "Year": int(year), "Stage": "annual", "Error": str(e)})
                ds.close()
    summary = pd.DataFrame(all_rows)
    summary_path = OUT_ROOT / "future_S0S7_annual_summary.csv"
    summary.to_csv(summary_path, index=False, encoding="utf-8-sig")
    failed = pd.DataFrame(failed_rows)
    failed_path = OUT_ROOT / "future_S0S7_failed_rows.csv"
    failed.to_csv(failed_path, index=False, encoding="utf-8-sig")
    if len(summary) > 0:
        s0 = summary[summary["Scenario"] == "S0"][["City", "SSP", "Year", "F1_mean", "P_flood_mean"]].rename(columns={"F1_mean": "S0_F1_mean", "P_flood_mean": "S0_P_flood_mean"})
        merged = summary.merge(s0, on=["City", "SSP", "Year"], how="left")
        merged["F1_reduction_vs_future_S0"] = merged["S0_F1_mean"] - merged["F1_mean"]
        merged["F1_reduction_pct_vs_future_S0"] = merged["F1_reduction_vs_future_S0"] / (merged["S0_F1_mean"] + EPS) * 100
        base_benefit = merged[merged["Year"] == 2015][["City", "SSP", "Scenario", "F1_reduction_vs_future_S0"]].rename(columns={"F1_reduction_vs_future_S0": "Benefit_2015"})
        merged = merged.merge(base_benefit, on=["City", "SSP", "Scenario"], how="left")
        merged["Robustness_vs_2015"] = merged["F1_reduction_vs_future_S0"] / (merged["Benefit_2015"] + EPS)
        metrics_path = OUT_ROOT / "future_S0S7_annual_summary_with_benefit_robustness.csv"
        merged.to_csv(metrics_path, index=False, encoding="utf-8-sig")
        print("\nSaved:")
        print(summary_path)
        print(metrics_path)
        print(failed_path)
    return summary

if __name__ == "__main__":
    summary_df = run_future_replay()
    print("\nDone. Output folder:")
    print(OUT_ROOT)
