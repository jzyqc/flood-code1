from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import colormaps
from matplotlib.lines import Line2D
from matplotlib.patches import RegularPolygon
from mpl_toolkits.axes_grid1.inset_locator import inset_axes
from matplotlib.ticker import FormatStrFormatter
import glob

base = Path('/mnt/data/v11_reinspect/RF_Stabilized_HydroConTex_GNNWRL_v11_robust_diagnostics')
out_dir = Path('/mnt/data/subjournal_figs_v40_big_value_labels')
out_dir.mkdir(parents=True, exist_ok=True)
FINAL = 'RF_Stabilized_HydroConTex_GNNWRL'
CMAP = colormaps['RdYlBu_r']

c_main = CMAP(0.96)
c_mid1 = CMAP(0.78)
c_mid2 = CMAP(0.62)
c_mid3 = CMAP(0.45)
c_warm1 = CMAP(0.28)
c_warm2 = CMAP(0.12)
c_grey = '#B3BBC5'
c_darkgrey = '#6D7884'
c_panel = '#FBFCFD'
c_grid = '#D8E0E7'

core_model_colors = {
    FINAL: c_main,
    'RandomForest': c_warm1,
    'ExtraTrees': c_mid2,
    'XGBoost': c_mid3,
    'CatBoost': c_mid1,
    'LightGBM': CMAP(0.86),
    'HGB_Tuned': CMAP(0.70),
}
constructive_colors = {
    'C0_RF_Anchor_Only': c_warm2,
    'C1_RF_plus_HydroConTex_encoder_no_graph_no_WRL': c_warm1,
    'C2_RF_plus_HydroConTex_spatial_graph_no_WRL': c_mid2,
    FINAL: c_main,
}
delection_colors = {
    FINAL: c_main,
    'D4_w_o_HydroConTex_grouping_single_context_diagnostic': c_mid1,
    'D3_w_o_WRL_local_context_weights': c_mid3,
    'D2_w_o_spatial_graph': c_warm1,
    'D1_GNNWRL_Only_without_RF_Stabilization': c_warm2,
}
metric_colors = {'AUC': c_main, 'PR-AUC': c_mid2, 'F1': c_mid3, 'Recall': c_warm2, '1-Brier': c_warm1}

plt.rcParams.update({
    'font.family': 'serif',
    'font.serif': ['Times New Roman', 'Liberation Serif', 'Nimbus Roman', 'DejaVu Serif'],
    'font.size': 18.8,
    'font.weight': 'bold',
    'axes.titlesize': 20.5,
    'axes.titleweight': 'bold',
    'axes.labelsize': 18.5,
    'axes.labelweight': 'bold',
    'xtick.labelsize': 15.8,
    'ytick.labelsize': 15.8,
    'legend.fontsize': 16.0,
    'axes.linewidth': 1.52,
    'figure.facecolor': 'white',
    'axes.facecolor': 'white',
    'savefig.facecolor': 'white',
})

def short_name(m):
    mapping = {
        FINAL:'Full', 'RandomForest':'RF', 'ExtraTrees':'ET', 'XGBoost':'XGB', 'CatBoost':'CatB',
        'LightGBM':'LGBM', 'HGB_Tuned':'HGB-T', 'C0_RF_Anchor_Only':'RF anchor',
        'C1_RF_plus_HydroConTex_encoder_no_graph_no_WRL':'+Context',
        'C2_RF_plus_HydroConTex_spatial_graph_no_WRL':'+Graph',
        'D1_GNNWRL_Only_without_RF_Stabilization':'GNN only',
        'D2_w_o_spatial_graph':'−Graph', 'D3_w_o_WRL_local_context_weights':'−WRL',
        'D4_w_o_HydroConTex_grouping_single_context_diagnostic':'−Group',
        'LogisticRegression':'LogReg', 'GaussianNB':'GNB', 'DecisionTree':'DT', 'GradientBoosting':'GB',
        'BaggingTree':'BagTree', 'AdaBoost':'AdaB', 'KNN':'KNN', 'SVM_Linear':'SVM-L', 'SVM_RBF':'SVM-R', 'MLP':'MLP',
    }
    return mapping.get(m, m)

def style_axes(ax, grid=True):
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.spines['left'].set_color('#7B8692')
    ax.spines['bottom'].set_color('#7B8692')
    ax.spines['left'].set_linewidth(1.28)
    ax.spines['bottom'].set_linewidth(1.28)
    if grid:
        ax.grid(alpha=0.16, linewidth=0.84, zorder=0, color=c_grid)
    ax.set_facecolor(c_panel)
    for lbl in ax.get_xticklabels() + ax.get_yticklabels():
        lbl.set_fontweight('bold')

def legend_style(leg):
    if leg is None:
        return
    frame = leg.get_frame()
    frame.set_facecolor('white')
    frame.set_alpha(0.95)
    frame.set_edgecolor('#CDD5DD')
    frame.set_linewidth(0.95)
    for txt in leg.get_texts():
        txt.set_fontweight('bold')


def _style_lollipop_axis(ax):
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.spines['left'].set_color('#7B8692')
    ax.spines['bottom'].set_color('#7B8692')
    ax.spines['left'].set_linewidth(1.20)
    ax.spines['bottom'].set_linewidth(1.20)
    ax.set_facecolor(c_panel)
    ax.grid(axis='x', alpha=0.14, linewidth=0.80, color=c_grid, zorder=0)
    for lbl in ax.get_xticklabels() + ax.get_yticklabels():
        lbl.set_fontweight('bold')


def _draw_absolute_lollipop(ax, names, values_by_metric, title, xlim, xticks, highlight_index=None,
                            legend_loc='lower right'):
    y = np.arange(len(names), dtype=float)
    metrics = list(values_by_metric.keys())
    offsets = np.linspace(-0.20, 0.20, len(metrics))
    baseline = xlim[0]

    if highlight_index is not None:
        ax.axhspan(highlight_index - 0.52, highlight_index + 0.52, color='#EAF3F7', zorder=0)

    for yi in y:
        ax.hlines(yi, xlim[0], xlim[1], color='#E3E8EE', lw=0.82, zorder=0)

    ax.axvline(baseline, color='#8994A0', lw=1.22, zorder=1)

    for off, metric in zip(offsets, metrics):
        vals = np.asarray(values_by_metric[metric], dtype=float)
        yoff = y + off
        for xv, yy in zip(vals, yoff):
            ax.plot([baseline, xv], [yy, yy], color='#D8E0E8', alpha=0.96,
                    lw=4.6, zorder=1, solid_capstyle='round')
            ax.plot([baseline, xv], [yy, yy], color=metric_colors[metric], alpha=0.76,
                    lw=2.55, zorder=2, solid_capstyle='round')

        sizes = np.full(len(vals), 84.0)
        if highlight_index is not None:
            sizes[highlight_index] = 136.0

        ax.scatter(np.full(len(vals), baseline), yoff, s=12.0, color=metric_colors[metric],
                   edgecolors='none', alpha=0.95, zorder=3)
        ax.scatter(vals, yoff, s=sizes, color=metric_colors[metric], edgecolors='black',
                   linewidths=0.82, zorder=4, label=metric)

    ax.set_yticks(y)
    ax.set_yticklabels(names, fontsize=10.8, fontweight='bold')
    ax.invert_yaxis()
    ax.set_xlim(*xlim)
    ax.set_xticks(xticks)
    ax.xaxis.set_major_formatter(FormatStrFormatter('%.2f'))
    ax.set_xlabel('Score')
    ax.set_title(title, loc='left')
    ax.tick_params(axis='y', length=0)
    _style_lollipop_axis(ax)

    leg = ax.legend(loc=legend_loc, frameon=True, fontsize=10.2, ncol=2,
                    handletextpad=0.28, columnspacing=0.55, labelspacing=0.10, borderpad=0.18)
    legend_style(leg)


def _draw_delta_lollipop(ax, names, delta_by_metric, title, xlim, xticks, highlight_index=None,
                         group_break=None, group_labels=None, legend_loc='lower right'):
    y = np.arange(len(names), dtype=float)
    metrics = list(delta_by_metric.keys())
    offsets = np.linspace(-0.20, 0.20, len(metrics))
    baseline = 0.0

    if highlight_index is not None:
        ax.axhspan(highlight_index - 0.52, highlight_index + 0.52, color='#EAF3F7', zorder=0)

    if group_break is not None:
        ax.axhline(group_break - 0.5, color='#C8D1DB', lw=1.0, ls='--', alpha=0.82, zorder=0)

    for yi in y:
        ax.hlines(yi, xlim[0], xlim[1], color='#E3E8EE', lw=0.82, zorder=0)

    ax.axvline(0, color='#808A96', lw=1.18, ls='--', zorder=1)

    for off, metric in zip(offsets, metrics):
        vals = np.asarray(delta_by_metric[metric], dtype=float)
        yoff = y + off
        for xv, yy in zip(vals, yoff):
            ax.plot([baseline, xv], [yy, yy], color='#D8E0E8', alpha=0.96,
                    lw=4.4, zorder=1, solid_capstyle='round')
            ax.plot([baseline, xv], [yy, yy], color=metric_colors[metric], alpha=0.78,
                    lw=2.50, zorder=2, solid_capstyle='round')

        sizes = np.full(len(vals), 82.0)
        if highlight_index is not None:
            sizes[highlight_index] = 132.0

        ax.scatter(np.full(len(vals), baseline), yoff, s=11.0, color=metric_colors[metric],
                   edgecolors='none', alpha=0.95, zorder=3)
        ax.scatter(vals, yoff, s=sizes, color=metric_colors[metric], edgecolors='black',
                   linewidths=0.82, zorder=4, label=metric)

        # Label non-zero ablation changes. Skip the Full-model zero row to avoid clutter.
        for xv, yy in zip(vals, yoff):
            if abs(float(xv)) < 5e-5:
                continue
            if xv < 0:
                ax.text(xv - 0.0012, yy, f'{xv:+.3f}', va='center', ha='right',
                        fontsize=8.2, fontweight='bold', color='#111111', zorder=5, clip_on=True,
                        bbox=dict(facecolor='white', edgecolor='none', alpha=0.72, pad=0.25))
            else:
                ax.text(xv + 0.0012, yy, f'{xv:+.3f}', va='center', ha='left',
                        fontsize=8.2, fontweight='bold', color='#111111', zorder=5, clip_on=True,
                        bbox=dict(facecolor='white', edgecolor='none', alpha=0.72, pad=0.25))

    ax.set_yticks(y)
    ax.set_yticklabels(names, fontsize=10.8, fontweight='bold')
    ax.invert_yaxis()
    ax.set_xlim(*xlim)
    ax.set_xticks(xticks)
    ax.xaxis.set_major_formatter(FormatStrFormatter('%.3f'))
    ax.set_xlabel(r'Δscore relative to Full model')
    ax.set_title(title, loc='left')
    ax.tick_params(axis='y', length=0)
    _style_lollipop_axis(ax)

    if group_labels:
        for text_label, ypos, xpos in group_labels:
            ax.text(xpos, ypos, text_label, fontsize=10.2, color='#5D6874',
                    fontweight='bold', va='center')

    leg = ax.legend(loc=legend_loc, frameon=True, fontsize=10.2, ncol=2,
                    handletextpad=0.28, columnspacing=0.55, labelspacing=0.10, borderpad=0.18)
    legend_style(leg)


def style_inset(ax):
    ax.set_facecolor('white')
    for sp in ax.spines.values():
        sp.set_linewidth(1.55)
        sp.set_color('#687482')
    ax.grid(axis='x', alpha=0.12, linewidth=0.55)
    ax.tick_params(labelsize=7.8, length=2.0, width=0.8)
    for lbl in ax.get_xticklabels() + ax.get_yticklabels():
        lbl.set_fontweight('bold')


def add_metric_inset(parent_ax, series, title, anchor='upper left', width='36%', height='31%',
                     bbox_to_anchor=None, bounds=None, xpad_left=0.010, xpad_right=0.008):
    loc_map = {'upper left':'upper left', 'upper right':'upper right', 'lower left':'lower left', 'lower right':'lower right',
               'center right':'center right', 'center left':'center left'}
    if bounds is not None:
        iax = parent_ax.inset_axes(bounds)
    else:
        kwargs = dict(width=width, height=height, loc=loc_map[anchor], borderpad=0.60)
        if bbox_to_anchor is not None:
            kwargs['bbox_to_anchor'] = bbox_to_anchor
            kwargs['bbox_transform'] = parent_ax.transAxes
        iax = inset_axes(parent_ax, **kwargs)
    iax.set_zorder(6)

    names = [x[0] for x in series][::-1]
    vals = np.asarray([x[1] for x in series][::-1], dtype=float)
    colors = [x[2] for x in series][::-1]
    y = np.arange(len(series), dtype=float)

    vmin = max(0, float(np.min(vals) - xpad_left))
    vmax = min(1.0, float(np.max(vals) + xpad_right))
    x0 = vmin

    for yi in y:
        iax.hlines(yi, vmin, vmax, color='#EEF2F6', lw=0.72, zorder=0)

    for yi, name, val, c in zip(y, names, vals, colors):
        iax.plot([x0, val], [yi, yi], color='#D8DEE6', lw=5.3, solid_capstyle='round', zorder=1)
        iax.plot([x0, val], [yi, yi], color=c, lw=2.9, alpha=0.82, solid_capstyle='round', zorder=2)
        iax.scatter([x0], [yi], s=18, color=c, edgecolors='none', zorder=3)
        iax.scatter([val], [yi], s=92, color=c, edgecolors='black', linewidths=0.86, zorder=4)
        # numeric PR-AUC value at the endpoint
        iax.text(val + (vmax - vmin) * 0.018, yi, f'{val:.3f}',
                 va='center', ha='left', fontsize=9.2, fontweight='bold',
                 color='#111111', zorder=5, clip_on=True)

    iax.set_yticks(y)
    iax.set_yticklabels(names, fontsize=8.6, fontweight='bold')
    iax.set_xlim(vmin, vmax)
    iax.xaxis.set_major_formatter(FormatStrFormatter('%.2f'))
    iax.set_title(title, fontsize=9.0, fontweight='bold', pad=2.0)
    style_inset(iax)
    return iax


def _build_full_hex_grid(df, xcol, ycol, ncols=11):
    # Build a complete honeycomb grid covering the city extent.
    x = df[xcol].astype(float).to_numpy()
    y = df[ycol].astype(float).to_numpy()
    xmin, xmax = np.nanmin(x), np.nanmax(x)
    ymin, ymax = np.nanmin(y), np.nanmax(y)

    xr = max(xmax - xmin, 1e-9)
    dx = xr / max(ncols - 1, 1)
    side = dx / np.sqrt(3.0)
    dy = 1.5 * side

    # city-specific adjustment for very tall / wide panels
    yr = max(ymax - ymin, 1e-9)
    nrows = int(np.ceil(yr / max(dy, 1e-9))) + 1
    if nrows < 5:
        nrows = 5

    rows = np.arange(nrows + 1)
    grid_rows = []
    for r in rows:
        xoff = dx / 2.0 if r % 2 == 1 else 0.0
        row_cols = np.arange(ncols + 1)
        cx = xmin + row_cols * dx + xoff
        cy = np.full_like(cx, ymin + r * dy, dtype=float)
        tmp = pd.DataFrame({"row": r, "col": row_cols, "cx": cx, "cy": cy})
        grid_rows.append(tmp)
    grid = pd.concat(grid_rows, ignore_index=True)

    return {
        "grid": grid,
        "xmin": xmin, "xmax": xmax, "ymin": ymin, "ymax": ymax,
        "dx": dx, "dy": dy, "side": side
    }


def _assign_points_to_hex(df, xcol, ycol, grid_meta):
    if df.empty:
        return pd.DataFrame(columns=["row", "col", "n"])
    xmin = grid_meta["xmin"]
    ymin = grid_meta["ymin"]
    dx = grid_meta["dx"]
    dy = grid_meta["dy"]

    x = df[xcol].astype(float).to_numpy()
    y = df[ycol].astype(float).to_numpy()

    row = np.floor((y - ymin) / dy + 0.5).astype(int)
    xoff = np.where(row % 2 == 1, dx / 2.0, 0.0)
    col = np.floor((x - xmin - xoff) / dx + 0.5).astype(int)

    out = pd.DataFrame({"row": row, "col": col, "n": 1})
    out = out.groupby(["row", "col"], as_index=False)["n"].sum()
    return out


def _hex_face_and_edge(row, train_max, test_max):
    # full-coverage base grid, training in grayscale, held-out overlaid in warm colors
    if row["test_n"] > 0:
        ratio = row["test_n"] / max(test_max, 1)
        face = plt.cm.YlOrRd(0.28 + 0.68 * ratio)
        edge = "black"
        lw = 0.62
    elif row["train_n"] > 0:
        ratio = row["train_n"] / max(train_max, 1)
        shade = 0.90 - 0.38 * ratio
        face = (shade, shade, shade, 1.0)
        edge = "#9A9A9A"
        lw = 0.48
    else:
        face = (1, 1, 1, 1)
        edge = "#D6DDE4"
        lw = 0.40
    return face, edge, lw


def _draw_full_coverage_honeycomb(ax, g, city_name, ncols=11):
    xcol = 'lon' if 'lon' in g.columns and g['lon'].notna().any() else 'x'
    ycol = 'lat' if 'lat' in g.columns and g['lat'].notna().any() else 'y'

    meta = _build_full_hex_grid(g, xcol, ycol, ncols=ncols)
    grid = meta["grid"].copy()

    train = g[g["Role"] == "train"].copy()
    test = g[g["Role"] == "test"].copy()
    pos_test = test[test["label"] == 1].copy() if "label" in test.columns else test.iloc[0:0].copy()

    train_cnt = _assign_points_to_hex(train, xcol, ycol, meta).rename(columns={"n": "train_n"})
    test_cnt = _assign_points_to_hex(test, xcol, ycol, meta).rename(columns={"n": "test_n"})
    pos_cnt = _assign_points_to_hex(pos_test, xcol, ycol, meta).rename(columns={"n": "pos_n"})

    grid = grid.merge(train_cnt, on=["row", "col"], how="left")
    grid = grid.merge(test_cnt, on=["row", "col"], how="left")
    grid = grid.merge(pos_cnt, on=["row", "col"], how="left")
    grid[["train_n", "test_n", "pos_n"]] = grid[["train_n", "test_n", "pos_n"]].fillna(0)

    train_max = max(grid["train_n"].max(), 1)
    test_max = max(grid["test_n"].max(), 1)
    side = meta["side"]

    ax.set_facecolor("white")
    for sp in ax.spines.values():
        sp.set_visible(False)

    for _, r in grid.iterrows():
        face, edge, lw = _hex_face_and_edge(r, train_max, test_max)
        patch = RegularPolygon(
            (r["cx"], r["cy"]),
            numVertices=6,
            radius=side * 0.88,
            orientation=np.radians(30),
            facecolor=face,
            edgecolor=edge,
            linewidth=lw,
            zorder=1 if r["test_n"] == 0 else 2
        )
        ax.add_patch(patch)

        # highlight flood-positive test hexes with a darker center marker
        if r["pos_n"] > 0:
            ax.scatter(
                [r["cx"]], [r["cy"]],
                s=18 + 5 * np.sqrt(r["pos_n"]),
                c="#BF1D2D",
                edgecolors="white",
                linewidths=0.35,
                zorder=3
            )

    xmin, xmax = meta["xmin"], meta["xmax"]
    ymin, ymax = meta["ymin"], meta["ymax"]
    padx = (xmax - xmin) * 0.09 if xmax > xmin else 0.01
    pady = (ymax - ymin) * 0.10 if ymax > ymin else 0.01
    ax.set_xlim(xmin - padx, xmax + padx)
    ax.set_ylim(ymin - pady, ymax + pady)
    ax.set_aspect("equal", adjustable="box")
    ax.set_xticks([])
    ax.set_yticks([])
    ax.set_title(city_name, fontsize=15.4, pad=1.4, fontweight="bold")

def aggregate_ablation_curves(kind='roc'):
    folder = base / '04_Ablation_CV' / 'Spatial_Block_CV_G5'
    patt = '*_roc_curve_data.csv' if kind == 'roc' else '*_pr_curve_data.csv'
    files = sorted(glob.glob(str(folder / patt)))
    grid = np.linspace(0, 1, 260)
    xcol, ycol = ('FPR', 'TPR') if kind == 'roc' else ('Recall', 'Precision')
    curves = {}
    for f in files:
        df = pd.read_csv(f)
        if df.empty:
            continue
        model = df['Model'].iloc[0]
        sub = df[[xcol, ycol]].dropna().copy().sort_values(xcol)
        sub = sub.groupby(xcol, as_index=False)[ycol].max()
        if kind == 'roc':
            interp = np.interp(grid, sub[xcol], sub[ycol], left=0.0, right=1.0)
        else:
            interp = np.interp(grid, sub[xcol], sub[ycol], left=sub[ycol].iloc[0], right=sub[ycol].iloc[-1])
            interp = np.clip(interp, 0, 1)
        curves.setdefault(model, []).append(interp)
    return {m: {'x': grid, 'mean': np.vstack(v).mean(axis=0)} for m, v in curves.items()}

metrics_all = pd.read_csv(base / 'plot_data' / 'metrics_all.csv')
holdout_rank = pd.read_csv(base / 'Model_selection_holdout_only_ranking.csv')
roc_all = pd.read_csv(base / 'plot_data' / 'roc_curve_data_all.csv')
pr_all = pd.read_csv(base / 'plot_data' / 'pr_curve_data_all.csv')
cal_all = pd.read_csv(base / 'plot_data' / 'calibration_curve_data_all.csv')
assign = pd.read_csv(base / 'plot_data' / 'spatial_cv_fold_train_test_assignments_G5.csv')
ci = pd.read_csv(base / 'Bootstrap_CI_fold_city_metrics.csv')
ab = pd.read_csv(base / '04_Ablation_CV' / 'Spatial_Block_CV_G5' / 'Ablation_Spatial_Block_CV_G5_summary_metrics.csv')
roc_ab = aggregate_ablation_curves('roc')
pr_ab = aggregate_ablation_curves('pr')

all_models = metrics_all[(metrics_all['Experiment'] == 'Holdout') & (metrics_all['Model'] != 'Dummy')]['Model'].tolist()
core = [m for m in [FINAL, 'RandomForest', 'ExtraTrees', 'XGBoost', 'CatBoost', 'LightGBM', 'HGB_Tuned'] if m in all_models]
others = [m for m in all_models if m not in core]

fig, axes = plt.subplots(3, 3, figsize=(18.8, 13.7))
fig.subplots_adjust(left=0.052, right=0.992, top=0.932, bottom=0.055, wspace=0.16, hspace=0.28)

# a ROC
ax = axes[0,0]
for m in core:
    sub = roc_all[(roc_all['Experiment']=='Holdout') & (roc_all['Model']==m)]
    ax.plot(sub['FPR'], sub['TPR'], color=core_model_colors[m], lw=4.2 if m==FINAL else 3.35, zorder=3)
for m in others:
    sub = roc_all[(roc_all['Experiment']=='Holdout') & (roc_all['Model']==m)]
    ax.plot(sub['FPR'], sub['TPR'], color=c_grey, lw=1.0, alpha=0.90, zorder=1)
ax.plot([0,1],[0,1],'--', color=c_darkgrey, lw=1.05)
ax.set_title('a  Holdout ROC curves', loc='left')
ax.set_xlabel('False positive rate'); ax.set_ylabel('True positive rate')
style_axes(ax)
handles = [Line2D([0],[0], color=core_model_colors[m], lw=3.5) for m in [FINAL,'RandomForest','ExtraTrees','XGBoost','CatBoost']] + [Line2D([0],[0], color=c_grey, lw=1.7)]
labels = [f'{short_name(m)} ({metrics_all[(metrics_all["Experiment"]=="Holdout")&(metrics_all["Model"]==m)]["AUC"].iloc[0]:.3f})' for m in [FINAL,'RandomForest','ExtraTrees','XGBoost','CatBoost']] + [f'Other (n={len(others)})']
leg = ax.legend(handles, labels, loc='lower right', bbox_to_anchor=(0.985, 0.025), ncol=2, frameon=True, fontsize=13.2, handlelength=1.55, handletextpad=0.28, columnspacing=0.55, labelspacing=0.12, borderpad=0.18)
legend_style(leg)

# b PR
ax = axes[0,1]
for m in core:
    sub = pr_all[(pr_all['Experiment']=='Holdout') & (pr_all['Model']==m)]
    ax.plot(sub['Recall'], sub['Precision'], color=core_model_colors[m], lw=4.2 if m==FINAL else 3.35, zorder=3)
for m in others:
    sub = pr_all[(pr_all['Experiment']=='Holdout') & (pr_all['Model']==m)]
    ax.plot(sub['Recall'], sub['Precision'], color=c_grey, lw=1.0, alpha=0.90, zorder=1)
ax.set_title('b  Holdout precision–recall curves', loc='left')
ax.set_xlabel('Recall'); ax.set_ylabel('Precision')
style_axes(ax)
handles = [Line2D([0],[0], color=core_model_colors[m], lw=3.5) for m in [FINAL,'RandomForest','ExtraTrees','XGBoost','CatBoost']] + [Line2D([0],[0], color=c_grey, lw=1.7)]
labels = [f'{short_name(m)} ({metrics_all[(metrics_all["Experiment"]=="Holdout")&(metrics_all["Model"]==m)]["PR_AUC"].iloc[0]:.3f})' for m in [FINAL,'RandomForest','ExtraTrees','XGBoost','CatBoost']] + [f'Other (n={len(others)})']
leg = ax.legend(handles, labels, loc='lower right', bbox_to_anchor=(0.985, 0.025), ncol=2, frameon=True, fontsize=13.2, handlelength=1.55, handletextpad=0.28, columnspacing=0.55, labelspacing=0.12, borderpad=0.18)
legend_style(leg)

# c benchmark summary - lollipop strategy
ax = axes[0,2]
df = holdout_rank[holdout_rank['Model']!='Dummy'].copy().sort_values('mean_rank').reset_index(drop=True)

metrics_c = {
    'AUC': df['AUC'].values,
    'PR-AUC': df['PR_AUC'].values,
    'F1': df['F1'].values,
    '1-Brier': 1 - df['Brier'].values
}
names_c = [short_name(m) for m in df['Model']]
hi_c = int(df.index[df['Model'] == FINAL][0]) if (df['Model'] == FINAL).any() else None

_draw_absolute_lollipop(
    ax=ax,
    names=names_c,
    values_by_metric=metrics_c,
    title='c  All benchmark models in Holdout',
    xlim=(0.642, 0.822),
    xticks=[0.65, 0.70, 0.75, 0.80],
    highlight_index=hi_c,
    legend_loc='lower right'
)

# d spatial CV honeycomb with full-coverage grid
ax = axes[1,0]
ax.set_facecolor('white'); ax.set_xticks([]); ax.set_yticks([])
for side, sp in ax.spines.items():
    if side in ['left', 'bottom']:
        sp.set_visible(True)
        sp.set_color('#7B8692')
        sp.set_linewidth(1.85)
    else:
        sp.set_visible(False)

fold = sorted(assign['Fold'].unique())[0]
sub = assign[assign['Fold']==fold].copy()
cities = [c for c in ['Beijing','Chengdu','Guangzhou','Shanghai','Shenzhen','Tianjin'] if c in set(sub['City'])]

positions = [
    (0.03,0.55,0.29,0.35), (0.355,0.55,0.29,0.35), (0.68,0.55,0.29,0.35),
    (0.03,0.10,0.29,0.35), (0.355,0.10,0.29,0.35), (0.68,0.10,0.29,0.35)
]

city_ncols = {'Beijing': 10, 'Chengdu': 10, 'Guangzhou': 10, 'Shanghai': 11, 'Shenzhen': 10, 'Tianjin': 10}

for city, pos in zip(cities, positions):
    iax = ax.inset_axes(pos)
    g = sub[sub['City'] == city].copy()
    _draw_full_coverage_honeycomb(iax, g, city, ncols=city_ncols.get(city, 11))

ax.set_title('d  Spatial block CV partition example', loc='left', fontsize=18.7)

leg = ax.legend(
    handles=[
        RegularPolygon((0, 0), numVertices=6, radius=4, orientation=np.radians(30),
                       facecolor='white', edgecolor='#D6DDE4', linewidth=0.7, label='full hex coverage'),
        RegularPolygon((0, 0), numVertices=6, radius=4, orientation=np.radians(30),
                       facecolor='#8C8C8C', edgecolor='#9A9A9A', linewidth=0.7, label='training density'),
        RegularPolygon((0, 0), numVertices=6, radius=4, orientation=np.radians(30),
                       facecolor=plt.cm.YlOrRd(0.55), edgecolor='black', linewidth=0.8, label='held-out block'),
        Line2D([0],[0], marker='o', color='none', markerfacecolor='#BF1D2D',
               markeredgecolor='white', markeredgewidth=0.4, markersize=7.0, label='flood-positive test')
    ],
    loc='lower center', bbox_to_anchor=(0.5,0.01), ncol=2, frameon=True,
    fontsize=11.6, handletextpad=0.36, columnspacing=0.72, borderpad=0.16
)
legend_style(leg)

# e CV CI
ax = axes[1,1]
for off,m in zip(np.linspace(-0.28,0.28,5), [FINAL,'RandomForest','ExtraTrees','XGBoost','CatBoost']):
    vals=[]; lo=[]; hi=[]
    for exp in ['Ordinary_StratifiedKFold_CV','Spatial_Block_CV_G5','Leave_One_City_Out_CV']:
        r = ci[(ci['Experiment']==exp)&(ci['Model']==m)&(ci['Metric']=='AUC')].iloc[0]
        vals.append(r['Mean']); lo.append(r['Mean']-r['CI95_low']); hi.append(r['CI95_high']-r['Mean'])
    ax.errorbar(np.arange(3)+off, vals, yerr=[lo,hi], fmt='o-', ms=7.2, lw=2.8, capsize=4.8, color=core_model_colors[m], label=short_name(m))
ax.set_xticks(np.arange(3)); ax.set_xticklabels(['Stratified CV','Spatial Block CV','LOCO'], fontweight='bold')
ax.set_ylabel('AUC with bootstrap 95% CI'); ax.set_title('e  Cross-validation AUC with confidence intervals', loc='left', fontsize=18.7)
style_axes(ax)
leg = ax.legend(loc='upper right', bbox_to_anchor=(0.985,0.985), ncol=1, frameon=True, fontsize=14.8, handlelength=1.45, handletextpad=0.24, borderpad=0.16, labelspacing=0.10)
legend_style(leg)

# f calibration
ax = axes[1,2]
f_models = [FINAL,'RandomForest','ExtraTrees','XGBoost','CatBoost','LightGBM','HGB_Tuned']
for m in f_models:
    sub = cal_all[(cal_all['Experiment']=='Holdout')&(cal_all['Model']==m)].dropna(subset=['mean_pred','obs_freq'])
    ax.plot(sub['mean_pred'], sub['obs_freq'], marker='o', ms=5.0, lw=2.75, color=core_model_colors[m])
ax.plot([0,1],[0,1],'--', color=c_darkgrey, lw=1.05)
ax.set_xlabel('Mean predicted probability'); ax.set_ylabel('Observed frequency'); ax.set_title('f  Holdout calibration curves', loc='left')
style_axes(ax)
handles = [Line2D([0],[0], color=core_model_colors[m], lw=3.0, marker='o', markersize=4.4) for m in [FINAL,'RandomForest','ExtraTrees','XGBoost','CatBoost','LightGBM','HGB_Tuned']]
labels = [f'{short_name(m)} ({metrics_all[(metrics_all["Experiment"]=="Holdout")&(metrics_all["Model"]==m)]["Brier"].iloc[0]:.3f})' for m in [FINAL,'RandomForest','ExtraTrees','XGBoost','CatBoost','LightGBM','HGB_Tuned']]
leg = ax.legend(handles, labels, loc='lower right', bbox_to_anchor=(0.985,0.02), ncol=2, frameon=True, fontsize=12.4, handlelength=1.6, columnspacing=0.48, labelspacing=0.12, borderpad=0.16)
legend_style(leg)

# g constructive ablation ROC + bar inset, no PR inset
ax = axes[2,0]
constructive_order = ['C0_RF_Anchor_Only','C1_RF_plus_HydroConTex_encoder_no_graph_no_WRL','C2_RF_plus_HydroConTex_spatial_graph_no_WRL',FINAL]
for m in constructive_order:
    curve = roc_ab[m]; ax.plot(curve['x'], curve['mean'], color=constructive_colors[m], lw=4.0 if m==FINAL else 3.1)
ax.plot([0,1],[0,1],'--', color=c_darkgrey, lw=1.05)
ax.set_xlabel('False positive rate'); ax.set_ylabel('True positive rate'); ax.set_title('g  Constructive ablation ROC curves', loc='left')
style_axes(ax)
# use PR-AUC bar inset only, no local zoom
pr_series_g = [(short_name(m), ab.loc[ab['Model']==m,'PR_AUC_mean'].iloc[0], constructive_colors[m]) for m in constructive_order]
add_metric_inset(ax, pr_series_g, 'PR-AUC summary', bounds=[0.58, 0.50, 0.37, 0.27], xpad_left=0.010, xpad_right=0.010)
handles = [Line2D([0],[0], color=constructive_colors[m], lw=3.0) for m in constructive_order]
labels = [f'{short_name(m)} ({ab.loc[ab["Model"]==m, "AUC_mean"].iloc[0]:.3f})' for m in constructive_order]
leg = ax.legend(handles, labels, loc='lower left', bbox_to_anchor=(0.015,0.020), ncol=2, frameon=True, fontsize=10.8, handlelength=1.20, handletextpad=0.22, columnspacing=0.40, labelspacing=0.08, borderpad=0.14)
legend_style(leg)

# h deletion ablation ROC + bar inset, no PR inset
ax = axes[2,1]
deletion_order = [FINAL,'D4_w_o_HydroConTex_grouping_single_context_diagnostic','D3_w_o_WRL_local_context_weights','D2_w_o_spatial_graph','D1_GNNWRL_Only_without_RF_Stabilization']
for m in deletion_order:
    curve = roc_ab[m]; ax.plot(curve['x'], curve['mean'], color=delection_colors[m], lw=4.0 if m==FINAL else 3.08)
ax.plot([0,1],[0,1],'--', color=c_darkgrey, lw=1.05)
ax.set_xlabel('False positive rate'); ax.set_ylabel('True positive rate'); ax.set_title('h  Deletion ablation ROC curves', loc='left')
style_axes(ax)
pr_series_h = [(short_name(m), ab.loc[ab['Model']==m,'PR_AUC_mean'].iloc[0], delection_colors[m]) for m in deletion_order]
add_metric_inset(ax, pr_series_h, 'PR-AUC summary', bounds=[0.58, 0.50, 0.37, 0.29], xpad_left=0.012, xpad_right=0.010)
handles = [Line2D([0],[0], color=delection_colors[m], lw=3.0) for m in deletion_order]
labels = [f'{short_name(m)} ({ab.loc[ab["Model"]==m, "AUC_mean"].iloc[0]:.3f})' for m in deletion_order]
leg = ax.legend(handles, labels, loc='lower left', bbox_to_anchor=(0.015,0.020), ncol=2, frameon=True, fontsize=10.2, handlelength=1.20, handletextpad=0.22, columnspacing=0.38, labelspacing=0.08, borderpad=0.14)
legend_style(leg)

# i ablation summary - lollipop delta strategy
ax = axes[2,2]
summary_order = [
    'C0_RF_Anchor_Only',
    'C1_RF_plus_HydroConTex_encoder_no_graph_no_WRL',
    'C2_RF_plus_HydroConTex_spatial_graph_no_WRL',
    FINAL,
    'D4_w_o_HydroConTex_grouping_single_context_diagnostic',
    'D3_w_o_WRL_local_context_weights',
    'D2_w_o_spatial_graph',
    'D1_GNNWRL_Only_without_RF_Stabilization'
]
sdf = ab.set_index('Model').loc[summary_order].reset_index()

# Relative to Proposed: positive means improvement, negative means performance loss.
base_auc = float(sdf.loc[sdf['Model']==FINAL, 'AUC_mean'].iloc[0])
base_pra = float(sdf.loc[sdf['Model']==FINAL, 'PR_AUC_mean'].iloc[0])
base_f1  = float(sdf.loc[sdf['Model']==FINAL, 'F1_mean'].iloc[0])
base_bri = float(sdf.loc[sdf['Model']==FINAL, 'Brier_mean'].iloc[0])

delta_i = {
    'AUC': sdf['AUC_mean'].values - base_auc,
    'PR-AUC': sdf['PR_AUC_mean'].values - base_pra,
    'F1': sdf['F1_mean'].values - base_f1,
    '1-Brier': (1 - sdf['Brier_mean'].values) - (1 - base_bri)
}
names_i = [short_name(m) for m in sdf['Model']]
hi_i = int(sdf.index[sdf['Model'] == FINAL][0]) if (sdf['Model'] == FINAL).any() else None

# Symmetric-ish limits around zero, with room for labels.
all_delta = np.concatenate([np.asarray(v, dtype=float) for v in delta_i.values()])
dmin = float(np.min(all_delta))
dmax = float(np.max(all_delta))
left = min(-0.066, dmin - 0.010)
right = max(0.012, dmax + 0.007)

_draw_delta_lollipop(
    ax=ax,
    names=names_i,
    delta_by_metric=delta_i,
    title='i  Ablation performance change',
    xlim=(left, right),
    xticks=[-0.05, -0.04, -0.03, -0.02, -0.01, 0.00],
    highlight_index=hi_i,
    group_break=4,
    group_labels=[
        ('Constructive ablation', -0.72, left + 0.001),
        ('Deletion ablation', 4.48, left + 0.001)
    ],
    legend_loc='lower right'
)

fig.suptitle('Comprehensive validation of RF-stabilized Hydro-ConTex GNNWRL', fontsize=24.8, fontweight='bold', y=0.988)

png = out_dir / 'Figure_Model_Validation_3x3_v40_BigValueLabels.png'
pdf = out_dir / 'Figure_Model_Validation_3x3_v40_BigValueLabels.pdf'
tif = out_dir / 'Figure_Model_Validation_3x3_v40_BigValueLabels.tif'
fig.savefig(png, dpi=450, bbox_inches='tight')
fig.savefig(pdf, dpi=450, bbox_inches='tight')
fig.savefig(tif, dpi=450, bbox_inches='tight')
print(png); print(pdf); print(tif)
