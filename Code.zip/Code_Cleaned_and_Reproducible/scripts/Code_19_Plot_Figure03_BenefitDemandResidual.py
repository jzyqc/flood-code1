
import os, shutil, zipfile, warnings
warnings.filterwarnings("ignore")
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import gridspec
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
from matplotlib.colors import LinearSegmentedColormap, to_rgba
import matplotlib.patheffects as pe

BASE = "/mnt/data/Figure2_v28_data_used"
OUT = "/mnt/data/figure2_realdata_code_v34"
os.makedirs(OUT, exist_ok=True)

plt.rcParams.update({
    "font.family": "serif",
    "font.serif": ["Times New Roman", "DejaVu Serif"],
    "axes.unicode_minus": False,
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
})

hexdf = pd.read_csv(os.path.join(BASE, "hex_plotting_data_scale_3000m.csv"))
ineq = pd.read_csv(os.path.join(BASE, "07_v50_s0_s7_target_inequality_change.csv"))
quint = pd.read_csv(os.path.join(BASE, "08_v50_demand_quintile_benefit_distribution.csv"))
lorenz = pd.read_csv(os.path.join(BASE, "02_lorenz_curve_points.csv"))
odds = pd.read_csv(os.path.join(BASE, "09_v50_residual_disadvantage_odds_ratios.csv"))
typology = pd.read_csv(os.path.join(BASE, "04_s7_city_equity_typology.csv"))

CMAP = plt.cm.RdYlBu_r
NAVY = "#17324f"
SPINE = "#22384d"
GRID = "#d9e3ef"
RED = "#b7191c"
BLUE = "#0b4fa2"

city_order = ["Beijing", "Shanghai", "Guangzhou", "Shenzhen", "Tianjin", "Chengdu"]
city_abbr = {"Beijing":"BJ", "Shanghai":"SH", "Guangzhou":"GZ", "Shenzhen":"SZ", "Tianjin":"TJ", "Chengdu":"CD"}
city_colors = {c: CMAP(v) for c, v in zip(city_order, np.linspace(0.10, 0.92, len(city_order)))}
scenario_order = [f"S{i}" for i in range(8)]
scenario_colors = {s: CMAP(v) for s, v in zip(scenario_order, np.linspace(0.06, 0.94, 8))}
q_order = [f"Q{i}" for i in range(1,6)]
q_colors = [CMAP(v) for v in [0.12, 0.30, 0.50, 0.70, 0.88]]

bg_blue = LinearSegmentedColormap.from_list("bg_blue", ["#dbe8f6", "#ffffff"])
bg_div = LinearSegmentedColormap.from_list("bg_div", ["#d7e8fb", "#ffffff", "#fde7df"])

def style(ax, grid_axis="y", fullbox=False, lw=1.22, tick=8.6):
    if fullbox:
        for s in ax.spines.values():
            s.set_visible(True)
            s.set_linewidth(lw)
            s.set_color(SPINE)
    else:
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)
        for s in ["left","bottom"]:
            ax.spines[s].set_linewidth(lw)
            ax.spines[s].set_color(SPINE)
    ax.tick_params(labelsize=tick, width=1.05, length=3.4, color=SPINE, pad=1.8)
    if grid_axis == "both":
        ax.grid(True, color=GRID, lw=0.60, alpha=0.92)
    else:
        ax.grid(axis=grid_axis, color=GRID, lw=0.60, alpha=0.92)
    ax.set_axisbelow(True)

def tag(ax, s):
    ax.text(-0.08, 1.028, s, transform=ax.transAxes, fontsize=11.1, fontweight="bold", ha="left", va="bottom")

def add_grad(ax, xmin, xmax, ymin, ymax, cmap, alpha=0.42, horizontal=True, z=0):
    arr = np.linspace(0,1,512)
    img = np.vstack([arr,arr]) if horizontal else np.vstack([arr,arr]).T
    ax.imshow(img, extent=[xmin,xmax,ymin,ymax], origin="lower", cmap=cmap, alpha=alpha, aspect="auto", zorder=z)

def violin_box_scatter(ax, data, colors, positions=None, width=0.75, seed=1, dot_size=6.5):
    rng = np.random.default_rng(seed)
    if positions is None:
        positions = np.arange(1, len(data)+1)
    data = [np.asarray(d, dtype=float)[np.isfinite(d)] for d in data]
    data = [d if len(d) else np.array([np.nan]) for d in data]
    parts = ax.violinplot(data, positions=positions, widths=width, showmeans=False, showextrema=False)
    for body, c in zip(parts["bodies"], colors):
        body.set_facecolor(to_rgba(c, 0.30))
        body.set_edgecolor(c)
        body.set_linewidth(1.45)
        body.set_zorder(1)
    bp = ax.boxplot(data, positions=positions, widths=width*0.26, patch_artist=True, showfliers=False,
                    medianprops=dict(color="#111", linewidth=1.28),
                    whiskerprops=dict(color="#3c4655", linewidth=1.05),
                    capprops=dict(color="#3c4655", linewidth=1.05),
                    boxprops=dict(edgecolor=SPINE, linewidth=1.05))
    for patch, c in zip(bp["boxes"], colors):
        patch.set_facecolor(to_rgba(c, 0.78))
        patch.set_edgecolor(SPINE)
        patch.set_zorder(3)
    for x, vals, c in zip(positions, data, colors):
        vals = vals[np.isfinite(vals)]
        if len(vals) > 120:
            vals = rng.choice(vals, 120, replace=False)
        if len(vals):
            ax.scatter(rng.normal(x, 0.027, len(vals)), vals, s=dot_size+0.8,
                       color=to_rgba(c, 0.40), edgecolor="white", linewidth=0.18, zorder=2)

def safe_sample(g, n=650, seed=42):
    return g.sample(n, random_state=seed) if len(g) > n else g

def slog(x):
    return np.sign(x) * np.log10(1 + np.abs(x))

# sampled hex data
dist_inds = [
    "DemandComposite","BenefitTotal","ACRComposite","ResidualDemandComposite","MismatchComposite","UnmetHighDemand",
    "BenefitLive","BenefitFunction","RiskReductionSupply",
    "ACRPopulation","ACREconomic","ACRBuilt","ACRRiskOnly",
    "PopExposureWeightedRiskReduction","EconExposureWeightedRiskReduction","BuiltExposureWeightedRiskReduction","CompositeExposureWeightedRiskReduction",
    "BenefitDeviationClass"
]
parts=[]
for ind in dist_inds:
    tmp=hexdf[(hexdf["Indicator"]==ind) & (hexdf["Scenario"].isin(scenario_order))]
    for _,g in tmp.groupby(["City","Scenario"]):
        parts.append(safe_sample(g, 500, 42))
hexs=pd.concat(parts, ignore_index=True)

fig = plt.figure(figsize=(20.4, 14.8), facecolor="white")
gs = fig.add_gridspec(24, 24, left=0.045, right=0.985, top=0.905, bottom=0.075, wspace=1.08, hspace=1.28)
fig.suptitle("Figure 2 | Storyline diagnostics of spatial adaptation inequality",
             fontsize=23.2, fontweight="bold", color=NAVY, y=0.988)

# Top legend strip
handles = [Patch(facecolor=to_rgba(c,0.35), edgecolor="none", label=f"Q{i+1}") for i,c in enumerate(q_colors)]
handles += [
    Line2D([0],[0], color=RED, lw=3.0, marker="o", ms=5, label="Cross-city mean"),
    Line2D([0],[0], color="#777", lw=1.1, label="City curve"),
    Line2D([0],[0], color="#103f73", lw=6, alpha=0.45, label="Interval / IQR"),
    Line2D([0],[0], marker="D", color="w", markerfacecolor=BLUE, markeredgecolor="#08336f", ms=7, label="Mean"),
]
handles += [Line2D([0],[0], marker="o", color="w", markerfacecolor=scenario_colors[s], ms=5, label=s) for s in scenario_order]
fig.legend(handles=handles, loc="upper left", bbox_to_anchor=(0.02,0.955), ncol=18, frameon=False,
           fontsize=9.2, handlelength=1.50, columnspacing=0.80)

# ---------------- A: Top-left distribution block ----------------
gs_top = gridspec.GridSpecFromSubplotSpec(2,3, subplot_spec=gs[0:6,0:10], wspace=0.24, hspace=0.38)
top_info = [
    ("DemandComposite","Demand"),("BenefitTotal","Benefit"),("ACRComposite","ACR"),
    ("ResidualDemandComposite","Residual"),("MismatchComposite","Mismatch"),("UnmetHighDemand","Unmet")
]
for i,(ind,ttl) in enumerate(top_info):
    ax=fig.add_subplot(gs_top[i//3,i%3])
    tmp=hexs[(hexs["Indicator"]==ind) & (hexs["Scenario"]=="S7")]
    data=[tmp[tmp["City"]==c]["Mean"].values for c in city_order]
    vals=np.concatenate([d for d in data if len(d)])
    lo,hi=np.nanpercentile(vals,[1,99]); span=max(hi-lo,1e-6)
    ax.set_ylim(min(0,lo-0.06*span),hi+0.16*span)
    add_grad(ax,0.45,6.55,ax.get_ylim()[0],ax.get_ylim()[1],bg_blue,alpha=0.30,horizontal=False)
    for xv in np.arange(1.5,6.0,1):
        ax.axvline(xv,color=to_rgba("#7e9bbb",0.14),lw=0.65,zorder=0)
    violin_box_scatter(ax,data,[city_colors[c] for c in city_order],np.arange(1,7),width=0.75,seed=100+i)
    ax.set_xticks(np.arange(1,7)); ax.set_xticklabels([city_abbr[c] for c in city_order], fontsize=7.8, fontweight="bold")
    style(ax, fullbox=True, tick=7.6)
    tag(ax,chr(ord("a")+i))
    ax.set_title(ttl, fontsize=11.0, fontweight="bold", loc="left", pad=2.2)
    if i%3==0:
        ax.set_ylabel("Hex value",fontsize=8.8,fontweight="bold")
    m=tmp.groupby("City")["Mean"].mean().mean()
    ax.text(0.97,0.92,f"mean={m:.2f}",transform=ax.transAxes,ha="right",va="top",fontsize=7.8,color="#8f1515",fontweight="bold")

# ---------------- B: Top-middle supplementary data modules ----------------
gs_sup = gridspec.GridSpecFromSubplotSpec(2,2, subplot_spec=gs[0:6,10:17], wspace=0.35, hspace=0.48)

# Benefit components
ax=fig.add_subplot(gs_sup[0,0])
benefit_inds=[("BenefitLive","Live"),("BenefitFunction","Func."),("RiskReductionSupply","Risk-red."),("BenefitTotal","Total")]
data=[hexs[(hexs["Indicator"]==ind)&(hexs["Scenario"]=="S7")]["Mean"].values for ind,_ in benefit_inds]
colors=[CMAP(v) for v in [0.20,0.42,0.62,0.86]]
vals=np.concatenate([d for d in data if len(d)])
lo,hi=np.nanpercentile(vals,[1,99]); span=max(hi-lo,1e-6)
ax.set_ylim(min(0,lo-0.06*span),hi+0.16*span)
add_grad(ax,0.4,len(data)+0.6,ax.get_ylim()[0],ax.get_ylim()[1],bg_blue,alpha=0.28,horizontal=False)
violin_box_scatter(ax,data,colors,np.arange(1,len(data)+1),width=0.68,seed=701,dot_size=5.7)
ax.set_xticks(np.arange(1,len(data)+1)); ax.set_xticklabels([lab for _,lab in benefit_inds],rotation=18,ha="right",fontsize=7.1)
style(ax,fullbox=True,tick=7.4); tag(ax,"g")
ax.set_title("Benefit components",fontsize=10.3,fontweight="bold",loc="left",pad=2.0)
ax.set_ylabel("Hex value",fontsize=8.3,fontweight="bold")

# ACR profile
ax=fig.add_subplot(gs_sup[0,1])
acr_inds=[("ACRPopulation","Pop"),("ACREconomic","Econ"),("ACRBuilt","Built"),("ACRRiskOnly","Risk"),("ACRComposite","Comp.")]
data=[hexs[(hexs["Indicator"]==ind)&(hexs["Scenario"]=="S7")]["Mean"].values for ind,_ in acr_inds]
colors=[CMAP(v) for v in np.linspace(0.12,0.88,len(acr_inds))]
vals=np.concatenate([d for d in data if len(d)])
lo,hi=np.nanpercentile(vals,[1,99]); span=max(hi-lo,1e-6)
ax.set_ylim(max(0,lo-0.06*span),hi+0.16*span)
add_grad(ax,0.4,len(data)+0.6,ax.get_ylim()[0],ax.get_ylim()[1],bg_blue,alpha=0.28,horizontal=False)
violin_box_scatter(ax,data,colors,np.arange(1,len(data)+1),width=0.66,seed=702,dot_size=5.7)
ax.set_xticks(np.arange(1,len(data)+1)); ax.set_xticklabels([lab for _,lab in acr_inds],rotation=18,ha="right",fontsize=7.1)
style(ax,fullbox=True,tick=7.4); tag(ax,"h")
ax.set_title("ACR profile",fontsize=10.3,fontweight="bold",loc="left",pad=2.0)
ax.set_ylabel("ACR",fontsize=8.3,fontweight="bold")

# City typology
ax=fig.add_subplot(gs_sup[1,0])
x=typology["DemandComposite"].values; y=typology["BenefitTotal"].values
size=260+2000*(typology["ResidualDemandComposite"].values-typology["ResidualDemandComposite"].min())/(typology["ResidualDemandComposite"].max()-typology["ResidualDemandComposite"].min()+1e-9)
c=typology["ACRComposite"].values
xpad=(x.max()-x.min())*0.18 if x.max()>x.min() else 0.1
ypad=(y.max()-y.min())*0.18 if y.max()>y.min() else 0.1
ax.set_xlim(x.min()-xpad,x.max()+xpad); ax.set_ylim(y.min()-ypad,y.max()+ypad)
add_grad(ax,*ax.get_xlim(),*ax.get_ylim(),bg_div,alpha=0.40,horizontal=True)
ax.axvline(np.median(x),color="#6f7b88",lw=0.9,ls="--"); ax.axhline(np.median(y),color="#6f7b88",lw=0.9,ls="--")
sc=ax.scatter(x,y,s=size,c=c,cmap=CMAP,edgecolor="white",linewidth=0.9,zorder=3)
for _,r in typology.iterrows():
    ax.text(r["DemandComposite"],r["BenefitTotal"],city_abbr[r["City"]],ha="center",va="center",fontsize=8.0,fontweight="bold",zorder=4)
style(ax,grid_axis="both",fullbox=True,tick=7.3); tag(ax,"i")
ax.set_title("City equity typology",fontsize=10.3,fontweight="bold",loc="left",pad=2.0)
ax.set_xlabel("Demand",fontsize=8.2,fontweight="bold"); ax.set_ylabel("Benefit",fontsize=8.2,fontweight="bold")

# Disadvantage gap
ax=fig.add_subplot(gs_sup[1,1])
outcomes={"ResidualHighRisk_F1_Top20":"High-risk","InsufficientBenefit_Total_Bottom20":"Low-benefit","ResidualDemand_Composite_Top20":"Residual"}
sub=odds[(odds["Scenario"]=="S7") & (odds["Group"].isin(["worse_off","average"]))].copy()
sub["Gap"]=sub["EventRate"]-sub["ReferenceEventRate"]
rows=[]
for out,lab in outcomes.items():
    for grp,glabel in [("worse_off","Worse-off"),("average","Average")]:
        g=sub[(sub["Outcome"]==out)&(sub["Group"]==grp)]
        vals=g["Gap"].values
        rows.append((lab,glabel,np.nanmean(vals),np.nanpercentile(vals,10),np.nanpercentile(vals,90)))
gap=pd.DataFrame(rows,columns=["Outcome","Group","Mean","P10","P90"])
ypos=np.arange(len(gap))[::-1]
lim=max(abs(gap["P10"]).max(),abs(gap["P90"]).max())*1.22
add_grad(ax,-lim,lim,-0.5,len(ypos)-0.5,bg_div,alpha=0.66,horizontal=True)
ax.axvline(0,color="#555",ls="--",lw=1.0)
for yi,(_,r) in zip(ypos,gap.iterrows()):
    col="#b7191c" if r["Group"]=="Worse-off" else "#1f5aa6"
    ax.hlines(yi,r["P10"],r["P90"],color=col,lw=2.7,alpha=0.50)
    ax.scatter(r["Mean"],yi,s=50,color=col,edgecolor="white",lw=0.75,zorder=3)
ax.set_yticks(ypos); ax.set_yticklabels([f"{r['Outcome']}\n{r['Group']}" for _,r in gap.iterrows()],fontsize=6.1)
ax.set_xlim(-lim,lim)
style(ax,grid_axis="x",fullbox=True,tick=7.3); tag(ax,"j")
ax.set_title("Disadvantage gap",fontsize=10.3,fontweight="bold",loc="left",pad=2.0)
ax.set_xlabel("Event-rate gap",fontsize=8.2,fontweight="bold")

# ---------------- C: Right scenario trajectories ----------------
gs_right=gridspec.GridSpecFromSubplotSpec(4,1, subplot_spec=gs[0:10,17:24], hspace=0.34)
right_titles=[("BenefitTotal","Benefit total"),("ACRComposite","Adaptive coverage"),("ResidualDemandComposite","Residual demand"),("MismatchComposite","Mismatch")]
for i,(ind,ttl) in enumerate(right_titles):
    ax=fig.add_subplot(gs_right[i,0])
    tmp=hexdf[hexdf["Indicator"]==ind]
    cm=tmp.groupby(["City","Scenario"])["Mean"].mean().reset_index()
    piv=cm.pivot(index="Scenario",columns="City",values="Mean").reindex(scenario_order)
    vals=piv.values.flatten(); vals=vals[np.isfinite(vals)]
    lo,hi=np.nanpercentile(vals,[1,99]); span=max(hi-lo,1e-6)
    ax.set_ylim(lo-0.16*span,hi+0.20*span)
    add_grad(ax,-0.2,7.2,ax.get_ylim()[0],ax.get_ylim()[1],bg_blue,alpha=0.35,horizontal=False)
    x=np.arange(8)
    for k,s in enumerate(scenario_order):
        ax.axvspan(k-0.5,k+0.5,color=to_rgba(scenario_colors[s],0.06),zorder=0)
    ax.fill_between(x,piv.min(axis=1).values,piv.max(axis=1).values,color=to_rgba("#79a6d7",0.10),zorder=1)
    ax.fill_between(x,piv.quantile(0.25,axis=1).values,piv.quantile(0.75,axis=1).values,color=to_rgba("#3c7bb6",0.16),zorder=2)
    for city in city_order:
        ax.plot(x,piv[city].values,color=to_rgba(city_colors[city],0.40),lw=1.0)
    meanline=piv.mean(axis=1)
    line,=ax.plot(x,meanline.values,color=RED,lw=3.1,marker="o",ms=4.7,mec="white",mew=0.9,zorder=4)
    line.set_path_effects([pe.Stroke(linewidth=4.5,foreground="white",alpha=0.82),pe.Normal()])
    d=meanline.iloc[-1]-meanline.iloc[0]
    pct=(d/meanline.iloc[0]*100) if meanline.iloc[0]!=0 else np.nan
    ax.text(0.98,0.86,f"Δ={d:+.3f}"+(f" ({pct:+.1f}%)" if np.isfinite(pct) else ""),transform=ax.transAxes,
            ha="right",va="top",fontsize=7.8,color="#8f1515",fontweight="bold")
    style(ax,fullbox=True,tick=7.6); tag(ax,chr(ord("k")+i))
    ax.set_title(ttl,fontsize=10.6,fontweight="bold",loc="left",pad=2.0)
    ax.set_xticks(x); ax.set_xticklabels(scenario_order if i==3 else [])
    if i==0: ax.set_ylabel("Mean",fontsize=8.8,fontweight="bold")

# ---------------- D: Middle Q block restored 3x5 ----------------
gs_q=gridspec.GridSpecFromSubplotSpec(3,5, subplot_spec=gs[6:15,0:17], wspace=0.14, hspace=0.22)
q_cols=[("Demand_Population","Population"),("Demand_Economic","Economic"),("Demand_Built","Built"),("Demand_Composite","Composite"),("Demand_RiskOnly","Risk-only")]
q_rows=[("ShareOfTotalBenefit","Benefit share (%)",100.0),("MeanACR","Mean ACR",1.0),("MeanResidualDemand","Residual demand",1.0)]
for col,(dind,dlab) in enumerate(q_cols):
    dat=quint[(quint["Scenario"]=="S7") & (quint["DemandIndicator"]==dind)]
    for row,(var,ylab,mult) in enumerate(q_rows):
        ax=fig.add_subplot(gs_q[row,col])
        piv=dat.pivot(index="DemandQuintile",columns="City",values=var).reindex(q_order)
        means=piv.mean(axis=1).values*mult
        data_groups=[piv.loc[q].dropna().values*mult for q in q_order]
        vals=np.r_[means,piv.values.flatten()*mult]; vals=vals[np.isfinite(vals)]
        lo,hi=(np.nanmin(vals),np.nanmax(vals)) if len(vals) else (0,1); span=max(hi-lo,1e-6)
        ymin=max(0 if row!=1 else lo-0.15*span,lo-0.10*span); ymax=hi+0.20*span
        ax.set_ylim(ymin,ymax)
        add_grad(ax,0.55,5.45,ymin,ymax,bg_blue,alpha=0.20,horizontal=False)
        x=np.arange(1,6)
        for xi,qc in zip(x,q_colors):
            ax.axvspan(xi-0.45,xi+0.45,color=to_rgba(qc,0.08),zorder=0)
        violin_box_scatter(ax,data_groups,q_colors,x,width=0.74,seed=830+row*10+col,dot_size=8.4)
        for city in city_order:
            y=piv[city].values*mult if city in piv.columns else np.full(5,np.nan)
            ax.plot(x,y,color=to_rgba(city_colors[city],0.42),lw=1.0,marker="o",ms=1.7,zorder=3)
        q10,q90=piv.quantile(0.10,axis=1).values*mult,piv.quantile(0.90,axis=1).values*mult
        q25,q75=piv.quantile(0.25,axis=1).values*mult,piv.quantile(0.75,axis=1).values*mult
        ax.fill_between(x,q10,q90,color=to_rgba(RED,0.08),zorder=3)
        ax.fill_between(x,q25,q75,color=to_rgba(RED,0.20),zorder=4)
        line,=ax.plot(x,means,color=RED,lw=3.35,marker="o",ms=5.2,mec="white",mew=0.9,zorder=5)
        line.set_path_effects([pe.Stroke(linewidth=5.0,foreground="white",alpha=0.90),pe.Normal()])
        style(ax,fullbox=True,tick=7.6)
        ax.set_xlim(0.6,5.4); ax.set_xticks(x); ax.set_xticklabels(q_order if row==2 else [])
        if row==0:
            if col==0: tag(ax,"o")
            ax.set_title(dlab,fontsize=10.6,fontweight="bold",loc="left",pad=2.0)
        if col==0: ax.set_ylabel(ylab,fontsize=8.9,fontweight="bold")
        if row==2: ax.set_xlabel("Demand quintile",fontsize=8.5,fontweight="bold")
        ax.text(0.97,0.90,f"Q5={means[-1]:.2f}",transform=ax.transAxes,ha="right",va="top",fontsize=7.8,color="#8f1515",fontweight="bold")

# ---------------- E: Middle-right extra unused-data modules ----------------
gs_extra=gridspec.GridSpecFromSubplotSpec(1,2, subplot_spec=gs[10:15,17:24], wspace=0.34, hspace=0.10)

# Exposure-weighted risk reduction
ax=fig.add_subplot(gs_extra[0,0])
exp_inds=[("PopExposureWeightedRiskReduction","Population"),("EconExposureWeightedRiskReduction","Economic"),("BuiltExposureWeightedRiskReduction","Built"),("CompositeExposureWeightedRiskReduction","Composite")]
x=np.arange(8)
add_grad(ax,-0.2,7.2,0,1,bg_blue,alpha=0.22,horizontal=False)
for ind,label in exp_inds:
    tmp=hexdf[hexdf["Indicator"]==ind]
    piv=tmp.groupby(["Scenario","City"])["Mean"].mean().reset_index().pivot(index="Scenario",columns="City",values="Mean").reindex(scenario_order)
    mean=piv.mean(axis=1).values*100
    q25=piv.quantile(0.25,axis=1).values*100
    q75=piv.quantile(0.75,axis=1).values*100
    col={"Population":CMAP(0.18),"Economic":CMAP(0.38),"Built":CMAP(0.62),"Composite":CMAP(0.86)}[label]
    ax.fill_between(x,q25,q75,color=to_rgba(col,0.14),zorder=1)
    ax.plot(x,mean,color=col,lw=2.15,marker="o",ms=3.6,mec="white",mew=0.6,label=label,zorder=3)
ax.set_xticks(x); ax.set_xticklabels(scenario_order)
ax.set_ylabel("%",fontsize=8.4,fontweight="bold")
style(ax,fullbox=True,grid_axis="both",tick=7.2)
tag(ax,"r")
ax.set_title("Exposure-weighted risk reduction",fontsize=10.0,fontweight="bold",loc="left",pad=2.0)
ax.legend(frameon=False,fontsize=6.9,ncol=2,loc="upper left",handlelength=1.35,columnspacing=0.7)

# Benefit deviation class composition
ax=fig.add_subplot(gs_extra[0,1])
bd=hexdf[(hexdf["Indicator"]=="BenefitDeviationClass") & (hexdf["Scenario"]=="S7")].copy()
bd["Class"]=pd.cut(bd["Mean"], bins=[-np.inf,-0.1,0.1,np.inf], labels=["Under","Balanced","Over"])
counts = bd.groupby(["City","Class"], observed=False).size().reset_index(name="count")
counts["pct"] = counts["count"] / counts.groupby("City")["count"].transform("sum") * 100
comp = counts[["City","Class","pct"]]
order=city_order
bottom=np.zeros(len(order))
class_colors={"Under":"#2b6cb0","Balanced":"#d9d9d9","Over":"#c92a2a"}
for cls in ["Under","Balanced","Over"]:
    vals=[comp[(comp["City"]==c)&(comp["Class"]==cls)]["pct"].sum() for c in order]
    ax.bar(np.arange(len(order)),vals,bottom=bottom,color=class_colors[cls],edgecolor="white",linewidth=0.6,label=cls)
    for xi,v,b in zip(np.arange(len(order)),vals,bottom):
        if v>9:
            ax.text(xi,b+v/2,f"{v:.0f}%",ha="center",va="center",fontsize=7.0,fontweight="bold",color="white" if cls!="Balanced" else "#333")
    bottom+=np.array(vals)
ax.set_ylim(0,100)
ax.set_xticks(np.arange(len(order))); ax.set_xticklabels([city_abbr[c] for c in order],fontweight="bold")
ax.set_ylabel("Composition (%)",fontsize=8.4,fontweight="bold")
style(ax,fullbox=True,grid_axis="y",tick=7.2)
tag(ax,"s")
ax.set_title("Benefit-deviation composition (S7)",fontsize=10.0,fontweight="bold",loc="left",pad=2.0)
ax.legend(frameon=False,fontsize=6.9,ncol=3,loc="upper center",bbox_to_anchor=(0.52,1.03),handlelength=0.9,columnspacing=0.55)

# ---------------- F: Bottom Lorenz curves ----------------
gs_lor=gridspec.GridSpecFromSubplotSpec(2,2, subplot_spec=gs[15:24,0:8], wspace=0.24, hspace=0.24)
lor_info=[("Raw_F1","Lorenz: raw F1"),("Benefit_Total","Lorenz: benefit"),("Demand_Composite","Lorenz: demand"),("ResidualDemand_Composite","Lorenz: residual")]
for i,(ind,ttl) in enumerate(lor_info):
    ax=fig.add_subplot(gs_lor[i//2,i%2])
    tmp=lorenz[(lorenz["Indicator"]==ind)&(lorenz["Scenario"].isin(scenario_order))]
    add_grad(ax,0,1,0,1,bg_blue,alpha=0.62,horizontal=False)
    ax.plot([0,1],[0,1],ls="--",lw=1.0,color="#555",dashes=(4,3))
    for s in scenario_order:
        g=tmp[tmp["Scenario"]==s].groupby("CellShare")["ValueShare"].mean().reset_index().sort_values("CellShare")
        ax.plot(g["CellShare"],g["ValueShare"],color=scenario_colors[s],lw=2.2 if s in ["S0","S7"] else 1.2,alpha=1.0 if s in ["S0","S7"] else 0.75,label=s)
    if i==0:
        leg=ax.legend(title="Scenario",frameon=True,fontsize=6.7,title_fontsize=6.9,loc="upper left",ncol=2,handlelength=1.2,columnspacing=0.45,borderpad=0.25,labelspacing=0.18)
        leg.get_frame().set_facecolor("white"); leg.get_frame().set_alpha(0.72); leg.get_frame().set_edgecolor("#b8c7d8")
    ax.set_xlim(0,1); ax.set_ylim(0,1)
    style(ax,grid_axis="both",fullbox=True,tick=7.4); tag(ax,chr(ord("t")+i))
    ax.set_title(ttl,fontsize=10.0,fontweight="bold",loc="left",pad=2.0)
    if i>=2: ax.set_xlabel("Cell share",fontsize=8.5,fontweight="bold")
    if i%2==0: ax.set_ylabel("Value share",fontsize=8.5,fontweight="bold")

# ---------------- G: Bottom forest diagnostics ----------------
gs_forest=gridspec.GridSpecFromSubplotSpec(1,3, subplot_spec=gs[15:24,8:24], wspace=0.18)
metric_map={"Gini":("Gini_RelativeChange_pct","Gini"),"Theil":("Theil_T_RelativeChange_pct","Theil"),"Atkinson":("Atkinson_1_0_RelativeChange_pct","Atkinson"),"Top20":("Top20_Share_RelativeChange_pct","Top20"),"P90/P10":("P90_P10_Ratio_RelativeChange_pct","P90/P10"),"Hoover":("Hoover_Index_RelativeChange_pct","Hoover")}
metric_order=["Gini","Theil","Atkinson","Top20","P90/P10","Hoover"]
for j,tgt in enumerate(["F1","F2","F3"]):
    ax=fig.add_subplot(gs_forest[0,j])
    sub=ineq[ineq["Target"]==tgt].copy()
    vals_all=[]
    for m in metric_order:
        vals_all.extend(sub[metric_map[m][0]].apply(slog).replace([np.inf,-np.inf],np.nan).dropna().tolist())
    lim=max(max(abs(np.nanmin(vals_all)),abs(np.nanmax(vals_all)))*1.25,0.12)
    add_grad(ax,-lim,lim,-0.5,len(metric_order)-0.5,bg_div,alpha=0.84,horizontal=True)
    ax.axvspan(-lim,-0.12*lim,color=to_rgba("#4a86cf",0.10),zorder=0)
    ax.axvspan(0.12*lim,lim,color=to_rgba("#cc4c39",0.10),zorder=0)
    ax.axvline(0,color="#555",ls="--",lw=1.0,dashes=(5,4),zorder=1)
    ys=np.arange(len(metric_order))[::-1]
    for yi,m in zip(ys,metric_order):
        col,lab=metric_map[m]
        vals=sub.set_index("City").loc[city_order][col].apply(slog)
        finite=vals[np.isfinite(vals)]
        mn,mx=finite.min(),finite.max(); q10,q90=finite.quantile(0.10),finite.quantile(0.90); q25,q75=finite.quantile(0.25),finite.quantile(0.75); meanv=finite.mean()
        ax.hlines(yi,mn,mx,color="#6b90b7",lw=2.0,zorder=2)
        ax.hlines(yi,q10,q90,color="#3f6996",lw=4.0,alpha=0.60,zorder=3)
        ax.hlines(yi,q25,q75,color="#103f73",lw=8.4,alpha=0.58,zorder=4)
        offs=np.linspace(-0.14,0.14,len(city_order))
        for off,city in zip(offs,city_order):
            v=vals.loc[city]
            if np.isfinite(v):
                ax.scatter(v,yi+off*0.70,s=42,color=city_colors[city],edgecolor="white",lw=0.5,zorder=5)
        ax.scatter(meanv,yi,marker="D",s=98,color=BLUE,edgecolor="#08336f",lw=0.95,zorder=6)
    ax.set_xlim(-lim,lim); ax.set_ylim(-0.5,len(metric_order)-0.5)
    ax.set_yticks(ys); ax.set_yticklabels([metric_map[m][1] for m in metric_order] if j==0 else [""]*len(metric_order),fontsize=8.0)
    style(ax,grid_axis="x",fullbox=True,tick=7.6); tag(ax,chr(ord("x")+j))
    ax.set_title({"F1":"F1 burden","F2":"F2 livability","F3":"F3 function"}[tgt],fontsize=10.8,fontweight="bold",pad=2.1)
    ax.set_xlabel("signed log10(1+% change)",fontsize=8.4,fontweight="bold")
    ax.text(0.04,0.96,"Worse",transform=ax.transAxes,ha="left",va="top",fontsize=7.1,color="#b7191c",fontweight="bold")
    ax.text(0.96,0.96,"Improved",transform=ax.transAxes,ha="right",va="top",fontsize=7.1,color="#1f5aa6",fontweight="bold")

# bottom legend
bottom_handles=[
    Line2D([0],[0],color=RED,lw=3.0,marker="o",ms=5,label="Cross-city mean"),
    Line2D([0],[0],color="#777",lw=1.1,label="City curve"),
    Line2D([0],[0],color="#103f73",lw=7,alpha=0.52,label="Forest IQR"),
    Line2D([0],[0],marker="D",color="w",markerfacecolor=BLUE,markeredgecolor="#08336f",ms=7,label="Forest mean"),
]
fig.legend(handles=bottom_handles,loc="lower center",ncol=4,frameon=False,fontsize=9.2,bbox_to_anchor=(0.50,0.012),handlelength=2.5)

# save
png=os.path.join(OUT,"Figure2_realdata_code_v34.png")
pdf=os.path.join(OUT,"Figure2_realdata_code_v34.pdf")
root_png="/mnt/data/Figure2_realdata_code_v34.png"
root_pdf="/mnt/data/Figure2_realdata_code_v34.pdf"
root_py="/mnt/data/make_figure2_realdata_code_v34.py"

fig.savefig(png,dpi=500,bbox_inches="tight",facecolor="white")
fig.savefig(pdf,dpi=300,bbox_inches="tight",facecolor="white")
plt.close(fig)

shutil.copy(__file__, os.path.join(OUT,"make_figure2_realdata_code_v34.py"))
shutil.copy(png,root_png); shutil.copy(pdf,root_pdf); shutil.copy(os.path.join(OUT,"make_figure2_realdata_code_v34.py"),root_py)

light="/mnt/data/Figure2_realdata_code_v34_light_package.zip"
full="/mnt/data/Figure2_realdata_code_v34_full_package.zip"
with zipfile.ZipFile(light,"w",zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in [root_png,root_pdf,root_py]:
        z.write(p,arcname=os.path.basename(p))
with zipfile.ZipFile(full,"w",zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in [root_png,root_pdf,root_py]:
        z.write(p,arcname=os.path.basename(p))
    for fn in ["hex_plotting_data_scale_3000m.csv","07_v50_s0_s7_target_inequality_change.csv","08_v50_demand_quintile_benefit_distribution.csv","02_lorenz_curve_points.csv","09_v50_residual_disadvantage_odds_ratios.csv","04_s7_city_equity_typology.csv"]:
        z.write(os.path.join(BASE,fn),arcname=os.path.join("data_used",fn))

print(root_png)
print(root_pdf)
print(root_py)
print(light)
print(full)
