# -*- coding: utf-8 -*-
"""
Portable template for the RF-stabilized Hydro-ConTex GNNWRL workflow.

Input requirement
-----------------
A row-level training table at source_data/model_training_samples.csv with:
    label, City, x, y,
    Rx1day, Rx5day, CWD, EV, SL, PRC, TWI, TPI, ST, NDVI, LULC,
    BD, PD, BH, BVI, CFI, FOE, GVI, Micro_ISA, Micro_PSA, SCE, SEL, SVF, TAE

This template gives a portable, path-clean version of the model workflow for
submission. The complete local production scripts are preserved under
legacy_reference_scripts/.
"""
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split, StratifiedKFold
from sklearn.metrics import roc_auc_score, average_precision_score, brier_score_loss
from sklearn.preprocessing import StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
import joblib

from config_project import MODEL_SAMPLE_TABLE, OUTPUT_DIR

RANDOM_STATE = 42
MODEL_VARS = [
    "Rx1day", "Rx5day", "CWD",
    "EV", "SL", "PRC", "TWI", "TPI",
    "ST", "NDVI", "LULC",
    "BD", "PD", "BH", "BVI",
    "CFI", "FOE", "GVI",
    "Micro_ISA", "Micro_PSA",
    "SCE", "SEL", "SVF", "TAE",
]
ZERO_FILL_VARS = ["BD", "PD", "BH", "BVI", "Micro_ISA", "Micro_PSA"]
MISSING_INDICATOR_BASE_VARS = ZERO_FILL_VARS

def add_missing_indicators(df):
    df = df.copy()
    for v in MISSING_INDICATOR_BASE_VARS:
        if v in df.columns:
            df[f"{v}_missing"] = df[v].isna().astype(int)
    for v in ZERO_FILL_VARS:
        if v in df.columns:
            df[v] = df[v].fillna(0)
    return df

def build_rf_anchor():
    return Pipeline([
        ("imputer", SimpleImputer(strategy="median")),
        ("scaler", StandardScaler()),
        ("rf", RandomForestClassifier(
            n_estimators=900,
            max_features="sqrt",
            min_samples_leaf=2,
            class_weight=None,
            random_state=RANDOM_STATE,
            n_jobs=-1,
        ))
    ])

def main():
    if not MODEL_SAMPLE_TABLE.exists():
        raise FileNotFoundError(
            f"Missing input table: {MODEL_SAMPLE_TABLE}. "
            "Place the prepared sample table in source_data/ or edit config_project.py."
        )
    df = pd.read_csv(MODEL_SAMPLE_TABLE)
    df = add_missing_indicators(df)
    feature_cols = [c for c in MODEL_VARS if c in df.columns] + [f"{v}_missing" for v in MISSING_INDICATOR_BASE_VARS if f"{v}_missing" in df.columns]
    X = df[feature_cols]
    y = df["label"].astype(int)

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.30, stratify=y, random_state=RANDOM_STATE
    )

    model = build_rf_anchor()
    model.fit(X_train, y_train)
    p = model.predict_proba(X_test)[:, 1]
    metrics = {
        "AUC": roc_auc_score(y_test, p),
        "PR_AUC": average_precision_score(y_test, p),
        "Brier": brier_score_loss(y_test, p),
    }
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    pd.DataFrame([metrics]).to_csv(OUTPUT_DIR / "model_holdout_metrics.csv", index=False)
    joblib.dump({"model": model, "feature_cols": feature_cols, "metrics": metrics}, OUTPUT_DIR / "rf_anchor_model.joblib")
    print(metrics)

if __name__ == "__main__":
    main()
