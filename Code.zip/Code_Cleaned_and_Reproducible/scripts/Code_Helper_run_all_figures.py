# -*- coding: utf-8 -*-
from plot_source_data_summaries import main as plot_summaries

if __name__ == "__main__":
    plot_summaries()
