
# -*- coding: utf-8 -*-
"""
Final polished SHAP mechanism figure v10
Main update from v9:
- axis tick labels enlarged strongly
- in-panel text enlarged strongly
- colorbar text enlarged
- panel titles and axis labels enlarged
"""

import os, zipfile, warnings
from pathlib import Path
warnings.filterwarnings("ignore")

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpec, GridSpecFromSubplotSpec
from matplotlib.ticker import MaxNLocator, FormatStrFormatter
from matplotlib.colors import Normalize
from matplotlib import colormaps
from matplotlib.patches import FancyBboxPatch
from scipy.interpolate import UnivariateSpline
from scipy import stats

ZIP_PATH = Path("/mnt/data/01_Point_RF_TreeSHAP.zip")
EXTRACT_ROOT = Path("/mnt/data/point_shap_final_polished_v10")
EXTRACT_ROOT.mkdir(parents=True, exist_ok=True)

with zipfile.ZipFile(ZIP_PATH, "r") as zf:
    zf.extractall(EXTRACT_ROOT)

BASE = EXTRACT_ROOT / "01_Point_RF_TreeSHAP"
sample = pd.read_csv(BASE / "Point_TreeSHAP_samples_raw.csv")
shap_df = pd.read_csv(BASE / "Point_TreeSHAP_values.csv")
global_imp = pd.read_csv(BASE / "TreeSHAP_top_variables_global.csv")

OUTDIR = Path("/mnt/data/SHAP_final_polished_v10")
OUTDIR.mkdir(parents=True, exist_ok=True)

CITY_ORDER = ["Beijing", "Chengdu", "Guangzhou", "Shanghai", "Shenzhen", "Tianjin"]
RESPONSE_VARS = ["Rx1day", "Rx5day", "EV", "TWI", "ST", "NDVI", "LULC", "BD", "SVF", "GVI", "Micro_PSA", "SCE"]
RESPONSE_VARS = [v for v in RESPONSE_VARS if v in sample.columns and v in shap_df.columns]
MAP_VARS = ["Rx1day", "Rx5day", "NDVI", "BD", "GVI", "Micro_PSA"]
INTERACTION_PLOTS = [("NDVI", "Micro_PSA"), ("NDVI", "SCE"), ("NDVI", "Rx1day")]
GROUP_MAP = {
    "Climate": ["Rx1day", "Rx5day"],
    "Terrain": ["EV", "TWI"],
    "Land cover": ["ST", "NDVI", "LULC"],
    "Built form": ["BD"],
    "Streetscape": ["SVF", "GVI", "Micro_PSA", "SCE"],
}
GROUP_ORDER = [g for g in ["Climate", "Terrain", "Land cover", "Built form", "Streetscape"] if any(v in shap_df.columns for v in GROUP_MAP[g])]

LABEL_MAP = {"Rx1day": "Rx1d", "Rx5day": "Rx5d", "Micro_PSA": "M.PSA", "Micro_ISA": "M.ISA"}
def disp(x): return LABEL_MAP.get(x, x)

CMAP = colormaps["RdYlBu_r"]
C_DARK="#13263B"; C_FRAME="#284A6A"; C_BG="#FFFFFF"; C_AX="#FCFCFB"; C_GRID="#D7DDE3"
C_LINE="#2267B5"; C_CI="#B9CFE6"; C_ZERO="#7C92AA"; C_THRESH="#B58A56"
C_POS="#F4E29A"; C_NEG="#BDD8E8"; C_PLACE_EDGE="#9AA8B5"

plt.rcParams.update({
    "font.family": "serif",
    "font.serif": ["Times New Roman", "Liberation Serif", "DejaVu Serif"],
    "font.size": 28,
    "font.weight": "bold",
    "axes.labelweight": "bold",
    "axes.titleweight": "bold",
    "axes.linewidth": 2.10,
    "figure.facecolor": C_BG,
    "axes.facecolor": C_AX,
    "savefig.facecolor": C_BG,
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
})

def clean_xy(x, y):
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    m = np.isfinite(x) & np.isfinite(y)
    return x[m], y[m]

def style_axes(ax, ticksize=19.5, gridx=False, gridy=False):
    for s in ax.spines.values():
        s.set_linewidth(1.70)
        s.set_color("#333333")
    ax.tick_params(axis="both", labelsize=ticksize, width=1.20, length=4.6, pad=2.8)
    if gridx:
        ax.grid(axis="x", color=C_GRID, linewidth=1.00, alpha=0.92)
    if gridy:
        ax.grid(axis="y", color=C_GRID, linewidth=1.00, alpha=0.92)
    for t in ax.get_xticklabels() + ax.get_yticklabels():
        t.set_fontweight("bold")
    ax.set_facecolor(C_AX)

def panel_title(ax, letter, title, fs=24.5):
    ax.set_title(f"({letter}) {title}", loc="left", fontsize=fs, fontweight="bold", color=C_DARK, pad=4.6)

def fmt_small(v):
    if not np.isfinite(v): return "NA"
    if v < 0.001: return f"{v:.1e}"
    if v < 0.01: return f"{v:.4f}"
    return f"{v:.3f}"

def fmt_p(p):
    if not np.isfinite(p): return "P = NA"
    if p < 0.001: return "P < 0.001"
    if p < 0.01: return "P < 0.01"
    return f"P = {p:.3f}"

def grouped_distributions():
    out=[]
    for g in GROUP_ORDER:
        cols=[v for v in GROUP_MAP[g] if v in shap_df.columns]
        vals=shap_df[cols].abs().mean(axis=1).to_numpy(dtype=float)
        vals=vals[np.isfinite(vals)]
        vals=vals[vals <= np.nanpercentile(vals, 99)]
        out.append((g, vals, float(np.nanmedian(vals))))
    return out

def top_variable_distributions(topn=8):
    top_vars = global_imp.sort_values("mean_abs_SHAP", ascending=False)["Variable"].tolist()
    top_vars = [v for v in top_vars if v in shap_df.columns][:topn]
    out=[]
    for v in top_vars:
        vals=np.abs(shap_df[v].to_numpy(dtype=float))
        vals=vals[np.isfinite(vals)]
        vals=vals[vals <= np.nanpercentile(vals, 99)]
        out.append((disp(v), vals, float(np.nanmedian(vals))))
    return out

def interaction_pairs(topn=8):
    vars_used=[v for v in global_imp.sort_values("mean_abs_SHAP", ascending=False)["Variable"].tolist() if v in shap_df.columns][:12]
    out=[]
    for i, vi in enumerate(vars_used):
        xi=shap_df[vi].values.astype(float)
        for j in range(i+1, len(vars_used)):
            vj=vars_used[j]
            xj=shap_df[vj].values.astype(float)
            m=np.isfinite(xi) & np.isfinite(xj)
            if m.sum():
                out.append((vi, vj, float(np.nanmean(np.abs(xi[m]*xj[m])))))
    return sorted(out, key=lambda t: -t[2])[:topn]

def interaction_distributions(topn=6):
    out=[]
    for a,b,score in interaction_pairs(topn=topn):
        xa=shap_df[a].values.astype(float)
        xb=shap_df[b].values.astype(float)
        m=np.isfinite(xa) & np.isfinite(xb)
        vals=np.abs(xa[m]*xb[m])
        vals=vals[vals <= np.nanpercentile(vals, 99)] if len(vals) else vals
        out.append((f"{disp(a)} × {disp(b)}", vals, score))
    return out

def plot_horizontal_boxpanel(ax, dist, letter, title, xlabel, fs=22.5, ylab_size=16.0):
    labels=[d[0] for d in dist]
    values=[d[1] for d in dist]
    colors=[CMAP(v) for v in np.linspace(0.10, 0.90, len(values))]
    pos=np.arange(len(values),0,-1)
    bp=ax.boxplot(values, vert=False, positions=pos, patch_artist=True, widths=0.58, showfliers=False,
                  medianprops=dict(color=C_DARK, linewidth=2.20),
                  whiskerprops=dict(color="#555555", linewidth=1.46),
                  capprops=dict(color="#555555", linewidth=1.46),
                  boxprops=dict(linewidth=1.46, color="#555555"))
    for patch,c in zip(bp["boxes"], colors):
        patch.set_facecolor(c); patch.set_alpha(0.84)
    rng=np.random.default_rng(17)
    for i, vals in enumerate(values):
        plot_vals = vals if len(vals) <= 210 else rng.choice(vals, 210, replace=False)
        yj=rng.normal(pos[i], 0.048, size=len(plot_vals))
        ax.scatter(plot_vals, yj, s=9.0, color=colors[i], alpha=0.18, edgecolors="none", zorder=1)
        ax.text(np.nanpercentile(vals, 82), pos[i]+0.20, fmt_small(np.nanmedian(vals)),
                ha="left", va="center", fontsize=17.0, fontweight="bold", color=C_DARK,
                bbox=dict(boxstyle="round,pad=0.16", facecolor="white", edgecolor="none", alpha=0.90))
    panel_title(ax, letter, title, fs=fs)
    ax.set_yticks(pos)
    ax.set_yticklabels(labels, fontsize=ylab_size, fontweight="bold")
    ax.set_xlabel(xlabel, fontsize=19.0, fontweight="bold", labelpad=0.8)
    style_axes(ax, ticksize=16.5, gridx=True)
    ax.xaxis.set_major_locator(MaxNLocator(nbins=4))
    ax.xaxis.set_major_formatter(FormatStrFormatter("%.3f"))
    ax.set_ylim(0.45, len(values)+0.55)
    ax.margins(x=0.10)

def plot_interaction_panel(ax, xvar, cvar, letter):
    x=sample[xvar].values; y=shap_df[xvar].values; c=sample[cvar].values
    m=np.isfinite(x) & np.isfinite(y) & np.isfinite(c)
    x,y,c=x[m],y[m],c[m]
    rng=np.random.default_rng(2027+len(cvar))
    idx=np.arange(len(x))
    if len(idx)>1000:
        idx=rng.choice(idx,1000,replace=False)
    norm=Normalize(vmin=np.nanpercentile(c,1), vmax=np.nanpercentile(c,99))
    sc=ax.scatter(x[idx], y[idx], c=c[idx], cmap=CMAP, norm=norm, s=9.8, alpha=0.88, edgecolors="none", rasterized=True)
    ax.axhline(0, color=C_ZERO, ls="--", lw=1.10)
    try:
        rho=stats.spearmanr(x,y).correlation
    except Exception:
        rho=np.nan
    panel_title(ax, letter, f"{disp(xvar)} × {disp(cvar)}", fs=23.0)
    if np.isfinite(rho):
        ax.text(0.03,0.96, rf"$\rho$ = {rho:.2f}", transform=ax.transAxes, ha="left", va="top",
                fontsize=18.0, fontweight="bold", color="#333333")
    ax.set_xlabel(disp(xvar), fontsize=18.5, fontweight="bold", labelpad=0.5)
    ax.set_ylabel("SHAP" if letter=="d" else "", fontsize=18.5, fontweight="bold")
    ax.xaxis.set_major_locator(MaxNLocator(nbins=4)); ax.yaxis.set_major_locator(MaxNLocator(nbins=4))
    ax.xaxis.set_major_formatter(FormatStrFormatter("%.2f")); ax.yaxis.set_major_formatter(FormatStrFormatter("%.2f"))
    style_axes(ax, ticksize=16.8)
    cb=plt.colorbar(sc, ax=ax, fraction=0.044, pad=0.016, shrink=0.84)
    cb.ax.tick_params(labelsize=14.6, width=0.88, length=2.3)
    cb.outline.set_linewidth(0.80)
    cb.set_label(disp(cvar), fontsize=15.6, fontweight="bold")

def fit_dependence_curve(x, y):
    x,y=clean_xy(x,y)
    order=np.argsort(x); x,y=x[order],y[order]
    if len(x)<35: return None
    unique_x, inv = np.unique(x, return_inverse=True)
    y_mean=np.array([np.mean(y[inv==i]) for i in range(len(unique_x))])
    if len(unique_x)<6:
        xx=np.linspace(unique_x.min(), unique_x.max(), 220)
        yy=np.interp(xx, unique_x, y_mean)
        se=np.array([stats.sem(y[inv==i]) if np.sum(inv==i)>1 else np.nanstd(y)*0.1 for i in range(len(unique_x))])
        se=np.nan_to_num(se, nan=np.nanmedian(se[np.isfinite(se)]) if np.isfinite(se).any() else np.nanstd(y)*0.1)
        se_i=np.interp(xx, unique_x, se)
        ci1,ci2=yy-1.96*se_i, yy+1.96*se_i
        pred=np.interp(x, unique_x, y_mean)
        denom=np.sum((y-np.mean(y))**2)
        r2=1-np.sum((y-pred)**2)/denom if denom>0 else np.nan
        try:
            groups=[y[inv==i] for i in range(len(unique_x)) if np.sum(inv==i)>1]
            pval=stats.kruskal(*groups).pvalue if len(groups)>1 else np.nan
        except Exception:
            pval=np.nan
        return xx,yy,ci1,ci2,r2,pval
    s_factor=max(len(unique_x)*np.var(y_mean)*0.65, 1e-10)
    try:
        spl=UnivariateSpline(unique_x, y_mean, s=s_factor, k=3)
    except Exception:
        spl=UnivariateSpline(unique_x, y_mean, s=s_factor, k=min(2, len(unique_x)-1))
    xx=np.linspace(unique_x.min(), unique_x.max(), 260)
    yy=spl(xx)
    pred=np.interp(x, xx, yy)
    resid=y-pred
    se=np.nanstd(resid)*0.55
    ci1,ci2=yy-1.96*se, yy+1.96*se
    denom=np.sum((y-np.mean(y))**2)
    r2=1-np.sum((y-pred)**2)/denom if denom>0 else np.nan
    try:
        pval=stats.spearmanr(x,y).pvalue
    except Exception:
        pval=np.nan
    return xx,yy,ci1,ci2,r2,pval

def auto_threshold(xx,yy):
    for i in range(1,len(xx)):
        if yy[i-1]*yy[i] < 0:
            return float(xx[i-1] + (0-yy[i-1])*(xx[i]-xx[i-1])/(yy[i]-yy[i-1]))
    slope=np.gradient(yy,xx)
    edge=max(3,int(0.08*len(xx)))
    valid=np.arange(edge, len(xx)-edge)
    return float(xx[valid[np.argmax(np.abs(slope[valid]))]]) if len(valid) else float(xx[np.argmax(np.abs(slope))])

def plot_dependence_panel(ax, var, letter):
    fit=fit_dependence_curve(sample[var].values, shap_df[var].values)
    x,y=clean_xy(sample[var].values, shap_df[var].values)
    if fit is None:
        ax.text(0.5,0.5,"Insufficient data",ha="center",va="center",fontsize=18.0,fontweight="bold")
        style_axes(ax, ticksize=16.5)
        return None
    xx,yy,ci1,ci2,r2,pval=fit
    thr=auto_threshold(xx,yy)
    rng=np.random.default_rng(2030+len(var))
    idx=np.arange(len(x))
    if len(idx)>1600:
        idx=rng.choice(idx,1600,replace=False)
    norm=Normalize(vmin=np.nanpercentile(x,1), vmax=np.nanpercentile(x,99))
    ax.scatter(x[idx], y[idx], c=x[idx], cmap=CMAP, norm=norm, s=7.6, alpha=0.28, edgecolors="none", rasterized=True)
    ax.fill_between(xx,0,yy,where=yy>=0,color=C_POS,alpha=0.37,interpolate=True)
    ax.fill_between(xx,0,yy,where=yy<0,color=C_NEG,alpha=0.37,interpolate=True)
    ax.fill_between(xx,ci1,ci2,color=C_CI,alpha=0.42,edgecolor="none")
    ax.plot(xx,yy,color=C_LINE,lw=2.60)
    ax.axhline(0,color=C_ZERO,ls="--",lw=1.12)
    ax.axvline(thr,color=C_THRESH,ls="--",lw=1.18)
    ax.text(0.03,0.96,rf"$R^2$ = {max(r2,0)*100:.1f}%",transform=ax.transAxes,
            ha="left",va="top",fontsize=22.0,fontweight="bold",color="#333333")
    ax.text(0.97,0.96,fmt_p(pval),transform=ax.transAxes,
            ha="right",va="top",fontsize=22.0,fontweight="bold",color="#333333")
    ax.text(0.97,0.08,f"N={len(x):,}",transform=ax.transAxes,
            ha="right",va="bottom",fontsize=18.0,fontweight="bold",color="#586574")
    x0,x1=ax.get_xlim()
    dx=0.018*(x1-x0)
    if thr > x0 + 0.72*(x1-x0):
        x_text,ha=thr-dx,"right"
    else:
        x_text,ha=thr+dx,"left"
    ax.text(x_text,0.72,f"{thr:.2f}",transform=ax.get_xaxis_transform(),
            ha=ha,va="center",fontsize=21.0,fontweight="bold",color="#4A4038",
            bbox=dict(boxstyle="round,pad=0.22", facecolor="#F6F0E8", edgecolor="#BCA68E", linewidth=0.90, alpha=0.97))
    ax.set_xlabel(f"({letter})  {disp(var)}", fontsize=19.2, fontweight="bold", labelpad=0.4)
    ax.set_ylabel("SHAP value" if letter in ["g","m"] else "", fontsize=19.2, fontweight="bold")
    ax.xaxis.set_major_locator(MaxNLocator(nbins=4)); ax.yaxis.set_major_locator(MaxNLocator(nbins=4))
    ax.xaxis.set_major_formatter(FormatStrFormatter("%.2f")); ax.yaxis.set_major_formatter(FormatStrFormatter("%.2f"))
    style_axes(ax, ticksize=17.0)
    return {"Variable": var, "Threshold": thr, "R2": r2, "P": pval, "N": len(x)}

fig=plt.figure(figsize=(25.4,18.9),dpi=220)
outer=GridSpec(5,12,figure=fig,height_ratios=[0.90,1.02,1.02,1.10,1.10],hspace=0.34,wspace=0.52)

ax=fig.add_subplot(outer[0,0:2]); plot_horizontal_boxpanel(ax, grouped_distributions(), "a", "Group |SHAP|", "grouped |SHAP|", fs=22.0, ylab_size=16.5)
ax=fig.add_subplot(outer[0,2:4]); plot_horizontal_boxpanel(ax, top_variable_distributions(topn=8), "b", "Top-variable |SHAP|", "|SHAP|", fs=22.0, ylab_size=15.2)
ax=fig.add_subplot(outer[0,4:6]); plot_horizontal_boxpanel(ax, interaction_distributions(topn=6), "c", "Interaction |SHAP|", "|pairwise SHAP|", fs=21.6, ylab_size=14.0)

for idx,(xv,cv) in enumerate(INTERACTION_PLOTS):
    ax=fig.add_subplot(outer[0,6+2*idx:8+2*idx])
    plot_interaction_panel(ax, xv, cv, ["d","e","f"][idx])

letters=list("ghijklmnopqr")
summary_rows=[]
for i,var in enumerate(RESPONSE_VARS):
    r=1+i//6; c=(i%6)*2
    ax=fig.add_subplot(outer[r,c:c+2])
    res=plot_dependence_panel(ax, var, letters[i])
    if res: summary_rows.append(res)

map_outer=GridSpecFromSubplotSpec(7,7,subplot_spec=outer[3:5,:],width_ratios=[0.23,1,1,1,1,1,1],
                                  height_ratios=[0.20,1,1,1,1,1,1],wspace=0.048,hspace=0.058)
ax_t=fig.add_subplot(map_outer[0,:]); ax_t.axis("off")
ax_t.text(0.002,0.88,"(s) Reserved GIS map matrix",fontsize=22.0,fontweight="bold",color=C_DARK,ha="left",va="top")
ax_t.text(0.002,0.12,"Blank slots kept for city-level attribution maps: six variables × six cities.",
          fontsize=15.0,fontweight="bold",color="#6B7580",ha="left",va="bottom")

for j,city in enumerate(CITY_ORDER):
    axh=fig.add_subplot(map_outer[1,j+1]); axh.axis("off")
    axh.text(0.5,1.08,city,ha="center",va="bottom",fontsize=15.6,fontweight="bold",color=C_DARK)

for i,var in enumerate(MAP_VARS):
    axr=fig.add_subplot(map_outer[i+1,0]); axr.axis("off")
    axr.text(0.98,0.5,disp(var),rotation=90,ha="right",va="center",fontsize=14.8,fontweight="bold",color=C_FRAME)
    for j,city in enumerate(CITY_ORDER):
        axm=fig.add_subplot(map_outer[i+1,j+1])
        axm.set_xticks([]); axm.set_yticks([]); axm.set_xlim(0,1); axm.set_ylim(0,1); axm.set_facecolor("#FCFCFB")
        for s in axm.spines.values(): s.set_visible(False)
        box=FancyBboxPatch((0.02,0.02),0.96,0.96,boxstyle="round,pad=0.01,rounding_size=0.014",
                           linewidth=1.0,linestyle="--",edgecolor=C_PLACE_EDGE,facecolor="#FBFBFA")
        axm.add_patch(box)
        axm.text(0.5,0.54,"GIS map slot",ha="center",va="center",fontsize=10.5,fontweight="bold",color="#9CA7B2")
        axm.text(0.5,0.33,f"{disp(var)} • {city}",ha="center",va="center",fontsize=8.8,fontweight="bold",color="#A7AFB8")

fig.subplots_adjust(left=0.025, right=0.996, top=0.990, bottom=0.018)

png_path=OUTDIR/"Figure_SHAP_final_polished_v10_doubleText.png"
pdf_path=OUTDIR/"Figure_SHAP_final_polished_v10_doubleText.pdf"
csv_path=OUTDIR/"Figure_SHAP_final_polished_v10_doubleText_thresholds.csv"
fig.savefig(png_path, dpi=300, bbox_inches="tight")
fig.savefig(pdf_path, dpi=260, bbox_inches="tight")
pd.DataFrame(summary_rows).to_csv(csv_path, index=False, encoding="utf-8-sig")
