# -*- coding: utf-8 -*-
"""
Historical grid flood prediction using the final RF-stabilized Hydro-ConTex GNNWRL model

用途
----
1. 只使用已经训练好的最终模型，不重新训练、不重新验证；
2. 对六个城市的历史栅格变量进行 Flood probability 预测；
3. 每个城市只输出一个历史 P_flood GeoTIFF，范围可按城市边界 shp 统一；
4. 在 Jupyter 中直接绘制六城市 2×3 对比图。

注意
----
- 运行前请确认 MODEL_DIR 中存在：
  1) Final_RF_Stabilized_HydroConTex_GNNWRL_package.joblib
  2) Final_GNNWRL_state_dict.pt
- 输出会保存到每个城市数据文件夹下：
  Historical_Flood_Prediction/<City>_Historical_P_flood.tif
"""

import os
import glob
import math
import random
import warnings
from pathlib import Path

warnings.filterwarnings("ignore")

import numpy as np
import pandas as pd
import joblib

import rasterio
from rasterio.warp import reproject, Resampling
from rasterio.transform import from_origin
from rasterio.features import geometry_mask
from rasterio.transform import xy as raster_xy

import geopandas as gpd

import matplotlib.pyplot as plt
from matplotlib.colors import Normalize

try:
    from scipy import ndimage
except Exception:
    ndimage = None

from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import NearestNeighbors

import torch
import torch.nn as nn
import torch.nn.functional as F


# =========================================================
# 0. 用户路径配置
# =========================================================

RANDOM_STATE = 42
np.random.seed(RANDOM_STATE)
random.seed(RANDOM_STATE)
torch.manual_seed(RANDOM_STATE)

DEVICE = "cuda" if torch.cuda.is_available() else "cpu"

CITY_DIRS = {
    "Beijing":   r"E:\中国特大城市洪水\北京市数据",
    "Chengdu":   r"E:\中国特大城市洪水\成都市数据",
    "Guangzhou": r"E:\中国特大城市洪水\广州市数据",
    "Shanghai":  r"E:\中国特大城市洪水\上海市数据",
    "Shenzhen":  r"E:\中国特大城市洪水\深圳市数据",
    "Tianjin":   r"E:\中国特大城市洪水\天津市数据",
}

# 可选：六个城市掩膜文件。
# 推荐优先填写“城市有效研究区/行政区掩膜”文件，可以是 shp，也可以是 tif。
# - 如果是 shp：代码会用 shp 范围构建输出模板，并 rasterize 为 mask；
# - 如果是 tif：代码会以该 mask 栅格作为输出模板，mask>0 的位置为预测区；
# - 如果不填写：代码会自动搜索名称包含“mask/掩膜/边界/boundary/市界/行政/范围”的 shp/tif。
#
# 如果自动搜索找错，请在这里手动写入你的掩膜路径。
CITY_MASK_FILES = {
    "Beijing":   None,
    "Chengdu":   None,
    "Guangzhou": None,
    "Shanghai":  None,
    "Shenzhen":  None,
    "Tianjin":   None,
}

# True：使用城市掩膜裁剪输出；
# False：使用第一个变量栅格作为模板，不做边界裁剪。
USE_MASK_CLIP = True

# True：只要像元落在边界内就预测，缺失变量由训练阶段 preprocessor 处理；
# False：仍然按 MIN_VALID_FEATURE_RATIO 过滤，有些边界区域可能为空。
PREDICT_FULL_BOUNDARY = True

# 栅格缺失填补策略。
# v4 中 MAX_FILL_DISTANCE_PIXELS=None 会把缺失区强行最近邻填满，
# 容易出现明显三角形 / Voronoi 拼接伪影。
#
# 推荐最终制图使用 conservative 策略：
# 1) 只填很小的 nodata 孔洞；
# 2) 不对大面积无变量覆盖区做外推；
# 3) 预测掩膜由“关键变量完整性 + 总变量覆盖率”控制。
GAP_FILL_METHOD = "nearest_small_holes"

# 对连续变量填补后的区域不做平滑。平滑会把最近邻分区变成大片三角形纹理。
SMOOTH_FILLED_CONTINUOUS = False
SMOOTH_SIGMA = 0.0

# 最大填补距离，单位：像元。只补很小的孔洞。
# 10 表示只补离已有有效像元 10 个像元以内的 nodata。
MAX_FILL_DISTANCE_PIXELS = 10

# 哪些变量按类别处理，只能 nearest，不能双线性/平滑。
CATEGORICAL_VARS = ["LULC"]

# 预测范围控制：
# - 不建议对完整行政边界内完全缺失预测变量的区域预测；
# - 这里保留边界模板，但只在变量覆盖可信区域输出 P_flood。
PREDICT_FULL_BOUNDARY = True

# 至少需要多少比例的变量有效才预测。
# 如果你想更保守，用 0.85 或 0.90；如果覆盖太少，用 0.70。
MIN_VALID_FEATURE_RATIO = 0.85

# 关键变量必须有效。这里避免气候/地形/土地覆盖完全缺失区域被硬预测。
CRITICAL_VALID_VARS = ["Rx1day", "Rx5day", "CWD", "EV", "SL", "TWI", "NDVI", "LULC"]

# 可选：只对有城市建成环境信息的区域预测，避免远郊空白区被填出结果。
# 如果你觉得覆盖太少，可以改为 False。
REQUIRE_ANY_BUILT_ENV = True
BUILT_ENV_VALID_VARS = ["BD", "PD", "BH", "BVI", "Micro_ISA", "Micro_PSA", "GVI", "SVF"]

MODEL_ROOT = r"E:\中国特大城市洪水\RF_Stabilized_HydroConTex_GNNWRL_v11_robust_diagnostics"
MODEL_DIR = os.path.join(MODEL_ROOT, "models")

PACKAGE_PATH = os.path.join(MODEL_DIR, "Final_RF_Stabilized_HydroConTex_GNNWRL_package.joblib")
STATE_DICT_PATH = os.path.join(MODEL_DIR, "Final_GNNWRL_state_dict.pt")

# 每个城市输出到自己的文件夹里面
OUT_SUBDIR_NAME = "Historical_Flood_Prediction_full_admin"

# 同时保存变量覆盖率栅格，用于标记哪些区域是观测支撑充分、哪些区域主要依赖缺失值填补。
SAVE_COVERAGE_TIF = True

# 一次预测多少个有效像元。显存/内存不够就调小，例如 20000。
# 如果你的栅格不大，可以调大到 100000。
BATCH_SIZE = 50000

# 最低有效变量比例。低于这个比例的像元不预测，保持 NoData。
MIN_VALID_FEATURE_RATIO = 0.70

# 只输出 P_flood.tif，不输出大量表格。
SAVE_ONLY_TIF = True

# =========================================================
# 1. 变量配置
# =========================================================

MODEL_VARS = [
    "Rx1day", "Rx5day", "CWD",
    "EV", "SL", "PRC", "TWI", "TPI",
    "ST", "NDVI", "LULC",
    "BD", "PD", "BH", "BVI",
    "CFI", "FOE", "GVI",
    "Micro_ISA", "Micro_PSA",
    "SCE", "SEL", "SVF", "TAE"
]

ZERO_FILL_VARS = ["BD", "PD", "BH", "BVI", "Micro_ISA", "Micro_PSA"]
MISSING_INDICATOR_BASE_VARS = ["BD", "PD", "BH", "BVI", "Micro_ISA", "Micro_PSA"]

CONTEXT_GROUPS = {
    "Climate": ["Rx1day", "Rx5day", "CWD"],
    "Terrain": ["EV", "SL", "PRC", "TWI", "TPI", "ST"],
    "LandCover": ["NDVI", "LULC"],
    "Built": ["BD", "PD", "BH", "BVI", "Micro_ISA", "Micro_PSA"],
    "Streetscape": ["CFI", "FOE", "GVI", "SCE", "SEL", "SVF", "TAE"],
}
CONTEXT_ORDER = ["Climate", "Terrain", "LandCover", "Built", "Streetscape"]

RASTER_STEMS = {
    "Rx1day": ["Rx1day", "Rx1 day"],
    "Rx5day": ["Rx5day", "Rx5 day"],
    "CWD": ["CWD"],
    "EV": ["EV"],
    "SL": ["SL"],
    "PRC": ["PRC"],
    "TWI": ["TWI"],
    "TPI": ["TPI"],
    "ST": ["ST"],
    "NDVI": ["NDVI"],
    "LULC": ["LULC", "LU"],
    "BD": ["BD"],
    "PD": ["PD"],
    "BH": ["BH"],
    "BVI": ["BVI"],
    "CFI": ["CFI"],
    "FOE": ["FOE"],
    "GVI": ["GVI"],
    "Micro_ISA": ["Micro_ISA"],
    "Micro_PSA": ["Micro_PSA"],
    "SCE": ["SCE"],
    "SEL": ["SEL", "SEI"],
    "SVF": ["SVF"],
    "TAE": ["TAE"],
}


# =========================================================
# 2. 必须保留：preprocessor 类，用于 joblib 正确加载
# =========================================================

class TabularPreprocessor:
    """
    与训练代码一致：
    - 对 BD/PD/BH/BVI/Micro_ISA/Micro_PSA 先生成缺失指示变量；
    - 对部分变量 zero-fill；
    - 其他变量 median-fill；
    - 最后使用训练阶段 scaler 标准化。
    """
    def __init__(self, model_vars, zero_fill_vars):
        self.model_vars = model_vars
        self.zero_fill_vars = zero_fill_vars
        self.missing_indicator_base_vars = [v for v in MISSING_INDICATOR_BASE_VARS if v in model_vars]
        self.missing_indicator_vars = [f"{v}_missing" for v in self.missing_indicator_base_vars]
        self.feature_vars = self.model_vars + self.missing_indicator_vars
        self.median_fill_vars = [v for v in model_vars if v not in zero_fill_vars]
        self.medians_ = {}
        self.scaler_ = StandardScaler()

    def _prepare_unscaled(self, df):
        X_raw = df[self.model_vars].copy()
        X = pd.DataFrame(index=df.index)

        for v in self.model_vars:
            X[v] = X_raw[v]

        for v in self.missing_indicator_base_vars:
            X[f"{v}_missing"] = X_raw[v].isna().astype(float)

        for v in self.zero_fill_vars:
            if v in X.columns:
                X[v] = X[v].fillna(0.0)

        for v in self.median_fill_vars:
            fill = self.medians_.get(v, np.nan)
            if not np.isfinite(fill):
                fill = float(X[v].median(skipna=True))
                if not np.isfinite(fill):
                    fill = 0.0
            X[v] = X[v].fillna(fill)

        X = X[self.feature_vars].astype(float)
        return X

    def fit(self, df):
        X_raw = df[self.model_vars].copy()
        for v in self.median_fill_vars:
            med = float(X_raw[v].median(skipna=True))
            if not np.isfinite(med):
                med = 0.0
            self.medians_[v] = med
        X = self._prepare_unscaled(df)
        self.scaler_.fit(X.values)
        return self

    def transform(self, df):
        X = self._prepare_unscaled(df)
        arr = self.scaler_.transform(X.values)
        return pd.DataFrame(arr, columns=self.feature_vars, index=df.index)

    def fit_transform(self, df):
        self.fit(df)
        return self.transform(df)


# =========================================================
# 3. GNNWRL 模型结构
# =========================================================

class GraphConv(nn.Module):
    def __init__(self, dim):
        super().__init__()
        self.lin_self = nn.Linear(dim, dim)
        self.lin_neigh = nn.Linear(dim, dim)
        self.norm = nn.LayerNorm(dim)

    def forward(self, h, edge_index, edge_weight):
        src, dst = edge_index[0], edge_index[1]
        msg = self.lin_neigh(h[src]) * edge_weight.view(-1, 1)
        agg = torch.zeros_like(h)
        agg.index_add_(0, dst, msg)
        out = self.lin_self(h) + agg
        out = self.norm(out)
        return F.relu(out)


class RFStabilizedHydroConTexGNNWRL(nn.Module):
    def __init__(
        self,
        input_dim,
        context_idx,
        hidden_dim=48,
        dropout=0.20,
        use_graph=True,
        use_wrl=True,
        use_global_branch=True,
    ):
        super().__init__()
        self.context_idx = context_idx
        self.context_names = list(context_idx.keys())
        self.use_graph = use_graph
        self.use_wrl = use_wrl
        self.use_global_branch = use_global_branch

        self.encoders = nn.ModuleDict()
        self.gconvs = nn.ModuleDict()
        self.context_logits = nn.ModuleDict()

        for cname in self.context_names:
            in_dim = len(context_idx[cname])
            self.encoders[cname] = nn.Sequential(
                nn.Linear(in_dim, hidden_dim),
                nn.ReLU(),
                nn.Dropout(dropout),
                nn.Linear(hidden_dim, hidden_dim),
                nn.ReLU(),
            )
            self.gconvs[cname] = GraphConv(hidden_dim)
            self.context_logits[cname] = nn.Linear(hidden_dim, 1)

        fusion_in = hidden_dim * len(self.context_names) + 2
        self.global_branch = nn.Sequential(
            nn.Linear(fusion_in, hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, max(hidden_dim // 2, 4)),
            nn.ReLU(),
            nn.Linear(max(hidden_dim // 2, 4), 1),
        )

        self.wrl_gate = nn.Sequential(
            nn.Linear(fusion_in, hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, len(self.context_names)),
        )

    def forward(self, x, coords_norm, edge_index, edge_weight, return_details=False):
        context_embeds = []
        context_logits = []

        for cname in self.context_names:
            idx = self.context_idx[cname]
            hx = self.encoders[cname](x[:, idx])
            if self.use_graph:
                hg = self.gconvs[cname](hx, edge_index, edge_weight)
            else:
                hg = hx
            context_embeds.append(hg)
            context_logits.append(self.context_logits[cname](hg))

        H = torch.cat(context_embeds, dim=1)
        Hc = torch.cat([H, coords_norm], dim=1)

        logits_stack = torch.cat(context_logits, dim=1)
        if self.use_wrl:
            alpha = F.softmax(self.wrl_gate(Hc), dim=1)
        else:
            alpha = torch.ones_like(logits_stack) / logits_stack.shape[1]

        local_logit = torch.sum(alpha * logits_stack, dim=1, keepdim=True)

        if self.use_global_branch:
            global_logit = self.global_branch(Hc)
        else:
            global_logit = torch.zeros_like(local_logit)

        base_logit = local_logit + global_logit

        if return_details:
            return base_logit.squeeze(1), {
                "context_weights": alpha,
                "context_logits": logits_stack,
                "global_logit": global_logit,
                "local_logit": local_logit,
            }
        return base_logit.squeeze(1)


# =========================================================
# 4. 图构建和预测函数
# =========================================================

def context_indices(feature_vars, context_groups):
    idx = {}
    for cname, vars_ in context_groups.items():
        idx[cname] = [feature_vars.index(v) for v in vars_ if v in feature_vars]
    return idx


def normalize_edge_weights(src, dst, weight, n_nodes):
    weight = np.asarray(weight, dtype=np.float32)
    dst = np.asarray(dst, dtype=np.int64)
    denom = np.zeros(n_nodes, dtype=np.float32)
    np.add.at(denom, dst, weight)
    denom = np.maximum(denom, 1e-8)
    return weight / denom[dst]


def build_knn_edges(coords, k_spatial=8):
    """
    对当前 batch 像元构建空间 KNN 图。
    为了避免全城市百万级像元构图内存爆炸，栅格预测默认按 batch 进行。
    """
    n = len(coords)
    if n <= 1:
        src = np.arange(n, dtype=np.int64)
        dst = np.arange(n, dtype=np.int64)
        w = np.ones(n, dtype=np.float32)
        return np.vstack([src, dst]), w

    k = min(k_spatial + 1, n)
    nbr = NearestNeighbors(n_neighbors=k, algorithm="auto").fit(coords)
    dist, ind = nbr.kneighbors(coords)

    positive_d = dist[:, 1:].ravel()
    positive_d = positive_d[positive_d > 0]
    bw = np.quantile(positive_d, 0.50) if len(positive_d) else 1.0
    bw = max(bw, 1e-6)

    src_all, dst_all, w_all = [], [], []
    for row in range(n):
        for jj in range(1, k):
            neigh = ind[row, jj]
            d = dist[row, jj]
            weight = math.exp(-(d * d) / (2 * bw * bw))
            src_all.append(neigh)
            dst_all.append(row)
            w_all.append(weight)

    src = np.asarray(src_all, dtype=np.int64)
    dst = np.asarray(dst_all, dtype=np.int64)
    w = normalize_edge_weights(src, dst, w_all, n)
    return np.vstack([src, dst]), w.astype(np.float32)


def load_final_model_package():
    print(f"[Load] {PACKAGE_PATH}")
    package = joblib.load(PACKAGE_PATH)

    preprocessor = package["preprocessor"]
    feature_vars = list(preprocessor.feature_vars)

    context_groups = package.get("CONTEXT_GROUPS", CONTEXT_GROUPS)
    # 确保 Built 组包含 missing indicators
    built = list(context_groups.get("Built", []))
    for v in getattr(preprocessor, "missing_indicator_vars", []):
        if v not in built:
            built.append(v)
    context_groups["Built"] = built

    ctx_idx = context_indices(feature_vars, context_groups)

    model = RFStabilizedHydroConTexGNNWRL(
        input_dim=len(feature_vars),
        context_idx=ctx_idx,
        hidden_dim=int(package.get("HIDDEN_DIM", 48)),
        dropout=float(package.get("DROPOUT", 0.20)),
        use_graph=True,
        use_wrl=True,
        use_global_branch=True,
    ).to(DEVICE)

    print(f"[Load] {STATE_DICT_PATH}")
    state = torch.load(STATE_DICT_PATH, map_location=DEVICE)
    model.load_state_dict(state)
    model.eval()

    package["model"] = model
    package["feature_vars"] = feature_vars
    package["context_groups_runtime"] = context_groups
    return package


def predict_batch(package, X_scaled_df, coords):
    """
    输入一个 batch 的标准化特征和坐标，返回 P_flood。
    """
    feature_vars = package["feature_vars"]
    X_np = X_scaled_df[feature_vars].values.astype(np.float32)

    edge_index_np, edge_weight_np = build_knn_edges(
        coords=coords,
        k_spatial=int(package.get("K_SPATIAL", 8))
    )

    coord_mu = package["coord_mu"]
    coord_sd = package["coord_sd"]
    coords_norm = (coords - coord_mu) / coord_sd

    x_t = torch.tensor(X_np, dtype=torch.float32, device=DEVICE)
    c_t = torch.tensor(coords_norm, dtype=torch.float32, device=DEVICE)
    edge_i_t = torch.tensor(edge_index_np, dtype=torch.long, device=DEVICE)
    edge_w_t = torch.tensor(edge_weight_np, dtype=torch.float32, device=DEVICE)

    model = package["model"]
    with torch.no_grad():
        logit = model(x_t, c_t, edge_i_t, edge_w_t, return_details=False)
        p_gnn = torch.sigmoid(logit).detach().cpu().numpy()

    # RF anchor 使用同样的标准化特征
    p_rf = package["rf_anchor"].predict_proba(pd.DataFrame(X_np, columns=feature_vars))[:, 1]

    alpha = float(package.get("alpha_gnn", 0.0))
    p = alpha * p_gnn + (1.0 - alpha) * p_rf
    return np.clip(p, 1e-6, 1 - 1e-6).astype(np.float32)


# =========================================================
# 5. 栅格读取、对齐、输出
# =========================================================

def find_raster_exact(folder, aliases):
    tif_files = []
    tif_files.extend(glob.glob(os.path.join(folder, "**", "*.tif"), recursive=True))
    tif_files.extend(glob.glob(os.path.join(folder, "**", "*.tiff"), recursive=True))

    alias_lower = [a.lower() for a in aliases]
    candidates = []
    for file in tif_files:
        stem = Path(file).stem.lower()
        if stem in alias_lower:
            candidates.append(file)
    candidates = sorted(list(set(candidates)))
    return candidates[0] if candidates else None


def build_city_raster_paths(city, folder, model_vars):
    paths = {}
    for var in model_vars:
        path = find_raster_exact(folder, RASTER_STEMS.get(var, [var]))
        paths[var] = path
        if path is None:
            raise FileNotFoundError(f"{city} 缺少变量栅格: {var}")
    return paths


def read_as_template(src_path, template_profile, resampling):
    with rasterio.open(src_path) as src:
        arr = src.read(1, masked=True).astype("float32").filled(np.nan)
        if src.nodata is not None:
            arr[arr == src.nodata] = np.nan
        arr[np.isinf(arr)] = np.nan

        same_grid = (
            src.height == template_profile["height"]
            and src.width == template_profile["width"]
            and src.crs == template_profile["crs"]
            and src.transform == template_profile["transform"]
        )

        if same_grid:
            return arr.astype(np.float32)

        dst = np.full(
            (template_profile["height"], template_profile["width"]),
            np.nan,
            dtype=np.float32
        )

        reproject(
            source=arr,
            destination=dst,
            src_transform=src.transform,
            src_crs=src.crs,
            dst_transform=template_profile["transform"],
            dst_crs=template_profile["crs"],
            src_nodata=np.nan,
            dst_nodata=np.nan,
            resampling=resampling
        )
        dst[np.isinf(dst)] = np.nan
        return dst.astype(np.float32)


def write_float_tif(out_path, arr, profile, nodata=-9999.0):
    out_profile = profile.copy()
    out_profile.update(
        dtype="float32",
        count=1,
        nodata=nodata,
        compress="lzw",
        BIGTIFF="IF_SAFER"
    )

    arr_out = arr.astype(np.float32).copy()
    arr_out[~np.isfinite(arr_out)] = nodata

    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    with rasterio.open(out_path, "w", **out_profile) as dst:
        dst.write(arr_out, 1)


def make_xy_from_profile(profile):
    """
    Return 2-D x/y coordinate grids with shape = (height, width).

    修复说明：
    rasterio.transform.xy 在某些版本中会把 2-D rows/cols 展平成 1-D，
    因此后面 x_grid[rr, cc] 会报：
        IndexError: too many indices for array
    这里直接用 affine transform 向量化计算像元中心坐标，保证输出一定是 2-D。
    """
    h, w = int(profile["height"]), int(profile["width"])
    rows, cols = np.indices((h, w), dtype=np.float64)
    transform = profile["transform"]

    # center of pixel: col + 0.5, row + 0.5
    cc = cols + 0.5
    rr = rows + 0.5

    x = transform.a * cc + transform.b * rr + transform.c
    y = transform.d * cc + transform.e * rr + transform.f

    return x.astype(np.float64), y.astype(np.float64)




def find_city_mask_file(city, folder):
    """
    自动寻找城市掩膜文件。若自动搜索不准确，请在 CITY_MASK_FILES 中手动指定。

    支持：
    - shp: 行政边界 / 研究区边界；
    - tif/tiff: 已经栅格化的 mask，mask > 0 为预测区。
    """
    manual = CITY_MASK_FILES.get(city, None)
    if manual is not None and str(manual).strip() != "":
        if os.path.exists(manual):
            return manual
        raise FileNotFoundError(f"{city} 手动指定的掩膜文件不存在: {manual}")

    files = []
    files.extend(glob.glob(os.path.join(folder, "**", "*.shp"), recursive=True))
    files.extend(glob.glob(os.path.join(folder, "**", "*.tif"), recursive=True))
    files.extend(glob.glob(os.path.join(folder, "**", "*.tiff"), recursive=True))
    if not files:
        return None

    include_keys = ["mask", "掩膜", "边界", "boundary", "市界", "行政", "范围", "study", "extent"]
    exclude_keys = ["样本", "sample", "point", "points", "点", "flood", "train", "test",
                    "Rx1day", "Rx5day", "CWD", "NDVI", "LULC", "BD", "BH", "GVI", "SVF"]

    candidates = []
    for f in files:
        stem = Path(f).stem.lower()
        if any(k.lower() in stem for k in exclude_keys):
            continue
        score = 0
        for k in include_keys:
            if k.lower() in stem:
                score += 2
        # 优先 shp，其次 tif mask
        if f.lower().endswith(".shp"):
            score += 1
        if score > 0:
            candidates.append((score, f))

    if candidates:
        candidates = sorted(candidates, key=lambda x: (-x[0], len(str(x[1]))))
        return candidates[0][1]

    return None


def make_template_and_mask_from_shp(mask_path, reference_raster_path, resolution=None, pad_pixels=2):
    """
    使用 shp 掩膜范围 + 参考栅格分辨率构建输出模板，并 rasterize 得到 boundary_mask。
    """
    with rasterio.open(reference_raster_path) as ref:
        ref_crs = ref.crs
        ref_transform = ref.transform
        ref_profile = ref.profile.copy()
        if resolution is None:
            xres = abs(ref_transform.a)
            yres = abs(ref_transform.e)
        else:
            xres, yres = resolution

    gdf = gpd.read_file(mask_path)
    if gdf.empty:
        raise ValueError(f"掩膜 shp 为空: {mask_path}")
    if gdf.crs is None:
        raise ValueError(f"掩膜 shp 没有 CRS，请先定义投影: {mask_path}")

    gdf = gdf.to_crs(ref_crs)
    minx, miny, maxx, maxy = gdf.total_bounds

    minx -= pad_pixels * xres
    maxx += pad_pixels * xres
    miny -= pad_pixels * yres
    maxy += pad_pixels * yres

    width = int(np.ceil((maxx - minx) / xres))
    height = int(np.ceil((maxy - miny) / yres))
    transform = from_origin(minx, maxy, xres, yres)

    profile = ref_profile.copy()
    profile.update({
        "height": height,
        "width": width,
        "transform": transform,
        "crs": ref_crs,
        "count": 1,
        "dtype": "float32",
        "nodata": -9999.0,
        "compress": "lzw",
        "BIGTIFF": "IF_SAFER",
    })

    boundary_mask = geometry_mask(
        geometries=list(gdf.geometry),
        out_shape=(height, width),
        transform=transform,
        invert=True,
        all_touched=True
    )

    return profile, boundary_mask, mask_path


def make_template_and_mask_from_raster(mask_path):
    """
    使用已有栅格 mask 作为输出模板。
    mask 中 >0 且非 nodata 的位置为预测区。
    """
    with rasterio.open(mask_path) as src:
        mask_arr = src.read(1, masked=True).astype("float32").filled(np.nan)
        if src.nodata is not None:
            mask_arr[mask_arr == src.nodata] = np.nan
        boundary_mask = np.isfinite(mask_arr) & (mask_arr > 0)

        profile = src.profile.copy()
        profile.update({
            "height": src.height,
            "width": src.width,
            "transform": src.transform,
            "crs": src.crs,
            "count": 1,
            "dtype": "float32",
            "nodata": -9999.0,
            "compress": "lzw",
            "BIGTIFF": "IF_SAFER",
        })

    return profile, boundary_mask, mask_path


def make_template_and_mask(city, folder, reference_raster_path):
    """
    根据城市掩膜构建输出模板和 boundary_mask。
    """
    if not USE_MASK_CLIP:
        with rasterio.open(reference_raster_path) as src0:
            profile = src0.profile.copy()
        mask = np.ones((profile["height"], profile["width"]), dtype=bool)
        print("[Mask clip] 未启用，使用第一个变量栅格作为模板。")
        return profile, mask, None

    mask_path = find_city_mask_file(city, folder)
    if mask_path is None:
        with rasterio.open(reference_raster_path) as src0:
            profile = src0.profile.copy()
        mask = np.ones((profile["height"], profile["width"]), dtype=bool)
        print("[Mask clip] 未找到掩膜文件，退回第一个变量栅格模板。")
        return profile, mask, None

    suffix = Path(mask_path).suffix.lower()
    print(f"[Mask clip] {mask_path}")
    if suffix == ".shp":
        return make_template_and_mask_from_shp(mask_path, reference_raster_path)
    if suffix in [".tif", ".tiff"]:
        return make_template_and_mask_from_raster(mask_path)

    raise ValueError(f"不支持的掩膜文件类型: {mask_path}")



def predict_city_historical_grid(city, folder, package):
    print(f"\n========== Predict historical grid: {city} ==========")

    raster_paths = build_city_raster_paths(city, folder, MODEL_VARS)

    # 构建输出模板和掩膜：
    # 预测和输出都严格按 boundary_mask 裁剪。
    template_path = raster_paths[MODEL_VARS[0]]
    template_profile, boundary_mask, used_mask_path = make_template_and_mask(city, folder, template_path)

    arr_dict = {}
    for var in MODEL_VARS:
        path = raster_paths[var]
        resampling = Resampling.nearest if var == "LULC" else Resampling.bilinear
        arr = read_as_template(path, template_profile, resampling=resampling)
        if var == "LULC":
            arr = np.rint(arr).astype(np.float32)
        arr_dict[var] = arr
        print(f"[Read] {var}: {Path(path).name}")

    h, w = template_profile["height"], template_profile["width"]

    # 对边界内各变量 nodata 做空间填补。
    # 这一步比让 preprocessor 直接 median-fill 更适合制图，因为它能保持空间连续性。
    if GAP_FILL_METHOD.lower().startswith("nearest"):
        print("[Gap fill] conservative nearest filling only for small nodata holes")
        for var in MODEL_VARS:
            before_missing = int((~np.isfinite(arr_dict[var]) & boundary_mask).sum())
            if before_missing > 0:
                smooth_flag = bool(SMOOTH_FILLED_CONTINUOUS and var not in CATEGORICAL_VARS)
                arr_filled, filled_n, filled_ratio = fill_nodata_nearest_inside_boundary(
                    arr_dict[var],
                    boundary_mask=boundary_mask,
                    var_name=var,
                    smooth_continuous=smooth_flag,
                    sigma=SMOOTH_SIGMA,
                    max_distance_pixels=MAX_FILL_DISTANCE_PIXELS
                )
                if var in CATEGORICAL_VARS:
                    arr_filled = np.rint(arr_filled).astype(np.float32)
                arr_dict[var] = arr_filled
                print(f"  {var}: missing before={before_missing:,}, spatial-filled={filled_n:,}, ratio={filled_ratio:.3f}")
    else:
        print("[Gap fill] none; missing values will be handled only by training-stage preprocessor.")

    # 有效比例掩膜
    stack_valid = np.zeros((h, w), dtype=np.float32)
    for var in MODEL_VARS:
        stack_valid += np.isfinite(arr_dict[var]).astype(np.float32)
    valid_ratio = stack_valid / float(len(MODEL_VARS))

    if PREDICT_FULL_BOUNDARY:
        # 完整行政区预测：掩膜内所有像元都输出 P_flood。
        # 注意：变量缺失区会使用训练阶段 preprocessor 的 median/zero/missing-indicator 机制处理。
        # 同时保存 Predictor_Coverage_Ratio.tif 作为可靠性标记。
        valid_mask = boundary_mask.copy()
        print("[Mask] 使用完整行政区掩膜预测；缺失变量由训练阶段 preprocessor 处理，并保存 coverage ratio。")
    else:
        # 推荐：只在变量覆盖可信区域输出预测，避免大面积外推伪影。
        valid_mask = boundary_mask & (valid_ratio >= MIN_VALID_FEATURE_RATIO)

        if len(CRITICAL_VALID_VARS) > 0:
            critical_mask = np.ones((h, w), dtype=bool)
            for v in CRITICAL_VALID_VARS:
                if v in arr_dict:
                    critical_mask &= np.isfinite(arr_dict[v])
            valid_mask &= critical_mask
            print(f"[Mask] 关键变量必须有效: {CRITICAL_VALID_VARS}")

        if REQUIRE_ANY_BUILT_ENV:
            built_mask = np.zeros((h, w), dtype=bool)
            for v in BUILT_ENV_VALID_VARS:
                if v in arr_dict:
                    built_mask |= np.isfinite(arr_dict[v])
            valid_mask &= built_mask
            print(f"[Mask] 至少一个建成环境变量有效: {BUILT_ENV_VALID_VARS}")

        print(f"[Mask] 有效变量比例过滤: >= {MIN_VALID_FEATURE_RATIO}")

    n_valid = int(valid_mask.sum())
    print(f"[Valid pixels] {n_valid:,} / {h*w:,}")
    if n_valid > 0:
        print(f"[Valid feature ratio inside prediction area] mean={np.nanmean(valid_ratio[valid_mask]):.3f}, "
              f"p10={np.nanpercentile(valid_ratio[valid_mask], 10):.3f}, min={np.nanmin(valid_ratio[valid_mask]):.3f}")

    p_map = np.full((h, w), np.nan, dtype=np.float32)
    if n_valid == 0:
        raise ValueError(f"{city}: 没有有效像元可预测。")

    # 坐标
    x_grid, y_grid = make_xy_from_profile(template_profile)
    valid_rows, valid_cols = np.where(valid_mask)
    valid_index = np.arange(n_valid)

    # 分 batch 预测，避免整城构图内存爆炸
    for start in range(0, n_valid, BATCH_SIZE):
        end = min(start + BATCH_SIZE, n_valid)
        idx = valid_index[start:end]
        rr = valid_rows[idx]
        cc = valid_cols[idx]

        data = {}
        for var in MODEL_VARS:
            data[var] = arr_dict[var][rr, cc]
        df = pd.DataFrame(data)

        X_scaled = package["preprocessor"].transform(df)
        coords = np.column_stack([x_grid[rr, cc], y_grid[rr, cc]]).astype(np.float64)

        p = predict_batch(package, X_scaled, coords)
        p_map[rr, cc] = p

        print(f"  batch {start:,}–{end:,}: mean P={np.nanmean(p):.4f}")

    # 严格按掩膜裁剪：掩膜外全部设为 NoData。
    p_map[~boundary_mask] = np.nan

    # 输出到城市文件夹
    out_dir = os.path.join(folder, OUT_SUBDIR_NAME)
    os.makedirs(out_dir, exist_ok=True)
    out_tif = os.path.join(out_dir, f"{city}_Historical_P_flood.tif")
    write_float_tif(out_tif, p_map, template_profile, nodata=-9999.0)

    coverage_tif = None
    if SAVE_COVERAGE_TIF:
        coverage_arr = valid_ratio.astype(np.float32).copy()
        coverage_arr[~boundary_mask] = np.nan
        coverage_tif = os.path.join(out_dir, f"{city}_Predictor_Coverage_Ratio.tif")
        write_float_tif(coverage_tif, coverage_arr, template_profile, nodata=-9999.0)
        print(f"[Saved coverage tif] {coverage_tif}")

    print(f"[Saved full-admin mask-clipped tif] {out_tif}")
    print(f"[Summary] {city}: mean={np.nanmean(p_map):.4f}, p90={np.nanpercentile(p_map, 90):.4f}, max={np.nanmax(p_map):.4f}")

    return {
        "city": city,
        "p_map": p_map,
        "profile": template_profile,
        "out_tif": out_tif,
        "coverage_tif": coverage_tif,
        "mask_path": used_mask_path,
        "boundary_mask": boundary_mask,
        "coverage_ratio": valid_ratio,
        "mean": float(np.nanmean(p_map)),
        "p90": float(np.nanpercentile(p_map, 90)),
        "max": float(np.nanmax(p_map)),
    }


# =========================================================
# 6. 六城市可视化
# =========================================================

def plot_six_city_flood(results, save_path=None):
    plt.rcParams.update({
        "font.family": "Times New Roman",
        "font.size": 12,
        "font.weight": "bold",
        "axes.labelweight": "bold",
        "axes.titleweight": "bold",
    })

    cities = list(results.keys())
    fig, axes = plt.subplots(2, 3, figsize=(14, 8), dpi=160)
    axes = axes.ravel()

    # 为了六城市可比，统一色带范围 0–1
    norm = Normalize(vmin=0, vmax=1)
    cmap = plt.get_cmap("RdYlBu_r").copy()
    cmap.set_bad(color="white")

    for ax, city in zip(axes, cities):
        arr = results[city]["p_map"]
        # 可视化时裁剪到非空范围，避免整幅图被巨大空白挤压。
        finite = np.isfinite(arr)
        if finite.any():
            rows, cols = np.where(finite)
            r0, r1 = max(rows.min() - 3, 0), min(rows.max() + 4, arr.shape[0])
            c0, c1 = max(cols.min() - 3, 0), min(cols.max() + 4, arr.shape[1])
            arr_show = arr[r0:r1, c0:c1]
        else:
            arr_show = arr
        im = ax.imshow(arr_show, cmap=cmap, norm=norm)
        ax.set_title(city, fontsize=14, fontweight="bold")
        ax.set_xticks([])
        ax.set_yticks([])

        # 简单标注均值
        mean_val = results[city]["mean"]
        p90_val = results[city]["p90"]
        cov_arr = results[city].get("coverage_ratio", None)
        if cov_arr is not None:
            cov_inside = cov_arr[np.isfinite(results[city]["p_map"])]
            cov_mean = float(np.nanmean(cov_inside)) if len(cov_inside) else np.nan
            note = f"Mean={mean_val:.3f}\nP90={p90_val:.3f}\nCov={cov_mean:.2f}"
        else:
            note = f"Mean={mean_val:.3f}\nP90={p90_val:.3f}"
        ax.text(
            0.02, 0.02,
            note,
            transform=ax.transAxes,
            fontsize=10,
            fontweight="bold",
            va="bottom",
            ha="left",
            bbox=dict(facecolor="white", edgecolor="none", alpha=0.72, pad=2.5)
        )

    for ax in axes[len(cities):]:
        ax.axis("off")

    cbar = fig.colorbar(im, ax=axes, fraction=0.025, pad=0.02)
    cbar.set_label("Historical flood probability", fontsize=12, fontweight="bold")

    fig.suptitle(
        "Historical flood probability predicted by RF-stabilized Hydro-ConTex GNNWRL",
        fontsize=16,
        fontweight="bold",
        y=0.98
    )

    plt.tight_layout(rect=[0, 0, 0.96, 0.95])

    if save_path is not None:
        os.makedirs(os.path.dirname(save_path), exist_ok=True)
        plt.savefig(save_path, dpi=600, bbox_inches="tight")
        print(f"[Saved figure] {save_path}")

    plt.show()


# =========================================================
# 7. 主执行：只预测历史 flood，不做验证
# =========================================================

package = load_final_model_package()

results = {}
for city, folder in CITY_DIRS.items():
    results[city] = predict_city_historical_grid(city, folder, package)

# 六城市 Jupyter 可视化
panel_out = os.path.join(MODEL_ROOT, "Historical_Flood_Probability_6Cities.png")
plot_six_city_flood(results, save_path=panel_out)

print("\n========== Finished ==========")
for city, r in results.items():
    print(f"{city}: {r['out_tif']}")
