#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
V50：S0-S7 像元级不平等 + 暴露耦合收益 + 适应供需匹配 ACR + 蜂巢绘图数据
================================================================================

核心路径已经按你的数据固定：

E:\中国特大城市洪水\绘图汇总\第三组图\03_city_scenarios\<City>\rasters

例如：
E:\中国特大城市洪水\绘图汇总\第三组图\03_city_scenarios\Beijing\rasters\S0_F1.tif
E:\中国特大城市洪水\绘图汇总\第三组图\03_city_scenarios\Beijing\rasters\S7_F1.tif

本脚本只负责“计算绘图数据”，不画正式论文图。

相比 V48/V49，这一版新增：
1. Adaptation demand（适应需求）：基准风险 × 暴露
2. Adaptation supply（适应供给）：风险削减收益
3. ACR, adaptation capacity ratio（适应供需覆盖率）
4. residual demand / mismatch（残余需求 / 供需错配）
5. high-demand top20 benefit coverage（高需求区域获得的收益份额）
6. demand quintile table（按适应需求五分组的收益分配）
7. ACR / residual demand 的蜂巢图绘图数据

不做多尺度蜂巢，只使用一个固定 hex-size。
"""

from __future__ import annotations

import argparse
import math
import re
import warnings
from pathlib import Path
from typing import Dict, Optional, Tuple, List

import numpy as np
import pandas as pd

import rasterio
from rasterio.warp import reproject, Resampling
from rasterio.transform import xy

try:
    import geopandas as gpd
    from shapely.geometry import Polygon
    from shapely import wkt
    HAS_GEO = True
except Exception:
    gpd = None
    Polygon = None
    wkt = None
    HAS_GEO = False

warnings.filterwarnings("ignore")

try:
    from tqdm import tqdm
except Exception:
    def tqdm(iterable=None, total=None, desc=None, unit=None, **kwargs):
        if desc:
            print(f"[{desc}] start", flush=True)
        return iterable if iterable is not None else range(total or 0)

# ============================================================
# 绝对路径固定区：直接运行即可
# ============================================================
DEFAULT_PROJECT_ROOT = r"E:\中国特大城市洪水"
DEFAULT_SCENARIO_ROOT = r"E:\中国特大城市洪水\绘图汇总\第三组图\03_city_scenarios"
DEFAULT_OUTPUT_DIR = r"E:\中国特大城市洪水\inequality_outputs_v50_ACR"
DEFAULT_HEX_SIZE = 3000
DEFAULT_SAMPLE_STEP = 2          # 快速版；最终完整蜂巢可改为 1
DEFAULT_BOOTSTRAP = 200
EPS = 1e-12
# ============================================================

CITY_ORDER = ["Beijing", "Chengdu", "Guangzhou", "Shanghai", "Shenzhen", "Tianjin"]
CITY_CN_DIRS = {
    "Beijing": "北京市数据",
    "Chengdu": "成都市数据",
    "Guangzhou": "广州市数据",
    "Shanghai": "上海市数据",
    "Shenzhen": "深圳市数据",
    "Tianjin": "天津市数据",
}
SCENARIOS = [f"S{i}" for i in range(8)]
TARGETS = ["F1", "F2", "F3"]

# F1 = 安全/风险负担，越低越好；收益 = S0 - Sx
# F2 = 宜居生态，越高越好；收益 = Sx - S0
# F3 = 城市功能保持，默认越高越好；若你的 F3 是 CGI loss，则把 F3 改成 decrease_is_benefit
BENEFIT_DIRECTION = {
    "F1": "decrease_is_benefit",
    "F2": "increase_is_benefit",
    "F3": "increase_is_benefit",
}

# 情景栅格中的可控变量
SCENARIO_COVARIATE_NAMES = [
    "BD", "BH", "GVI", "LULC", "Micro_ISA", "Micro_PSA", "NDVI", "P",
    "SVF", "SCE", "SEL", "BVI", "CFI", "FOE", "TAE"
]

# 城市根目录中可读的暴露/背景变量
BASE_COVARIATE_NAMES = [
    "PopD", "PD", "GDP", "NTL", "RD", "BD", "BH", "NDVI", "GVI",
    "Micro_ISA", "Micro_PSA", "LULC", "SVF"
]

# ---------------------------------------------------------------------
# 1. 文件匹配与栅格读取
# ---------------------------------------------------------------------
def norm(s: str) -> str:
    return re.sub(r"[^A-Za-z0-9]+", "", str(s)).lower()

def infer_scenario(path_or_name: str) -> Optional[str]:
    text = str(path_or_name)
    for s in SCENARIOS:
        if re.search(rf"(^|[^A-Za-z0-9]){s}([^A-Za-z0-9]|$)", text, flags=re.I):
            return s
    n = norm(text)
    for s in SCENARIOS:
        if s.lower() in n:
            return s
    if any(k in n for k in ["bau", "base", "baseline", "current", "reference", "ref"]):
        return "S0"
    return None

def infer_target(path_or_name: str) -> Optional[str]:
    text = str(path_or_name)
    for t in TARGETS:
        if re.search(rf"(^|[^A-Za-z0-9]){t}([^A-Za-z0-9]|$)", text, flags=re.I):
            return t
    n = norm(text)
    if "safetyexpectedimpact" in n or "risk" in n or "flood" in n:
        return "F1"
    if "livableecological" in n or "livability" in n or "ecological" in n:
        return "F2"
    if "cgi" in n or "growthintensity" in n or "function" in n:
        return "F3"
    return None

def infer_covariate(path_or_name: str) -> Optional[str]:
    stem = Path(str(path_or_name)).stem
    stem = re.sub(r"^S[0-7]_", "", stem, flags=re.I)
    n = norm(stem)
    ordered = sorted(SCENARIO_COVARIATE_NAMES + BASE_COVARIATE_NAMES, key=len, reverse=True)
    for c in ordered:
        if norm(c) == n:
            return c
    for c in ordered:
        if norm(c) in n:
            return c
    return None

def scenario_raster_folder(scenario_root: Path, city: str) -> Path:
    return scenario_root / city / "rasters"

def base_city_folder(project_root: Path, city: str) -> Path:
    return project_root / CITY_CN_DIRS[city]

def inventory_scenario_rasters(scenario_root: Path):
    target_rows, cov_rows, debug_rows = [], [], []
    for city in CITY_ORDER:
        folder = scenario_raster_folder(scenario_root, city)
        if not folder.exists():
            debug_rows.append({"City": city, "FolderExists": False, "Path": str(folder)})
            continue
        for p in folder.rglob("*.tif"):
            rel = str(p.relative_to(folder))
            sc = infer_scenario(p.name) or infer_scenario(rel)
            target = infer_target(p.name)
            cov = infer_covariate(p.name)
            debug_rows.append({
                "City": city, "FolderExists": True, "Path": str(p), "RelativePath": rel,
                "FileName": p.name, "Scenario": sc or "", "Target": target or "", "Covariate": cov or ""
            })
            if sc and target:
                target_rows.append({"City": city, "Scenario": sc, "Target": target, "Path": str(p), "FileName": p.name})
            elif sc and cov:
                cov_rows.append({"City": city, "Scenario": sc, "Covariate": cov, "Path": str(p), "FileName": p.name})
    return pd.DataFrame(target_rows), pd.DataFrame(cov_rows), pd.DataFrame(debug_rows)

def inventory_base_covariates(project_root: Path) -> pd.DataFrame:
    rows = []
    for city in CITY_ORDER:
        folder = base_city_folder(project_root, city)
        if not folder.exists():
            continue
        for p in folder.glob("*.tif"):
            cov = infer_covariate(p.name)
            if cov in BASE_COVARIATE_NAMES:
                rows.append({"City": city, "Covariate": cov, "Path": str(p), "FileName": p.name})
    df = pd.DataFrame(rows)
    if not df.empty:
        df = df.drop_duplicates(["City", "Covariate"], keep="first")
    return df

def read_raster(path: Path) -> Tuple[np.ndarray, dict]:
    with rasterio.open(path) as src:
        arr = src.read(1).astype("float64")
        nodata = src.nodata
        meta = src.meta.copy()
        meta["transform"] = src.transform
        meta["crs"] = src.crs
        meta["width"] = src.width
        meta["height"] = src.height
        meta["bounds"] = src.bounds
    if nodata is not None:
        arr = np.where(arr == nodata, np.nan, arr)
    arr = np.where(np.abs(arr) > 1e30, np.nan, arr)
    return arr, meta

def align_to_ref(path: Path, ref_meta: dict, categorical: bool = False) -> np.ndarray:
    with rasterio.open(path) as src:
        arr = src.read(1).astype("float64")
        nodata = src.nodata
        if nodata is not None:
            arr = np.where(arr == nodata, np.nan, arr)

        dst = np.full((ref_meta["height"], ref_meta["width"]), np.nan, dtype="float64")
        reproject(
            source=arr,
            destination=dst,
            src_transform=src.transform,
            src_crs=src.crs,
            dst_transform=ref_meta["transform"],
            dst_crs=ref_meta["crs"],
            src_nodata=np.nan,
            dst_nodata=np.nan,
            resampling=Resampling.nearest if categorical else Resampling.bilinear,
        )
    return np.where(np.abs(dst) > 1e30, np.nan, dst)

def finite_vals(arr: np.ndarray) -> np.ndarray:
    x = np.asarray(arr, dtype="float64").ravel()
    return x[np.isfinite(x)]

# ---------------------------------------------------------------------
# 2. 不平等指数
# ---------------------------------------------------------------------
def pos(x: np.ndarray, eps=1e-12) -> np.ndarray:
    x = np.asarray(x, dtype="float64")
    x = x[np.isfinite(x)]
    if x.size == 0:
        return x
    if np.nanmin(x) < 0:
        x = x - np.nanmin(x)
    return np.maximum(x, 0) + eps

def gini(x: np.ndarray) -> float:
    x = pos(x, eps=0.0)
    if x.size == 0:
        return np.nan
    s = np.sum(x)
    if s <= 0:
        return 0.0
    x = np.sort(x)
    n = x.size
    i = np.arange(1, n + 1)
    return float((2 * np.sum(i * x) / (n * s)) - (n + 1) / n)

def theil_t(x: np.ndarray) -> float:
    x = pos(x)
    if x.size == 0:
        return np.nan
    mu = np.mean(x)
    if mu <= 0:
        return 0.0
    r = x / mu
    return float(np.mean(r * np.log(r)))

def theil_l(x: np.ndarray) -> float:
    x = pos(x)
    if x.size == 0:
        return np.nan
    mu = np.mean(x)
    if mu <= 0:
        return 0.0
    return float(np.mean(np.log(mu / x)))

def atkinson(x: np.ndarray, epsilon=1.0) -> float:
    x = pos(x)
    if x.size == 0:
        return np.nan
    mu = np.mean(x)
    if mu <= 0:
        return 0.0
    if abs(epsilon - 1) < 1e-12:
        return float(1 - np.exp(np.mean(np.log(x))) / mu)
    ede = (np.mean(x ** (1 - epsilon))) ** (1 / (1 - epsilon))
    return float(1 - ede / mu)

def cv(x: np.ndarray) -> float:
    x = pos(x, eps=0.0)
    if x.size == 0:
        return np.nan
    m = np.mean(x)
    return float(np.std(x) / m) if m != 0 else 0.0

def top_share(x: np.ndarray, q=0.2) -> float:
    x = pos(x, eps=0.0)
    if x.size == 0:
        return np.nan
    s = np.sum(x)
    if s <= 0:
        return 0.0
    k = max(1, int(math.ceil(len(x) * q)))
    return float(np.sum(np.sort(x)[-k:]) / s)

def bottom_share(x: np.ndarray, q=0.2) -> float:
    x = pos(x, eps=0.0)
    if x.size == 0:
        return np.nan
    s = np.sum(x)
    if s <= 0:
        return 0.0
    k = max(1, int(math.ceil(len(x) * q)))
    return float(np.sum(np.sort(x)[:k]) / s)

def pratio(x: np.ndarray, high=90, low=10) -> float:
    x = pos(x, eps=0.0)
    if x.size == 0:
        return np.nan
    return float(np.nanpercentile(x, high) / (np.nanpercentile(x, low) + EPS))

def lorenz(x: np.ndarray, n=101) -> pd.DataFrame:
    x = pos(x, eps=0.0)
    grid = np.linspace(0, 1, n)
    if x.size == 0 or np.sum(x) <= 0:
        return pd.DataFrame({"CellShare": grid, "ValueShare": np.zeros_like(grid)})
    xs = np.sort(x)
    cum = np.concatenate([[0.0], np.cumsum(xs) / np.sum(xs)])
    share = np.linspace(0, 1, len(cum))
    return pd.DataFrame({"CellShare": grid, "ValueShare": np.interp(grid, share, cum)})

def hoover(x: np.ndarray) -> float:
    lp = lorenz(x)
    return float(np.max(np.abs(lp["CellShare"] - lp["ValueShare"])))

def summary(x: np.ndarray) -> Dict[str, float]:
    x0 = np.asarray(x, dtype="float64")
    v = x0[np.isfinite(x0)]
    if v.size == 0:
        return {"N": 0}
    b40 = bottom_share(v, 0.40)
    return {
        "N": int(v.size),
        "Mean": float(np.nanmean(v)),
        "Median": float(np.nanmedian(v)),
        "P10": float(np.nanpercentile(v, 10)),
        "P20": float(np.nanpercentile(v, 20)),
        "P80": float(np.nanpercentile(v, 80)),
        "P90": float(np.nanpercentile(v, 90)),
        "Gini": gini(v),
        "Theil_T": theil_t(v),
        "Theil_L": theil_l(v),
        "Atkinson_0_5": atkinson(v, 0.5),
        "Atkinson_1_0": atkinson(v, 1.0),
        "Atkinson_2_0": atkinson(v, 2.0),
        "CV": cv(v),
        "Top20_Share": top_share(v, 0.20),
        "Top10_Share": top_share(v, 0.10),
        "Top5_Share": top_share(v, 0.05),
        "Bottom20_Share": bottom_share(v, 0.20),
        "Bottom40_Share": b40,
        "Palma_Ratio": top_share(v, 0.10) / b40 if b40 and b40 > 0 else np.nan,
        "P90_P10_Ratio": pratio(v, 90, 10),
        "P80_P20_Ratio": pratio(v, 80, 20),
        "Hoover_Index": hoover(v),
    }

def robust01(arr: np.ndarray, mask: np.ndarray) -> np.ndarray:
    x = arr.astype("float64")
    valid = mask & np.isfinite(x)
    out = np.full_like(x, np.nan, dtype="float64")
    if valid.sum() == 0:
        return out
    lo, hi = np.nanpercentile(x[valid], [2, 98])
    if not np.isfinite(lo) or not np.isfinite(hi) or hi <= lo:
        out[valid] = 0.5
        return out
    out[valid] = np.clip((x[valid] - lo) / (hi - lo), 0, 1)
    return out

def mean_stack(arrs: List[Optional[np.ndarray]]) -> Optional[np.ndarray]:
    arrs = [a for a in arrs if a is not None]
    if not arrs:
        return None
    return np.nanmean(np.stack(arrs, axis=0), axis=0)

def benefit(s0: np.ndarray, sx: np.ndarray, target: str) -> np.ndarray:
    if BENEFIT_DIRECTION[target] == "decrease_is_benefit":
        return s0 - sx
    return sx - s0

def pos_benefit(x: np.ndarray) -> np.ndarray:
    return np.where(np.isfinite(x), np.maximum(x, 0), np.nan)

# ---------------------------------------------------------------------
# 3. 适应需求、适应供给、ACR 指标
# ---------------------------------------------------------------------
def exposure_indices(covs: Dict[str, np.ndarray], mask: np.ndarray):
    z = {k: robust01(v, mask) for k, v in covs.items()}

    out = {}
    out["Exposure_Population"] = mean_stack([z.get("PopD"), z.get("PD"), z.get("P")])
    out["Exposure_Economic"] = mean_stack([z.get("GDP"), z.get("NTL")])

    bd = z.get("BD")
    bh = z.get("BH")
    built = np.sqrt(np.maximum(bd, 0) * np.maximum(bh, 0)) if bd is not None and bh is not None else None
    out["Exposure_Built"] = mean_stack([built, z.get("RD"), z.get("NTL")])
    out["Exposure_Composite"] = mean_stack([
        out.get("Exposure_Population"),
        out.get("Exposure_Economic"),
        out.get("Exposure_Built")
    ])

    out["Ecological_Context"] = mean_stack([z.get("NDVI"), z.get("GVI"), z.get("Micro_PSA"), z.get("SVF")])
    out["Runoff_Pressure_Context"] = mean_stack([z.get("Micro_ISA"), z.get("BD"), z.get("RD")])

    return {k: v for k, v in out.items() if v is not None}

def build_adaptation_demand(f1_s0: np.ndarray, exposures: Dict[str, np.ndarray], mask: np.ndarray):
    out = {}
    f1_base = robust01(f1_s0, mask)

    for exp_name, exp_arr in exposures.items():
        if not exp_name.startswith("Exposure_"):
            continue
        out[f"Demand_{exp_name.replace('Exposure_', '')}"] = f1_base * exp_arr

    # 如果没有任何暴露变量，至少保留基准风险需求
    out["Demand_RiskOnly"] = f1_base
    return out

def build_benefit_and_acr(
    benefit_dict: Dict[str, np.ndarray],
    target_dict: Dict[str, np.ndarray],
    exposures: Dict[str, np.ndarray],
    demands: Dict[str, np.ndarray],
    mask: np.ndarray
):
    out = {}

    b1 = benefit_dict.get("F1")
    b2 = benefit_dict.get("F2")
    b3 = benefit_dict.get("F3")

    nb1 = robust01(pos_benefit(b1), mask) if b1 is not None else None
    nb2 = robust01(pos_benefit(b2), mask) if b2 is not None else None
    nb3 = robust01(pos_benefit(b3), mask) if b3 is not None else None

    total = mean_stack([nb1, nb2, nb3])
    if total is not None:
        out["Benefit_Total"] = total

    if b1 is not None:
        risk = pos_benefit(b1)
        risk01 = robust01(risk, mask)
        out["Benefit_RiskReduction"] = risk
        out["Benefit_RiskReduction_Normalized"] = risk01

        # 暴露加权风险削减
        if "Exposure_Population" in exposures:
            out["Benefit_PopExposureWeightedRiskReduction"] = risk * exposures["Exposure_Population"]
        if "Exposure_Economic" in exposures:
            out["Benefit_EconExposureWeightedRiskReduction"] = risk * exposures["Exposure_Economic"]
        if "Exposure_Built" in exposures:
            out["Benefit_BuiltExposureWeightedRiskReduction"] = risk * exposures["Exposure_Built"]
        if "Exposure_Composite" in exposures:
            out["Benefit_CompositeExposureWeightedRiskReduction"] = risk * exposures["Exposure_Composite"]

        # 适应供需覆盖率 ACR = supply / demand
        # 为了避免单位问题，使用归一化 risk benefit 作为 supply，Demand_* 已经是 0-1 风险×暴露需求。
        for dname, darr in demands.items():
            acr_name = dname.replace("Demand_", "ACR_")
            res_name = dname.replace("Demand_", "ResidualDemand_")
            mismatch_name = dname.replace("Demand_", "DemandBenefitMismatch_")
            aligned_name = dname.replace("Demand_", "DemandAlignedBenefit_")

            acr = risk01 / (darr + EPS)
            acr_capped = np.where(np.isfinite(acr), np.minimum(acr, 5), np.nan)
            residual = np.where(np.isfinite(darr) & np.isfinite(risk01), np.maximum(darr - risk01, 0), np.nan)
            mismatch = np.where(np.isfinite(darr) & np.isfinite(risk01), darr - risk01, np.nan)
            aligned = risk01 * darr

            out[acr_name] = acr_capped
            out[res_name] = residual
            out[mismatch_name] = mismatch
            out[aligned_name] = aligned

        # 公平导向：高基准风险 + 高暴露区域是否获得风险削减
        f1_cur = target_dict.get("F1")
        if f1_cur is not None:
            f1n = robust01(f1_cur, mask)
            if "Exposure_Population" in exposures:
                out["Benefit_EquityOrientedPopulationRiskReduction"] = risk * exposures["Exposure_Population"] * f1n
            if "Exposure_Economic" in exposures:
                out["Benefit_EquityOrientedEconomicRiskReduction"] = risk * exposures["Exposure_Economic"] * f1n

    if b2 is not None:
        live = pos_benefit(b2)
        out["Benefit_LivabilityEcological"] = live
        if "Ecological_Context" in exposures:
            out["Benefit_EcologyContextWeightedLivability"] = live * exposures["Ecological_Context"]

    if b3 is not None:
        func = pos_benefit(b3)
        out["Benefit_FunctionRetention"] = func
        if "Exposure_Built" in exposures:
            out["Benefit_BuiltContextWeightedFunctionRetention"] = func * exposures["Exposure_Built"]

    return out

# ---------------------------------------------------------------------
# 4. 分组与 OR
# ---------------------------------------------------------------------
def deviation_groups(x: np.ndarray, mask: np.ndarray):
    out = np.full(x.shape, "", dtype=object)
    vals = x[mask & np.isfinite(x)]
    if vals.size == 0:
        return out
    p20, p80 = np.nanpercentile(vals, [20, 80])
    out[(x <= p20) & mask] = "worse_off"
    out[(x > p20) & (x < p80) & mask] = "average"
    out[(x >= p80) & mask] = "better_off"
    return out

def odds_ratio(groups, event, boot=200, seed=42, ref="better_off"):
    m = (groups != "") & np.isfinite(event)
    g = groups[m]
    y = event[m].astype(int)
    if y.size == 0 or np.sum(g == ref) == 0:
        return pd.DataFrame()

    rng = np.random.default_rng(seed)
    if y.size > 200000:
        idx = rng.choice(np.arange(y.size), 200000, replace=False)
        g = g[idx]; y = y[idx]

    def odds(label, gg=g, yy=y):
        mm = gg == label
        return (np.sum(yy[mm] == 1) + 0.5) / (np.sum(yy[mm] == 0) + 0.5)

    ref_odds = odds(ref)
    rows = []
    ids = np.arange(y.size)

    for label in ["worse_off", "average", "better_off"]:
        if np.sum(g == label) == 0:
            continue
        val = odds(label) / ref_odds
        boots = []
        for _ in range(boot):
            bidx = rng.choice(ids, len(ids), replace=True)
            gb = g[bidx]; yb = y[bidx]
            if np.sum(gb == label) == 0 or np.sum(gb == ref) == 0:
                continue
            def odds_b(lab):
                mm = gb == lab
                return (np.sum(yb[mm] == 1)+0.5) / (np.sum(yb[mm] == 0)+0.5)
            boots.append(odds_b(label) / odds_b(ref))

        if boots:
            boots = np.asarray(boots)
            lo, hi = np.nanpercentile(boots, [2.5, 97.5])
            p = min(1.0, 2 * min(np.mean(boots <= 1), np.mean(boots >= 1)))
        else:
            lo, hi, p = np.nan, np.nan, np.nan

        rows.append({
            "Group": label, "Reference": ref, "N": int(np.sum(g == label)),
            "EventRate": float(np.mean(y[g == label])),
            "ReferenceEventRate": float(np.mean(y[g == ref])),
            "OddsRatio": float(val),
            "LogOddsRatio": float(np.log(val)) if val > 0 else np.nan,
            "CI2_5": float(lo), "CI97_5": float(hi), "p_bootstrap": p
        })
    return pd.DataFrame(rows)

def demand_quintile_table(city, scenario, demand_arr, benefit_arr, acr_arr, residual_arr, mask, demand_name):
    valid = mask & np.isfinite(demand_arr) & np.isfinite(benefit_arr)
    vals = demand_arr[valid]
    if vals.size == 0:
        return []
    qs = np.nanpercentile(vals, [20, 40, 60, 80])
    bins = np.digitize(vals, qs, right=True) + 1

    b = benefit_arr[valid]
    a = acr_arr[valid] if acr_arr is not None else np.full_like(b, np.nan)
    r = residual_arr[valid] if residual_arr is not None else np.full_like(b, np.nan)

    rows = []
    total_b = np.nansum(b)
    for q in range(1, 6):
        m = bins == q
        rows.append({
            "City": city,
            "Scenario": scenario,
            "DemandIndicator": demand_name,
            "DemandQuintile": f"Q{q}",
            "N": int(np.sum(m)),
            "MeanDemand": float(np.nanmean(vals[m])) if np.sum(m) else np.nan,
            "MeanBenefit": float(np.nanmean(b[m])) if np.sum(m) else np.nan,
            "ShareOfTotalBenefit": float(np.nansum(b[m]) / (total_b + EPS)) if np.sum(m) else np.nan,
            "MeanACR": float(np.nanmean(a[m])) if np.sum(m) else np.nan,
            "MeanResidualDemand": float(np.nanmean(r[m])) if np.sum(m) else np.nan,
        })
    return rows

# ---------------------------------------------------------------------
# 5. 蜂巢聚合
# ---------------------------------------------------------------------
def hex_ids(xs, ys, radius, origin_x, origin_y):
    X = xs - origin_x
    Y = ys - origin_y
    q = (2/3 * X) / radius
    r = (-1/3 * X + np.sqrt(3)/3 * Y) / radius

    x = q; z = r; y = -x-z
    rx, ry, rz = np.round(x), np.round(y), np.round(z)
    xd, yd, zd = abs(rx-x), abs(ry-y), abs(rz-z)

    mx = (xd > yd) & (xd > zd)
    my = (~mx) & (yd > zd)
    mz = ~(mx | my)
    rx[mx] = -ry[mx] - rz[mx]
    ry[my] = -rx[my] - rz[my]
    rz[mz] = -rx[mz] - ry[mz]

    q = rx.astype(int)
    r = rz.astype(int)
    key = np.char.add(np.char.add(q.astype(str), "_"), r.astype(str))
    return q, r, key

def hex_center(q, r, radius, origin_x, origin_y):
    x = radius * (3/2 * q)
    y = radius * (np.sqrt(3) * (r + q/2))
    return origin_x + x, origin_y + y

def make_hex(cx, cy, radius):
    if Polygon is None:
        return ""
    angles = np.deg2rad(np.arange(0, 360, 60))
    return Polygon([(cx + radius*np.cos(a), cy + radius*np.sin(a)) for a in angles]).wkt

def aggregate_hex(arr, ref_meta, city, scenario, indicator, target, radius, sample_step):
    print(f"    [HEX] {city} {scenario} {indicator}", flush=True)
    mask = np.isfinite(arr)
    if mask.sum() == 0:
        return pd.DataFrame()

    rows, cols = np.where(mask)
    if sample_step > 1:
        rows = rows[::sample_step]
        cols = cols[::sample_step]
    vals = arr[rows, cols]
    xs, ys = xy(ref_meta["transform"], rows, cols, offset="center")
    xs = np.asarray(xs); ys = np.asarray(ys)

    origin_x, origin_y = ref_meta["bounds"].left, ref_meta["bounds"].bottom
    q, r, keys = hex_ids(xs, ys, radius, origin_x, origin_y)

    df = pd.DataFrame({"q": q, "r": r, "hex_key": keys, "value": vals})
    df = df[np.isfinite(df["value"])]
    if df.empty:
        return df

    def _sum(g):
        v = g["value"].to_numpy()
        return pd.Series({
            "N_pix": len(v),
            "Mean": np.nanmean(v),
            "Median": np.nanmedian(v),
            "P10": np.nanpercentile(v, 10),
            "P90": np.nanpercentile(v, 90),
            "Std": np.nanstd(v),
            "Gini": gini(v),
            "Theil_T": theil_t(v),
            "Top20_Share": top_share(v, 0.2),
        })

    out = df.groupby(["q", "r", "hex_key"]).apply(_sum).reset_index()
    out["City"] = city
    out["Scenario"] = scenario
    out["Target"] = target
    out["Indicator"] = indicator
    out["HexRadius"] = radius
    out["OriginX"] = origin_x
    out["OriginY"] = origin_y
    centers = [hex_center(int(a), int(b), radius, origin_x, origin_y) for a, b in zip(out["q"], out["r"])]
    out["center_x"] = [c[0] for c in centers]
    out["center_y"] = [c[1] for c in centers]
    out["geometry"] = [make_hex(c[0], c[1], radius) for c in centers]
    return out

# ---------------------------------------------------------------------
# 6. 城市数据加载
# ---------------------------------------------------------------------
def load_city_targets(target_inv: pd.DataFrame, city: str):
    city_inv = target_inv[target_inv.City == city]
    ref_row = city_inv[(city_inv.Scenario == "S0") & (city_inv.Target == "F1")]
    if ref_row.empty:
        ref_row = city_inv.iloc[[0]]
    ref_arr, ref_meta = read_raster(Path(ref_row.Path.iloc[0]))

    targets = {}
    for _, row in tqdm(list(city_inv.iterrows()), total=len(city_inv), desc=f"{city} load F rasters", unit="file"):
        arr, meta = read_raster(Path(row.Path))
        if arr.shape != ref_arr.shape or meta["transform"] != ref_meta["transform"] or meta["crs"] != ref_meta["crs"]:
            arr = align_to_ref(Path(row.Path), ref_meta, categorical=False)
        targets[(row.Scenario, row.Target)] = arr

    return targets, ref_meta

def load_covariates(city: str, scenario_cov_inv, base_cov_inv, scenario: str, ref_meta: dict):
    covs = {}

    sc = scenario_cov_inv[(scenario_cov_inv.City == city) & (scenario_cov_inv.Scenario == scenario)]
    for _, row in sc.iterrows():
        cov = row.Covariate
        categorical = cov == "LULC"
        covs[cov] = align_to_ref(Path(row.Path), ref_meta, categorical=categorical)

    bc = base_cov_inv[base_cov_inv.City == city] if not base_cov_inv.empty else pd.DataFrame()
    for _, row in bc.iterrows():
        if row.Covariate not in covs:
            cov = row.Covariate
            categorical = cov == "LULC"
            covs[cov] = align_to_ref(Path(row.Path), ref_meta, categorical=categorical)

    return covs

# ---------------------------------------------------------------------
# 7. 主程序
# ---------------------------------------------------------------------
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--project-root", default=DEFAULT_PROJECT_ROOT)
    parser.add_argument("--scenario-root", default=DEFAULT_SCENARIO_ROOT)
    parser.add_argument("--output-dir", default=DEFAULT_OUTPUT_DIR)
    parser.add_argument("--hex-size", type=float, default=DEFAULT_HEX_SIZE)
    parser.add_argument("--sample-step", type=int, default=DEFAULT_SAMPLE_STEP)
    parser.add_argument("--lorenz-points", type=int, default=101)
    parser.add_argument("--bootstrap", type=int, default=DEFAULT_BOOTSTRAP)
    args = parser.parse_args()

    project_root = Path(args.project_root)
    scenario_root = Path(args.scenario_root)
    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    target_inv, scenario_cov_inv, debug = inventory_scenario_rasters(scenario_root)
    base_cov_inv = inventory_base_covariates(project_root)

    debug.to_csv(out_dir / "00_DEBUG_all_tifs_in_city_scenario_rasters.csv", index=False, encoding="utf-8-sig")
    target_inv.to_csv(out_dir / "00_target_file_inventory.csv", index=False, encoding="utf-8-sig")
    scenario_cov_inv.to_csv(out_dir / "00_scenario_covariate_file_inventory.csv", index=False, encoding="utf-8-sig")
    base_cov_inv.to_csv(out_dir / "00_base_covariate_file_inventory.csv", index=False, encoding="utf-8-sig")

    print("\n[MATCHED TARGETS]", flush=True)
    print(target_inv.head(80).to_string(index=False), flush=True)

    if target_inv.empty:
        raise FileNotFoundError("没有匹配到 S0-S7 的 F1/F2/F3。请查看 00_DEBUG_all_tifs_in_city_scenario_rasters.csv")

    all_index, all_lorenz, all_change, all_coupled, all_dev, all_odds = [], [], [], [], [], []
    all_demand_quintile, all_hex = [], []
    city_crs = None

    for city in tqdm(CITY_ORDER, desc="Cities", unit="city"):
        city_targets = target_inv[target_inv.City == city]
        if city_targets.empty:
            continue

        print(f"\n[PROCESS] {city}", flush=True)
        targets, ref_meta = load_city_targets(target_inv, city)
        if city_crs is None:
            city_crs = ref_meta["crs"]

        valid_mask = np.zeros((ref_meta["height"], ref_meta["width"]), dtype=bool)
        for arr in targets.values():
            valid_mask |= np.isfinite(arr)

        # 原始目标不平等
        for (sc, tar), arr in tqdm(list(targets.items()), desc=f"{city} raw indices + raw hex", unit="raster"):
            vals = finite_vals(arr)
            row = summary(vals)
            row.update({"City": city, "Scenario": sc, "Target": tar, "Indicator": f"Raw_{tar}", "ValueType": "Raw"})
            all_index.append(row)

            lp = lorenz(vals, args.lorenz_points)
            lp["City"] = city; lp["Scenario"] = sc; lp["Target"] = tar; lp["Indicator"] = f"Raw_{tar}"; lp["ValueType"] = "Raw"
            all_lorenz.append(lp)

            all_hex.append(aggregate_hex(arr, ref_meta, city, sc, f"Raw_{tar}", tar, args.hex_size, args.sample_step))

        # S0-S7 变化
        for tar in TARGETS:
            s0 = targets.get(("S0", tar)); s7 = targets.get(("S7", tar))
            if s0 is None or s7 is None:
                continue
            r0 = summary(finite_vals(s0)); r7 = summary(finite_vals(s7))
            rec = {"City": city, "Target": tar}
            for col in ["Mean","Median","Gini","Theil_T","Atkinson_1_0","Top20_Share","P90_P10_Ratio","Hoover_Index"]:
                rec[f"{col}_S0"] = r0.get(col, np.nan)
                rec[f"{col}_S7"] = r7.get(col, np.nan)
                rec[f"{col}_Delta_S7_minus_S0"] = r7.get(col, np.nan) - r0.get(col, np.nan)
                rec[f"{col}_RelativeChange_pct"] = (r7.get(col, np.nan) - r0.get(col, np.nan)) / r0.get(col, np.nan) * 100 if r0.get(col, 0) not in [0, np.nan] else np.nan
            all_change.append(rec)

        # 情景收益、供需匹配、ACR
        for sc in tqdm(SCENARIOS, desc=f"{city} benefits + ACR + OR", unit="scenario"):
            if sc == "S0":
                continue

            benefit_dict, target_dict = {}, {}

            for tar in TARGETS:
                s0 = targets.get(("S0", tar))
                sx = targets.get((sc, tar))
                if s0 is None or sx is None:
                    continue

                b = benefit(s0, sx, tar)
                benefit_dict[tar] = b
                target_dict[tar] = sx

                # signed benefit
                bv = finite_vals(b)
                all_coupled.append({
                    "City": city, "Scenario": sc, "Target": tar,
                    "Indicator": f"BenefitSigned_{tar}", "ValueType": "BenefitSigned",
                    "N": int(bv.size),
                    "Mean": float(np.nanmean(bv)) if bv.size else np.nan,
                    "Median": float(np.nanmedian(bv)) if bv.size else np.nan,
                    "PositiveShare": float(np.mean(bv > 0)) if bv.size else np.nan,
                })

                # positive benefit inequality
                bp = pos_benefit(b)
                vals = finite_vals(bp)
                row = summary(vals)
                row.update({"City": city, "Scenario": sc, "Target": tar, "Indicator": f"Benefit_{tar}", "ValueType": "BenefitPositive"})
                all_index.append(row)

                lp = lorenz(vals, args.lorenz_points)
                lp["City"] = city; lp["Scenario"] = sc; lp["Target"] = tar; lp["Indicator"] = f"Benefit_{tar}"; lp["ValueType"] = "BenefitPositive"
                all_lorenz.append(lp)

                all_hex.append(aggregate_hex(bp, ref_meta, city, sc, f"Benefit_{tar}", tar, args.hex_size, args.sample_step))

            if not benefit_dict:
                continue

            covs = load_covariates(city, scenario_cov_inv, base_cov_inv, sc, ref_meta)
            exp = exposure_indices(covs, valid_mask)
            f1_s0 = targets.get(("S0", "F1"))
            demands = build_adaptation_demand(f1_s0, exp, valid_mask) if f1_s0 is not None else {}
            coupled = build_benefit_and_acr(benefit_dict, target_dict, exp, demands, valid_mask)

            for ind, arr in coupled.items():
                vals = finite_vals(arr)
                row = summary(vals)
                row.update({"City": city, "Scenario": sc, "Target": "CompositeOrCoupled", "Indicator": ind, "ValueType": "CoupledBenefitOrACR"})
                all_index.append(row)

                lp = lorenz(vals, args.lorenz_points)
                lp["City"] = city; lp["Scenario"] = sc; lp["Target"] = "CompositeOrCoupled"; lp["Indicator"] = ind; lp["ValueType"] = "CoupledBenefitOrACR"
                all_lorenz.append(lp)

                # 蜂巢只保存关键指标，避免输出过大
                keep_hex = (
                    ind in [
                        "Benefit_Total", "Benefit_RiskReduction",
                        "Benefit_PopExposureWeightedRiskReduction",
                        "Benefit_EconExposureWeightedRiskReduction",
                        "Benefit_BuiltExposureWeightedRiskReduction",
                        "Benefit_CompositeExposureWeightedRiskReduction",
                        "ACR_Composite", "ACR_Population", "ACR_Economic", "ACR_Built",
                        "ResidualDemand_Composite", "ResidualDemand_Population",
                        "DemandBenefitMismatch_Composite",
                        "DemandAlignedBenefit_Composite"
                    ]
                )
                if keep_hex:
                    all_hex.append(aggregate_hex(arr, ref_meta, city, sc, ind, "CompositeOrCoupled", args.hex_size, args.sample_step))

            # Demand 本身也作为绘图数据
            for dname, darr in demands.items():
                vals = finite_vals(darr)
                row = summary(vals)
                row.update({"City": city, "Scenario": sc, "Target": "Demand", "Indicator": dname, "ValueType": "AdaptationDemand"})
                all_index.append(row)

                lp = lorenz(vals, args.lorenz_points)
                lp["City"] = city; lp["Scenario"] = sc; lp["Target"] = "Demand"; lp["Indicator"] = dname; lp["ValueType"] = "AdaptationDemand"
                all_lorenz.append(lp)

                if dname in ["Demand_Composite", "Demand_Population", "Demand_Economic", "Demand_Built", "Demand_RiskOnly"]:
                    all_hex.append(aggregate_hex(darr, ref_meta, city, sc, dname, "Demand", args.hex_size, args.sample_step))

            # high-demand benefit coverage + demand quintile table
            risk_benefit_norm = coupled.get("Benefit_RiskReduction_Normalized")
            for dname, darr in demands.items():
                if risk_benefit_norm is None:
                    continue
                m = valid_mask & np.isfinite(darr) & np.isfinite(risk_benefit_norm)
                if m.sum() < 20:
                    continue
                dvals = darr[m]
                bvals = risk_benefit_norm[m]
                high = dvals >= np.nanpercentile(dvals, 80)
                all_coupled.append({
                    "City": city,
                    "Scenario": sc,
                    "Target": "F1",
                    "Indicator": f"HighDemandBenefitCoverage_{dname}",
                    "ValueType": "SupplyDemandMatching",
                    "N": int(m.sum()),
                    "HighDemandCellShare": float(np.mean(high)),
                    "HighDemandBenefitShare": float(np.nansum(bvals[high]) / (np.nansum(bvals) + EPS)),
                    "DemandBenefitPearson": float(np.corrcoef(dvals, bvals)[0,1]) if np.nanstd(dvals) > 0 and np.nanstd(bvals) > 0 else np.nan,
                })

                acr_name = dname.replace("Demand_", "ACR_")
                res_name = dname.replace("Demand_", "ResidualDemand_")
                all_demand_quintile.extend(
                    demand_quintile_table(
                        city=city,
                        scenario=sc,
                        demand_arr=darr,
                        benefit_arr=risk_benefit_norm,
                        acr_arr=coupled.get(acr_name),
                        residual_arr=coupled.get(res_name),
                        mask=valid_mask,
                        demand_name=dname
                    )
                )

            # worse_off / average / better_off + OR
            bt = coupled.get("Benefit_Total")
            if bt is not None:
                groups = deviation_groups(bt - np.nanmean(bt[valid_mask]), valid_mask)
                for lab in ["worse_off", "average", "better_off"]:
                    m = (groups == lab) & valid_mask
                    all_dev.append({
                        "City": city, "Scenario": sc,
                        "DeviationBasis": "Benefit_Total_minus_city_mean",
                        "Group": lab,
                        "N": int(m.sum()),
                        "MeanBenefitTotal": float(np.nanmean(bt[m])) if m.sum() else np.nan,
                        "ShareOfTotalBenefit": float(np.nansum(bt[m]) / (np.nansum(bt[valid_mask]) + EPS)) if m.sum() else np.nan,
                    })

                # 残余高风险 OR
                f1 = targets.get((sc, "F1"))
                if f1 is not None:
                    rv = f1[valid_mask & np.isfinite(f1)]
                    if rv.size:
                        event = np.where(np.isfinite(f1), f1 >= np.nanpercentile(rv, 80), np.nan)
                        od = odds_ratio(groups, event, boot=args.bootstrap)
                        if not od.empty:
                            od["City"] = city; od["Scenario"] = sc; od["Outcome"] = "ResidualHighRisk_F1_Top20"
                            all_odds.append(od)

                # 收益不足 OR
                bv = bt[valid_mask & np.isfinite(bt)]
                if bv.size:
                    event = np.where(np.isfinite(bt), bt <= np.nanpercentile(bv, 20), np.nan)
                    od = odds_ratio(groups, event, boot=args.bootstrap)
                    if not od.empty:
                        od["City"] = city; od["Scenario"] = sc; od["Outcome"] = "InsufficientBenefit_Total_Bottom20"
                        all_odds.append(od)

                # 残余需求 OR：高 residual demand top20
                rd = coupled.get("ResidualDemand_Composite")
                if rd is not None:
                    rv = rd[valid_mask & np.isfinite(rd)]
                    if rv.size:
                        event = np.where(np.isfinite(rd), rd >= np.nanpercentile(rv, 80), np.nan)
                        od = odds_ratio(groups, event, boot=args.bootstrap)
                        if not od.empty:
                            od["City"] = city; od["Scenario"] = sc; od["Outcome"] = "ResidualDemand_Composite_Top20"
                            all_odds.append(od)

    # 保存结果
    index_df = pd.DataFrame(all_index)
    lorenz_df = pd.concat(all_lorenz, ignore_index=True) if all_lorenz else pd.DataFrame()
    change_df = pd.DataFrame(all_change)
    coupled_df = pd.DataFrame(all_coupled)
    dev_df = pd.DataFrame(all_dev)
    odds_df = pd.concat(all_odds, ignore_index=True) if all_odds else pd.DataFrame()
    demand_q_df = pd.DataFrame(all_demand_quintile)
    hex_df = pd.concat([h for h in all_hex if isinstance(h, pd.DataFrame) and not h.empty], ignore_index=True) if all_hex else pd.DataFrame()

    index_df.to_csv(out_dir / "01_pixel_inequality_indices_all_indicators.csv", index=False, encoding="utf-8-sig")
    lorenz_df.to_csv(out_dir / "02_lorenz_curve_points.csv", index=False, encoding="utf-8-sig")
    change_df.to_csv(out_dir / "03_s0_s7_target_inequality_change.csv", index=False, encoding="utf-8-sig")
    coupled_df.to_csv(out_dir / "04_exposure_coupled_benefit_and_matching_summary.csv", index=False, encoding="utf-8-sig")
    dev_df.to_csv(out_dir / "05_benefit_deviation_groups_summary.csv", index=False, encoding="utf-8-sig")
    if not odds_df.empty:
        odds_df.to_csv(out_dir / "06_residual_disadvantage_odds_ratios.csv", index=False, encoding="utf-8-sig")
    if not demand_q_df.empty:
        demand_q_df.to_csv(out_dir / "07_demand_quintile_benefit_distribution.csv", index=False, encoding="utf-8-sig")
    if not hex_df.empty:
        hex_df.to_csv(out_dir / "08_hexagon_honeycomb_plotting_data.csv", index=False, encoding="utf-8-sig")
        if HAS_GEO and "geometry" in hex_df.columns:
            try:
                gdf = hex_df.copy()
                gdf["geometry"] = gdf["geometry"].apply(wkt.loads)
                gdf = gpd.GeoDataFrame(gdf, geometry="geometry", crs=city_crs)
                gdf.to_file(out_dir / "08_hexagon_honeycomb_plotting_data.gpkg", layer="hex_stats", driver="GPKG")
            except Exception as e:
                print("[WARN] GPKG export failed:", e)

    if not index_df.empty:
        scen_summary = index_df.groupby(["Indicator","ValueType","Scenario"], dropna=False)[
            ["Mean","Median","Gini","Theil_T","Atkinson_1_0","Top20_Share","P90_P10_Ratio","Hoover_Index"]
        ].agg(["mean","median","std","min","max"]).reset_index()
        scen_summary.columns = ["_".join([str(x) for x in c if str(x)!=""]) for c in scen_summary.columns.to_flat_index()]
        scen_summary.to_csv(out_dir / "09_scenario_summary_for_plotting.csv", index=False, encoding="utf-8-sig")

    if not hex_df.empty:
        hs = hex_df.groupby(["City","Scenario","Target","Indicator"]).agg(
            HexN=("hex_key","nunique"),
            Mean_of_hex_mean=("Mean","mean"),
            Median_of_hex_median=("Median","median"),
            Mean_hex_gini=("Gini","mean"),
            Mean_hex_theil=("Theil_T","mean"),
            Mean_hex_top20=("Top20_Share","mean"),
        ).reset_index()
        hs.to_csv(out_dir / "10_hexagon_summary_for_plotting.csv", index=False, encoding="utf-8-sig")

    readme = f"""V50 outputs

Scenario raster root:
{scenario_root}

Project root:
{project_root}

Key additions in V50:
- Adaptation demand = normalized S0 F1 × exposure
- ACR = normalized risk-reduction supply / adaptation demand
- ResidualDemand = max(demand - supply, 0)
- DemandBenefitMismatch = demand - supply
- DemandAlignedBenefit = supply × demand
- Demand quintile table
- ResidualDemand odds ratio

Core outputs:
00_DEBUG_all_tifs_in_city_scenario_rasters.csv
00_target_file_inventory.csv
00_scenario_covariate_file_inventory.csv
00_base_covariate_file_inventory.csv
01_pixel_inequality_indices_all_indicators.csv
02_lorenz_curve_points.csv
03_s0_s7_target_inequality_change.csv
04_exposure_coupled_benefit_and_matching_summary.csv
05_benefit_deviation_groups_summary.csv
06_residual_disadvantage_odds_ratios.csv
07_demand_quintile_benefit_distribution.csv
08_hexagon_honeycomb_plotting_data.csv
08_hexagon_honeycomb_plotting_data.gpkg
09_scenario_summary_for_plotting.csv
10_hexagon_summary_for_plotting.csv

Interpretation:
F1 benefit = F1_S0 - F1_Sx.
F2 benefit = F2_Sx - F2_S0.
F3 benefit = F3_Sx - F3_S0 by default.
If F3 is CGI loss, change BENEFIT_DIRECTION['F3'] to decrease_is_benefit.
"""
    (out_dir / "README_outputs.txt").write_text(readme, encoding="utf-8")

    print("\n[DONE] outputs saved to:", out_dir, flush=True)
    for p in sorted(out_dir.iterdir()):
        print(" -", p.name, flush=True)

if __name__ == "__main__":
    main()
