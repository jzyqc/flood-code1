# -*- coding: utf-8 -*-
"""
Plot source-data summary figures from SourceData_Fig1.xlsx--SourceData_Fig5.xlsx.

This script intentionally reads the clean source-data workbooks rather than using
local absolute paths. It provides a portable figure-regeneration scaffold for
manuscript submission. The full spatial raster rendering workflow is preserved in
legacy_reference_scripts/ for environments where the original rasters are available.
"""
from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

from config_project import FIGURE_DATA, OUTPUT_DIR

plt.rcParams.update({
    "font.family": "Times New Roman",
    "axes.unicode_minus": False,
    "font.size": 9,
    "axes.titlesize": 11,
    "axes.labelsize": 9,
    "legend.fontsize": 8,
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
})

def savefig(fig, name):
    out = OUTPUT_DIR / name
    fig.tight_layout()
    fig.savefig(out.with_suffix(".png"), dpi=600, bbox_inches="tight")
    fig.savefig(out.with_suffix(".pdf"), bbox_inches="tight")
    plt.close(fig)

def plot_fig1_model_performance():
    df = pd.read_excel(FIGURE_DATA["fig1"], sheet_name="Model_Holdout")
    df = df.sort_values("AUC", ascending=True)
    fig, ax = plt.subplots(figsize=(7.2, 6.0))
    ax.barh(df["Model"], df["AUC"])
    ax.set_xlabel("Holdout AUC")
    ax.set_title("Figure 1 source summary: model discrimination")
    savefig(fig, "Fig1_model_holdout_auc")

def plot_fig1_shap_summary():
    df = pd.read_excel(FIGURE_DATA["fig1"], sheet_name="SHAP_Group")
    fig, ax = plt.subplots(figsize=(5.0, 3.2))
    ax.barh(df["Mechanism group"], df["Grouped |SHAP|"])
    ax.set_xlabel("Grouped |SHAP|")
    ax.set_title("Figure 1 source summary: grouped SHAP")
    savefig(fig, "Fig1_grouped_shap")

def plot_fig2_frontier_summary():
    df = pd.read_excel(FIGURE_DATA["fig2"], sheet_name="City_S7_Frontier")
    df = df[pd.to_numeric(df["F1 reduction relative to S0 (%)"], errors="coerce").notna()].copy()
    df["F1 reduction relative to S0 (%)"] = pd.to_numeric(df["F1 reduction relative to S0 (%)"])
    df["F2 improvement relative to S0 (%)"] = pd.to_numeric(df["F2 improvement relative to S0 (%)"])
    fig, ax = plt.subplots(figsize=(4.5, 3.5))
    ax.scatter(df["F1 reduction relative to S0 (%)"], df["F2 improvement relative to S0 (%)"], s=70)
    for _, r in df.iterrows():
        ax.text(r["F1 reduction relative to S0 (%)"], r["F2 improvement relative to S0 (%)"], str(r["City"]), fontsize=8)
    ax.set_xlabel("F1 reduction relative to S0 (%)")
    ax.set_ylabel("F2 improvement relative to S0 (%)")
    ax.set_title("Figure 2 source summary: S7 city frontier")
    savefig(fig, "Fig2_S7_frontier_summary")

def plot_fig3_q5_benefit():
    df = pd.read_excel(FIGURE_DATA["fig3"], sheet_name="Q5_Benefit_Shares")
    fig, ax = plt.subplots(figsize=(6.4, 3.2))
    ax.plot(df["Demand definition"], df["Q5 benefit share (%)"], marker="o")
    ax.set_ylabel("Q5 benefit share (%)")
    ax.set_title("Figure 3 source summary: benefit captured by Q5")
    ax.tick_params(axis="x", rotation=25)
    savefig(fig, "Fig3_Q5_benefit_share")

def plot_fig4_lever_changes():
    df = pd.read_excel(FIGURE_DATA["fig4"], sheet_name="Lever_Change_Shares")
    fig, ax = plt.subplots(figsize=(6.0, 3.5))
    ax.bar(df["Variable / response"], df["Share of total normalized change (%)"])
    ax.set_ylabel("Share of total normalized change (%)")
    ax.set_title("Figure 4 source summary: planning-lever responses")
    ax.tick_params(axis="x", rotation=35)
    savefig(fig, "Fig4_planning_lever_shares")

def plot_fig5_future_targeting():
    df = pd.read_excel(FIGURE_DATA["fig5"], sheet_name="Future_Aggregate")
    row = df[df["Metric"] == "Q5 targeting"].iloc[0]
    vals = {
        "SSP1-2.6": row["SSP1-2.6"],
        "SSP2-4.5": row["SSP2-4.5"],
        "SSP5-8.5": row["SSP5-8.5"],
    }
    fig, ax = plt.subplots(figsize=(4.8, 3.3))
    ax.bar(list(vals.keys()), list(vals.values()))
    ax.set_ylabel("Q5 targeting (%)")
    ax.set_title("Figure 5 source summary: future Q5 targeting at 2100")
    savefig(fig, "Fig5_future_Q5_targeting")

def main():
    plot_fig1_model_performance()
    plot_fig1_shap_summary()
    plot_fig2_frontier_summary()
    plot_fig3_q5_benefit()
    plot_fig4_lever_changes()
    plot_fig5_future_targeting()
    print(f"Saved summary plots to: {OUTPUT_DIR}")

if __name__ == "__main__":
    main()
