import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib import patches, colormaps
from matplotlib.colors import Normalize, TwoSlopeNorm, ListedColormap, BoundaryNorm
from matplotlib.cm import ScalarMappable
from matplotlib.gridspec import GridSpec
from mpl_toolkits.axes_grid1.inset_locator import inset_axes

plt.rcParams.update({
    "font.family": "serif",
    "font.serif": ["Times New Roman", "DejaVu Serif", "Liberation Serif"],
    "axes.unicode_minus": False,
    "font.size": 12,
    "font.weight": "bold",
    "axes.titlesize": 13,
    "axes.titleweight": "bold",
    "axes.labelsize": 12,
    "axes.labelweight": "bold",
    "xtick.labelsize": 10,
    "ytick.labelsize": 10,
    "legend.fontsize": 8.5,
    "axes.linewidth": 1.0,
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
    "figure.facecolor": "white",
    "axes.facecolor": "white",
    "savefig.facecolor": "white",
})
CMAP = colormaps["RdYlBu_r"]
C_DARK = "#0D2B4A"
C_GRID = "#DDE5EC"
city_order = ["Beijing", "Shanghai", "Guangzhou", "Shenzhen", "Tianjin", "Chengdu"]
city_short = {"Beijing":"BJ", "Shanghai":"SH", "Guangzhou":"GZ", "Shenzhen":"SZ", "Tianjin":"TJ", "Chengdu":"CD"}

def style_axes(ax, grid=True):
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_color("#7A8793")
    ax.spines["bottom"].set_color("#7A8793")
    ax.spines["left"].set_linewidth(1.0)
    ax.spines["bottom"].set_linewidth(1.0)
    if grid:
        ax.grid(True, color=C_GRID, linewidth=0.8, alpha=0.36, zorder=0)
    for t in ax.get_xticklabels() + ax.get_yticklabels():
        t.set_fontweight("bold")

def panel_title(ax, letter, title, fs=13.0):
    ax.set_title(f"{letter}  {title}", loc="left", fontsize=fs, fontweight="bold", color=C_DARK, pad=4)

def build_figure1(hex_csv, adaptive_csv=None, out_png="Figure1.png", out_pdf="Figure1.pdf"):
    hex_cols = ["q","r","N_pix","CenterX","CenterY","City","Scenario","Indicator","Mean"]
    hex_df = pd.read_csv(hex_csv, usecols=hex_cols)

    hex_vars = [
        ("RawF1", "Raw F1", "Flood adaptation burden"),
        ("RawF2", "Raw F2", "Livability / ecological benefit"),
        ("RawF3", "Raw F3", "Function retention / CGI benefit"),
        ("BenefitTotal", "Benefit\nTotal", "Total adaptation benefit"),
        ("DemandComposite", "Demand\nComposite", "Multi-hazard demand pressure"),
        ("DemandAlignedBenefitComposite", "Demand-Aligned\nBenefit", "Benefit where demand is high"),
        ("ACRComposite", "ACR\nComposite", "Adaptive coverage ratio"),
        ("MismatchComposite", "Mismatch\nComposite", "Benefit–demand mismatch"),
        ("ResidualDemandComposite", "Residual\nDemand", "Unmet demand after delivered benefit"),
        ("UnmetHighDemand", "Unmet\nHigh Demand", "High-demand areas still unmet"),
    ]
    hex_s7 = hex_df[(hex_df["Scenario"]=="S7") & (hex_df["Indicator"].isin([x[0] for x in hex_vars]))].copy()

    # adaptive coarsening: Shenzhen-like sparse cities fall back to factor=1
    records = []
    factor_table = []
    for city in city_order:
        city_sub = hex_s7[hex_s7["City"] == city].copy()
        raw_f1 = city_sub[city_sub["Indicator"] == "RawF1"].copy()
        tmp = raw_f1.copy()
        tmp["qg"] = np.floor(tmp["q"].astype(float)/2).astype(int)
        tmp["rg"] = np.floor(tmp["r"].astype(float)/2).astype(int)
        grouped_n = len(tmp.groupby(["qg","rg"], observed=False))
        factor = 1 if grouped_n < 80 else 2
        city_sub["factor_used"] = factor
        city_sub["qg"] = np.floor(city_sub["q"].astype(float)/factor).astype(int)
        city_sub["rg"] = np.floor(city_sub["r"].astype(float)/factor).astype(int)
        records.append(city_sub)
        factor_table.append({"City":city, "Factor_used":factor})
    hex_s7a = pd.concat(records, ignore_index=True)
    factors = pd.DataFrame(factor_table)

    def wmean(g):
        w = g["N_pix"].clip(lower=1).astype(float).values
        return pd.Series({
            "CenterX": np.average(g["CenterX"].values, weights=w),
            "CenterY": np.average(g["CenterY"].values, weights=w),
            "Mean": np.average(g["Mean"].astype(float).values, weights=w),
            "N_pix": g["N_pix"].sum(),
        })
    hex_c = hex_s7a.groupby(["City","Indicator","qg","rg"], observed=False).apply(wmean).reset_index()

    city_extent = {}
    for city in city_order:
        g = hex_c[(hex_c["City"]==city) & (hex_c["Indicator"]=="RawF1")]
        xmin, xmax = g["CenterX"].min(), g["CenterX"].max()
        ymin, ymax = g["CenterY"].min(), g["CenterY"].max()
        dx, dy = xmax-xmin, ymax-ymin
        city_extent[city] = (xmin-dx*0.035, xmax+dx*0.035, ymin-dy*0.035, ymax+dy*0.035)

    norms = {}
    for ind, _, _ in hex_vars:
        vals = hex_c.loc[hex_c["Indicator"]==ind, "Mean"].astype(float)
        if ind == "MismatchComposite":
            lim = float(np.nanquantile(np.abs(vals), 0.98))
            lim = max(lim, 1e-6)
            norms[ind] = TwoSlopeNorm(vcenter=0, vmin=-lim, vmax=lim)
        elif ind == "UnmetHighDemand":
            norms[ind] = BoundaryNorm([0,0.333,0.667,1.01], 3)
        else:
            vmin = float(np.nanquantile(vals, 0.02))
            vmax = float(np.nanquantile(vals, 0.98))
            if (not np.isfinite(vmax)) or (vmax <= vmin):
                vmin, vmax = float(vals.min()), float(vals.max())
            norms[ind] = Normalize(vmin=vmin, vmax=vmax)

    fig = plt.figure(figsize=(20.2, 22.4))
    gs = GridSpec(nrows=len(hex_vars)+2, ncols=9, figure=fig,
                  width_ratios=[0.25,1.08,1,1,1,1,1,1,0.24],
                  height_ratios=[0.42]+[1]*len(hex_vars)+[0.58],
                  wspace=0.045, hspace=0.05)

    fig.suptitle("Figure 1 | Repaired integrated honeycomb mechanism atlas",
                 fontsize=24, fontweight="bold", color=C_DARK, y=0.988)
    fig.text(0.5, 0.965, "Burden → Delivered benefit → Demand–benefit alignment → Residual / unmet gap",
             ha="center", va="top", fontsize=14.5, fontweight="bold", color=C_DARK)

    ax = fig.add_subplot(gs[0,0]); ax.axis("off")
    ax = fig.add_subplot(gs[0,1]); ax.axis("off")
    ax.text(0.5, 0.52, "Indicator", ha="center", va="center", fontsize=13, fontweight="bold", color=C_DARK)
    for j, city in enumerate(city_order):
        axh = fig.add_subplot(gs[0, j+2]); axh.axis("off")
        factor = int(factors.loc[factors["City"]==city, "Factor_used"].iloc[0])
        axh.text(0.5, 0.56, city, ha="center", va="center", fontsize=14.5, fontweight="bold", color=C_DARK)
        axh.text(0.5, 0.18, f"(factor {factor})", ha="center", va="center", fontsize=8.0, fontweight="bold", color="#516274")

    groups = [("Burden",0,3,CMAP(0.05)),
              ("Delivered benefit",3,7,CMAP(0.36)),
              ("Demand–benefit\nalignment",7,9,CMAP(0.60)),
              ("Residual /\nunmet gap",9,10,CMAP(0.92))]
    for gname, start, end, color in groups:
        axg = fig.add_subplot(gs[start+1:end+1, 0])
        axg.set_facecolor(color)
        axg.text(0.5, 0.5, gname, ha="center", va="center", rotation=90, fontsize=14.5, fontweight="bold", color="white")
        axg.set_xticks([]); axg.set_yticks([])
        for sp in axg.spines.values(): sp.set_visible(False)

    cat_cmap = ListedColormap([CMAP(0.08), CMAP(0.50), CMAP(0.92)])

    for i, (ind, label, desc) in enumerate(hex_vars):
        axl = fig.add_subplot(gs[i+1,1]); axl.axis("off")
        circle_color = CMAP(0.08 if i<3 else 0.36 if i<7 else 0.60 if i<9 else 0.92)
        axl.scatter([0.13], [0.70], s=390, color=circle_color, edgecolor="white", linewidth=1.0, transform=axl.transAxes, zorder=2)
        axl.text(0.13, 0.70, str(i+1), ha="center", va="center", fontsize=14, color="white", fontweight="bold", transform=axl.transAxes)
        axl.text(0.27, 0.74, label, ha="left", va="top", fontsize=12.0, fontweight="bold", color="#111111", transform=axl.transAxes)
        axl.text(0.27, 0.35, desc, ha="left", va="top", fontsize=8.4, fontweight="bold", color="#333333", transform=axl.transAxes, wrap=True)

        for j, city in enumerate(city_order):
            axm = fig.add_subplot(gs[i+1, j+2])
            base = hex_c[(hex_c["City"]==city) & (hex_c["Indicator"]=="RawF1")]
            sub  = hex_c[(hex_c["City"]==city) & (hex_c["Indicator"]==ind)]
            axm.scatter(base["CenterX"], base["CenterY"], marker="h", s=62, facecolors="#F6F8FA", edgecolors="#CDD8E1", linewidths=0.18, zorder=1)
            if ind == "UnmetHighDemand":
                vals_all = hex_c[hex_c["Indicator"]==ind]["Mean"]
                q1, q2 = np.nanquantile(vals_all, [0.20, 0.80])
                cats = np.where(sub["Mean"].values >= q2, 2, np.where(sub["Mean"].values <= q1, 0, 1))
                axm.scatter(sub["CenterX"], sub["CenterY"], c=cats, cmap=cat_cmap,
                            norm=BoundaryNorm([-0.5,0.5,1.5,2.5], 3),
                            marker="h", s=66, edgecolors="white", linewidths=0.14, zorder=2)
            else:
                axm.scatter(sub["CenterX"], sub["CenterY"], c=sub["Mean"], cmap=CMAP, norm=norms[ind],
                            marker="h", s=66, edgecolors="white", linewidths=0.14, zorder=2)
            xmin, xmax, ymin, ymax = city_extent[city]
            axm.set_xlim(xmin, xmax); axm.set_ylim(ymin, ymax)
            axm.set_aspect("equal", adjustable="box")
            axm.set_xticks([]); axm.set_yticks([])
            for sp in axm.spines.values():
                sp.set_visible(True); sp.set_color("#D3DDE6"); sp.set_linewidth(0.55)

        axcb = fig.add_subplot(gs[i+1,8]); axcb.axis("off")
        if ind == "UnmetHighDemand":
            for kk, (cc, lab) in enumerate(zip([CMAP(0.92), CMAP(0.50), CMAP(0.08)], ["High","Moderate","Low"])):
                y0 = 0.72 - kk*0.25
                axcb.add_patch(patches.Rectangle((0.12, y0), 0.32, 0.13, facecolor=cc, edgecolor="#333333", transform=axcb.transAxes))
                axcb.text(0.50, y0+0.065, lab, ha="left", va="center", fontsize=8, fontweight="bold", transform=axcb.transAxes)
        else:
            cax = inset_axes(axcb, width="34%%", height="72%%", loc="center", borderpad=0)
            sm = ScalarMappable(norm=norms[ind], cmap=CMAP)
            cb = fig.colorbar(sm, cax=cax, orientation="vertical")
            cb.outline.set_linewidth(0.6)
            cb.ax.tick_params(labelsize=7, length=2, width=0.6)
            if ind == "MismatchComposite":
                cb.ax.set_title("More +\n0\nMore −", fontsize=6.5, fontweight="bold", pad=2)
            else:
                cb.ax.set_title("High", fontsize=7, fontweight="bold", pad=2)
                cb.ax.text(0.5, -0.06, "Low", ha="center", va="top", fontsize=7, fontweight="bold", transform=cb.ax.transAxes)

    axleg = fig.add_subplot(gs[-1,:]); axleg.axis("off")
    axleg.add_patch(patches.FancyBboxPatch((0.02,0.05),0.96,0.86,boxstyle="round,pad=0.01,rounding_size=0.02",
                                           facecolor="#FAFCFE", edgecolor="#C7D4E0", linewidth=0.8, transform=axleg.transAxes))
    axleg.text(0.05, 0.30, "Adaptive coarsening: Shenzhen uses factor = 1 to preserve geometry; other cities retain factor = 2 where stable.", fontsize=8.7, transform=axleg.transAxes)

    fig.savefig(out_png, dpi=600, bbox_inches="tight")
    fig.savefig(out_pdf, dpi=600, bbox_inches="tight")
    plt.close(fig)

if __name__ == "__main__":
    build_figure1(
        hex_csv="hex_plotting_data_scale_3000m.csv",
        adaptive_csv="adaptive_coarsening_summary.csv",
        out_png="Figure1_final_manuscript_honeycomb.png",
        out_pdf="Figure1_final_manuscript_honeycomb.pdf",
    )
