# -*- coding: utf-8 -*-

import os
import re
import math
from pathlib import Path

import numpy as np
import pandas as pd
from tqdm import tqdm

import rasterio
from rasterio.transform import from_origin
from rasterio.features import rasterize

from pyproj import Transformer
from scipy.spatial import cKDTree
from scipy.ndimage import binary_dilation


# ===================== 0) 配置 =====================
IN_CSV = r"C:\Users\86133\Downloads\guangzhouout.csv"
SHP_DIR = r"E:\中国特大城市洪水\全部市图层"

TARGET_CITY = "广州"  # 只处理这个城市（会自动去掉“市”做匹配）

OUT_ROOT = r"E:\中国特大城市洪水\SV_Guangzhou_outputs_90m_IDW"
TMP_RAW_CSV = os.path.join(OUT_ROOT, "streetview_raw_guangzhou.csv")
FINAL_CSV   = os.path.join(OUT_ROOT, "streetview_final_guangzhou.csv")

# 90m 米制栅格
PIXEL_SIZE_M = 90.0
PAD_M = 0.0

CHUNKSIZE = 200_000

# IDW：mask + 覆盖缓冲 + 最大距离
COVER_BUFFER_M = 2000.0
MAX_DIST_M = 3000.0
IDW_K = 12
IDW_POWER = 2.0
IDW_QUERY_CHUNK = 200_000

# 防止 CRS/边界错误导致巨大栅格爆内存
MAX_CELLS = 60_000_000

# 最终要栅格化的变量
RASTER_VARS = [
    "GVI", "SVF", "BVI", "Micro_ISA", "Micro_PSA",
    "SCE", "SEI", "TAE", "CFI", "FOE",
    "RPP", "MSRI", "ECO"
]


# ===================== 1) 列名匹配（尾空格安全） =====================
def _norm(s: str) -> str:
    if s is None:
        return ""
    s = str(s).strip().lower().replace("，", ",")
    s = re.sub(r"\s+", " ", s)
    return s

def build_colmap(columns):
    return {_norm(c): c for c in columns}

def resolve_cols(colmap, candidates):
    found, missing = [], []
    keys = list(colmap.keys())
    for cand in candidates:
        nc = _norm(cand)
        if nc in colmap:
            found.append(colmap[nc])
            continue
        first = nc.split(",")[0].strip()
        if first in colmap:
            found.append(colmap[first])
            continue
        hits = [k for k in keys if (k == nc) or (nc in k and len(nc) >= 5)]
        if len(hits) == 1:
            found.append(colmap[hits[0]])
        else:
            missing.append(cand)
    return found, missing

def sum_cols(df, cols):
    if not cols:
        return pd.Series(0.0, index=df.index)
    cols2 = [c for c in cols if c in df.columns]
    if not cols2:
        return pd.Series(0.0, index=df.index)
    return df[cols2].sum(axis=1)

def safe_div(a, b, eps=1e-6):
    return a / (b + eps)


# ===================== 2) 解析 city / lon / lat =====================
FLOAT_RE = re.compile(r"-?\d+(?:\.\d+)?")
BAD_ANGLES = {0.0, 90.0, 180.0, 270.0}

def canon_city(name: str) -> str:
    name = str(name).strip()
    if name.endswith("市"):
        name = name[:-1]
    return name

def extract_city(s: str) -> str:
    """
    从 image/id 中提取城市：
    1) 支持 '广州/xxx.jpg' 或 '广州\\xxx.jpg'
    2) 支持文件名中直接包含“广州”或“广州市”
    3) 如果都没有，则返回空字符串
    """
    s = str(s).strip()

    if "/" in s:
        c = s.split("/")[0].strip()
        c = canon_city(c)
        if c:
            return c

    if "\\" in s:
        c = s.split("\\")[0].strip()
        c = canon_city(c)
        if c:
            return c

    if "广州市" in s:
        return "广州"
    if "广州" in s:
        return "广州"

    return ""

def extract_lon_lat(s: str):
    """
    更稳的经纬度解析，兼容：
    - 100001_113.381961_22.927742.jpg
    - 广州/100001_113.381961_22.927742.jpg
    - 各种路径字符串里出现经纬度

    规则：
    - 优先从所有数字中，从后往前找一对 lon/lat
    - lon [70,140]
    - lat [10,60]
    - 避免把 0/90/180/270 这种角度当成坐标
    """
    s = str(s)
    nums = FLOAT_RE.findall(s)
    if len(nums) < 2:
        return (np.nan, np.nan)

    vals = [float(x) for x in nums]

    # 从后往前找最像经纬度的一对
    for i in range(len(vals) - 2, -1, -1):
        a, b = vals[i], vals[i + 1]

        # lon, lat
        if 70 <= a <= 140 and 10 <= b <= 60:
            if (a in BAD_ANGLES) and (b in BAD_ANGLES):
                continue
            return (a, b)

        # lat, lon
        if 70 <= b <= 140 and 10 <= a <= 60:
            if (b in BAD_ANGLES) and (a in BAD_ANGLES):
                continue
            return (b, a)

    return (np.nan, np.nan)


# ===================== 3) 在线统计（Welford） =====================
class RunningStats:
    def __init__(self):
        self.n = 0
        self.mean = 0.0
        self.M2 = 0.0

    def update(self, x: np.ndarray):
        x = x.astype(np.float64, copy=False)
        for v in x:
            self.n += 1
            delta = v - self.mean
            self.mean += delta / self.n
            delta2 = v - self.mean
            self.M2 += delta * delta2

    def std(self):
        if self.n <= 0:
            return 0.0
        var = self.M2 / self.n
        return math.sqrt(var) if var > 0 else 0.0

def z_from_stats(series: pd.Series, mean: float, std: float, eps=1e-12):
    if std < eps:
        return (series - mean) * 0.0
    return (series - mean) / std


# ===================== 4) ADE150 类集合（按你原脚本口径） =====================
SKY = ["sky"]
VEG_ALL = ["tree", "palm, palm tree", "plant", "grass", "flower"]
WATER_ALL = ["water", "river", "sea", "lake", "pool", "fountain", "falls"]

IMPERV = ["road, route", "sidewalk, pavement", "path", "stairs", "stairway, staircase"]
PERV = ["earth, ground", "land, ground, soil", "sand", "field", "grass"]

V_HARD = ["building", "skyscraper", "house", "tower", "wall", "column, pillar", "bridge, span"]
BARRIER = ["wall", "fence"]

VEH_ALL = ["car", "bus", "truck", "van", "bicycle", "minibike, motorbike"]
STREET_ASSET = ["traffic light", "street lamp", "pole", "signboard, sign", "booth",
                "awning, sunshade, sunblind", "canopy"]

SIGNAGE = ["signboard, sign", "poster, posting, placard, notice, bill, card", "trade name", "bulletin board"]
OPENINGS = ["door", "window", "screen door, screen"]


# ===================== 5) 读取表头 -> usecols =====================
def prepare_usecols():
    header = pd.read_csv(IN_CSV, nrows=0, encoding="utf-8-sig")
    cols = list(header.columns)
    id_col = cols[0]  # 第一列按 image/id 处理
    colmap = build_colmap(cols)

    sets = {
        "Sky": SKY,
        "Veg": VEG_ALL,
        "Water": WATER_ALL,
        "Imperv": IMPERV,
        "Perv": PERV,
        "V_hard": V_HARD,
        "Barrier": BARRIER,
        "Veh_all": VEH_ALL,
        "StreetAsset": STREET_ASSET,
        "Signage": SIGNAGE,
        "Openings": OPENINGS,
    }

    resolved = {}
    for name, cand in sets.items():
        real_cols, _ = resolve_cols(colmap, cand)
        resolved[name] = real_cols

    needed = {id_col}
    for v in resolved.values():
        needed.update(v)

    needed_cols = [c for c in needed if c in set(cols)]
    return id_col, resolved, needed_cols


# ===================== 6) Pass1：只广州 raw + 统计 =====================
def pass1_raw_and_stats_only_city(id_col, resolved, needed_cols, target_city):
    z_targets = ["Micro_ISA","Micro_PSA","GVI","SVF","BVI","SCE","SEI","TAE","CFI","FOE"]
    stats = {k: RunningStats() for k in z_targets}

    first_write = True
    total_kept = 0
    scale_div = None  # 1 or 100

    reader = pd.read_csv(
        IN_CSV, usecols=needed_cols,
        chunksize=CHUNKSIZE,
        encoding="utf-8-sig", low_memory=False
    )
    pbar = tqdm(desc=f"Pass1 raw（仅{target_city}）", unit="rows")

    target_city = canon_city(target_city)

    for chunk in reader:
        pbar.update(len(chunk))

        # 解析 city/lon/lat
        city = chunk[id_col].map(extract_city).map(canon_city)
        lonlat = chunk[id_col].map(extract_lon_lat)
        lon = lonlat.map(lambda t: t[0]).astype(float)
        lat = lonlat.map(lambda t: t[1]).astype(float)

        # 坐标有效
        okxy = np.isfinite(lon.to_numpy()) & np.isfinite(lat.to_numpy())

        # 城市匹配逻辑：
        # 1) 若文件名里能识别出城市，则要求 == TARGET_CITY
        # 2) 若文件名里识别不出城市（例如 100001_113.381961_22.927742.jpg），
        #    但坐标有效，则默认这些记录属于当前 TARGET_CITY
        city_arr = city.fillna("").astype(str).to_numpy()
        okcity = (city_arr == "") | (city_arr == target_city)

        keep = okxy & okcity
        if keep.sum() == 0:
            continue

        sub = chunk.loc[keep].copy()

        # 对于空城市，直接补成 TARGET_CITY
        sub_city = city.loc[keep].reset_index(drop=True)
        sub_city = sub_city.replace("", target_city).fillna(target_city)

        lon = lon.loc[keep].reset_index(drop=True)
        lat = lat.loc[keep].reset_index(drop=True)

        # 数值列转 float
        num_cols = [c for c in sub.columns if c != id_col]
        if num_cols:
            sub[num_cols] = sub[num_cols].apply(pd.to_numeric, errors="coerce").fillna(0.0)

        # 0-100 归一（只在第一次有效数据块判断一次）
        if scale_div is None and num_cols:
            maxv = sub[num_cols].max().max()
            scale_div = 100.0 if maxv > 1.5 else 1.0
        if scale_div is None:
            scale_div = 1.0
        if scale_div != 1.0 and num_cols:
            sub[num_cols] = sub[num_cols] / scale_div

        # buckets
        Sky = sum_cols(sub, resolved["Sky"])
        Veg = sum_cols(sub, resolved["Veg"])
        Water = sum_cols(sub, resolved["Water"])
        Imperv = sum_cols(sub, resolved["Imperv"])
        Perv = sum_cols(sub, resolved["Perv"])
        Vhard = sum_cols(sub, resolved["V_hard"])
        Barrier = sum_cols(sub, resolved["Barrier"])
        Veh = sum_cols(sub, resolved["Veh_all"])
        StreetAsset = sum_cols(sub, resolved["StreetAsset"])
        Signage = sum_cols(sub, resolved["Signage"])
        Openings = sum_cols(sub, resolved["Openings"])

        eps = 1e-6
        out = pd.DataFrame({
            "image": sub[id_col].astype(str).values,
            "city": sub_city.values,
            "lon": lon.values,
            "lat": lat.values,

            "GVI": Veg,
            "SVF": Sky,
            "BVI": Water,
            "Micro_ISA": Imperv,
            "Micro_PSA": Perv,

            "SCE": safe_div(Vhard, Vhard + Sky, eps),
            "SEI": safe_div(Barrier, Barrier + Sky, eps),

            "TAE": Veh + StreetAsset,
            "CFI": Signage,
            "FOE": Openings,
        })

        for k in z_targets:
            stats[k].update(out[k].to_numpy())

        out.to_csv(
            TMP_RAW_CSV, index=False,
            mode="w" if first_write else "a",
            header=first_write, encoding="utf-8-sig"
        )
        first_write = False
        total_kept += len(out)

    pbar.close()
    means = {k: stats[k].mean for k in stats}
    stds  = {k: stats[k].std() for k in stats}
    return total_kept, means, stds


# ===================== 7) Pass2：复合指数（仅广州） =====================
def pass2_final_only_city(means, stds):
    first_write = True
    total_rows = 0
    reader = pd.read_csv(TMP_RAW_CSV, chunksize=CHUNKSIZE, encoding="utf-8-sig", low_memory=False)
    pbar = tqdm(desc="Pass2 复合指数（仅广州）", unit="rows")

    for chunk in reader:
        pbar.update(len(chunk))
        total_rows += len(chunk)

        for c in chunk.columns:
            if c not in ["image","city"]:
                chunk[c] = pd.to_numeric(chunk[c], errors="coerce")

        z = {}
        for k in means.keys():
            z[k] = z_from_stats(chunk[k], means[k], stds[k])

        chunk["RPP"]  = z["Micro_ISA"] + z["SCE"] + z["SEI"] - z["Micro_PSA"] - z["GVI"]
        chunk["MSRI"] = z["Micro_PSA"] + z["GVI"] + z["SVF"] - z["Micro_ISA"] - z["SEI"]
        chunk["ECO"]  = z["GVI"] + z["Micro_PSA"] + z["SVF"] + z["BVI"]

        chunk.to_csv(
            FINAL_CSV, index=False,
            mode="w" if first_write else "a",
            header=first_write, encoding="utf-8-sig"
        )
        first_write = False

    pbar.close()
    return total_rows


# ===================== 8) shp 批量索引与匹配 =====================
def index_shapefiles(shp_dir: str):
    shp_dir = Path(shp_dir)
    return [p for p in shp_dir.rglob("*.shp")]

def choose_shp_for_city(city: str, shp_paths):
    """
    根据文件名包含 city 或 city市 来匹配。
    若多个，按“更短文件名 + 含区域/边界等关键词”优先。
    """
    c0 = canon_city(city)
    c1 = c0 + "市"

    cand = []
    for p in shp_paths:
        name = p.stem
        if (c0 in name) or (c1 in name):
            score = 0.0
            if c0 in name:
                score += 2.0
            if c1 in name:
                score += 1.0
            if "区域" in name:
                score += 0.3
            if "边界" in name:
                score += 0.3
            if "行政" in name:
                score += 0.2
            score += max(0.0, 1.0 - len(name)/60.0)
            cand.append((score, len(name), str(p)))
    if not cand:
        return None
    cand.sort(key=lambda x: (-x[0], x[1]))
    return cand[0][2]


# ===================== 9) 读城市边界 -> EPSG:3857（含CRS缺失兜底） =====================
def read_city_geom_3857(shp_path: str):
    import geopandas as gpd
    gdf = gpd.read_file(shp_path)
    if gdf.crs is None:
        # 常见：4490(CGCS2000) 或 4326，这里默认先按 4490
        gdf = gdf.set_crs("EPSG:4490", allow_override=True)
    gdf = gdf.to_crs("EPSG:3857")
    return gdf.unary_union


# ===================== 10) 写点图层（GeoPackage） =====================
def write_points_gpkg(city_name, df_city, out_gpkg):
    import fiona
    from shapely.geometry import Point, mapping

    out_gpkg = str(out_gpkg)
    if os.path.exists(out_gpkg):
        os.remove(out_gpkg)

    props = {"image": "str:254", "city": "str:64", "lon": "float", "lat": "float"}
    for col in RASTER_VARS:
        if col in df_city.columns:
            props[col] = "float"

    schema = {"geometry": "Point", "properties": props}

    with fiona.open(
        out_gpkg, mode="w", driver="GPKG",
        crs="EPSG:4326", layer="points", schema=schema
    ) as dst:
        for _, r in tqdm(df_city.iterrows(), total=len(df_city), desc=f"写点图层 {city_name}", unit="pt"):
            if not (np.isfinite(r["lon"]) and np.isfinite(r["lat"])):
                continue
            geom = mapping(Point(float(r["lon"]), float(r["lat"])))
            prop = {
                "image": str(r["image"]),
                "city": str(r["city"]),
                "lon": float(r["lon"]),
                "lat": float(r["lat"])
            }
            for col in RASTER_VARS:
                if col in df_city.columns:
                    v = r[col]
                    prop[col] = None if pd.isna(v) else float(v)
            dst.write({"geometry": geom, "properties": prop})


# ===================== 11) IDW 填充（带 cover buffer + max dist） =====================
def idw_fill(raw_arr, idw_mask, transform, k=12, power=2.0, max_dist=3000.0, query_chunk=200_000):
    inside = (idw_mask == 1)

    vr, vc = np.where(inside & np.isfinite(raw_arr))
    if len(vr) == 0:
        return raw_arr

    x0 = transform.c
    y0 = transform.f
    px = transform.a
    py = transform.e  # negative

    xs = x0 + (vc + 0.5) * px
    ys = y0 + (vr + 0.5) * py
    pts = np.column_stack([xs, ys]).astype(np.float64)
    vals = raw_arr[vr, vc].astype(np.float64)

    tree = cKDTree(pts)

    tr, tc = np.where(inside & (~np.isfinite(raw_arr)))
    if len(tr) == 0:
        return raw_arr

    filled = raw_arr.copy().astype(np.float32)

    for start in tqdm(range(0, len(tr), query_chunk), desc="IDW 填充", unit="cells", leave=False):
        rr = tr[start:start + query_chunk]
        cc = tc[start:start + query_chunk]

        tx = x0 + (cc + 0.5) * px
        ty = y0 + (rr + 0.5) * py
        tpts = np.column_stack([tx, ty]).astype(np.float64)

        try:
            d, idx = tree.query(tpts, k=min(k, len(vals)), workers=-1)
        except TypeError:
            d, idx = tree.query(tpts, k=min(k, len(vals)))

        if d.ndim == 1:
            d = d[:, None]
            idx = idx[:, None]

        too_far = d[:, 0] > max_dist
        zero = (d == 0)

        outv = np.full(d.shape[0], np.nan, dtype=np.float64)

        hit0 = zero.any(axis=1)
        if hit0.any():
            row_idx = np.where(hit0)[0]
            nearest_zero_col = zero[hit0].argmax(axis=1)
            outv[row_idx] = vals[idx[hit0, nearest_zero_col]]

        miss = ~hit0
        if miss.any():
            dm = d[miss]
            im = idx[miss]
            w = 1.0 / (dm ** power + 1e-12)
            outv[miss] = (w * vals[im]).sum(axis=1) / w.sum(axis=1)

        outv[too_far] = np.nan
        filled[rr, cc] = outv.astype(np.float32)

    return filled

def write_tif(path, arr, profile):
    nodata = profile.get("nodata", -9999.0)
    out = np.where(np.isfinite(arr), arr.astype(np.float32), nodata).astype(np.float32)
    with rasterio.open(path, "w", **profile) as dst:
        dst.write(out, 1)


# ===================== 12) 描述性统计 =====================
def describe_series(x: pd.Series):
    x = pd.to_numeric(x, errors="coerce")
    n = x.notna().sum()
    if n == 0:
        return {
            "n": 0, "missing_rate": 1.0, "mean": np.nan, "std": np.nan, "min": np.nan,
            "q25": np.nan, "median": np.nan, "q75": np.nan, "max": np.nan
        }
    return {
        "n": int(n),
        "missing_rate": float(1 - n / len(x)),
        "mean": float(x.mean()),
        "std": float(x.std(ddof=0)),
        "min": float(x.min()),
        "q25": float(x.quantile(0.25)),
        "median": float(x.quantile(0.50)),
        "q75": float(x.quantile(0.75)),
        "max": float(x.max())
    }

def describe_array(arr: np.ndarray):
    v = arr[np.isfinite(arr)]
    n = v.size
    if n == 0:
        return {
            "n_cells": 0, "missing_rate": 1.0, "mean": np.nan, "std": np.nan, "min": np.nan,
            "q25": np.nan, "median": np.nan, "q75": np.nan, "max": np.nan
        }
    return {
        "n_cells": int(n),
        "missing_rate": float(1 - n / arr.size),
        "mean": float(np.mean(v)),
        "std": float(np.std(v)),
        "min": float(np.min(v)),
        "q25": float(np.quantile(v, 0.25)),
        "median": float(np.quantile(v, 0.50)),
        "q75": float(np.quantile(v, 0.75)),
        "max": float(np.max(v))
    }

def warn_if_all_zero(city: str, var: str, level: str, arr: np.ndarray):
    v = arr[np.isfinite(arr)]
    if v.size == 0:
        return
    if np.nanmin(v) == 0.0 and np.nanmax(v) == 0.0:
        print(f"[警告] {city}-{var}：{level} 在 mask 内全部为 0（检查列是否匹配/该类是否全为0/解析是否有误）")


# ===================== 13) 仅广州：points + raw栅格 + IDW 栅格 + 统计 =====================
def process_one_city(city: str, final_csv: str, shp_path: str, out_city_dir: str):
    out_city_dir = Path(out_city_dir)
    raw_dir = out_city_dir / "01_raw_rasters"
    idw_dir = out_city_dir / "02_idw_rasters"
    raw_dir.mkdir(parents=True, exist_ok=True)
    idw_dir.mkdir(parents=True, exist_ok=True)

    df = pd.read_csv(final_csv, encoding="utf-8-sig", low_memory=False)
    df["city"] = df["city"].map(canon_city)
    df = df[df["city"] == canon_city(city)].copy()

    df["lon"] = pd.to_numeric(df["lon"], errors="coerce")
    df["lat"] = pd.to_numeric(df["lat"], errors="coerce")
    df = df.dropna(subset=["lon", "lat"])
    if len(df) == 0:
        print(f"[终止] {city}：FINAL_CSV 中无有效坐标点")
        return

    # points.gpkg
    points_gpkg = out_city_dir / "points.gpkg"
    cols_keep = ["image", "city", "lon", "lat"] + [v for v in RASTER_VARS if v in df.columns]
    write_points_gpkg(city, df[cols_keep].copy(), points_gpkg)

    # city polygon -> 3857
    geom_3857 = read_city_geom_3857(shp_path)
    minx, miny, maxx, maxy = geom_3857.bounds
    minx -= PAD_M
    miny -= PAD_M
    maxx += PAD_M
    maxy += PAD_M

    def align_floor(v, s):
        return math.floor(v / s) * s

    def align_ceil(v, s):
        return math.ceil(v / s) * s

    minx = align_floor(minx, PIXEL_SIZE_M)
    miny = align_floor(miny, PIXEL_SIZE_M)
    maxx = align_ceil(maxx, PIXEL_SIZE_M)
    maxy = align_ceil(maxy, PIXEL_SIZE_M)

    width  = int(round((maxx - minx) / PIXEL_SIZE_M))
    height = int(round((maxy - miny) / PIXEL_SIZE_M))
    cells = width * height
    if cells <= 0 or cells > MAX_CELLS:
        raise RuntimeError(f"{city}：栅格尺寸异常 {width}x{height}={cells}（检查 shp CRS/范围）")

    transform = from_origin(minx, maxy, PIXEL_SIZE_M, PIXEL_SIZE_M)

    mask = rasterize([(geom_3857, 1)], out_shape=(height, width), transform=transform, fill=0, dtype=np.uint8)
    mask_arr = mask.astype(np.float32)
    mask_arr[mask == 0] = np.nan

    profile = {
        "driver": "GTiff",
        "height": height,
        "width": width,
        "count": 1,
        "dtype": "float32",
        "crs": "EPSG:3857",
        "transform": transform,
        "nodata": -9999.0,
        "compress": "DEFLATE",
        "tiled": True,
        "blockxsize": 256,
        "blockysize": 256,
    }

    # 输出 mask.tif
    write_tif(str(raw_dir / "mask.tif"), mask_arr, profile)

    # 点投影到3857 -> row/col
    to3857 = Transformer.from_crs("EPSG:4326", "EPSG:3857", always_xy=True)
    xs, ys = to3857.transform(df["lon"].to_numpy(dtype=np.float64), df["lat"].to_numpy(dtype=np.float64))

    col = np.floor((xs - minx) / PIXEL_SIZE_M).astype(np.int32)
    row = np.floor((maxy - ys) / PIXEL_SIZE_M).astype(np.int32)
    valid = (row >= 0) & (row < height) & (col >= 0) & (col < width)
    if valid.sum() == 0:
        raise RuntimeError(f"{city}：点全部落在栅格外（检查 shp/坐标）")

    rowv = row[valid]
    colv = col[valid]
    flat_idx = (rowv.astype(np.int64) * width + colv.astype(np.int64))

    # count.tif
    cnt_flat = np.bincount(flat_idx, minlength=height * width).astype(np.float32)
    cnt_arr = cnt_flat.reshape((height, width))
    cnt_arr[mask == 0] = np.nan
    write_tif(str(raw_dir / "count.tif"), cnt_arr, profile)

    # IDW mask：mask & 覆盖缓冲
    cov = np.isfinite(cnt_arr) & (cnt_arr >= 1)
    buffer_cells = max(int(round(COVER_BUFFER_M / PIXEL_SIZE_M)), 0)
    cov_buf = binary_dilation(cov, iterations=buffer_cells) if buffer_cells > 0 else cov
    idw_mask = ((mask == 1) & cov_buf).astype(np.uint8)

    # stats: points / raw / idw
    stats_points, stats_raw, stats_idw = [], [], []

    for v in RASTER_VARS:
        if v not in df.columns:
            continue
        d = describe_series(df[v])
        d.update({"city": city, "var": v, "level": "points"})
        stats_points.append(d)

    for v in RASTER_VARS:
        if v not in df.columns:
            continue

        vals = pd.to_numeric(df[v], errors="coerce").to_numpy(dtype=np.float64)[valid]
        ok = np.isfinite(vals)
        if ok.sum() == 0:
            continue

        idx_ok = flat_idx[ok]
        vals_ok = vals[ok]

        sum_flat = np.bincount(idx_ok, weights=vals_ok, minlength=height * width).astype(np.float64)
        cnt2_flat = np.bincount(idx_ok, minlength=height * width).astype(np.float64)

        raw_flat = np.full(height * width, np.nan, dtype=np.float64)
        has = cnt2_flat > 0
        raw_flat[has] = sum_flat[has] / cnt2_flat[has]
        raw_arr = raw_flat.reshape((height, width)).astype(np.float32)
        raw_arr[mask == 0] = np.nan

        write_tif(str(raw_dir / f"{v}.tif"), raw_arr, profile)
        warn_if_all_zero(city, v, "raw_raster", raw_arr)

        d_raw = describe_array(raw_arr)
        d_raw.update({"city": city, "var": v, "level": "raw_raster"})
        stats_raw.append(d_raw)

        idw_arr = idw_fill(raw_arr, idw_mask, transform, IDW_K, IDW_POWER, MAX_DIST_M, IDW_QUERY_CHUNK)
        idw_arr[mask == 0] = np.nan
        write_tif(str(idw_dir / f"{v}.tif"), idw_arr, profile)
        warn_if_all_zero(city, v, "idw_raster", idw_arr)

        d_idw = describe_array(idw_arr)
        d_idw.update({"city": city, "var": v, "level": "idw_raster"})
        stats_idw.append(d_idw)

        print(f"[{city}-{v}] raw_cells={d_raw.get('n_cells', 0)} idw_cells={d_idw.get('n_cells', 0)}")

    stats_points_df = pd.DataFrame(stats_points)
    stats_raw_df = pd.DataFrame(stats_raw)
    stats_idw_df = pd.DataFrame(stats_idw)

    out_xlsx = str(out_city_dir / "descriptive_stats.xlsx")
    with pd.ExcelWriter(out_xlsx, engine="openpyxl") as writer:
        stats_points_df.to_excel(writer, sheet_name="points_stats", index=False)
        stats_raw_df.to_excel(writer, sheet_name="raw_raster_stats", index=False)
        stats_idw_df.to_excel(writer, sheet_name="idw_raster_stats", index=False)

    print(f"\n✅ {city} 完成！")
    print(f"输出目录：{out_city_dir}")
    print(f"统计表：{out_xlsx}")


# ===================== 14) 主流程（仅广州） =====================
def main():
    Path(OUT_ROOT).mkdir(parents=True, exist_ok=True)

    # (A) 只广州：计算 raw + z 统计
    id_col, resolved, needed_cols = prepare_usecols()
    kept, means, stds = pass1_raw_and_stats_only_city(id_col, resolved, needed_cols, TARGET_CITY)
    if kept == 0:
        raise RuntimeError(
            f"未找到任何可用记录。当前已支持：\n"
            f"1) 文件名中包含 '广州/广州市'\n"
            f"2) 文件名直接为 '100001_经度_纬度.jpg' 这种格式\n"
            f"请检查第一列是否确实包含可解析经纬度。"
        )

    print(f"\nPass1 完成：{TARGET_CITY} 有效记录数={kept}")
    print(f"raw 输出：{TMP_RAW_CSV}")

    # (B) 只广州：复合指数
    total = pass2_final_only_city(means, stds)
    print(f"Pass2 完成：final 行数={total}")
    print(f"final 输出：{FINAL_CSV}")

    # (C) 找广州 shp
    shp_paths = index_shapefiles(SHP_DIR)
    shp = choose_shp_for_city(TARGET_CITY, shp_paths)
    if shp is None:
        raise RuntimeError(f"在 {SHP_DIR} 中找不到匹配 {TARGET_CITY} 的 shp（文件名需包含 ‘广州’ 或 ‘广州市’）。")

    print(f"\n匹配到 shp：{shp}")

    # (D) 栅格化 + IDW + 统计
    out_city_dir = Path(OUT_ROOT) / canon_city(TARGET_CITY)
    process_one_city(canon_city(TARGET_CITY), FINAL_CSV, shp, out_city_dir)


if __name__ == "__main__":
    main()